clc

lb     =[0.1 0.1 0.1];
ub     =[1 1 1];
options = optimoptions('gamultiobj','MaxGenerations',300,'PlotFcn',{@gaplotpareto,@gaplotspread,@gaplotscorediversity});
[x,fval,exitflag,output] = gamultiobj(@NETWORK3_GA,3,[],[],[],[],lb,ub,[],options)

x
fval
exitflag
output



