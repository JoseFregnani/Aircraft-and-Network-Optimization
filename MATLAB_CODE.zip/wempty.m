function wefrac=wempty(arw,sw,MMO,W2lb,T0,sweep14)
% Empty-to-MTOW ratio calculation
% Reference: Raymer, Aircraft Design, a Conceptual Approach
% INPUT:
% arw = wing aspect ratio
% sw  = wing area [ft2]
% MMO = Maximum operating Mach number;
% W2lb = Maximum Takeoff weight (lb)
% T0   = Maximum takeoff thrust (all engines) [lbf]
%

a=0.32;
b=0.66;
% Raymer
% C1=-0.13;
% C2=0.30;
% C3=0.06;
% C4=-0.05;
% C5=0.05;
%
% Bento
C0=-0.2661;C1= -0.1870; C2= 0.6000; C3=0.0100;  C4= -0.0010; C5=0.0010;

auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
