function [ACFT]=LOADDATA2();

fid = fopen('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\FIXED_NETWORK\parameters.dat');
    MTOW           = str2num(fgetl(fid));ACFT.MTOW=MTOW;
    MLW            = str2num(fgetl(fid));ACFT.MLW=MLW;
    MZFW           = str2num(fgetl(fid));ACFT.MZFW=MLW*0.98;
    OEW            = str2num(fgetl(fid));ACFT.OEW=OEW;
    MAXFUEL        = str2num(fgetl(fid));ACFT.MAXFUEL=MAXFUEL;
    wS             = str2num(fgetl(fid));ACFT.wS=wS;
    wSft2          = str2num(fgetl(fid));ACFT.wSft2=wSft2;
    wAR            = str2num(fgetl(fid));ACFT.wAR=wAR;
    wTR            = str2num(fgetl(fid));ACFT.wTR=wTR;
    wSweep14       = str2num(fgetl(fid));ACFT.wSweep14=wSweep14;
    wTwist         = str2num(fgetl(fid));ACFT.wTwist=wTwist;
    CLMAX          = str2num(fgetl(fid));ACFT.CLMAX=CLMAX;
    CLMAX_TO       =CLMAX+0.8;ACFT.CLMAX_TO=CLMAX_TO;
    CLMAX_LD       =CLMAX+0.6;ACFT.CLMAX_LD=CLMAX_LD;    
    PWing          = str2num(fgetl(fid));ACFT.PWing=PWing;
    VTarea         = str2num(fgetl(fid));ACFT.VTarea=VTarea;
    VTAR           = str2num(fgetl(fid));ACFT.VTAR=VTAR;
    VTTR           = str2num(fgetl(fid));ACFT.VTTR=VTTR;
    VTSweep        = str2num(fgetl(fid));ACFT.VTSweep=VTSweep;
    HTarea         = str2num(fgetl(fid));ACFT.HTarea=HTarea;
    HTAR           = str2num(fgetl(fid));ACFT.HTAR=HTAR;
    HTTR           = str2num(fgetl(fid));ACFT.HTTR=HTTR;
    PHT            = str2num(fgetl(fid));ACFT.PHT=PHT;
    NPax           = str2num(fgetl(fid));ACFT.NPax=NPax;
    NCorr          = str2num(fgetl(fid));ACFT.NCorr=NCorr;
    NSeat          = str2num(fgetl(fid));ACFT.NSeat=NSeat;
    ncrew          = str2num(fgetl(fid));ACFT.ncrew=ncrew;
    AisleWidth     = str2num(fgetl(fid));ACFT.AisleWidth=AisleWidth;
    CabHeightm     = str2num(fgetl(fid));ACFT.CabHeightm=CabHeightm;
    Kink_semispan  = str2num(fgetl(fid));ACFT.Kink_semispan=Kink_semispan;
    SEATwid        = str2num(fgetl(fid));ACFT.SEATwid=SEATwid;
    widthreiratio  = str2num(fgetl(fid));ACFT.widthreiratio=widthreiratio;
    inc_root       = str2num(fgetl(fid));ACFT.inc_root=inc_root;
    inc_kink       = str2num(fgetl(fid));ACFT.inc_kink=inc_kink;
    inc_tip        = str2num(fgetl(fid));ACFT.inc_tip=inc_tip;    
    MMO            = str2num(fgetl(fid));ACFT.MMO=MMO;
    VMO            = str2num(fgetl(fid));ACFT.VMO=VMO;
    PEng           = str2num(fgetl(fid));ACFT.PEng=PEng; 
    MAXRATE        = str2num(fgetl(fid));ACFT.MAXRATE=MAXRATE;
    n              = str2num(fgetl(fid));ACFT.n=n;   
    nedebasa       = str2num(fgetl(fid));ACFT.nedebasa=nedebasa; 
    ebypass        = str2num(fgetl(fid));ACFT.ebypass=ebypass; 
    ediam          = str2num(fgetl(fid));ACFT.ediam=ediam;  
    efanpr         = str2num(fgetl(fid));ACFT.efanpr=efanpr;   
    eopr           = str2num(fgetl(fid));ACFT.eopr=eopr; 
    eTIT           = str2num(fgetl(fid));ACFT.eTIT=eTIT; 
    wTCmed         = str2num(fgetl(fid));ACFT.wTCmed=wTCmed;
    fus_width      = str2num(fgetl(fid));ACFT.fus_width=fus_width;
    fus_height     = str2num(fgetl(fid));ACFT.fus_height=fus_height;
    FusDiam        = str2num(fgetl(fid));ACFT.FusDiam=FusDiam;
    Airp_SWET      = str2num(fgetl(fid));ACFT.Airp_SWET=Airp_SWET;
    wingSwet       = str2num(fgetl(fid));ACFT.wingSwet=wingSwet;
    lf             = str2num(fgetl(fid));ACFT.lf=lf;
    lco            = str2num(fgetl(fid));ACFT.lco=lco;
    wMAC           = str2num(fgetl(fid));ACFT.wMAC=wMAC;
    wSweepLE       = str2num(fgetl(fid));ACFT.wSweepLE=wSweepLE;
    Ccentro        = str2num(fgetl(fid));ACFT.Ccentro=Ccentro;
    Craiz          = str2num(fgetl(fid));ACFT.Craiz=Craiz;
    Cquebra        = str2num(fgetl(fid));ACFT.Cquebra=Cquebra;
    Cponta         = str2num(fgetl(fid));ACFT.Cponta=Cponta;    
    T0             = str2num(fgetl(fid));ACFT.T0=T0;
    swet2          = str2num(fgetl(fid));ACFT.swet2=swet2;
    container_type = fgetl(fid);ACFT.container_type=container_type;
fclose(fid);

% OPS DATA
ACFT.ceiling=41000;
ACFT.Flap_def_take=5;
ACFT.Flap_def_land=30;
ACFT.longtras=0.75;
RANGE=1600;
ACFT.RANGE=RANGE;
  
% 2D Airfoils parameters
r0      =[0.0153 0.0150 0.0150];ACFT.r0=r0;
t_c     =[0.1228 0.1055 0.0982];ACFT.t_c=t_c;
phi     =[-0.0799 -0.1025 -0.1553];ACFT.phi=phi;
X_tcmax =[0.3738 0.3585 0.3590];ACFT.X_tcmax=X_tcmax;
theta   =[0.0787 -0.0295 0.1000];ACFT.theta=theta;
epsilon =[-0.0549 -0.2101 -0.0258];ACFT.epsilon=epsilon;
Ycmax   =[-4.0000e-04 0.0185 0.0104];ACFT.Ycmax=Ycmax;
YCtcmax =[-6.0000e-04 0.0028 0.0109];ACFT.YCtcmax=YCtcmax;
X_Ycmax =[0.6188 0.7870 0.5567];ACFT.X_Ycmax=X_Ycmax;
wTCmed  =0.1100; ACFT.wTCmed=wTCmed; 

% initialize vector with airfoils coordinates
xutip   =zeros(1,51);ACFT.xutip=xutip;
yutip   =zeros(1,51);ACFT.yutip=yutip;
xltip   =zeros(1,51);ACFT.xltip=xltip;
yltip   =zeros(1,51);ACFT.yltip=yltip;
xukink  =zeros(1,51);ACFT.xukink=xukink;
yukink  =zeros(1,51);ACFT.yukink=yukink;
xlkink  =zeros(1,51);ACFT.xlkink=xlkink;
ylkink  =zeros(1,51);ACFT.ylkink=ylkink;
xuroot  =zeros(1,51);ACFT.xuroot=xuroot;
yuroot  =zeros(1,51);ACFT.yuroot=yuroot;
xlroot  =zeros(1,51);ACFT.xlroot=xlroot;
ylroot  =zeros(1,51);ACFT.ylroot=ylroot;
%




