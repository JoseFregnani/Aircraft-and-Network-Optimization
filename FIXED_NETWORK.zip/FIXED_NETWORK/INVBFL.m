function GW=INVBFL(A,TOFL,ISADEV,elev)

MAXRATE=A.MAXRATE;
MTOW=A.MTOW;
wS  =A.wS;
BPR =A.ebypass;
CLMAX_TO=A.CLMAX_TO;
TOW=MTOW;

flag=0;
while flag==0
  FL=BFL(TOW,wS,MAXRATE,BPR,ISADEV,elev,CLMAX_TO);
  if FL>TOFL
     TOW=TOW-10;
  else
     flag=1;
  end
end
GW=TOW;