
function [Wf,T,DOC,CRZMACH,PAX,RMK,S] = Mission4_FIXED(ACFT,ORIGALT,DESTALT,ALTELEV,HDG,HDG_ALT,DISTTOT,ALTDIST,ASDA,LDA,ALT_LDA,DEP_TREF,ARR_TREF,ALT_TREF,ISADEV,PAYLOAD_INIT,TIT,TOT,printflag,TO_ALLOWANCE,ARR_ALLOWANCE)

% Constants
N2lbf   = 0.2248;
ft2m    = 0.3048;
rad     = pi/180;
cfe     = 0.0030;  
kg2lb   = 2.2046;
m2feet  = 3.28083;
g       = 9.80665;
Gal2l   = 3.7852;
tol     = 100;
RMK='';

% AIRCRAFT DATA
OEW=ACFT.OEW;
MSTOW=ACFT.MTOW;
MSLW=ACFT.MLW;
MZFW=ACFT.MZFW;
MAXFUEL=ACFT.MAXFUEL;
MMO=ACFT.MMO; 
VMO=ACFT.VMO; 
%
wS=ACFT.wS;
wSft2=ACFT.wSft2;
wAR=ACFT.wAR;
wTR=ACFT.wTR;
wSweep14=ACFT.wSweep14;
wTwist=ACFT.wTwist;
CLMAX=ACFT.CLMAX;
PWing=ACFT.PWing;
Kink_semispan=ACFT.Kink_semispan;
inc_root=ACFT.inc_root; 
inc_kink=ACFT.inc_kink; 
inc_tip=ACFT.inc_tip; 
wMAC=ACFT.wMAC;
wSweepLE=ACFT.wSweepLE;
%
VTarea=ACFT.VTarea;
VTAR=ACFT.VTAR;
VTTR=ACFT.VTTR;
VTSweep=ACFT.VTSweep;
%
HTarea=ACFT.HTarea;
HTAR=ACFT.HTAR;
HTTR=ACFT.HTTR;
PHT=ACFT.PHT;
%
container_type=ACFT.container_type;
NPax=ACFT.NPax;
NCorr=ACFT.NCorr;
NSeat=ACFT.NSeat;
ncrew=ACFT.ncrew;
AisleWidth=ACFT.AisleWidth;
CabHeightm=ACFT.CabHeightm;    
SEATwid=ACFT.SEATwid;  
fus_width=ACFT.fus_width;
fus_height=ACFT.fus_height;
FusDiam=ACFT.FusDiam;
%
PEng=ACFT.PEng; 
MAXRATE=ACFT.MAXRATE;
T0=ACFT.T0;
n=ACFT.n;  
nedebasa=ACFT.nedebasa; 
ebypass=ACFT.ebypass;
ediam=ACFT.ediam;
efanpr=ACFT.efanpr;
eopr=ACFT.eopr;
eTIT=ACFT.eTIT;
%
r0=ACFT.r0;
t_c=ACFT.t_c;
phi=ACFT.phi;
X_tcmax=ACFT.X_tcmax;
theta=ACFT.theta;
epsilon=ACFT.epsilon;
Ycmax=ACFT.Ycmax;
YCtcmax=ACFT.YCtcmax;
X_Ycmax=ACFT.X_Ycmax;
wTCmed=ACFT.wTCmed;
%
Airp_SWET=ACFT.Airp_SWET;
wingSwet=ACFT.wingSwet;
lf=ACFT.lf;
lco=ACFT.lco;
%
Ccentro=ACFT.Ccentro;
Craiz=ACFT.Craiz;
Cquebra=ACFT.Cquebra;
Cponta=ACFT.Cponta;
xutip=ACFT.xutip;
yutip=ACFT.yutip;
xltip=ACFT.xltip;
yltip=ACFT.yltip;
xukink=ACFT.xukink;
yukink=ACFT.yukink;
xlkink=ACFT.xlkink;
ylkink=ACFT.ylkink;
xuroot=ACFT.xuroot;
yuroot=ACFT.yuroot;
xlroot=ACFT.xlroot;
ylroot=ACFT.ylroot;
swet2=ACFT.Airp_SWET;

% LOAD NEURAL NETWORK
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');

% OPERATIONS AND CERTIFICATION PARAMETERS
BUFFMARGIN    =1.3;  % BUFFET MARGIN [g]
RCMIN         =300;  % RESIDUAL  ROC [min]
ceiling       =ACFT.ceiling;%[ft]

% NETWORK AND MISSION PARAMETERS
HOLDTIME          =     30;% HOLDING  TIME [min]
MINCRZTIME        =      1;% MINIMUM CRUISE TIME [min]
fueldens          =   0.81;% FUEL DENSITY [kg/l]
Fuel_price_perkg =    0.50;% FUEL PRICE in EUR/kg (source:https://www.indexmundi.com/commodities/?commodity=jet-fuel&months=120&currency=eur)
Fuel_price        =   (Fuel_price_perkg/fueldens)*Gal2l;
TBO               =   2500;% Time Between Overhaul [hours]
TAXIFF_ref        =      5;% REF TAXI FUEL FLOW FOR MTOW=22000kg [kg/min]
CONTPCT           =   0.05;% CONTINGENCY FUEL PCT (JAR 121)
MINCRZTIME        =      3;% MINIMUM CRUISE TIME [min]
PAXWT             =    110;% PASSENGER WEIGHT [kg]
GA_allowance      =    300;% GO-AROUND ALLOWANCE
USD2EUR           =   0.90;% DOLLAR TO EURO CONVERSION

% INITIAL FLIGHT SPEED SCHEDULE
CLBCAS=280;
CLBMACH=0.78;
CRZMACH=0.78;
CRZCAS=310;
DESCAS=310;
DESMACH=0.78;
CLBCAS_ALT=280;
CLBMACH_ALT=0.78;
CRZMACH_ALT=0.78;
CRZCAS_ALT=310;
DESCAS_ALT=310;
DESMACH_ALT=0.78;

% CALCULATE CREW SALARY
[Sal_Captain,Sal_FO,Sal_FA]=CREWSALARY(MSTOW);

% CALCULATE RTOW and RLW limits
[RTOW,RLW]=PERFOLIM(ACFT,NNind,NNwav,NNcd0,NNCL,ASDA,LDA,ORIGALT,DESTALT,DEP_TREF,ARR_TREF);
%
if RTOW<MSTOW
  RMK=strcat(RMK,'T '); 
end    
if RLW<MSLW
  RMK=strcat(RMK,'L '); 
end
    
PAYLOAD=PAYLOAD_INIT;
MLW=RLW;
MTOW=RTOW;
ZFW=OEW+PAYLOAD;
TOW=MTOW;
TOF=0;
%
f=0;

while f==0 
         
   % MAX & OPT ALTITUDE CALCULATION
   initalt = ORIGALT;
   hf      = ceiling;
   step    = 500;
   out=0;
    
    while out==0;
        
        %% CALCULATE MAXALT
            [HMAX,RCRES]=MAXALT(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
            inc_root,inc_kink,inc_tip,Kink_semispan,...
            r0,t_c,phi,X_tcmax,theta,epsilon,...
            Ycmax,YCtcmax,X_Ycmax,...
            n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,step,hf,...
            CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);

        %% CALCULATE OPTALT
            [HOPT,SRMAX]=optalt(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
            inc_root,inc_kink,inc_tip,Kink_semispan,...
            r0,t_c,phi,X_tcmax,theta,epsilon,...
            Ycmax,YCtcmax,X_Ycmax,...
            n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,...
            CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

        %% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK
            g_sub=4/1000;
            g_des=3/1000;
            K1=g_sub+g_des;
            Dmin=10*CRZMACH*MINCRZTIME;
            K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
            HMAX2=K2/K1;
            %
            if HMAX2>ceiling
               HMAX2=ceiling;
            end
            if HMAX>HMAX2
               HMAX=HMAX2;
            end
            if HOPT<HMAX
               finalalt=HOPT;
            else
               finalalt=HMAX;
            end   

            % NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 
            finalalt= 1000*(fix (finalalt/1000));
            FL=finalalt/100;
            ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
            EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
            if and(HDG>0,HDG<=180)
                C=ismember([FL],[ODDFL]);
                if C==0
                    finalalt=finalalt+1000;
                    if finalalt>=HMAX
                        finalalt=finalalt-2000;
                    end    
                end
            elseif and(HDG>180,HDG<=360)
                C=ismember([FL],[EVENFL]);
                if C==0
                    finalalt=finalalt+1000;
                    if finalalt>=HMAX
                        finalalt=finalalt-2000;
                    end 
                end
            end    

        % INIT CLIMB FUEL ESTIMATION 
        maneted=0.95;
        initalt=ORIGALT+1500;
        [~,~,fclb0,~]=CALC_CLB_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
            n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
            inc_root,inc_kink,inc_tip,Kink_semispan,...
            r0,t_c,phi,X_tcmax,theta,epsilon,...
            Ycmax,YCtcmax,X_Ycmax,...
            TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

        % CALCULATE BEST CRUISE MACH
        WTOC=TOW-fclb0;    
        CRZMACH=BESTCRZSPEED(ACFT,WTOC,finalalt,ISADEV,NNind,NNwav,NNcd0,NNCL,VMO,MMO);
        CLBMACH=CRZMACH;
        DESMACH=CRZMACH;

        % RECALCULATE CLIMB WITH NEW MACH
        maneted=0.95;
        initalt=ORIGALT+1500;
        [dclb,tclb,fclb,hf]=CALC_CLB_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
            n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
            inc_root,inc_kink,inc_tip,Kink_semispan,...
            r0,t_c,phi,X_tcmax,theta,epsilon,...
            Ycmax,YCtcmax,X_Ycmax,...
            TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL); 

        delta=fclb0-fclb;
        if delta<tol
           out=1; 
        end    
        
    end
    
    % CRUISE & DESCENT ALGORITHM 
    WTOC=TOW-fclb;
    INITCRZALT=finalalt;
    h=INITCRZALT;
    des0=0;
    dcrz=DISTTOT-dclb-des0;

    flag=1;
    while flag==1

        %% CRUISE
        [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
        [TR, PR, DR, a] = atmos(h,ISADEV);
        if h<=10000
            M=CAS2MACH(250,PR);
        end
        if and(h>10000,h<=TA)
            M=CAS2MACH(CRZCAS,PR);
        end
        if h>TA
            M=CRZMACH;
        end
       [tcrz,fcrz,mancrz]=CALC_CRZ(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
                          inc_root,inc_kink,inc_tip,Kink_semispan,...
                          r0,t_c,phi,X_tcmax,theta,epsilon,...
                          Ycmax,YCtcmax,X_Ycmax,n,ebypass,ediam,efanpr,eopr,eTIT,...
                          WTOC,h,M,dcrz,ISADEV,NNind,NNwav,NNcd0,NNCL);
        WTOD=WTOC-fcrz;
        FINALCRZALT=h;

        % DESCENT
        
        destype=1;% 1:FULL CALCULATION  2:NO DESCENT COMPUTED

        switch destype

            case 1           
                FINALCRZALT=INITCRZALT;
                initalt=FINALCRZALT;
                finalalt=DESTALT+1500;
                maneted=0.3;

               [ddes,tdes,fdes]=CALC_DES_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweep14,...
                     inc_root,inc_kink,inc_tip,Kink_semispan,...
                    r0,t_c,phi,X_tcmax,theta,epsilon,...
                    Ycmax,YCtcmax,X_Ycmax,...
                    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
                    WTOD,initalt,finalalt,DESCAS,DESMACH,ISADEV,NNind,NNwav,NNcd0,NNCL);

                dTOT=dclb+dcrz+ddes;
                e=abs(DISTTOT-dTOT);
                if e<=1.0;
                   flag=0;
                else   
                   dcrz=dcrz-e; 
                end    

            case 2   
                flag=0;
                fdes=0;
                tdes=0;
                ddes=0;              
        end     

    end
        
%   CRZALT=FINALCRZALT;
    Wf = fclb+fdes+fcrz;
    T  = tclb+tdes+tcrz;
    D  = dclb+ddes+dcrz;
    LW=TOW-Wf;
      
   % RESERVE FUEL    
   restype=0;% 0=simplified computation, 1=full computation
   CONT=CONTPCT*Wf;
   if restype==0
      RESF=RES(LW,ALTDIST,HOLDTIME,ISADEV)+CONT;       
   else    
      [Wf_alt]  = ALTERNATEFUEL2(ACFT,NNind,NNwav,NNcd0,NNCL,LW,DESTALT,ALTELEV,4000,ALT_LDA,ARR_TREF,ALT_TREF,ISADEV,ALTDIST,HDG_ALT,GA_allowance);
       LW_alt= LW-Wf_alt-GA_allowance;
      [Wf_hold] = HOLDINGFUEL(ACFT,LW_alt,ALTELEV,ISADEV,NNind,NNwav,NNcd0,NNCL,HOLDTIME);      
      RESF=Wf_alt+Wf_hold+CONT;
   end 
   %
   TAXIFF=TAXIFF_ref*TOW/22000;
   TOF=Wf+RESF+TO_ALLOWANCE+TIT*TAXIFF;
   TAXIFUEL=TOT*TAXIFF;
   FOB=TOF+TAXIFUEL;
   REM=TOF-Wf-ARR_ALLOWANCE-TIT*TAXIFF; 
              
   % PAYLOAD RANGE ENVELOPE CHECK
   MTOW_ZFW=MZFW+FOB;
   MTOW_LW =MLW+Wf;
   delta1=TOW-MTOW_ZFW;
   delta2=FOB-MAXFUEL;         
   delta3=TOW-MTOW_LW;    
   extra =(TOW-OEW-PAYLOAD)-TOF;
   delta=max([delta1 delta2 delta3 extra]);                                        
   %
   if delta>tol
     TOW=TOW-delta;     
   else
     % PAYLOAD REDUCTION IF RESTRICTED  
     MTOW=min([RTOW MTOW_ZFW MTOW_LW]);  
     PAYLOAD_calc=MTOW-TOF-OEW; 
     if PAYLOAD_calc>PAYLOAD_INIT
        PAYLOAD=PAYLOAD_INIT;
     else
        PAYLOAD=PAYLOAD_calc; 
     end   
     f=1;
   end    
   PAX=round(PAYLOAD/PAXWT); 
   LF =PAX/NPax*100;   
end
 
% DOC CALCULATION
Wf    = Wf+(TIT+TOT)*TAXIFF;
ENGWT = 0.35*OEW;
DOC   = DOCROSKAN(T,Wf,D,Sal_Captain,Sal_FO,Sal_FA,OEW,ENGWT,RTOW,n,TBO,MAXRATE,Fuel_price/USD2EUR);
% DOC   = USD2EUR*DOC;

% PRINT RESULTS
if printflag>0    
    fprintf('%5.0f ',ZFW);
    fprintf('%5.0f ',FOB);
    fprintf('%5.0f ',TAXIFUEL);
    fprintf('%5.0f ',TOF);
    fprintf('%5.0f ',TOW);
    fprintf('%5.0f ',Wf);
    fprintf('%5.0f ',LW);
    fprintf('%5.0f ',REM);
    fprintf('%6.1f ',DISTTOT);
    fprintf('%6.1f ',HDG);
    fprintf('%5.0f ',INITCRZALT/100);
    fprintf('%5.1f ',T);
    fprintf('%5.2f ',DOC);
    fprintf('%5.0f ',RTOW);
    fprintf('%5.0f ',RLW);
    fprintf('%5.3f ',CRZMACH);    
end

    S1=int2str(ZFW);
    S2=int2str(FOB);
    S3=int2str(TAXIFUEL);
    S4=int2str(TOF);
    S5=int2str(TOW);
    S6=int2str(Wf);
    S7=int2str(LW);
    S8=int2str(REM);
    S9=int2str(DISTTOT);
    S10=int2str(HDG);
    S11=int2str(INITCRZALT/100);
    S12=int2str(T);
    S13=num2str(DOC);
    S14=int2str(RTOW);
    S15=int2str(RLW);
    S16=num2str(CRZMACH,3);
    S=strcat(S1,',',S2,',',S3,',',S4,',',S5,',',S6,',',S7,',',S8,',',S9,',',S10,',',S11,',',S12,',',S13,',',S14,',',S15,',',S16);
