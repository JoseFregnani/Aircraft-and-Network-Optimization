%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - FIXED NETWORK MODULE
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 1.0 / April 2017
%          1.1 / August 2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
close all

% LOAD AIRCRAFT

  [MTOW,MLW,MZFW,OEW,MAXFUEL,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2,ACFT]=LOADDATA2();
     
% Constants
N2lbf   = 0.2248;
kg2lb   = 2.2046;
ft2m    = 0.3048;
rad     = pi/180;
cfe     = 0.0030;  
kg2lb   = 2.2046;
m2feet  = 3.28083;
g       = 9.80665;
Gal2l   = 3.7852;

% SETUP PARAMETERS
ISADEV=10;         % ISA DEVIATION [oC]
PAXWT=110;         % PASSENGER's WEIGHT [kg]
MAXUTIL=13;        % MAXIMUM DAILY UTILIZATION [h]
TURNAROUND=45;     % TURN AROUND TIME  [min]
TIT=5;             % AVG TAXI IN TIME  [min]
TOT=10;            % AVG TAXI OUT TIME [min]
avg_ticket=150;    % AVERAGE TIKET PRICE [$/pax]
SHARE=0.20;        % 20% of the market  
LFREF=0.80;        % REFERENCE LOAD FACTOR  
K1=1.2;            % TOTAL REVENUE TO TICKET REVENUE FACTOR  
K2=1.1;            % TOTAL COST TO DOC FACTOR
ACFT_Mkt_Share=0.6;% ACFT Market Share
IR=0.05;           % Interest rate  
p=15;              % life cycle (years) 
KVA=75;            % Electrical system AC Power
USD2EUR = 0.90;    % DOLLAR TO EURO CONVERSION
TO_ALLOWANCE=200*MTOW/22000;  % TAKEOFF ALLOWANCE FUEL [kg]
ARR_ALLOWANCE=100*MTOW/22000; % APPROACH ALLOWANCE FUEL [kg]    

% NPV CALCULATION
[TOT_NPV,CASHFLOW,PV,IRR,BE,Price]=NPV(ACFT_Mkt_Share,IR,p,MTOW,wS,n,MAXRATE,ediam,NPax,KVA);

% Retrieve Airport and Demand Data
  [Airport,D,LF,DIST,HDG]=LOADAPT(SHARE,LFREF);
   X = [0 1 1 1 1 1;
        1 0 1 0 0 1;
        1 1 0 1 1 1;
        0 1 1 0 1 0;
        1 1 1 1 0 1;
        0 1 1 1 0 0];
         
% Construct Frequencies Matrix
    TOTDEMAND=0;
    for i=1:n
      for j=1:n
         if i==j
           f=0;
         else  
           f=round(D(i,j)/(NPax*LF(i,j)));
         end
         FREQ(i,j)=f;  
         TOTDEMAND=TOTDEMAND+D(i,j)*X(i,j);
      end
    end 
    [n,N,AVG_DON,L,ND,AVG_C]=NETWORKPAR(X,DIST,500);      
                
  % CONSTRUCT Wf,T and CF 
        for i=1:n
            for j=1:n
               if i~=j;
                   if X(i,j)~0;
                     DISTANCE=DIST(i,j);
                     [DISTALT]=MINALTDIST(DIST,i); 
                     NPAX=round(LFREF*NPax);
                     PAYLOAD=NPAX*PAXWT;
                     dep=Airport(i).name;
                     arr=Airport(j).name;
                     Origelev=Airport(i).elev;
                     Destelev=Airport(j).elev;
                     Altelev=Airport(i).elev;
                     ASDA=Airport(i).ASDA;
                     LDA=Airport(j).LDA;
                     ALT_LDA=Airport(i).LDA;
                     DEP_TREF=Airport(i).Reftemp;
                     ARR_TREF=Airport(j).Reftemp;
                     ALT_TREF=Airport(i).Reftemp;                      
                     TH=HDG(i,j);
                     THA=HDG(j,i);                    
%                    [Wf(i,j),T(i,j),CF(i,j)]=Mission4(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,NPax);
                     [Wf(i,j),T(i,j),CF(i,j),CRZMACH(i,j),PAX_calc,RMK,S] = Mission4_FULL(ACFT,Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ASDA,LDA,ALT_LDA,DEP_TREF,ARR_TREF,ALT_TREF,ISADEV,PAYLOAD,TIT,TOT,1,TO_ALLOWANCE,ARR_ALLOWANCE);  
                     if PAX_calc<NPAX(i,j);
                        NPAX(i,j)=PAX_calc;
                     end
                     T(i,j)=T(i,j)+TIT+TOT;                    
                     Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
                   end
               end 
            end
        end    

     % TOTAL 
        TOTCOST=0;
        TOTDIST=0;
        TOTALFREQ=0;
        TOTALPAX=0;
        TOTTIME=0;
        TOTFUEL=0;
        TOTFLIGHTS=0;
        AVGMACH=0;
        AVGDOC=0;
        NF=0;
        AVA=24.253+0.0009*MTOW; % ARRIVAL DELAY COST [$/min]
        AVD=9.8308+0.0007*MTOW; % DEPARTURE DELAY COST [$/min]
        
     % CONSOLIDATED DATA
        for i=1:n
            for j=1:n
                if X(i,j)>0
                    TOTCOST=TOTCOST+FREQ(i,j)*(DIST(i,j)*CF(i,j)+AVD*Airport(i).AVG_DEP_delay+AVA*Airport(j).AVG_ARR_delay);
                    TOTDIST=TOTDIST+FREQ(i,j)*DIST(i,j);
                    TOTALPAX=TOTALPAX+FREQ(i,j)*round(LFREF*NPAX(i,j));
                    TOTTIME=TOTTIME+FREQ(i,j)*(T(i,j)+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay+TURNAROUND);
                    TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);
                    TOTFUEL=TOTFUEL+FREQ(i,j)*Wf(i,j);
                    NF= NF+FREQ(i,j);
                    AVGMACH=AVGMACH+FREQ(i,j)*CRZMACH(i,j);
                    AVGDOC=AVGDOC+FREQ(i,j)*CF(i,j);
                end    
            end    
        end
       
AVGMACH=AVGMACH/NF;
AVGDOC=AVGDOC/NF;
COST=K2*TOTCOST;
REV=K1*TOTALPAX*avg_ticket;
PROFIT=REV-COST;
CASK=COST/(TOTALPAX*TOTDIST);
RASK=REV/(TOTALPAX*TOTDIST);
NP=RASK-CASK;               
NACFT=round(TOTTIME/(MAXUTIL*60));   
CO2EFF(a)=3.15*TOTFUEL/(TOTALPAX*TOTDIST*1.852);

fprintf('\n');
fprintf('\n ** NETWORK RESULTS **');
fprintf('\n'); 
fprintf('\n Average Cruise Mach      : %10.3f',AVGMACH);
fprintf('\n TOTAL FUEL (kg)          : %10.2f',TOTFUEL);
fprintf('\n TOTAL CO2  (kg)          : %10.2f',TOTFUEL*3.15);
fprintf('\n CO2 EFF(kg/PAX.km)       : %6.4E',CO2EFF);
fprintf('\n TOTAL DIST (nm)          : %10.2f',TOTDIST);
fprintf('\n TOTAL PAX                : %10.0f',TOTALPAX);
fprintf('\n TOTAL COST    ($)        : %10.2f',COST);
fprintf('\n TOTAL REVENUE ($)        : %10.2f',REV);
fprintf('\n TOTAL PROFIT  ($)        : %10.2f',PROFIT);
fprintf('\n MARGIN        (pct)      : %10.2f',100*PROFIT/COST); 
fprintf('\n AVG DOC ($/nm)           : %6.2E',AVGDOC);
fprintf('\n NRASK ($/pax.nm)         : %6.4E',RASK);
fprintf('\n NCASK ($/pax.nm)         : %6.4E',CASK);
fprintf('\n NP    ($/pax.nm)         : %6.4E',NP);
fprintf('\n NUM OF FREQUENCIES       : %4.0f',NF);
fprintf('\n NUM OF ACFT              : %3.0f',NACFT);
fprintf('\n SECTORS PER ACFT         : %3.0f',NF/NACFT);


        