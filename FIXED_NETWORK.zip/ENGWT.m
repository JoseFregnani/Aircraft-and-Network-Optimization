function [engine_wt]= ENGWT(BPR,OPR,T0,eDiam,FF,le)

T1=2587.2461;
T2=50.1920;
T3=154.6179;
a=-0.1965;
b=-0.0718;
c=1.0435;
d=0.2493;
e=-0.3444;
f=-0.1455;
BPR_avg=4.6911;
OPR_avg=25.4000;
eDiam_avg=1.7906;
le_avg=3.3276;
T0_avg=148.1217;
FF_avg=464.7333;

engine_wt=T1*((BPR/BPR_avg)^a)*((OPR/OPR_avg)^b)*((T0/T0_avg)^c)*((eDiam/eDiam_avg)^d)*((le/le_avg)^e)*((FF/FF_avg)^f)+...
          T2*(OPR/OPR_avg)*(T0/T0_avg)*(eDiam/eDiam_avg)*(le/le_avg)*(FF/FF_avg)+T3;
