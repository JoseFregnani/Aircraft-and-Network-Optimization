%% DESCRI��O DA FUN��O
% Compila��o de par�metros para o c�lculo do ru�do


%% DECLARA��O DA FUN��O %%
function noiseparameters()


%% Vari�veis globais
global var
global wing
global flap
global ht
global vt
global landinggear
global TOPAR
global LDPAR
global ACTGEO
global NOPAR
global f
global g
global V2VS


%% PAR�METROS COMUNS
f                   = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];
                                                                            % freq��ncias-padr�o para avalia��o do ru�do

                                                                            
%% PAR�METROS DE DECOLAGEM
TOPAR.HP            = 0;                                                    % Altitude da pista [ft]
TOPAR.DISA          = 10;                                                   % Temperatura DISA [C]
TOPAR.WTO           = var.MTOW*g;                                           % Peso [N]
TOPAR.lambda        = 0;                                                    % �ngulo da tra��o em rela��o � dire��o da velocidade [deg] 
TOPAR.time1         = 3.0;                                                  % tempo entre VEF e V1 [s]
TOPAR.time2         = 3.0;                                                  % tempo entre VLO e VOBS [s]
TOPAR.tstep         = 0.5;                                                  % Intervalo de tempo para avalia��o de EPNdB [s]
TOPAR.distmax       = 10000;                                                % Dist�ncia m�xima para avalia��o da trajet�ria [m]
TOPAR.SH            = 35;                                                   % Altura da barreira [ft]
TOPAR.CLMAX         = wing.CLmax_to;                                        % CLMax configura��o de decolagem [-]
TOPAR.CDAIRGUP      = var.CDTOGUP;                                          % coeficiente de arrasto com trem-de-pouso recolhido (decolagem)
TOPAR.CDAIRGDN      = var.CDTOGDN;                                          % coeficiente de arrasto com trem-de-pouso baixado (decolagem)
TOPAR.CLAIR         = TOPAR.CLMAX/V2VS^2;                                   % coeficiente de sustenta��o no ar (decolagem)
TOPAR.CL3P          = 0.3000;                                               % coeficiente de sustenta��o no solo (tr�s-pontos)
TOPAR.CD3P          = 0.0800;                                               % coeficiente de arrasto no solo (tr�s-pontos)
TOPAR.murol         = 0.0300;                                               % Coeficiente de atrito de rolamento [-]
TOPAR.mubrk         = 0.3000;                                               % Coeficiente de atrito de frenagem [-]

%% PAR�METROS DE POUSO
LDPAR.HP            = 0;                                                    % Altitude da pista [ft]
LDPAR.DISA          = 10;                                                   % Temperatura DISA [C]
LDPAR.WLD           = var.MLW*g;                                            % Peso [N]
LDPAR.CDAIRGDN      = var.CDLDGDN;                                          % Coeficiente de arrasto [-]
LDPAR.gamma         = -3.000;                                               % �ngulo da trajet�ria [deg]

%% PAR�METROS AERODIN�MICOS DA AERONAVE
ACTGEO.SH           = ht.S;                                                 % �rea de refer�ncia da empenagem horizontal [m�]
ACTGEO.bH           = ht.b;                                                 % envergadura da empenagem horizontal [m]
ACTGEO.SV           = vt.S;                                                 % �rea de refer�ncia da empenagem vertical [m�]
ACTGEO.bV           = vt.b;                                                 % envergadura da empenagem vertical [m]
ACTGEO.SF           = flap.SF;                                              % �rea total dos flapes [m�]
ACTGEO.bF           = flap.bF;                                              % bF - envergadura total dos flapes [m]
ACTGEO.deltafTO     = var.FLAPTAKEOFF;                                      % deltafTO - deflex�o dos flapes - decolagem [deg]
ACTGEO.deltafLD     = var.FLAPLAND;                                         % deltafLD - deflex�o dos flapes - pouso [deg]
ACTGEO.dmtyre       = landinggear.dmtyre;                                   % dmtyre - di�metro do pneu - trem de pouso principal [m]
ACTGEO.dntyre       = landinggear.dntyre;                                   % dntyre - di�metro do pneu - trem de pouso dianteiro [m]
ACTGEO.nmgear       = 2;                                                    % nmgear - n�mero de unidades no trem de pouso principal
ACTGEO.nngear       = 1;                                                    % nmgear - n�mero de unidades no trem de pouso dianteiro
ACTGEO.lmgear       = landinggear.lmgear;                                   % lmgear - comprimento da perna do trem de pouso principal [m]
ACTGEO.lngear       = landinggear.lngear;                                   % lngear - comprimento da perna do trem de pouso dianteiro [m]
ACTGEO.nmwheel      = 2;                                                    % nmwheel - n�mero de pneus por trem principal 
ACTGEO.nnwheel      = 2;                                                    % nnwheel - n�mero de pneus por trem dianteiro
ACTGEO.fwtype1      = 1;                                                    % fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
ACTGEO.fwtype2      = 0;                                                    % fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
ACTGEO.fslats       = 1;                                                    % fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
ACTGEO.fhtype       = 1;                                                    % fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
ACTGEO.fvtype       = 1;                                                    % fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
ACTGEO.nslots       = 2;                                                    % nslots - n�mero de slots no flape
ACTGEO.fmgear       = 1;                                                    % fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
ACTGEO.fngear       = 1;                                                    % fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
ACTGEO.hprec        = 0;                                                    % hprec - altitude no ponto de medi��o
ACTGEO.disarec      = 10;                                                   % disarec - temperatura no ponto de medi��o [�C]


%% PAR�METROS PARA O C�LCULO DO RU�DO
NOPAR.RH            = 70;                                                   % umidade relativa [%]
NOPAR.dlatLD        = 1;                                                    % dist�ncia lateral para avalia��o do ru�do - pouso [m]
NOPAR.dlatSL        = 450;                                                  % dist�ncia lateral para avalia��o do ru�do - lateral[m]
NOPAR.dlatTO        = 1;                                                    % dist�ncia lateral para avalia��o do ru�do - decolagem [m]
NOPAR.XALD          = 2000;                                                 % dist�ncia longitudinal para avalia��o do ru�do - pouso [m]
NOPAR.XASL          = 0;                                                    % dist�ncia longitudinal para avalia��o do ru�do - lateral [m]
NOPAR.XATO          = 6500;                                                 % dist�ncia longitudinal para avalia��o do ru�do - decolagem [m]


%% T�rmino da fun��o
end