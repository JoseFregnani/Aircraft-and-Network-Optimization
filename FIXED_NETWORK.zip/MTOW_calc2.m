 function [MTOWcalc, OEW, W_climb_final, SWETsai,...
     TOTFUEL, TOTFUEL_ALT, TOTTIME, htsai,vtsai,xlesai,xcg_fwd,xcg_aft]...
    = MTOW_calc2(MTOW,AirplaneCLmaxClean,wTCmed,wSweepLE,wSweep14,...
    wS,wTR,wAR,wMAC,wYMAC,...
    inc_root,inc_kink,inc_tip,Kink_semispan,longtras,posxmunhao,...
    xcgtanques,NSeat,fuelcapacitykg,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,Ccentro,Craiz,Cponta,margin_static,...
    Range,Engine_data, CruiseMach,Ceiling,SWET,wingSwet,Payload,ncrew,...
    TLOIT,DIST_ALT,NNind,NNwav,NNcd0,NNCL,PHT,ht,...
    EnginLength_m,EngineDe_m,pylon,...
    CLALFA_rad,wingfuelcapacity,PWing,vt,vtac_rel,htac_rel,...
    YEIS,xle,slat,fus_width, fus_height, FusSwet_m2,lf,lcab,ltail,VHT,VVT)

% CONSTANTS
lb2kg   = 1/2.2046;

% GEOMECTRIC PARAMETERS
S       = wS; % WING REFERENCE AREA [m2]
lco     = lf -(lcab+ltail); % forward fuselage length [m]
PEng    = Engine_data(1); % 1= two underwing engines; 2= two engines at rear fuselage
ebypass = Engine_data(2); % Engine by-pass ratio
ediam   = Engine_data(3); % Fan diameter [m]
efanpr  = Engine_data(4); % Fan pressure ratio
eopr    = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT    = Engine_data(6); % Turbine Inlet Temperature [K]
CLMAX   = AirplaneCLmaxClean;
%ENGINE PARAMETERS

%MAXRATE=13400;

n=max(2,PEng); % number of engines

% OPERATIONS PARAMETERS
DISTTOT     = Range; % [nm]
ALTDIST     = 200; 
HDG         = 0;
TOW         = MTOW;
ORIGALT     = 0;
DESTALT     = 0;
CLBCAS      = 280;
CLBCAS_ALT  = 250;
CLBMACH     = 0.78;
CLBMACH_ALT = 0.74;
CRZMACH     = 0.78;
CRZMACH_ALT = 0.74;
CRZCAS      = 270;
CRZCAS_ALT  = 270;
DESCAS      = 280;
DESCAS_ALT  = 280;
DESMACH     = 0.78;
DESMACH_ALT = 0.72;
ISADEV      = 0;
RCMIN       = 300; % Rate of climb [ft/min]
BUFFMARGIN  = 1.3;
MINCRZTIME  = 3;
HOLDTIME    = 30;
MMO         =0.82;

% Takeoff 

ftakeoff = 0.005*TOW;
ttakeoff = 1;

% MAX & OPT ALTITUDE CALCULATION
initalt = ORIGALT;
hf      = Ceiling;
step    = 100;
W_climb = TOW - ftakeoff;
[HMAX,RCRES]=MAXALT(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,W_climb,initalt,step,hf,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
    [HOPT,SRMAX]=optalt(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,W_climb,initalt,hf,step,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

g_sub=4/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=10*CRZMACH*MINCRZTIME;
K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>Ceiling
  HMAX2=Ceiling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt=HOPT;
else
    finalalt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 
finalalt= 1000*(fix (finalalt/1000));
FL=finalalt/100;
ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end 
    end
end    

% CLIMB CALCULATION
maneted=0.95;
initalt=ORIGALT+1500;
[dclb,tclb,fclb,hf]=CALC_CLB_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    W_climb,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

% CRUISE & DESCENT ALGORITHM 
W_climb_final = W_climb-fclb;
WTOC          = W_climb_final;
INITCRZALT    = finalalt;
CRZMACH       = CLBMACH;
h             = INITCRZALT;
K = 0;
dcrz=DISTTOT-dclb-K;
flag=1;

while flag==1
    
  % CRUISE
  [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
  [~, PR, ~, ~] = atmos(h,ISADEV);
  if h<=10000
    M=CAS2MACH(250,PR);
  end
  if and(h>10000,h<=TA)
    M=CAS2MACH(CRZCAS,PR);
  end
  if h>TA
    M=CRZMACH;
  end
  [tcrz,fcrz,mancrz]=CALC_CRZ(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,ebypass,ediam,efanpr,eopr,eTIT,WTOC,h,M,dcrz,ISADEV,NNind,NNwav,NNcd0,NNCL);
   WTOD=WTOC-fcrz;
    
  % DESCENT
  FINALCRZALT=INITCRZALT;
  initalt=FINALCRZALT;
  finalalt=DESTALT+1500;
  maneted=0.55;

  [ddes,tdes,fdes]=CALC_DES_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
   WTOD,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,NNind,NNwav,NNcd0,NNCL);
   dTOT=dclb+dcrz+ddes;
   e=abs(DISTTOT-dTOT);
   if e<=0.5;
     flag=0;
   else   
     dcrz=dcrz-e; 
   end 
   
end

% Alternate 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% MAX & OPT ALTITUDE CALCULATION
initalt_climb_alt=DESTALT;
step=50;
TOW_ALT=TOW-fclb-fdes-fcrz-ftakeoff;
[HMAX,RCRES]=MAXALT(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,step,hf,...
    CLBCAS,CLBMACH_ALT,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
[HOPT,SRMAX]=optalt(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,hf,step,...
    CLBCAS,CLBMACH_ALT,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK
g_sub=2/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=CRZMACH*10*MINCRZTIME;
K2=DIST_ALT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>Ceiling
  HMAX2=Ceiling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt_climb_alt=HOPT;
else
    finalalt_climb_alt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 
finalalt_climb_alt= 1000*(fix (finalalt_climb_alt/1000));
FL=finalalt_climb_alt/100;

if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        finalalt_climb_alt=finalalt_climb_alt+1000;
        if finalalt_climb_alt>=HMAX
            finalalt_climb_alt=finalalt_climb_alt-3000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        finalalt_climb_alt=finalalt_climb_alt+1000;
        if finalalt_climb_alt>=HMAX
            finalalt_climb_alt=finalalt_climb_alt-3000;
        end 
    end
end    

% CLIMB to ALTERNATE CALCULATION
maneted=0.95;
initalt_climb_alt=ORIGALT+1500;
[dclb_alt,tclb_alt,fclb_alt,hf]=CALC_CLB_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    W_climb,initalt_climb_alt,finalalt_climb_alt,CLBCAS_ALT,...
    CLBMACH_ALT,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

% CRUISE e DESCENT to ALTERNATE 
WTOC_ALT=TOW_ALT-fclb_alt;
INITCRZALT=finalalt_climb_alt;
CRZMACH=CLBMACH_ALT;
h=finalalt_climb_alt;
K=0;
dcrz_alt=DIST_ALT-dclb_alt-K;
flag=1;

while flag==1
    
    % CRUISE
    [TR, PR, DR, a] = atmos(h,ISADEV);
    [MCRZ]=CAS2MACH(CRZCAS,PR);
    if MCRZ>CRZMACH
      MCRZ=CRZMACH;
    end  
    
    [tcrz_alt,fcrz_alt,mancrz]=CALC_CRZ(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,ebypass,ediam,efanpr,eopr,eTIT,WTOC_ALT,h,MCRZ,dcrz_alt,...
        ISADEV,NNind,NNwav,NNcd0,NNCL);
    WTOD_ALT=WTOC_ALT-fcrz_alt;
    FINALCRZALT=h;
    
    % DESCENT
    FINALCRZALT=INITCRZALT;
    initalt_crz_alt=FINALCRZALT;
    finalalt_crz_alt=DESTALT+1500;
    maneted=0.50;
    [ddes_alt,tdes_alt,fdes_alt]=CALC_DES_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
        WTOD_ALT,initalt_crz_alt,finalalt_crz_alt,DESCAS_ALT,DESMACH_ALT,...
        ISADEV,NNind,NNwav,NNcd0,NNCL);
    dTOT=dclb_alt+dcrz_alt+ddes_alt;
    e=abs(ALTDIST-dTOT);
    if e<=0.5;
     flag=0;
    else   
     dcrz=dcrz-e; 
    end        
end

% HOLDING 
WLoit       = WTOD;
hLoit       = DESTALT + 1500;
MLoit       = 0.55;
Tspan       =[0.01 30]; % [min]
IC          = WLoit;
[~, X]= ode45(@(t,x) loiter(t,x,hLoit,MLoit,S,ISADEV,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
     Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,SWET,wingSwet,...
     n,efanpr,eopr,ebypass,ediam,eTIT),Tspan,IC);
nf           = size(X,1);
WLoitf       = X(nf);
floit        = WLoit-WLoitf;
TOTFUEL     = fclb+fdes+fcrz+ftakeoff;
TOTFUEL_ALT = TOTFUEL + fclb_alt + fcrz_alt + fdes_alt + ftaxi+floit;
TOTTIME     = tclb+tdes+tcrz+ttakeoff;
TOTDIST     = dclb+ddes+dcrz;
%
fprintf('\n TOTAL:');
fprintf('\n => time = %5.1f h',TOTTIME/60);
fprintf('\n => dist = %5.1f',TOTDIST);
fprintf('\n => fuel = %5.1f kg',TOTFUEL);

% New MTOW Estimation

MMO        = CruiseMach;
[Fn,~]     = engine_main(0,0,efanpr,eopr,ebypass,1,ediam,eTIT);
MTOW_error = 1E06;
MTOWcalc   = MTOW;
while MTOW_error > 50
    NPax          = round(Payload/100);
    [OEW_lb, weightcomp] = WeightAirplane(NPax,Range,MTOW,TOTFUEL,...
        Ceiling,wTCmed,MMO,...
        Fn,EnginLength_m,EngineDe_m,ebypass,...
        Engine_data(1),PWing,...
        YEIS,xle,slat,wMAC,wYMAC,wTR,wS,wAR,wSweepLE,wSweep14,PHT,ht,vt,...
        fus_width,fus_height,FusSwet_m2,lf,lcab,ltail,wingfuelcapacity);
    OEW           = OEW_lb*lb2kg;
    MTOWnew       = Payload + OEW + ncrew*100 + TOTFUEL_ALT*1.0025;
    MTOW_error    = abs(MTOWcalc-MTOWnew);
    MTOWcalc      = 0.20*MTOWcalc+ 0.80*MTOWnew;
    HTSWET_old    = ht.Swet;
    VTSWET_old    = vt.Swet;
    SWET_old      = SWET;
    [xleout,htout, vtout,~,xcg_fwd,xcg_aft,~]=...
        tailsizing(xle,VHT,VVT,...
        slat,PWing,wS,wAR,wTR,wSweep14,wMAC,wYMAC,...
        wSweepLE,Ccentro,Craiz,Cponta,margin_static,fus_width,fus_height,lf,...
        lcab,lco,longtras,posxmunhao,xcgtanques,NPax,NSeat,fuelcapacitykg,...
        PEng,EnginLength_m,EngineDe_m,PHT,ht,vt,Kink_semispan,vtac_rel,htac_rel,...
        Ceiling,CruiseMach,CLALFA_rad,pylon,weightcomp);
    xle = xleout;
    ht  = htout;
    vt  = vtout;
    SWET = SWET_old + ht.Swet + vt.Swet - (HTSWET_old + VTSWET_old);
end
    vtsai  = vt;
    htsai  = ht;
    xlesai = xle;
    SWETsai = SWET;
end
%