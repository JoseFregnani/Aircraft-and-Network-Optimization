function X_norm = ann_normalize_internal(X, Mean, Range)

%Number of training sets
m = size(X,2);
%Normalization
X_norm = 2*(X - Mean*ones(1,m))./(Range*ones(1,m));
%
end