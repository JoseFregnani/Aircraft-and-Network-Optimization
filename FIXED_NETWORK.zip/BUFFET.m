function[BUFFALT]= BUFFET (h,W,S,TAS,M,ISADEV,CLMAX,BUFFMARGIN)

[TR, PR, DR, a] = atmos(h,ISADEV);
dens0=1.225;
g=9.80665;
kt2ms=0.514;
dens=dens0*DR;
V=TAS*kt2ms;
q=(1/2)*dens*(V^2);
CL=(W*g)/(q*S);
Beta=sqrt(1-(M^2));

MARG=Beta*CLMAX/CL;
%fprintf('\n =>CLMAX = %5.3f',Beta*CLMAX);
%fprintf('\n => MARG  = %5.3f',MARG);

if MARG<BUFFMARGIN
    BUFFALT=h;
else
    BUFFALT=999999;
end    