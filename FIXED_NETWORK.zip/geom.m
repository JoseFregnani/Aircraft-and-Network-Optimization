clc
clear

% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% GEOMECTRIC PARAMETERS
S=72.72;
b=25;
WAR=8.6;
afil=0.235;
tcroot = 0.145; 
tctip  = 0.11;  
tc=(3*tcroot+2*tctip)/5;
tr=0.285;
df=3.3;
phi14=23.5;
CLMAX=1.6;
PWing=1;
VTarea=16.2;
VTAR=0.89;
VTTR=0.740;
VTSweep=41;
HTarea=23.35;
HTAR=4.35;
HTTR=0.4;
PHT=1;
FusDiam=3.5;
NPax=78;
NCorr=1;
NSeat=4;
ncrew= 5;
AisleWidth=0.49;
CabHeightm=2;
Kink_semispan=0.34;
SEATwid=0.46;
widthreiratio=1.1;

%ENGINE PARAMETERS
MAXRATE=13400;
n=2;

PEng = 1; % 1= two underwing engines; 2= two engines at rear fuselage
if PEng == 1
    nedebasa=n;
else
    nedebasa=0;
end

maneted=1;
ebypass= 5;    
ediam= 1.36;  
efanpr= 1.425;
eopr= 28.5;    
eTIT= 1240; 

Engine_data(1)     = maneted;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;

% OPERATIONS PARAMETERS

MMO=0.82;
VMO=340;
DISTTOT=170;
HDG=10;
MTOW=37500;
TOW=37500;
ORIGALT=0;
DESTALT=0;
cieling=41000;
CLBCAS=280;
CLBMACH=0.78;
CRZMACH=0.78;
CRZCAS=310;
DESCAS=280;
DESMACH=0.78;
ISADEV=0;
RCMIN=300;
BUFFMARGIN=1.3;
MINCRZTIME=3;

% WET AREA CALCULATION

%swet2=wettedarea(0.82,FusDiam,NPax,NCorr,NSeat,SEATwid,AisleWidth,Kink_semispan,S,WAR,tr,phi14,PWing,Engine_data,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT)
swet2=480;