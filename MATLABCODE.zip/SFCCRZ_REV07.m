function [TSFC,CDoCL,FF,maneted]=SFCCRZ_REV07(Sref,wAR,wTR,...
    swet2,Swetwing,wLEsweep,...
    inc_root,inc_kink,inc_tip,kink_position,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,ebypass,ediam,efanpr,eopr,eTIT,W,h,M,ISADEV,NNind,NNwav,NNcd0,NNCL)

% CONSTANTS
g    = 9.80665;
ft2m = 0.3048;

[~, ~, ~, a] = atmos(h,ISADEV);
TAS  = a*M;
%[CDoCL]=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,ISADEV);
[CDoCL]=CDCL_mod (Sref,wAR,wTR,swet2,Swetwing,wLEsweep,...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,kink_position,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
%
FnR  =(W*g)*(CDoCL);

maneted=0.6;
stepman=0.01;
T=0;
altm=h*ft2m;

while and(T<FnR,maneted<=1)
  [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
  TSFC=FF/(Fn/g);
  T=n*Fn;
  maneted=maneted+stepman;
end  

%fprintf('\n => FnR   = %5.1f',FnR);
%fprintf('\n => Fn    = %5.1f',Fn);
%fprintf('\n => T     = %5.1f',T);
%fprintf('\n => FF    = %5.1f',FF);
%fprintf('\n => FFtot = %5.1f',2*FF);
%fprintf('\n => maneted  = %5.2f',maneted);