function [xleout,htout, vtout,xnp,xcg_fwd,xcg_aft,weightcompout]=...
    tailsizing(xle,VHT,VVT,...
    slat,PWing,wS,wAR,wTR,wSweep14,wMAC,wYMAC,...
    wSweepLE,Ccentro,Craiz,Cponta,margin_static,fus_width,fus_height,lf,...
    lcab,lco,longtras,posxmunhao,xcgtanques,NPax,NSeat,fuelcapacitykg,...
    PEng,EnginLength_m,EngineDe_m,PHT,ht,vt,Kink_semispan,vtac_rel,htac_rel,...
    Ceiling,CruiseMach,CLALFA_rad,pylon,weightcomp, ...
    SeatPitch,Aislewidth,SeatWidth)
%
VTArea       = vt.S;
HTarea       = ht.S;
rad          = pi/180;
%
wingb        = sqrt(wS*wAR);
relax        = 0.70;
dist_quebra  = (wingb/2)*Kink_semispan;
%
% Aislewidth  = 0.50;  % [m]
% SeatWidth   = 0.45; % [m]
% SeatPitch   = 0.8128; % [m]
[~, xcg_aft]=cg2(weightcomp,xle,slat,fus_width,lf,lco,lcab,longtras,PEng,...
    wS,wAR,wMAC,wYMAC,wSweepLE,PHT,ht,vt,pylon,Ccentro,Cponta,...
    EnginLength_m,EngineDe_m,Kink_semispan,PWing,posxmunhao,xcgtanques,...
    NPax,NSeat,fuelcapacitykg, SeatPitch,Aislewidth,SeatWidth);
%
DeltaHT      = 10000;
DeltaVT      = 10000;
margin       = margin_static*wMAC;
%
while DeltaHT > 0.025 || DeltaVT > 0.025
%
% [airac_rel]=aerocenter(xle,CruiseMach,PWing,CLALFA_rad,wS,wAR,wTR,wSweep14,...
%     wMAC,wYMAC,wSweepLE,Craiz,PHT,ht,vt,pylon,...
%     fus_width,fus_height,lf,PEng,EnginLength_m,EngineDe_m,dist_quebra);
%
airac_rel = 0.25;
xnp       = xle + wYMAC*tan(rad*wSweepLE) + airac_rel*wMAC;
dist      = xnp - xcg_aft;
Deltadist = dist - margin ;
%AbsDeltadist  = abs(Deltadist);
xlenew    = xle - Deltadist;
%Deltaxle  = abs(xlenew-xle);
xle       = xlenew;
% Ciclo VT
vtxac     = 0.95*lf - vt.c0 + vt.ymac*tan(vt.sweepLE*rad) + ...
            vtac_rel*vt.mac;
lv        = vtxac - xcg_aft;
VTAreanew = wS*VVT*wingb/lv;
DeltaVT   = abs(VTArea - VTAreanew);
VTArea    = relax*VTAreanew + (1-relax)*VTArea;
[vt]      = sizevt(VTArea,vt.AR,vt.TR,vt.sweep,wS,PHT,ht,CruiseMach+0.05,...
    Ceiling);
weightcomp.vt = vt.weight;
% Ciclo HT
    if PHT == 1
    htxac = 0.95*lf - ht.c0 + ht.ymac*tan(rad*ht.sweepLE) +...
        htac_rel*ht.mac;
    else
    htxac = 0.95*lf - vt.c0 + vt.b*tan(rad*vt.sweepLE) +...
        htac_rel*ht.mac + ht.ymac*tan(rad*ht.sweepLE);
    end
lh        = htxac-xcg_aft;
HTAreanew = VHT*wS*wMAC/lh;
DeltaHT   = abs(ht.S - HTAreanew);
HTarea    = relax*HTAreanew + (1.-relax)*HTarea;
ht=sizeht(HTarea,ht.AR,ht.TR,PHT,wS,wSweep14,lf,vt.sweepLE,vt.ct,vt.c0,vt.b,...
    htac_rel,CruiseMach+0.05,Ceiling);
weightcomp.ht = ht.weight;
%
[xcg_fwd, xcg_aft]=cg2(weightcomp,xle,slat,fus_width,lf,lco,lcab,longtras,PEng,...
    wS,wAR,wMAC,wYMAC,wSweepLE,PHT,ht,vt,pylon,Ccentro,Cponta,...
    EnginLength_m,EngineDe_m,Kink_semispan,PWing,posxmunhao,xcgtanques,...
    NPax,NSeat,fuelcapacitykg,SeatPitch,Aislewidth,SeatWidth);
%
% PlotAirplaneNP(xle,fus_width,lco,lcab,lf,PEng,EnginLength_m,EngineDe_m,wSweepLE,...
%     Ccentro,Craiz,wTR,wingb,Kink_semispan,vt,PHT,...
%     ht,xnp,xcg_aft,xcg_fwd,pylon)
%
end
htout         = ht;
vtout         = vt;
xleout        = xle;
weightcompout = weightcomp;
%
end
%