function plot_airplanetopview(xle,fuselage,ht,vt,...
    wing,engine,pylon,PEng,PHT)
% 
rad = pi/180;
lf = fuselage.length;
%
figure(10)
%__________________________________________________________________________
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%TOP VIEW%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%__________________________________________________________________________
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%FUSELAGE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
df=fuselage.df;

cockpit.r=fuselage.df/2; % height [m]
cockpit.parameter1=2; % paramero elipse
cockpit.parameter2=1.3; % paramero elipse
aux2=0;

for aux1=0:0.01:fuselage.lco
    aux2=aux2+1;
    cockpit.x(aux2)=aux1;
    cockpit.y(aux2)=real((cockpit.r^cockpit.parameter2-(((aux1-fuselage.lco)^cockpit.parameter1)*(cockpit.r^cockpit.parameter2)/(fuselage.lco^cockpit.parameter1)))^(1/cockpit.parameter2));
    cockpit.w(aux2)=2*cockpit.y(aux2);
end

plot(cockpit.x,cockpit.y)
hold on
plot(cockpit.x,-cockpit.y)
axis equal
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CABINE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cabine.x=[fuselage.lco, (fuselage.lco+fuselage.lcab)];
cabine.y=[fuselage.df/2, fuselage.df/2];
cabine.w=fuselage.df;


plot(cabine.x,cabine.y)
hold on
plot(cabine.x,-cabine.y)
axis equal
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%TAIL BOOM%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
auxfus=fuselage.lco+fuselage.lcab;
    if PEng == 2
    auxfus2=0.50*engine.length;
    else
    auxfus2=2;
    end
tail.x=[auxfus (auxfus+auxfus2) fuselage.length fuselage.length];
tail.y=[df/2 0.85*df/2 0.40 0];

plot(tail.x,tail.y)
hold on
plot(tail.x,-tail.y)
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%WING%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%REFERENCE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%wingref.x=[wing.le wing.le+wing.b/2*tan(wing.sweepLE*rad) wing.le+wing.b/2*tan(wing.sweepLE*rad)+wing.ct wing.le+wingref.c0];
%wingref.y=[0 wing.b/2 wing.b/2 0];

%plot(wingref.x,wingref.y,'--r')
%hold on
%plot(wingref.x,-wingref.y,'--r') % plot inverso
%axis equal
%hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CRANK%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

wing.x=[xle, xle+wing.b/2*tan(wing.sweepLE*rad), xle+wing.b/2*tan(wing.sweepLE*rad)+wing.ct, xle+wing.c0, xle+wing.c0];
wing.y=[0, wing.b/2, wing.b/2, wing.s1, 0];

plot(wing.x,wing.y)
hold on
plot(wing.x,-wing.y) % Outra metade
axis equal
hold on

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%VERTICAL TAIL%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

vt.x=[(0.97*fuselage.length-vt.c0) (0.97*fuselage.length-vt.c0+vt.b*tan(vt.sweepLE*rad)) (0.97*fuselage.length-vt.c0+vt.b*tan(vt.sweepLE*rad)+vt.ct) (0.97*fuselage.length)];
vt.y=[0 0 0 0];

plot(vt.x,vt.y)
hold on
axis equal

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%HORIZONTAL TAIL%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch PHT
case 1
    ht.x=[(0.92*fuselage.length-ht.c0) (0.92*fuselage.length-ht.c0+ht.b/2*tan(ht.sweepLE*rad)) (0.92*fuselage.length-ht.c0+ht.b/2*tan(ht.sweepLE*rad)+ht.ct) 0.92*fuselage.length];
    ht.y=[0 ht.b/2 ht.b/2 0];
    
    plot(ht.x,ht.y)
    hold on
    plot(ht.x,-ht.y) % plot inverso
    axis equal
    hold on
    otherwise
    auxht=0.97*fuselage.length-vt.c0+vt.b*tan(vt.sweepLE*rad);
    ht.x=[auxht (auxht+ht.b/2*tan(ht.sweepLE*rad)) (auxht+ht.b/2*tan(ht.sweepLE*rad)+ht.ct) (auxht+ht.c0)];
    ht.y=[0 ht.b/2 ht.b/2 0];
    
    plot(ht.x,ht.y)
    hold on
    plot(ht.x,-ht.y) % plot inverso
    axis equal
    hold on
end  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PYLON %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
auxpyl=0.97*lf-vt.c0-engine.length;
compmotor = engine.length;

switch PEng
    case 1
    case 2
    pyl.x(1) = auxpyl+0.20*compmotor;
    pyl.x(2) = pyl.x(1);
    pyl.x(3) = pyl.x(2)+pylon.ct;
    pyl.x(4) = pyl.x(2)+pylon.c0;
    
    pyl.y(1) = fuselage.df/2;
    pyl.y(2) = fuselage.df/2+pylon.b;
    pyl.y(3) = fuselage.df/2+pylon.b;
    pyl.y(4) = pyl.y(1);
    
    plot(pyl.x,pyl.y)
    hold on
    pyl.x(1) = auxpyl+0.20*compmotor;
    pyl.x(2) = pyl.x(1);
    pyl.x(3) = pyl.x(2)+pylon.ct;
    pyl.x(4) = pyl.x(2)+pylon.c0;
    
    pyl.y(1) = -fuselage.df/2;
    pyl.y(2) = -fuselage.df/2-pylon.b;
    pyl.y(3) = -fuselage.df/2-pylon.b;
    pyl.y(4) = pyl.y(1);
    
    plot(pyl.x,pyl.y)
    hold on
    case 3
    case 4
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%ENGINE%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

switch PEng
    case 1
        % livro 6 pag 111 fig 4.41 x/l=0.6
        aux = xle + wing.s1*tan(rad*wing.sweepLE);
        x1 = aux -0.40*engine.length;
        x2 = x1 + engine.length;
        engine.x=[x1 x1 x2 x2];
        y1 = wing.s1 - engine.de/2;
        y2 = y1 + engine.de;
        engine.y=[y1 y2 y2 y1];
        
        fill(engine.x,engine.y,'y')
        hold on
        fill(engine.x,-engine.y,'y') % plot inverso
        axis equal
        hold on
    case 2
%         Livro 6 pag 116 fig 4.42 t/D = 0.6 ang=15
        engine.x(1)=0.97*fuselage.length-vt.c0-engine.length;
        engine.x(2)=0.97*fuselage.length-vt.c0-engine.length;
        engine.x(3)=0.97*fuselage.length-vt.c0;
        engine.x(4)=0.97*fuselage.length-vt.c0;

        engine.y(1)=fuselage.df/2+0.65*engine.de*cos(15*rad)-engine.de/2;
        engine.y(2)=fuselage.df/2+0.65*engine.de*cos(15*rad)+engine.de/2;
        engine.y(3)=fuselage.df/2+0.65*engine.de*cos(15*rad)+engine.de/2;
        engine.y(4)=fuselage.df/2+0.65*engine.de*cos(15*rad)-engine.de/2;

        fill(engine.x,engine.y,'b')
        hold on
        fill(engine.x,-engine.y,'b') % plot inverso
        axis equal
        hold on
    case 3
        engine.x=[fuselage.length-vt.c0-engine.length fuselage.length-vt.c0-engine.length fuselage.length-vt.c0 fuselage.length-vt.c0 fuselage.length-vt.c0-engine.length ];
        engine.y=[fuselage.df/2+0.65*engine.de*cos(15*rad)-engine.de/2 fuselage.df/2+0.65*engine.de*cos(15*rad)+engine.de/2 fuselage.df/2+0.65*engine.de*cos(15*rad)+engine.de/2 fuselage.df/2+0.65*engine.de*cos(15*rad)-engine.de/2 fuselage.df/2+0.65*engine.de*cos(15*rad)-engine.de/2];
        
        engine.x2=[fuselage.length-vt.c0/2+engine.length/2 fuselage.length-vt.c0/2+engine.length/2 fuselage.length-vt.c0/2-engine.length/2 fuselage.length-vt.c0/2-engine.length/2 fuselage.length-vt.c0/2+engine.length/2];
        engine.y2=[engine.de/2 -engine.de/2 -engine.de/2 engine.de/2 engine.de/2];
        
        plot(engine.x,engine.y)
        hold on
        plot(engine.x,-engine.y) % plot inverso
        hold on
        plot(engine.x2,engine.y2)
        axis equal
        hold on
    case 4
        % livro 6 pag 111 fig 4.41 x/l=0.6
        engine.x=[xle+wing.se*tan(rad*wing.sweepLE)-0.6*wing.ce xle+wing.se*tan(rad*wing.sweepLE)-0.6*wing.ce xle+wing.se*tan(rad*wing.sweepLE)-0.6*wing.ce+engine.length xle+wing.se*tan(rad*wing.sweepLE)-0.6*wing.ce+engine.length xle+wing.se*tan(rad*wing.sweepLE)-0.6*wing.ce];
        engine.y=[wing.se-engine.de/2 wing.se+engine.de/2 wing.se+engine.de/2 wing.se-engine.de/2 wing.se-engine.de/2];
        %motor externo
        engine.x2=[xle+wing.seout*tan(rad*wing.sweepLE)-0.6*wing.ceout xle+wing.seout*tan(rad*wing.sweepLE)-0.6*wing.ceout xle+wing.seout*tan(rad*wing.sweepLE)-0.6*wing.ceout+engine.length xle+wing.seout*tan(rad*wing.sweepLE)-0.6*wing.ceout+engine.length xle+wing.seout*tan(rad*wing.sweepLE)-0.6*wing.ceout];
        engine.y2=[wing.seout-engine.de/2 wing.seout+engine.de/2 wing.seout+engine.de/2 wing.seout-engine.de/2 wing.seout-engine.de/2];

        plot(engine.x,engine.y)
        hold on
        plot(engine.x,-engine.y) % plot inverso
        hold on
        plot(engine.x2,engine.y2)
        hold on
        plot(engine.x2,-engine.y2) % plot inverso
        axis equal
        hold on
end
%__________________________________________________________________________


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear aux aux1 aux2 auxfus auxfus2 xceg yceg x1 x2 y1 y2 