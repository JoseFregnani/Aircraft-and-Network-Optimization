clc

% TEST ACFT
MTOW =24044;
wS   =93;
ne   =2;
Tmax =(MTOW/22000)*8895;
ediam=1.11;
NPax =44;
KVA=75;

% Financial inputs
Share=0.6;
IR=0.05;
p =14;

[TOT_NPV,CASHFLOW,PV,IRR]=NPV(Share,IR,p,MTOW,wS,ne,Tmax,ediam,NPax,KVA);

CASHFLOW
PV
TOT_NPV
IRR
