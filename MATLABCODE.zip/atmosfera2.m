function [temp,pres] = atmosfera2(H)

% *************************************************************************
% ---- implementado modelo de atmosfera da NASA -----
% -- http://www.grc.nasa.gov/WWW/K-12/airplane/atmosmet.html
% --acessado dia 2/8/2008

% INPUT:    (H) - Altitude em metros
% OUTPUT:   (temp) - Temperatura em Kelvin
%           (pres) - Press�o em Pascal
% *************************************************************************
if (H<=11000)
    temp = 288.19-0.00649*H;
    pres = 101290*(temp/288.08)^5.256;
elseif (H<=25000)
    temp = 216.69;
    pres = 22650*exp(1.73-0.000157*H);
else
    temp = 141.94 + 0.0299*H;
    pres = 2488*(temp/216.6)^(-11.388);
end