function[CDoCL]= CDCL_mod (Sref,AR,afil,swet2,swetwing,LEsweep, ...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL)

% Calculates drad coefficient for the wing by ANN
% Drag coefficient ofr the rest of aircraft by Class I formulatin
[~, ~, DR, a] = atmos(h,ISADEV);
dens0 = 1.225;
g     = 9.80665;
kt2ms = 0.514;
ft2m  = 0.3048;
dens  = dens0*DR;
%
V=TAS*kt2ms; % [m/s]
M=TAS/a;
q=(1/2)*dens*(V^2);
CL=(W*g)/(q*Sref);
alfag = 1;
%
[CDwing, ~]=CDCLneural2(M, h*ft2m,CL, alfag,Sref,AR,afil,LEsweep,...
   inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL);
%
cfe    = 0.0030;
[CD0_ubrige] = cfe*(swet2-swetwing)/Sref;
%
CD    = CDwing + CD0_ubrige;
% efeito winglet
dcd_wlet=3e-04-4.2308e-03*CL*CL;
%
CD    = CD +dcd_wlet;
%
LD    = CL/CD;
CDoCL = 1/LD;
