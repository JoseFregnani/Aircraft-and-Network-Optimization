clc
clear all

AIRPLANE_MF()
NETWORK()