function [Airport,RTE,NA,f,LF,DIST,HDG]=NETWORKOPT_R01(MAXPAX,AVGDOC,SHARE,LFREF,TKTPRICE,K1,K2,RANGE);

% INIT DATA
b=MAXPAX;
c=AVGDOC;
MAXFREQ=10;
MINFREQ=2;
MAXHUB=3;
MINRANGE=100;
R=500; % Reference clustering radius (nm)

% LOAD AIRPORTS AND DEMAND DATA
[Airport,f,LF,DIST,HDG]=LOADAPT(SHARE,LFREF);
n=size(DIST,1);
N=n*n-n;
frac1=0.5;
frac2=0.3/(N-2);
frac3=0.2/(2*(N-2));

% calculate fraction of demand
for i=1:n
    for j=1:n
      for t=1:n
        for l=1:n  
          if t==l  
            %  
            if i==j
              X(i,t,l,j)=0;
            else  
              if or(t==i,t==j)
                  X(i,t,l,j)=frac1;
              else
                  X(i,t,l,j)=frac2;
              end          
            end 
            %
          else
            %  
            if i==j
              X(i,t,l,j)=0;
            else  
              if t~=i
                  X(i,t,l,j)=frac3;
              end          
            end 
            %        
          end          
        end
      end
    end
end 

% Objective function vector
fun=zeros(1,N);
k=1;
for i=1:n
  for j=1:n
      if (i~=j)
        fun(k)=-(K1*TKTPRICE-K2*c*DIST(i,j)/(b*LFREF));
        k=k+1;
      end 
  end  
end 

% Constraint vectors
PAX=zeros(1,n);
k=1;
for i=1:n
    for j=1:n
      if i~=j  
        PAX(k)=b*LF(i,j);
        k=k+1;
      end  
    end
end    

k=1;
for i=1:N
    for j=1:N
       if i==j
         A(i,j)=PAX(k);
         k=k+1;
       else
         A(i,j)=0;
       end
    end
end

B=zeros(1,N);
flag=1;

k=1;
for i=1:n;
  for j=1:n;
      if i~=j
        B(k)=f(i,j);
        for t=1:n
           for l=1:n 
             if l==t  
               if t~=i 
                 B(k)=B(k)+(f(i,t)*X(i,j,l,t)+f(t,i)*X(t,i,l,j)-f(i,j)*X(i,t,l,j));             
               end
             else
               if t~=i 
                 B(k)=B(k)+(f(l,j)*X(l,t,i,j)+f(i,t)*X(i,j,l,t)+f(l,t)*X(l,i,j,t)-f(i,j)*X(i,l,t,j));             
               end  
             end    
           end
        end;
        k=k+1;
      end  
  end  
end 

% Lower and upper bands
for i=1:N
  lb(1,i)=0;
  ub(1,i)=MAXFREQ;
end

intcon=[1:N];
options = optimoptions('intlinprog','Display','iter','Heuristics','advanced')
[Y,fval]=intlinprog(fun,intcon,A,B,[],[],lb,ub,options);

% Route assignment
k=1;
for i=1:n
    for j=1:n
      if i==j
         RTE(i,j)=0;
         NA(i,j)=0;
      else   
         if Y(k)>MINFREQ && DIST(i,j)>=MINRANGE
            RTE (i,j)=1;
            NA(i,j)=round(Y(k));
         else
            RTE (i,j)=0;
            NA(i,j)=0;
         end  
         k=k+1;
         if or(DIST(i,j)>RANGE,DIST(i,j)<MINRANGE)
            RTE (i,j)=0;
            NA(i,j)=0;
         end    
      end       
    end
end   

% Hub Locations
for i=1:n
   NA_dep=0; 
   for j=1:n    
     NA_dep=NA_dep+NA(i,j);
   end  
   Hub(i)=NA_dep;
end
for j=1:n
   NA_arr=0; 
   for i=1:n    
     NA_arr=NA_arr+NA(i,j);
   end  
   Hub(j)=Hub(j)+NA_arr;
end
for i=1:MAXHUB
  [M,k]=max(Hub);
  HNAME=Airport(k).name;
  HUBNAME(i)=string(HNAME);
  Hub(k)=0;
end

% plot network
figure (1)
for i=1:n
  LAT(i)=Airport(i).lat;
  LON(i)=Airport(i).lon;    
end    
plot(LON,LAT,'bo')

k=1;
for i=1:n    
  for j=1:n
      if i~=j
        if RTE(i,j)==1;  
          LAT1=Airport(i).lat;
          LON1=Airport(i).lon;           
          LAT2=Airport(j).lat;
          LON2=Airport(j).lon;         
          X=[LON1 LON2];          
          Y=[LAT1 LAT2];
          s(1,k)=i;
          t(1,k)=j;
          w(1,k)=NA(i,j);           
          k=k+1;
          line(X,Y);
          hold on          
        end  
      end
  end 
end
hold off   

RTE
NA
DIST
HDG
HUBNAME


