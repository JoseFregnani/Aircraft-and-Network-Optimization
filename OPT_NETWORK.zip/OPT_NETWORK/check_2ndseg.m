function w2seg=check_2ndseg(wS,wAR,wTR,wLEsweep,...
inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
neng,SWET,sWingSwe,longtras,clmaxt,MTOW,VTS,VTSweep,ediam,ebypass,...
NNind,NNwav,NNcd0,NNCL,cfe,dflecflaptakeoff)

% 2nd segment required T/W
g       = 9.80665;
rad     = pi/180;
%
cl2seg              = clmaxt/1.44;
V                   = sqrt(MTOW*g/(cl2seg*wS*0.50*1.225));
M                   = V/340;
%
alfagdummy = 1;
[CDwing, ~]=CDCLneural2(0.2, 0.,cl2seg, alfagdummy,wS,wAR,wTR,wLEsweep,...
    inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
%
[CD0_ubrige]        = cfe*(SWET-sWingSwe)/wS;
% oswaldfact2ndseg    = oswaldf(M,wAR,wSweep14,wTR,tcmed,nedebasa);
% oswaldfact2ndseg    = oswaldfact2ndseg*0.90;
%
bw                  = sqrt(wS*wAR);
%
% Drag increase due to flaps and rudder deflection
dcdflapetakeoff     = CD_flap(dflecflaptakeoff,longtras);
dcdrudder           = 0.0020*cos(rad*VTSweep)*(VTS/wS); 
%
% Windmilling drag(Torenbeek) 
jmach            = M;
VN               = 0.92; 
   if ebypass < 3.5
   VN = 0.42;
   end   
AN=pi*ediam*ediam/4;
term1=2/(1+0.16*jmach*jmach);
cdwindmilli=0.0785*(ediam*ediam)+term1*AN*VN*(1-VN);
%
% cdzero=cd0torenbeek(M,V,wS,bw,wTR,tcmed,FusDiam,0,SWET,0);
% cdind2seg=(cl2seg*cl2seg)/(pi*oswaldfact2ndseg*wAR);
cd2seg=CDwing+CD0_ubrige+dcdflapetakeoff+dcdrudder+(cdwindmilli/wS);
%
ld2seg=cl2seg/cd2seg;

w2seg = 1;
switch neng
case 2 
w2seg =2*(1/ld2seg+sin(0.024));
case 3
w2seg =(3/2)*(1/ld2seg+sin(0.027));
case 4
w2seg =(4/3)*(1/ld2seg+sin(0.03));
end
%
end