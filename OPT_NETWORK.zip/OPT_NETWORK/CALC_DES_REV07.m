function [dist,time,fuel]=CALC_DES_REV07...
    (S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,W,initalt,finalalt,DESCAS,...
    DESMACH,ISADEV,NNind,NNwav,NNcd0,NNCL)

% CONSTANTS
fpm2mps = 0.005;
kt2ms   = 0.514;
g       = 9.80665;
%
b       = sqrt(wAR*S);
%
[TA]=transitionalt(DESMACH,DESCAS,ISADEV);
%fprintf('\n => TA   = %5.0f',TA);

deltah=0;
deltaf=0;
deltas=0;
deltat=0;
timedes1=0;
timedes2=0;
timedes3=0;
d1=0;
d2=0;
d3=0;
fuel1=0;
fuel2=0;
fuel3=0;
Wf=W;

if initalt>TA
    flag1=1;
    flag2=1;
    flag3=1;
end
if and(initalt>10000,initalt<=TA)
    flag1=0;
    flag2=1;
    flag3=1;
end
if initalt<=10000
    flag1=0;
    flag2=0;
    flag3=1;
end

% DESCENT TO TA with CONSTANT MACH

if flag1==1
    
    hi=initalt;
    hf=TA;
    Hspan=[hi hf];
    IC=[0; W; 0]; 

    [h, T]= ode45(@(h,t) descida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,0,DESMACH,NNind,NNwav,NNcd0,NNCL),Hspan,IC);

    nstep    = size(T,1);
    timedes1 = T(nstep,1);
    Wf       = T(nstep,2);
    d1       = T(nstep,3);
    fuel1    = W-Wf;

    %fprintf('\n');
    %fprintf('\n => ALTi = %5.0f',hi);
    %fprintf('\n => ALTf = %5.0f',hf);
    %fprintf('\n => Wi   = %5.0f',W);
    %fprintf('\n => Wf   = %5.0f',Wf);
    %fprintf('\n => time = %5.1f',timedes1);
    %fprintf('\n => dist = %5.1f',d1);
    %fprintf('\n => fuel = %5.1f',fuel1);
    %fprintf('\n => AVG RD = %5.1f',(hf-hi)/timedes1);

    
end

if flag2==1 
  
    % DESCENT TO 10000ft with CONSTANT CAS
      
    W = Wf;
    hi=TA;
    hf=10000;
    Hspan=[hi hf];
    IC=[0; W; 0]; 
    
    [h, T]= ode45(@(h,t) descida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,DESCAS,0,NNind,NNwav,NNcd0,NNCL),Hspan,IC);

%     [h, T]= ode45(@(h,t) descida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
%         S,b,afil,tc,df,swet2,phi14,nedebasa,ISADEV,DESCAS,0,0),Hspan,IC);

    nstep    = size(T,1);
    timedes2 = T(nstep,1);
    Wf       = T(nstep,2);
    d2       = T(nstep,3);
    fuel2    = W-Wf;

    %fprintf('\n');
    %fprintf('\n => ALTi = %5.0f',hi);
    %fprintf('\n => ALTf = %5.0f',hf);
    %fprintf('\n => Wi   = %5.0f',W);
    %fprintf('\n => Wf   = %5.0f',Wf);
    %fprintf('\n => time = %5.1f',timedes2);
    %fprintf('\n => dist = %5.1f',d2);
    %fprintf('\n => fuel = %5.1f',fuel2);
    %fprintf('\n => AVG RD = %5.1f',(hf-hi)/timedes2);

    % DECEL FROM CAS to 250Kt @ 10000ft

    [deltat,deltas,deltaf,deltah]=DECEL_DESCASto250...
        (efanpr,eopr,ebypass,ediam,eTIT,DESCAS,ISADEV,-500,n,maneted);

end    

if flag3==1

    % DESCENT TO INITALT+1500 with CONSTANT 250

    W = Wf;
    if initalt<10000
        hi=initalt
    else    
        hi=10000-deltah;
    end
        
    hf=finalalt+1500;
    Hspan=[hi hf];
    IC=[0; W; 0]; 
    
    [h, T]= ode45(@(h,t) descida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,250,0,NNind,NNwav,NNcd0,NNCL),Hspan,IC);

    %[h, T]= ode45(@(h,t) descida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,S,b,afil,tc,df,swet2,phi14,nedebasa,ISADEV,250,0,0),Hspan,IC);

    nstep    = size(T,1);
    timedes3 = T(nstep,1);
    Wf       = T(nstep,2);
    d3        = T(nstep,3);
    fuel3    = W-Wf;
 
    %fprintf('\n');
    %fprintf('\n => ALTi = %5.0f',hi);
    %fprintf('\n => ALTf = %5.0f',hf);
    %fprintf('\n => Wi   = %5.0f',W);
    %fprintf('\n => Wf   = %5.0f',Wf);
    %fprintf('\n => time = %5.1f',timedes3);
    %fprintf('\n => dist = %5.1f',d3);
    %fprintf('\n => fuel = %5.1f',fuel3);
    %fprintf('\n => AVG RD = %5.1f',(hf-hi)/timedes3);

end
    
fuel   = fuel1 + fuel2 + fuel3+deltaf;
time   = timedes1+timedes2+timedes3+deltat;
dist   = d1+d2+d3+deltas;
