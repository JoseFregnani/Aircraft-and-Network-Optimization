%----------------------------------------------------------------------------------------------------------------------
%DESCRI��O E AUTORIA
%Nome       - atmosfp.m
%Descri��o  - Rotina para determina�ao das propriedades da atmosfera ISA e  off-ISA
%Autor      - Paulo Eduardo Cypriano da Silva Magalh�es
%Vers�o     - 1.0
%Data       - 22 de abril de 2009
%
%Dados de entrada: altitude-pressao, varia�ao da ISA, "flag" indicador do sistema de unidades
%Dados de saida  : Temperatura, densidade, pressao, velocidade do som
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pela refer�ncia bibliogr�fica n�1.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.
%----------------------------------------------------------------------------------------------------------------------


%----------------------------------------------------------------------------------------------------------------------
%NOMENCLATURA ADOTADA NO C�LCULO
%HP         - altitude [ft]
%DISA       - varia��o da temperatura padr�o [�C]
%Mach       - n�mero de Mach
%a          - velocidade do som [kt]
%theta      - raz�o de temperaturas
%delta      - raz�o de press�es
%sigma      - raz�o de densidades
%----------------------------------------------------------------------------------------------------------------------


function [theta, delta, sigma, a] = atmosfp(HP,DISA,Mach)


%----------------------------------------------------------------------------------------------------------------------
%CALCULO DAS PROPRIEDADES DA ATMOSFERA
%Calculo de theta

TROPO=(71.5+DISA)/0.0019812;
if HP <=TROPO
    theta = ((288.15-0.0019812*HP)+DISA)/288.15;
else
    theta = 216.65/288.15;
end
theta = theta * (1 + 0.2 * Mach ^ 2);
%Calculo de delta
if HP <=TROPO
    delta = ((288.15-0.0019812*HP+DISA)/288.15)^5.25588;
else
    delta = 0.22336*exp((TROPO-HP)/20805.1);
end
delta = delta * (1 + 0.2 * Mach ^ 2) ^ 3.5;
%Calculo de sigma
    sigma = delta/theta;
%Calculo de a
    a = 661.4786*theta^0.5;
%----------------------------------------------------------------------------------------------------------------------


%----------------------------------------------------------------------------------------------------------------------
%SAIDA DOS RESULTADOS
%saida = [theta, delta, sigma, a];
%----------------------------------------------------------------------------------------------------------------------


%----------------------------------------------------------------------------------------------------------------------
%REFER�NCIAS BIBLIOGR�FICAS
%[1] BOEING CO. Flight Operations Engineering - Performance Methods. 7th ed. Boeing Co.,Everett,Estados Unidos,1989.
%[2] BOEING CO. Summary of useful information for performance engineers. Boeing Co.,Everett,Estados Unidos,1989.
%----------------------------------------------------------------------------------------------------------------------