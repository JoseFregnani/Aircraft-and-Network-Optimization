function S=LD(LW,wS,ISADEV,elev,CLMAX_LD)

% Torenbeek (1996).Synthesis fo Subsonic Airplane Design. Chapter 6, Design For Performance (Pg.171, Eq.5-06)

% Constants
ft2m=0.3048;
Gamma=3;
g=9.8061;
Gamma_rad=(Gamma/180)*pi();
Hland=15.24;% 50ft screen height
avg_decel=0.4;% jet aircraft with gnd spoilers, anti skid and speed brakes
dn=0.1;% load factor during flare
fac=1.15;% Operational factor

% Calculation 
CLmax=CLMAX_LD;
h=elev;
[~, ~, sigma, ~] = atmos(h,ISADEV);
rho=1.22*sigma;
S1=1.69*(g*LW/wS)/(Hland*rho*g*CLmax);
S2=((1/avg_decel)*(1-(Gamma_rad^2)/dn)+Gamma_rad/dn); 
S=(1/Gamma_rad)+S1*S2;
S=fac*S*Hland;

