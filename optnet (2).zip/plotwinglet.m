function plotwinglet(semispan,SweepLE_winglet,AR_winglet,...
         TR_winglet,xLE_wing_ponta,Cponta,CantAngle_wlet,Z_wing_ponta)
 %
 rad            = pi/180;
 %
 CRaiz_winglet  = 0.75*Cponta;
 CPonta_winglet = CRaiz_winglet*TR_winglet;
 Span_winglet   = CRaiz_winglet*((1+TR_winglet)/2)*AR_winglet;
%  Swlet          = (CRaiz_winglet+CPonta_winglet)*Span_winglet/2;
 %
 %%%%%%%%%%%%%%%%%%%%%%%%%%% Read winglet airfoil
arq_input = ('pwlet.dat');

fid = fopen(arq_input);
fgetl(fid);
%fprintf(' \n %s \n',linhai);
icount=0;
while (~feof(fid))
    linha = fgetl(fid);
    READ=strread(linha);
    icount=icount+1;
    xp=READ(1);
    %
    yp=READ(2);
    xperwlet(icount)=xp;
    yperwlet(icount)=yp;
end
npwlet=icount;
fclose(fid);
% reinterpola perfil da ponta
npontos = 50;
xspline = (cos(pi:-pi/npontos:0)+1)/2.;
ds=[];
ds(1) = 0;
for i=1:1:(npwlet-1)
ds(i+1) = ds(i)+sqrt((xperwlet(i+1)-xperwlet(i))^2 + (yperwlet(i+1)-yperwlet(i))^2);
end


[xmin, indp]=min(xperwlet);
xaux   = xperwlet(1:1:indp);
dsaux  = ds(1:1:indp);
dsplin = spline(xaux,dsaux,xspline);
%nutip  = npontos+1;
xuwlet  = xspline;
yuwlet  = spline(ds,yperwlet,dsplin);
%
%nltip   = npontos+1;
xaux1   = xperwlet(indp:1:npwlet);
dsaux1  = ds(indp:1:npwlet);
dsplin1 = spline(xaux1,dsaux1,xspline);
xlwlet   = xspline;
ylwlet   = spline(ds,yperwlet,dsplin1);

xperwlet=[xuwlet(npontos+1:-1:2), xlwlet];
yperwlet=[yuwlet(npontos+1:-1:2), ylwlet];

xistosXper=[xLE_wing_ponta+0.25*Cponta+ CRaiz_winglet*xperwlet;...
    xLE_wing_ponta+0.25*Cponta+ Span_winglet*tan(rad*SweepLE_winglet)+CPonta_winglet*xperwlet];

[~, n]=size(xistosXper);

Y1per(1:n)= semispan;
Y2per(1:n)= semispan + Span_winglet;

% Y1per     = xistosYper(1,1:n);
% Y2per     = xistosYper(2,1:n);

Z1per     = Z_wing_ponta+CRaiz_winglet*yperwlet;
Z2per     = Z_wing_ponta+CPonta_winglet*yperwlet;


%
teta  =CantAngle_wlet;
tetar =teta*rad;
Y0        = semispan;
Z0         = Z_wing_ponta;

Y1peraux = Y0 + (Y1per-Y0)*cos(tetar)-(Z1per-Z0)*sin(tetar);
Z1per    = Z0 + (Y1per-Y0)*sin(tetar)+(Z1per-Z0)*cos(tetar);
Y1per    = Y1peraux;

Y2peraux = Y0+(Y2per-Y0)*cos(tetar)-(Z2per-Z0)*sin(tetar);
Z2per    = Z0+ (Y2per-Y0)*sin(tetar)+(Z2per-Z0)*cos(tetar);
Y2per    = Y2peraux;

xistosYper=[Y1per; Y2per];
xistosZper=[Z1per; Z2per];
%
surface(xistosXper,xistosYper,xistosZper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xistosXper,-xistosYper,xistosZper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
%