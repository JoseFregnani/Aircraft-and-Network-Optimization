clc

filename='parameters.dat';
fid = fopen(filename);

    MTOW           = str2num(fgetl(fid));
    MLW            = str2num(fgetl(fid));
    MZFW           = str2num(fgetl(fid));
    OEW            = str2num(fgetl(fid));
    MAXFUEL        = str2num(fgetl(fid));
    wS             = str2num(fgetl(fid));
    wSft2          = str2num(fgetl(fid));
    wAR            = str2num(fgetl(fid));
    wTR            = str2num(fgetl(fid));
    wSweep14       = str2num(fgetl(fid));
    wTwist         = str2num(fgetl(fid));
    CLMAX          = str2num(fgetl(fid));
    PWing          = str2num(fgetl(fid));
    VTarea         = str2num(fgetl(fid));
    VTAR           = str2num(fgetl(fid));
    VTTR           = str2num(fgetl(fid));
    VTSweep        = str2num(fgetl(fid));
    HTarea         = str2num(fgetl(fid));
    HTAR           = str2num(fgetl(fid));
    HTTR           = str2num(fgetl(fid));
    PHT            = str2num(fgetl(fid));
    NPax           = str2num(fgetl(fid));
    NCorr          = str2num(fgetl(fid));
    NSeat          = str2num(fgetl(fid));
    ncrew          = str2num(fgetl(fid));
    AisleWidth     = str2num(fgetl(fid)); 
    CabHeightm     = str2num(fgetl(fid));
    Kink_semispan  = str2num(fgetl(fid));
    SEATwid        = str2num(fgetl(fid));
    widthreiratio  = str2num(fgetl(fid));
    inc_root       = str2num(fgetl(fid));
    inc_kink       = str2num(fgetl(fid));
    inc_tip        = str2num(fgetl(fid));    
    MMO            = str2num(fgetl(fid));
    VMO            = str2num(fgetl(fid)); 
    PEng           = str2num(fgetl(fid)); 
    MAXRATE        = str2num(fgetl(fid)); 
    n              = str2num(fgetl(fid)); 
    nedebasa       = str2num(fgetl(fid)); 
    ebypass        = str2num(fgetl(fid)); 
    ediam          = str2num(fgetl(fid)); 
    efanpr         = str2num(fgetl(fid)); 
    eopr           = str2num(fgetl(fid));
    eTIT           = str2num(fgetl(fid)); 
    wTCmed         = str2num(fgetl(fid));
    fus_width      = str2num(fgetl(fid));
    fus_height     = str2num(fgetl(fid));
    FusDiam        = str2num(fgetl(fid));
    Airp_SWET      = str2num(fgetl(fid));
    wingSwet       = str2num(fgetl(fid));
    lf             = str2num(fgetl(fid));
    lco            = str2num(fgetl(fid));
    wMAC           = str2num(fgetl(fid));
    wSweepLE       = str2num(fgetl(fid));
    Ccentro        = str2num(fgetl(fid));
    Craiz          = str2num(fgetl(fid));
    Cquebra        = str2num(fgetl(fid));
    Cponta         = str2num(fgetl(fid));
    T0             = str2num(fgetl(fid));
    swet2          = str2num(fgetl(fid));
    container_type = fgetl(fid);
    
    for i=1:3
        r0(1,i)     = str2num(fgetl(fid))
        t_c(1,i)    = str2num(fgetl(fid))
        phi(1,i)    = str2num(fgetl(fid))
        X_tcmax(1,i)= str2num(fgetl(fid))
        theta(1,i)  = str2num(fgetl(fid))
        epsilon(1,i)= str2num(fgetl(fid))
        X_Ycmax(1,i)= str2num(fgetl(fid))
        Ycmax(1,i)  = str2num(fgetl(fid))
        YCtcmax(1,i)= str2num(fgetl(fid))
    end
    
    for i=1:51
        xutip(1,i)  = str2num(fgetl(fid))
        yutip(1,i)  = str2num(fgetl(fid)) 
        xltip(1,i)  = str2num(fgetl(fid))
        yltip(1,i)  = str2num(fgetl(fid)) 
        xukink(1,i) = str2num(fgetl(fid))
        yukink(1,i) = str2num(fgetl(fid)) 
        xlkink(1,i) = str2num(fgetl(fid))
        ylkink(1,i) = str2num(fgetl(fid)) 
        xuroot(1,i) = str2num(fgetl(fid))
        yuroot(1,i) = str2num(fgetl(fid))
        xlroot(1,i) = str2num(fgetl(fid))
        ylroot(1,i) = str2num(fgetl(fid))
    end      
    RANGE          = str2num(fgetl(fid));
    BLK1           = str2num(fgetl(fid));
       
   
       

