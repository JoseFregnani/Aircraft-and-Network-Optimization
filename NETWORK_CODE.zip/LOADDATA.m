function [wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2]=LOADDATA();

fid = fopen('parameters.dat');

    wS             = str2num(fgetl(fid));
    wSft2          = str2num(fgetl(fid));
    wAR            = str2num(fgetl(fid));
    wTR            = str2num(fgetl(fid));
    wSweep14       = str2num(fgetl(fid));
    wTwist         = str2num(fgetl(fid));
    CLMAX          = str2num(fgetl(fid));
    PWing          = str2num(fgetl(fid));
    VTarea         = str2num(fgetl(fid));
    VTAR           = str2num(fgetl(fid));
    VTTR           = str2num(fgetl(fid));
    VTSweep        = str2num(fgetl(fid));
    HTarea         = str2num(fgetl(fid));
    HTAR           = str2num(fgetl(fid));
    HTTR           = str2num(fgetl(fid));
    PHT            = str2num(fgetl(fid));
    NPax           = str2num(fgetl(fid));
    NCorr          = str2num(fgetl(fid));
    NSeat          = str2num(fgetl(fid));
    ncrew          = str2num(fgetl(fid));
    AisleWidth     = str2num(fgetl(fid)); 
    CabHeightm     = str2num(fgetl(fid));
    Kink_semispan  = str2num(fgetl(fid));
    SEATwid        = str2num(fgetl(fid));
    widthreiratio  = str2num(fgetl(fid));
    inc_root       = str2num(fgetl(fid));
    inc_kink       = str2num(fgetl(fid));
    inc_tip        = str2num(fgetl(fid));    
    MMO            = str2num(fgetl(fid));
    VMO            = str2num(fgetl(fid)); 
    PEng           = str2num(fgetl(fid)); 
    MAXRATE        = str2num(fgetl(fid)); 
    n              = str2num(fgetl(fid)); 
    nedebasa       = str2num(fgetl(fid)); 
    ebypass        = str2num(fgetl(fid)); 
    ediam          = str2num(fgetl(fid)); 
    efanpr         = str2num(fgetl(fid)); 
    eopr           = str2num(fgetl(fid));
    eTIT           = str2num(fgetl(fid)); 
    wTCmed         = str2num(fgetl(fid));
    fus_width      = str2num(fgetl(fid));
    fus_height     = str2num(fgetl(fid));
    FusDiam        = str2num(fgetl(fid));
    Airp_SWET      = str2num(fgetl(fid));
    wingSwet       = str2num(fgetl(fid));
    lf             = str2num(fgetl(fid));
    lco            = str2num(fgetl(fid));
    wMAC           = str2num(fgetl(fid));
    wSweepLE       = str2num(fgetl(fid));
    Ccentro        = str2num(fgetl(fid));
    Craiz          = str2num(fgetl(fid));
    Cquebra        = str2num(fgetl(fid));
    Cponta         = str2num(fgetl(fid));
    T0             = str2num(fgetl(fid));
    swet2          = str2num(fgetl(fid));
    container_type = fgetl(fid);
    
    for i=1:3
        r0(1,i)     = str2num(fgetl(fid));
        t_c(1,i)    = str2num(fgetl(fid));
        phi(1,i)    = str2num(fgetl(fid));
        X_tcmax(1,i)= str2num(fgetl(fid));
        theta(1,i)  = str2num(fgetl(fid));
        epsilon(1,i)= str2num(fgetl(fid));
        X_Ycmax(1,i)= str2num(fgetl(fid));
        Ycmax(1,i)  = str2num(fgetl(fid));
        YCtcmax(1,i)= str2num(fgetl(fid));
    end
    
    for i=1:51
        xutip(1,i)  = str2num(fgetl(fid));
        yutip(1,i)  = str2num(fgetl(fid)); 
        xltip(1,i)  = str2num(fgetl(fid));
        yltip(1,i)  = str2num(fgetl(fid)); 
        xukink(1,i) = str2num(fgetl(fid));
        yukink(1,i) = str2num(fgetl(fid)); 
        xlkink(1,i) = str2num(fgetl(fid));
        ylkink(1,i) = str2num(fgetl(fid)); 
        xuroot(1,i) = str2num(fgetl(fid));
        yuroot(1,i) = str2num(fgetl(fid)); 
        xlroot(1,i) = str2num(fgetl(fid));
        ylroot(1,i) = str2num(fgetl(fid));
    end  
       
fclose(fid);

%         fprintf('%6.2f\n',wS);
%         fprintf('%6.2f\n',wSft2);
%         fprintf('%6.2f\n',wAR);  
%         fprintf('%6.2f\n',wTR);
%         fprintf('%6.2f\n',wSweep14);
%         fprintf('%6.2f\n',wTwist); 
%         fprintf('%6.2f\n',CLMAX);
%         fprintf('%6.2f\n',PWing);
%         fprintf('%6.2f\n',VTarea);
%         fprintf('%6.2f\n',VTAR); 
%         fprintf('%6.2f\n',VTTR);
%         fprintf('%6.2f\n',VTSweep);
%         fprintf('%6.2f\n',HTarea);
%         fprintf('%6.2f\n',HTAR);
%         fprintf('%6.2f\n',HTTR);
%         fprintf('%6.2f\n',PHT);
%         
%         fprintf('%6.2f\n',NPax);
%         fprintf('%6.2f\n',NCorr);
%         fprintf('%6.2f\n',NSeat);
%         fprintf('%3.0f\n',ncrew);
%         fprintf('%6.2f\n',AisleWidth);  
%         fprintf('%6.2f\n',CabHeightm); 
%         fprintf('%6.2f\n',Kink_semispan);
%         fprintf('%6.2f\n',SEATwid);
%         fprintf('%6.2f\n',widthreiratio);
%      
%         fprintf('%6.2f\n',inc_root);
%         fprintf('%6.2f\n',inc_kink);
%         fprintf('%6.2f\n',inc_tip);
%         fprintf('%6.2f\n',MMO);
%         fprintf('%6.2f\n',VMO);
%         fprintf('%6.2f\n',PEng);
%         fprintf('%6.2f\n',MAXRATE);
%         fprintf('%6.2f\n',n);
%         fprintf('%6.2f\n',nedebasa);
%         fprintf('%6.2f\n',ebypass);
%         fprintf('%6.2f\n',ediam);
%         fprintf('%6.2f\n',efanpr);
%         fprintf('%6.2f\n',eopr);
%         fprintf('%6.2f\n',eTIT);   
%         
%         fprintf('%6.2f\n',wTCmed);
%         fprintf('%6.2f\n',fus_width);
%         fprintf('%6.2f\n',fus_height);
%         fprintf('%6.2f\n',FusDiam);
%         
%         fprintf('%6.2f\n',Airp_SWET);
%         fprintf('%6.2f\n',wingSwet);
%         fprintf('%6.2f\n',lf);
%         fprintf('%6.2f\n',lco);
%         fprintf('%6.2f\n',wMAC);
%         fprintf('%6.2f\n',wSweepLE);
%         fprintf('%6.2f\n',Ccentro);
%         fprintf('%6.2f\n',Craiz);
%         fprintf('%6.2f\n',Cquebra);
%         fprintf('%6.2f\n',Cponta);
%         
%         fprintf('%6.2f\n',T0);
%         fprintf('%6.2f\n',swet2);        
%       
%         container_type           
%                      
%         r0
%         t_c
%         phi
%         X_tcmax
%         theta
%         epsilon
%         Ycmax
%         YCtcmax
%         X_Ycmax
%           
%         xutip
%         yutip
%         xltip
%         yltip
%         xukink
%         yukink
%         xlkink
%         ylkink
%         xuroot
%         yuroot
%         xlroot
%         ylroot
%         
% 
% 
% 
