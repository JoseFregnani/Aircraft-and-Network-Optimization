%% DESCRI��O E AUTORIA %%
%bocal    - Rotina para estimativa do ruido de jato de motores a rea��o
%autores  - Daniel ...
%           Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP          - altitude-press�o [ft]
%                   DISA        - varia��o da temperatura em rela��o � ISA [�C]
%                   RH          - relative humidity [%]
%                   vairp       - velocidade do avi�o [m/s]
%                   teta        - dire��o para avalia��o do ru�do [deg]
%                   fi          - eleva��o para avalia��o do ru�do [deg]
%                   R           - dist�ncia para avalia��o do ru�do [m]
%                   plug        - flag para a presen�a de plug no escapamento
%                   coaxial     - flag para a presen�a de escoamento coaxial
%                   ACJ         - �rea de escape do jato central [m�]
%                   ABJ         - �rea de escape do jato perif�rico [m�]
%                   h           - altura do gap no plug [m]
%                   DCJ         - di�metro do escape do jato central [m]
%                   VCJ         - velocidade do jato central [m/s]
%                   VBJ         - velocidade do jato perif�rico [m/s]
%                   TCJ         - temperatura do jato central [K]
%                   TBJ         - temperatura do jato perif�rico [K]
%                   roCJ        - densidade dos gases no jato central [kg/m�]
%                   roBJ        - densidade dos gases no jato perif�rico [kg/m�]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Daniel ...                              Vers�o original (Bocal)
%2.0        Paulo Eduardo Cypriano      21-08-09    Remo��o da plotagem de gr�ficos
%3.0        Paulo Eduardo Cypriano      19-01-13    Uniformiza��o dos calculos atmosfericos
%4.0        Paulo Eduardo Cypriano      18-03-13    Corre��es nos c�lculos


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft ruidoJatot] = Bocal3(HP,DISA,RH,vairp,teta,fi,R,plug,coaxial,ACJ,ABJ,h,DCJ,VCJ,VBJ,TCJ,TBJ,roCJ,roBJ)


%% Vari�veis globais
%global f
f                  = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];


%% Fatores de convers�o
%global m2ft deg2rad
deg2rad = pi/180;
m2ft = 3.28084;

%% Tabelas para interpola��o
ARPtab              = [0;.05;.1;.15;.2;.25;.3;.35;.4;.45;.5;.55;.6;.65;.7;.75;.8;.85;.9;.95;1;1.05;1.1;1.15;1.2;1.25;1.3;1.35;1.4;1.45;1.5;1.55;1.6;1.65;1.7];
VRtab               = [0.2 0.4 0.6 0.8 1];
FSPtab              = [ 0.0    4.0    7.0   11.0   14.0   16.0   19.0   21.0   24.0   25.0   27.0   28.0   28.0   29.0   29.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0   30.0;
                        0.0    5.0    9.0   13.0   17.0   21.0   25.0   28.0   31.0   35.0   38.0   41.0   43.0   46.0   48.0   51.0   53.0   55.0   57.0   59.0   61.0   63.0   65.0   66.0   68.0   69.0   71.0   72.0   73.0   74.0   76.0   77.0   78.0   79.0   80.0;
                        0.0    6.0   12.0   18.0   23.0   28.0   33.0   37.0   41.0   45.0   48.0   51.0   53.0   56.0   59.0   61.0   64.0   65.0   67.0   69.0   71.0   73.0   74.0   75.0   77.0   78.0   79.0   81.0   82.0   83.0   84.0   85.0   86.0   87.0   88.0;
                        0.0    5.0   10.0   15.0   20.0   25.0   29.0   33.0   37.0   40.0   43.0   46.0   48.0   52.0   54.0   56.0   59.0   61.0   63.0   64.0   65.0   68.0   69.0   70.0   72.0   73.0   74.0   75.0   76.0   77.0   78.0   80.0   81.0   82.0   82.5;
                        0.0    4.0    8.0   12.0   16.0   20.0   23.0   26.0   30.0   32.0   35.0   38.0   41.0   43.0   45.0   48.0   50.0   52.0   54.0   56.0   58.0   60.0   61.0   63.0   65.0   66.0   67.0   69.0   70.0   71.0   73.0   74.0   75.0   76.0   77.0]'/100;
logStab             = [-1.7;-1.6;-1.5;-1.4;-1.3;-1.2;-1.1;-1;-0.9;-0.8;-0.7;-0.6;-0.5;-0.4;-0.3;-0.2;-0.1;0;0.1;0.2;0.3;0.4;0.5;0.6;0.7;0.8;0.9;1;1.1;1.2;1.3;1.4;1.5;1.6;1.7;1.8;1.9];
tetatab             = [109.9 120 130 140 150 160 170 180.1];
SDLtab              = -[39.1 36.8 34.5 32.3 30.0 27.7 25.4 23.2 21.1 19.1 17.4 15.9 14.7 13.7 12.8 12.1 11.6 11.3 11.1 11.2 11.3 11.7 12.3 13.0 13.7 14.6 15.6 16.7 17.8 18.9 20.1 21.3 22.4 23.6 24.8 26.0 27.2;
                        42.4 40.0 37.6 35.2 32.8 30.4 28.0 25.6 23.2 20.8 18.5 16.2 14.1 12.2 10.9 10.2 09.9 10.2 10.6 11.1 11.8 12.7 13.7 14.7 15.8 16.9 18.0 19.2 20.4 21.6 22.8 24.0 25.2 26.4 27.6 28.8 30.0;
                        43.0 40.2 37.4 34.6 31.8 29.0 26.2 23.4 20.6 17.8 15.2 13.1 11.5 10.2 09.6 09.3 09.6 10.2 11.4 12.7 14.0 15.3 16.6 18.0 19.3 20.7 22.0 23.4 24.7 26.1 27.5 28.8 30.2 31.5 32.8 34.1 35.5;
                        44.5 41.3 38.2 35.0 31.8 28.7 25.5 22.4 19.3 16.1 13.2 11.3 10.0 09.4 09.1 09.4 09.9 10.9 12.4 14.0 15.6 17.2 18.8 20.4 22.1 23.7 25.3 26.9 28.5 30.1 31.7 33.3 34.9 36.5 38.1 39.7 41.3;
                        42.4 39.3 36.2 33.1 29.9 26.9 23.6 20.5 17.5 14.7 12.1 09.9 08.3 07.7 08.3 09.7 11.6 13.4 15.2 17.0 18.8 20.6 22.3 24.1 25.9 27.7 29.5 31.3 33.1 34.9 36.7 38.5 40.3 42.0 43.8 45.6 47.4;
                        36.4 31.9 27.9 24.3 21.1 18.3 15.9 13.8 12.1 10.8 09.9 09.2 08.7 09.2 10.2 12.0 13.9 15.8 17.7 19.6 21.5 23.4 25.3 27.2 29.1 31.0 32.9 34.8 36.7 38.6 40.5 42.4 44.3 46.2 48.1 50.0 51.9;
                        32.8 28.7 25.0 21.7 18.8 16.3 14.1 12.3 10.9 09.8 09.0 08.5 09.0 10.0 11.8 13.8 15.8 17.8 19.8 21.8 23.8 25.8 27.8 29.8 31.8 33.8 35.8 37.8 39.8 41.8 43.8 45.8 47.8 49.8 51.8 53.8 55.8;
                        29.4 25.6 22.2 19.2 16.6 14.3 12.4 10.9 09.7 08.9 08.4 08.9 09.9 11.8 13.9 16.0 18.1 20.2 22.3 24.4 26.5 28.6 30.7 32.8 34.9 37.0 39.1 41.2 43.3 45.4 47.5 49.6 51.7 53.8 55.9 58.0 60.1]';

                    
%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
Acorejet            = ACJ;                                                  % �rea do jato central [m�]
Abypassjet          = ABJ;                                                  % area do jato perfif�rico [m�]
hgap                = h;                                                    % diferen�a entre os di�metros do jato central e do plug [m]
D                   = DCJ;                                                  % di�metro dojato central [m]
De                  = 2*sqrt(D*hgap-hgap^2);                                % di�metro equivalente [m]
v0                  = vairp;                                                % velocidade da aeronave [m/s]
radialdistance      = R;                                                    % dist�ncia para avalia��o do ru�do [m]


%% Dados da atmosfera %%
atm                 = atmosfera(HP*m2ft,DISA);                              % propriedades da atmosfera
T                   = atm(1);                                               % temperatura ambiente [K]
ro0                 = atm(6);                                               % densidade ambiente [kg/m�]
vsom                = atm(7);                                               % velocidade do som [m/s]


%% C�lculos iniciais %%
M0                  = v0/vsom;                                              % n�mero de Mach da aeronave
tetalinha           = teta*(VCJ/vsom)^0.1;                                  % �ngulo efetivo para c�lculo do ru�do
w                   = 3*(VCJ/vsom)^3.5/(0.60+(VCJ/vsom)^3.5)-1;             % expoente de corre��o do ru�do devido � densidade do jato de escape
vrel                = (VCJ/vsom)*(1-v0/VCJ)^0.75;                           % velocidade relativa do escoamento
Mc                  = 0.62*(VCJ-v0)/vsom;                                   % raz�o entre a velocidade relativa do jato ao avi�o e a velocidade do som

%% Ruido para jato circular %%
OASPLcirc           = 10*log10(Acorejet/radialdistance^2*(ro0/1.225)^2*(vsom/340)^4)+10*(3*vrel^3.5/(0.6+vrel^3.5)-1)*log10(roCJ/ro0)+141+10*log10(vrel^7.5/(1+0.01*vrel^4.5));

%% Ruido para jato plugue %%
termo1              = 10*log10((Acorejet/radialdistance^2)*(ro0/1.225)^2*(vsom/340.3)^4);
termo2              = 10*(3*vrel^3.5/(0.6+vrel^3.5)-1)*log10(roCJ/ro0);
termo3              = 141;
termo4              = 3*log10(0.1+2*hgap/D);
termo5              = 10*log10(vrel^7.5/(1+0.01*vrel^4.5));
OASPLplug           = termo1+termo2+termo3+termo4+termo5;

%% Ruido para jato coaxial, plugue ou circular %%
if (Abypassjet/Acorejet)<29.7
    m               = 1.1*sqrt(Abypassjet/Acorejet);
else
    m               = 6.0;
end
termo1              = 5*log10((TCJ)/(TBJ));
termo2              = (1-VBJ/VCJ)^m;
termo3              = 1.2*(1+(Abypassjet*VBJ^2)/(Acorejet*VCJ^2))^4;
termo4              = (1+(Abypassjet/Acorejet))^3;
deltaOASPLcoaxial   = termo1+10*log10(termo2+termo3/termo4);
OASPL90plug         = OASPLplug+deltaOASPLcoaxial;
OASPL90circ         = OASPLcirc+deltaOASPLcoaxial;

ARP                 = log10(1+Abypassjet/Acorejet);                         % Area ratio parameter
vratio              = VBJ/VCJ;
minvratio           = min(VRtab);
if vratio<minvratio
    VBJ      = minvratio*VCJ;
end
FSP                 = interp2(VRtab,ARPtab,FSPtab,VBJ/VCJ,ARP);

%% Corre��o espectral
S_S1                = 1/(1-FSP*((TBJ)/(TCJ)));
termo1              = S_S1;
termo2              = De/VCJ;
termo3              = (2*hgap/De)^0.4;
termo4              = ((TCJ)/T)^(0.4*(1+cos(tetalinha*pi/180)));
S_f                 = termo1*termo2*termo3*termo4;
logS                = log10(S_f*f);

%% Espectro de frequ�ncias %%
cdf                 = 30*log10(1+Mc*(1+Mc^5)^0.2)*cos(teta*deg2rad);        % ordenada do gr�fico do espectro %
if tetalinha<110
    tetalinha       = 110;
end
if tetalinha>180
    tetalinha       = 180;
end
tetainterp          = tetalinha;
% logS
ai1                 = length(logS);
for iai1=1:ai1
    if logS(iai1)<min(logStab)
        logS(iai1) = min(logStab);
    end
    if logS(iai1)>max(logStab)
        logS(iai1) = max(logStab);
    end
end

% c�lculos
aux0                = numel(logS);
aux1                = isfinite(logS);
aux2                = sum(isfinite(aux0),1);
aux3                = sum(aux1,2);
if aux3==aux0 && aux2==1
    SDL             = interp2(tetatab,logStab,SDLtab,tetainterp,logS);
else
    SDL             = ones(size(logStab));
end

SPLcoaxial          = OASPL90plug*(plug==1)+OASPL90circ*(plug==0)+SDL-cdf; 
SPLplug             = OASPL90plug+SDL-cdf;
SPLcirc             = OASPL90circ+SDL-cdf;
if plug==0
    SPLJet          = SPLcirc';
else
    if coaxial ==0
        SPLJet      = SPLplug';
    else
        SPLJet      = SPLcoaxial';
    end
end


%% Atenua��o do ru�do na atmosfera %%
[ft alfaamortt amorttott deltaLamort SPLrt] = amort(T,RH,radialdistance,f);


%% DADOS DE SAIDA %%
ruidoJato           = SPLJet-deltaLamort';
ft                  = f';
ruidoJatot          = ruidoJato';

a1                  = length(ruidoJatot);
for ia1=1:a1
    if ruidoJatot(ia1)<1
        ruidoJatot(ia1) = 1;
    end
end


%% VERIFICA��ES EM DEBUG
% figure()
% semilogx(f,SPLJet,'o-b');
% grid on;
% legend('Jet noise');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - NASA TM X-71618 - Interim prediction method for jet noise
%2 - ESDU77022 - Atmospheric properties