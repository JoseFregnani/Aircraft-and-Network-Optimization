function y = RTEKML (LAT1,LON1,LAT2,LON2,NETNAME);

n=size(LAT1,2);
LIN = strings([n*n,1]);

% FILE PARAMETERS SET UP
LIN(1)='<?xml version="1.0" encoding="UTF-8"?>';
LIN(2)='<kml xmlns="http://www.opengis.net/kml/2.2">';
LIN(3)='<Document>';
LIN(4)='        <Folder>';
LIN(5)='          <name>NETWORK01</name>  ';
LIN(6)='              <Style>';
LIN(7)='                <LineStyle>';
LIN(8)='                   <color>ffff0055</color> <width>2</width>';
LIN(9)='                </LineStyle>';
LIN(10)='             </Style>';
i=11;
for k=1:n
    LIN(i)  ='      <Placemark>       ';
    LIN(i+1)='             <LineString>';
    s1='                <coordinates> ';
    s2=num2str(LON1(k));
    s3=',';
    s4=num2str(LAT1(k));
    s5=string(blanks(1));
    s6=num2str(LON2(k));
    s7=',';
    s8=num2str(LAT2(k));
    s9='';
    s10='</coordinates>';
    s=strcat(s1,s2,s3,s4,s5,s6,s7,s8,s9,s10);
    LIN(i+2)=s;
    LIN(i+3)='             </LineString>';
    LIN(i+4)='     	</Placemark>';    
    i=i+5;
end
LIN(i)='       </Folder>';
LIN(i+1)='</Document>';
LIN(i+2)='</kml>';
N=i+2;

if exist(NETNAME)
  delete(NETNAME);
end

% SAVE PARAMETERS TO INPUT FILE

  fid=fopen(NETNAME,'w+');
  for i=1:N 
     fprintf(fid,'%s\n',LIN(i));
  end
  fclose(fid);

