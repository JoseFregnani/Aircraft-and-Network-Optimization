%% DESCRI��O E AUTORIA %%
%calcNOY  - Rotina para covers�o de SPL em Noys
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   NOY         - ru�do [NOY]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-08-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [f,NOY] = calcNOY(f,SPL)


%% CORPO DA FUN��O %%
%% Tabelas para c�lculo %%
fref                = [00050 00063 00080 00100 00125 00160 00200 00250 00315 00400 00500 00630 00800 01000 01250 01600 02000 02500 03150 04000 05000 06300 08000 10000];
SPLa                = [91.00 85.90 87.30 79.90 79.80 76.00 74.00 74.90 94.60 inf   inf   inf   inf   inf   inf   inf   inf   inf   inf   inf   inf   inf   44.30 50.70];
SPLb                = [64.00 60.00 56.00 53.00 51.00 48.00 46.00 44.00 42.00 40.00 40.00 40.00 40.00 40.00 38.00 34.00 32.00 30.00 29.00 29.00 30.00 31.00 37.00 41.00];
SPLc                = [52.00 51.00 49.00 47.00 46.00 45.00 43.00 42.00 41.00 40.00 40.00 40.00 40.00 40.00 38.00 34.00 32.00 30.00 29.00 29.00 30.00 31.00 34.00 37.00];
SPLd                = [49.00 44.00 39.00 34.00 30.00 27.00 24.00 21.00 18.00 16.00 16.00 16.00 16.00 16.00 15.00 12.00 09.00 05.00 04.00 05.00 06.00 10.00 17.00 21.00];
SPLe                = [55.00 51.00 46.00 42.00 39.00 36.00 33.00 30.00 27.00 25.00 25.00 25.00 25.00 25.00 23.00 21.00 18.00 15.00 14.00 14.00 15.00 17.00 23.00 29.00];
Mb                  = [0.043478 0.040570 0.036831 0.036831 0.035336 0.033333 0.033333 0.032051 0.030675 0.030103 0.030103 0.030103 0.030103 0.030103 0.030103 0.029960 0.029960 0.029960 0.029960 0.029960 0.029960 0.029960 0.042285 0.042285];
Mc                  = [0.030103 0.030103 0.030103 0.030103 0.030103 0.030103 0.030103 0.030103 0.030103 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.000000 0.029960 0.029960];
Md                  = [0.079520 0.068160 0.068160 0.059640 0.053103 0.053103 0.053103 0.053103 0.053103 0.053103 0.053103 0.053103 0.053103 0.053103 0.059640 0.053103 0.053103 0.047712 0.047712 0.053103 0.053103 0.068160 0.079520 0.059640];
Me                  = [0.058098 0.058098 0.052288 0.047534 0.043573 0.043573 0.040221 0.037349 0.034859 0.034859 0.034859 0.034859 0.034859 0.034859 0.034859 0.040221 0.037349 0.034859 0.034859 0.034859 0.034859 0.037349 0.037349 0.043573];

%% Compara��o das frequencias %%



%% Defini��es dos loops %%
a1                  = max(size(f));
[a2 a3]             = size(SPL);

%% Convers�o de SPL em NOY %%
for i2 = 1:a3
    for i1 = 1:24
        if SPL(i1,i2)>=SPLa(i1)
            n(i1,i2) = 10^(Mc(i1)*(SPL(i1,i2)-SPLc(i1)));
        end
        if (SPL(i1,i2)<SPLa(i1) && SPL(i1,i2)>=SPLb(i1))
            n(i1,i2) = 10^(Mb(i1)*(SPL(i1,i2)-SPLb(i1)));
        end
        if (SPL(i1,i2)<SPLb(i1) && SPL(i1,i2)>=SPLe(i1))
            n(i1,i2) = 0.3*10^(Me(i1)*(SPL(i1,i2)-SPLe(i1)));
        end
        if (SPL(i1,i2)<SPLe(i1) && SPL(i1,i2)>=SPLd(i1))
            n(i1,i2) = 0.1*10^(Md(i1)*(SPL(i1,i2)-SPLd(i1)));
        end
    end
end



%% DADOS DE SAIDA %%
NOY                 = n;


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T. Aircraft Noise (1989)
%2 - ICAO - Annex 16 - Environmental Protection ()