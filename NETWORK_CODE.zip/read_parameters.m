function [Range,DOC,MMO,Ceiling, MTOW_kg, OEW_kg,MLW,...
         MZFW,PEng, PHT,PWing,slat,lco,ltail,lf,...
		 fus_w,fus_h,FUSELAGE_Dz_floor, FusSwet_m2,container_type,...
		 NSeat, NPax,NCorr,CabHeightm,AisleWidth,...
		 SEATwid,SeatPitch,fuselagefuelcapacity_kg,...
		 wS,wAR,wTR, Ccentro, Craiz, Cquebra,Cponta,...
		 iroot, ikink, itip, tcroot,tcbreak,tctip,...
		 wingb, yposeng, wingdi, xle, wSweepLE,...
		 wSweep14,wingSwet,bflap, posaileron, longtras,...
		 flap_area_m2, Flap_def_take, Flap_def_land,...
		 wingfuelcapacity_kg,arh, sweepLEht, crootht,...
		 ctipht, arv, sweepLEvt,crootvt, ctipvt,...
		 EnginLength_m, BPR, OPR, FANPR, DFAN, eTIT,...
		 DX_Eng, ESwet, DZ_Pylon,mlg,nlg,wlet_present,...
         SweepLE_winglet, AR_winglet, TR_winglet,...
		 CantAngle_wlet,Twist_wlet]= read_parameters(file_name)
% read data contained in file file_name or analogous
%----------------------------------------------------------%
% Variables that are read by these routine:
%
% Range = design range with typical payload [nm]
% DOC = standard Direct Operational Cost calculation [US%/nm]
% MMO = Maximum Operational Mach number
% Ceiling = Service ceiling [ft]
% MTOW_kg = Maximum Takeoff Weight [kg]
% OEW_kg = Operational Empty Weight [kg]
% MLW = MaximumLanding Weight [kg]
% MZFW = Maximum Zero-fuel Weight [kg]
% PEng = Engine configuration identifier
% PHT = Horizontal tail configuration identifier
% PWing = Wing vertical position flag (=1 low; =2 high)
% Slat = slat for wings (=o no slat; ~= 0 slat present)
% lco = length of front fuselage [m]
% ltail = length of tail cone [m]
% lf = fuselage total length [m]
% fus_w = fuselage external width [m]
% fus_h = fuselage external height [m]
% FUSELAGE_Dz_floor = level of cabin floor relative the center of transveral section of fuselage [m]
% FusSwet_m2 = Fuselage wetted area [m2]
% container_type = 
% NSeat = Seating abreast
% NPax = Passenger capacity single class 32 inch arrangement
% NCorr = number of aisles
% CabHeightm = pax cabin height used in specification for fuselage cross cross section [m]
%                actual value may differ
% AisleWidth = width of aisle [m]
% SEATwid = width of seat (no distinction  for those from middle) [m]
% SeatPitch = distance between two adjacent seats [ inch] Used for sizing of PAX cabin
% fuselagefuelcapacity_kg = capacity of fuel tank placed in the wing stub (fuselage) [kg]
% wS = Wing reference area [m2]
% wAR = wing aspect ratio
% wTR = wing taper ratio
% Ccentro = chord at wing centerline
% Craiz = chord at wing root
% Cquebra = chord at break station
% Cponta = chord at wing tip
% iroot = incidence at wing root
% ikink = incidence at break station
% itip = incidence at wing tip
% tcroot = maximum relative thickness at wing root
% tcbreak = maximum relative thickness at wing break station
% tctip = maximum relative thickness at wing tip
% wingb = wingspan [m]
% yposeng = fraction of semispan where the break station is located
% wingdi = wing dihedral angle
% xle = x-coordinate of the leading edge of the center section
% wSweepLE = wing sweepback angle at the leading edge
% wSweep14 = quarter-chord wing sweepback angle
% wingSwet = wing wetted area
% bflap = fraction of semispan where the outer flap ends
% posaileron = fraction of semispan where the aileron bwgins
% longtras = fraction of chord where the aft spar is located
% flap_area_m2 = flap area 
% Flap_def_take = flap deflection at takeoff
% Flap_def_land = flap deflection at landing
% wingfuelcapacity_kg = fuel storage capacity inside wings [kg]
% arh = HT aspect ratio
% sweepLEht = HT sweepback angle at leading edge
% crootht = HT chord at root [m]
% ctipht = HT chord at tip [m]
% arv = VT aspect ratio
% sweepLEvt = VT sweepback angle at leading edge
% crootvt = VT chord at root [m]
% ctipvt = VT chord at tip [m]
% EnginLength_m = engine length [m]
% BPR = engine by-pass ratio
% OPR = engine overall pressure ratio
% FANPR = engine fan pressure ratio
% DFAN = engine fan diameter [m]
% eTIT = turbie inlet temperature [K]
% DX_Eng = horizontal displacement of engine relative to leading edge of break station [m]
% ESwet = engine wetted area [m2]
% DZ_Pylon = pylon height or width (depending on the engine positioning)
% mlg.dispan = 
% mlg.trudiam =
% mlg.xtpm = x-ccordinate of the main landing gear [m]
% mlg.tyred = tyre diameter of main landign gear [m]
% mlg.tyrew = tyre width of main landign gear [m]
% mlg.trupist =
% nlg.xtpn =
% nlg.trudiam =
% nlg.tyred = tyre diameter of nose landign gear [m]
% nlg.tyrew = 
% nlg.trupist =
% wlet_present = winglet flag (if nonzero it is considered)
% SweepLE_winglet =
% AR_winglet =
% TR_winglet = Winglet taper ratio
% CantAngle_wlet = 
% Twist_wlet = twist angle of the winglet
%----------------------------------------------------------%
fid=fopen(file_name,'r');
linha1 = fgetl(fid);
linha2 = fgetl(fid);
linha3 = fgetl(fid);
PARAM = strread(linha3);
Range = PARAM(1);
linha3a = fgetl(fid);
clear PARAM
PARAM = strread(linha3a);
DOC = PARAM(1);
linha4 = fgetl(fid);
clear PARAM
PARAM = strread(linha4);
MMO = PARAM(1);
linha5 = fgetl(fid);
clear PARAM
PARAM = strread(linha5);
Ceiling = PARAM(1);
linha6 = fgetl(fid);
linha7 = fgetl(fid);
clear PARAM
PARAM = strread(linha7);
MTOW_kg = PARAM(1);
linha8 = fgetl(fid);
clear PARAM
PARAM = strread(linha8);
OEW_kg = PARAM(1);
linha9 = fgetl(fid);
clear PARAM
PARAM = strread(linha9);
MLW = PARAM(1);
linha10 = fgetl(fid);
clear PARAM
PARAM = strread(linha10);
MZFW = PARAM(1);
linha11=fgetl(fid);
linha12 = fgetl(fid);
clear PARAM
PARAM = strread(linha12);
PEng = PARAM(1);
linha13 = fgetl(fid);
clear PARAM
PARAM = strread(linha13);
PHT = PARAM(1);
linha14 = fgetl(fid);
clear PARAM
PARAM = strread(linha14);
PWing = PARAM(1);
linha15 = fgetl(fid);
clear PARAM
PARAM = strread(linha14);
slat  = PARAM(1);
linha16 = fgetl(fid);
linha17 = fgetl(fid);
clear PARAM
PARAM = strread(linha17);
lco = PARAM(1);
linha18 = fgetl(fid);
clear PARAM
PARAM = strread(linha18);
lcab = PARAM(1);
linha19 = fgetl(fid);
clear PARAM
PARAM = strread(linha19);
ltail = PARAM(1);
linha20 = fgetl(fid);
clear PARAM
PARAM = strread(linha20);
lf = PARAM(1);
linha21 = fgetl(fid);
clear PARAM
PARAM = strread(linha21);
fus_w = PARAM(1);
linha22 = fgetl(fid);
clear PARAM
PARAM = strread(linha22);
fus_h = PARAM(1);
linha23 = fgetl(fid);
clear PARAM
PARAM = strread(linha23);
FUSELAGE_Dz_floor = PARAM(1);
linha24 = fgetl(fid);
clear PARAM
PARAM = strread(linha24);
FusSwet_m2 = PARAM(1);
linha25 = fgetl(fid);
container_type_n = linha25;
container_type=num2str(container_type_n);
container_type=strtrim(container_type);
linha26 = fgetl(fid);
clear PARAM
PARAM = strread(linha26);
NSeat = PARAM(1);
linha27 = fgetl(fid);
clear PARAM
PARAM = strread(linha27);
NPax = PARAM(1);
linha28 = fgetl(fid);
clear PARAM
PARAM = strread(linha28);
NCorr = PARAM(1);
linha29 = fgetl(fid);
clear PARAM
PARAM = strread(linha29);
CabHeightm = PARAM(1);
linha30 = fgetl(fid);
clear PARAM
PARAM = strread(linha30);
AisleWidth = PARAM(1);
linha31 = fgetl(fid);
clear PARAM
PARAM = strread(linha31);
SEATwid = PARAM(1);
linha32 = fgetl(fid);
clear PARAM
PARAM = strread(linha32);
SeatPitch = PARAM(1);
linha32a=fgetl(fid);
clear PARAM
PARAM = strread(linha32a);
fuselagefuelcapacity_kg=PARAM(1);
linha33 = fgetl(fid);
linha34 = fgetl(fid);
clear PARAM
PARAM = strread(linha34);
wS = PARAM(1);
linha35 = fgetl(fid);
clear PARAM
PARAM = strread(linha35);
wAR = PARAM(1);
linha36 = fgetl(fid);
clear PARAM
PARAM = strread(linha36);
wTR = PARAM(1);
linha36 = fgetl(fid);
clear PARAM
PARAM = strread(linha36);
Ccentro = PARAM(1);
linha37 = fgetl(fid);
clear PARAM
PARAM = strread(linha37);
Craiz = PARAM(1);
linha38 = fgetl(fid);
clear PARAM
PARAM = strread(linha38);
Cquebra = PARAM(1);
linha39 = fgetl(fid);
clear PARAM
PARAM = strread(linha39);
Cponta = PARAM(1);
linha40 = fgetl(fid);
clear PARAM
PARAM = strread(linha40);
iroot = PARAM(1);
linha41 = fgetl(fid);
clear PARAM
PARAM = strread(linha41);
ikink = PARAM(1);
linha42 = fgetl(fid);
clear PARAM
PARAM = strread(linha42);
itip = PARAM(1);
linha43 = fgetl(fid);
clear PARAM
PARAM = strread(linha43);
tcroot = PARAM(1);
linha44 = fgetl(fid);
clear PARAM
PARAM = strread(linha44);
tcbreak = PARAM(1);
linha45 = fgetl(fid);
clear PARAM
PARAM = strread(linha45);
tctip = PARAM(1);
linha46 = fgetl(fid);
clear PARAM
PARAM = strread(linha46);
wingb = PARAM(1);
linha47 = fgetl(fid);
clear PARAM
PARAM = strread(linha47);
yposeng = PARAM(1);
linha48 = fgetl(fid);
clear PARAM
PARAM = strread(linha48);
wingdi = PARAM(1);
linha49 = fgetl(fid);
clear PARAM
PARAM = strread(linha49);
xle = PARAM(1);
linha50 = fgetl(fid);
clear PARAM
PARAM = strread(linha50);
wSweepLE = PARAM(1);
linha51 = fgetl(fid);
clear PARAM
PARAM = strread(linha51);
wSweep14 = PARAM(1);
linha52 = fgetl(fid);
clear PARAM
PARAM = strread(linha52);
wingSwet = PARAM(1);
linha53 = fgetl(fid);
clear PARAM
PARAM = strread(linha53);
bflap = PARAM(1);
linha54 = fgetl(fid);
clear PARAM
PARAM = strread(linha54);
posaileron = PARAM(1);
linha55 = fgetl(fid);
clear PARAM
PARAM = strread(linha55);
longtras = PARAM(1);
linha56 = fgetl(fid);
clear PARAM
PARAM = strread(linha56);
flap_area_m2 = PARAM(1);
linha57 = fgetl(fid);
clear PARAM
PARAM = strread(linha57);
Flap_def_take = PARAM(1);
linha57 = fgetl(fid);
clear PARAM
PARAM = strread(linha57);
Flap_def_land = PARAM(1);
linha57a = fgetl(fid);
clear PARAM
PARAM = strread(linha57a);
wingfuelcapacity_kg=strread(linha57a);
linha58 = fgetl(fid);
linha59 = fgetl(fid);
clear PARAM
PARAM = strread(linha59);
arh = PARAM(1);
linha60 = fgetl(fid);
clear PARAM
PARAM = strread(linha60);
sweepLEht = PARAM(1);
linha61 = fgetl(fid);
clear PARAM
PARAM = strread(linha61);
crootht = PARAM(1);
linha62 = fgetl(fid);
clear PARAM
PARAM = strread(linha62);
ctipht = PARAM(1);
linha63 = fgetl(fid);
linha64 = fgetl(fid);
clear PARAM
PARAM = strread(linha64);
arv = PARAM(1);
linha65 = fgetl(fid);
clear PARAM
PARAM = strread(linha65);
sweepLEvt = PARAM(1);
linha66 = fgetl(fid);
clear PARAM
PARAM = strread(linha66);
crootvt = PARAM(1);
linha67 = fgetl(fid);
clear PARAM
PARAM = strread(linha67);
ctipvt = PARAM(1);
linha68 = fgetl(fid);
linha69 = fgetl(fid);
clear PARAM
PARAM = strread(linha69);
EnginLength_m = PARAM(1);
linha70 = fgetl(fid);
clear PARAM
PARAM = strread(linha70);
EnginDe_m = PARAM(1);
linha71 = fgetl(fid);
clear PARAM
PARAM = strread(linha71);
BPR = PARAM(1);
linha72 = fgetl(fid);
clear PARAM
PARAM = strread(linha72);
OPR = PARAM(1);
linha73 = fgetl(fid);
clear PARAM
PARAM = strread(linha73);
FANPR = PARAM(1);
linha73 = fgetl(fid);
clear PARAM
PARAM = strread(linha73);
DFAN = PARAM(1);
linha74 = fgetl(fid);
clear PARAM
PARAM = strread(linha74);
eTIT = PARAM(1);
linha75 = fgetl(fid);
clear PARAM
PARAM = strread(linha75);
DX_Eng = PARAM(1);
linha76 = fgetl(fid);
clear PARAM
PARAM = strread(linha76);
ESwet = PARAM(1);
linha77 = fgetl(fid);
clear PARAM
PARAM = strread(linha77);
DZ_Pylon = PARAM(1);
linha78 = fgetl(fid);
linha79 = fgetl(fid);
clear PARAM
PARAM = strread(linha79);
mlg.dispan = PARAM(1);
linha80 = fgetl(fid);
clear PARAM
PARAM = strread(linha80);
mlg.trudiam = PARAM(1);
linha81 = fgetl(fid);
clear PARAM
PARAM = strread(linha81);
mlg.xtpm = PARAM(1);
linha82 = fgetl(fid);
clear PARAM
PARAM = strread(linha82);
mlg.tyred = PARAM(1);
linha83 = fgetl(fid);
clear PARAM
PARAM = strread(linha83);
mlg.tyrew = PARAM(1);
linha84 = fgetl(fid);
clear PARAM
PARAM = strread(linha84);
mlg.trupist = PARAM(1);
linha85 = fgetl(fid);
clear PARAM
PARAM = strread(linha85);
nlg.xtpn = PARAM(1);
linha86 = fgetl(fid);
clear PARAM
PARAM = strread(linha86);
nlg.trudiam = PARAM(1);
linha87 = fgetl(fid);
clear PARAM
PARAM = strread(linha87);
nlg.tyred = PARAM(1);
linha88 = fgetl(fid);
clear PARAM
PARAM = strread(linha88);
nlg.tyrew = PARAM(1);
linha89 = fgetl(fid);
clear PARAM
PARAM = strread(linha89);
nlg.trupist = PARAM(1);
linha90 = fgetl(fid);
clear linha90
linha91 = fgetl(fid);
clear PARAM
PARAM = strread(linha91);
wlet_present = PARAM(1);
linha92 = fgetl(fid);
clear PARAM
PARAM = strread(linha92);
SweepLE_winglet = PARAM(1);
linha93 = fgetl(fid);
clear PARAM
PARAM = strread(linha93);
AR_winglet = PARAM(1);
linha94 = fgetl(fid);
clear PARAM
PARAM = strread(linha94);
TR_winglet = PARAM(1);
linha95 = fgetl(fid);
clear PARAM
PARAM = strread(linha95);
CantAngle_wlet = PARAM(1);
linha96 = fgetl(fid);
clear PARAM
PARAM = strread(linha96);
Twist_wlet = PARAM(1);
fclose(fid);
fprintf('\n +++++++++++++++ ')
fprintf('\n file %s read! \n',file_name)
fprintf('   +++++++++++++++ \n')
%
end % function