function [vt]=sizevt(VTArea,VTAR,VTTR,VTSweep,wS,varht,ht,Mach,Ceiling)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%VERTICAL TAIL%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rad   = pi/180;
kg2lb = 2.2046;  % [kg] para [lb]
% initial guess for VT area
vt.S=VTArea;
vt.Sv_Sw=vt.S/wS; % rela�ao de areas
vt.AR=VTAR; % alongamento EV
vt.TR=VTTR; % Afilamento EV
vt.sweep=VTSweep; % Enfl c/4 EV
vt.et=0; % torcao EV
vt.di=90; % diedro RV
vt.b=sqrt(vt.AR*vt.S); % Envergadura EV (m)
vt.c0=2*vt.S/(vt.b*(1+vt.TR)); % corda de centro 
vt.ct=vt.TR*vt.c0; % corda da ponta 
vt.cr=vt.ct/vt.TR; % corda na raiz
vt.mgc=vt.S/vt.b; % mgc
vt.mac=2/3*vt.c0*(1+vt.TR+vt.TR^2)/(1+vt.TR); %mac
vt.ymac=2*vt.b/6*(1+2*vt.TR)/(1+vt.TR);
vt.sweepLE=1/rad*(atan(tan(rad*vt.sweep)+1/vt.AR*(1-vt.TR)/(1+vt.TR))); % [�] enflechamento bordo de ataque
vt.sweepC2=1/rad*(atan(tan(rad*vt.sweep)-1/vt.AR*(1-vt.TR)/(1+vt.TR))); % [�] enflechamento C/2
vt.sweepTE=1/rad*(atan(tan(rad*vt.sweep)-3/vt.AR*(1-vt.TR)/(1+vt.TR))); % [�] enflechamento bordo de fuga
%lv=(0.060*wingref.S*wing.b)/vt.S; % fisrt estimate
%lv=lh - 0.25*ht.ct - vt.b * tan(rad*vt.sweepLE) + 0.25*vt.c0 + vt.ymac*tan(rad*vt.sweep); % braco da EV
%vt.v=vt.S*lv/(wingref.S*wing.b); % volume de cauda   
%%%%%%%%%%%%%%%%%%%%%%%%%%%%% VT wetted area %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
vt.tcroot = 0.11; % [%]espessura relativa raiz
vt.tctip  = 0.11; % [%]espessura relativa ponta
vt.tcmed=(vt.tcroot+3*vt.tctip)/4; % [%]espessura media
vt.Swet=2*vt.S*(1+0.25*vt.tcroot*(1+(vt.tcroot/vt.tctip)*vt.TR)/(1+vt.TR)); % [m2] 
%
%% EMPENAGEM VERTICAL (VERTICAL TAIL)
vtb                 = sqrt(vt.AR*vt.S);                                      % Envergadura EV [m]
if varht==1
    kv              = 1.0;                                                 % EH montada na fuselagem
else
    zh              = 0.95*vtb;
    kv              = 1+0.15*((ht.S*zh)/(vt.S*vt.b));                         % EH montada na EV
end
% prod1               = 3.81*(((vtS*m22ft2)^0.2)*vdkeas);                  % termo 1
% prod2               = (1000*(cos(vt.sweepC2*degre2rad))^0.5);            % termo 2
% prodf               = prod1/prod2;                                       % termo 3
% weightvt            = 1.00*kv*(vtS*m22ft2)*(prodf-0.287);   
% peso da EV, segundo a ref.(1) [lb]
atm                   = atmosfera(Ceiling,0);                                 % propriedades da atmosfera
va                    = atm(7); 
VD                    = Mach*va;
vt.sweepC2rad         = vt.sweepC2*rad;
aux                   = ((vt.S^0.2)*VD)/(1000*sqrt(cos(vt.sweepC2rad)));
weightvt              = kv*vt.S*(62*aux-2.5);
vt.weight             = weightvt*kg2lb;