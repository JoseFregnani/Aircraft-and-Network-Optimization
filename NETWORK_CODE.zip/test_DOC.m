%% Inicialization
clear all, close all, clc

global weightData

weightData.LoDl = 17;
weightData.LoDc = 0.866*weightData.LoDl;
% weightData.LoDc = weightData.LoDl;
weightData.Sfc = 0.6;
weightData.tL = 0.5;

%% Aircraft data

%Plane A
wa = 5000; % Cargo Capacity
ra = 1063; % Range capacity
va = 252;  % Speed
fa = 1481; % Fixed cost
la = 758;  % Variable cost
% fa = 1107; % Fixed cost
% la = 370;  % Variable cost

%Plane B
wb = 72210; % Cargo Capacity
rb = 3000;  % Range capacity
vb = 465;   % Speed
fb = 10616; % Fixed cost
lb = 3116;  % Variable cost
% fb = 7057; % Fixed cost
% lb = 1497;  % Variable cost

%Plane C
wc = 202100; % Cargo Capacity
rc = 3950;   % Range capacity
vc = 526;    % Speed
fc = 26129;  % Fixed cost
lc = 7194;   % Variable cost
% fc = 14750;  % Fixed cost
% lc = 2576;   % Variable cost

%% Network data - Distancie and Demand
% First Seven City
% Dist = [   0 1222 1933 1426 1160 1209 1393;
%         1222    0  934  208  622  400  619;
%         1933  934    0  731  882  755  563;
%         1426  208  731    0  682  423  448;
%         1160  622  882  682    0  260  309;
%         1209  400  755  423  260    0  219;
%         1393  619  563  448  309  219    0];
% 
% Demand = [    0  2356  2051   673  4572   214   747;
%            2356     0 14045  4610 31313  1465  5112;
%            2051 14045     0  4014 27261  1276  4451;
%             673  4610  4014     0  8948   419  1461;
%            4572 31313 27261  8948     0  2844  9923;
%             214  1465  1276   419  2844     0   464;
%             747  5112  4451  1461  9923   464     0];

% Largest Seven City
Dist = [   0  934  622  688 1921  756 2179;
         934    0  882 1538 2629  183 2729;
         622  882    0  806 1767  713 1866;
         688 1538  806    0 1257 1360 1518;
        1921 2629 1767 1257    0 2454  330;
         756  183  713 1360 2454    0 2560;
        2179 2729 1866 1518  330 2560    0];

Demand = [     0  14045  31313  19984  34506  57949  37318;
           14045      0  27261  17398  30041  50451  32489;
           31313  27261      0  38788  66975 112479  72434;
           19984  17398  38788      0  42743  71784  46227;
           34506  30041  66975  42743      0 123984  79820;
           57949  50451 112479  71784 123984      0 134050;
           37318  32489  72434  46227  79820 134050      0];

%% Cost calulation
% Setting size problem 
[N,M] = size(Dist);
% Number of routes and packages
Route = N*(N-1);
Package = N^2*(N-1);

% Removing the routes from one city to the same city from distance matrix
Dist2 = Dist';
Dist2(1:(N+1):(N*N))=[];

[w0a, wea, wTa, wfa, sfa] = weightFraction(wa,ra,va);
[w0b, web, wTb, wfb, sfb] = weightFraction(wb,rb,vb);
[w0c, wec, wTc, wfc, sfc] = weightFraction(wc,rc,vc);

% Cost by Roskam (DOC)
CostAr = zeros(1,Route);
CostBr = zeros(1,Route);
CostCr = zeros(1,Route);
for i = 1:Route
    CostAr(i) = routeCost(wa,Dist2(i),va,w0a,wea);
    CostBr(i) = routeCost(wb,Dist2(i),vb,w0b,web);
    CostCr(i) = routeCost(wc,Dist2(i),vc,w0c,wec);
end    

% Cost by Christine (Raymer)
CostAc = fa*ones(1,Route) + (2*la/va)*Dist2;
CostBc = fb*ones(1,Route) + (2*lb/vb)*Dist2;
CostCc = fc*ones(1,Route) + (2*lc/vc)*Dist2;

% Capability Constraint (Page 74)
for ind = 1:(N^2-N)
    if (Dist2(ind) > ra) CostAr(ind) = Inf; end
    if (Dist2(ind) > rb) CostBr(ind) = Inf; end
    if (Dist2(ind) > rc) CostCr(ind) = Inf; end
    if (Dist2(ind) > ra) CostAc(ind) = Inf; end
    if (Dist2(ind) > rb) CostBc(ind) = Inf; end
    if (Dist2(ind) > rc) CostCc(ind) = Inf; end    
end

% Generating Cost matricies with N by N format
CostAr2 = zeros(N,N);
DOCAr2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostAr2(i,j) =  CostAr(ind);
            DOCAr2(i,j) = CostAr2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostAr2(i,j) = Inf;
            DOCAr2(i,j) = Inf;
        end
    end    
end

CostBr2 = zeros(N,N);
DOCBr2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostBr2(i,j) =  CostBr(ind);
            DOCBr2(i,j) = CostBr2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostBr2(i,j) = Inf;
            DOCBr2(i,j) = Inf;
        end
    end    
end

CostCr2 = zeros(N,N);
DOCCr2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostCr2(i,j) =  CostCr(ind);
            DOCCr2(i,j) = CostCr2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostCr2(i,j) = Inf;
            DOCCr2(i,j) = Inf;
        end
    end    
end

CostAc2 = zeros(N,N);
DOCAc2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostAc2(i,j) =  CostAc(ind);
            DOCAc2(i,j) = CostAc2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostAc2(i,j) = Inf;
            DOCAc2(i,j) = Inf;
        end
    end    
end

CostBc2 = zeros(N,N);
DOCBc2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostBc2(i,j) =  CostBc(ind);
            DOCBc2(i,j) = CostBc2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostBc2(i,j) = Inf;
            DOCBc2(i,j) = Inf;
        end
    end    
end

CostCc2 = zeros(N,N);
DOCCc2 = zeros(N,N);
ind = 1;
for i = 1:N
    for  j = 1:N
        if (j ~= i)
            CostCc2(i,j) =  CostCc(ind);
            DOCCc2(i,j) = CostCc2(i,j)/Dist(i,j);
            ind = ind + 1;
        else
            CostCc2(i,j) = Inf;
            DOCCc2(i,j) = Inf;
        end
    end    
end


% Results - Comparison between Roskan formulation and Thesis values
% Total cost comparison
% Roskam
CostAr2
CostBr2
CostCr2
% Thesis (Raymer)
CostAc2
CostBc2
CostCc2
% Roskam - Thesis 
CostAr2 - CostAc2
CostBr2 - CostBc2
CostCr2 - CostCc2

% DOC comparison for each route and fixed MTOW
% Roskam
DOCAr2
DOCBr2
DOCCr2
% Thesis (Raymer)
DOCAc2
DOCBc2
DOCCc2
% Roskam - Thesis
DOCAr2 - DOCAc2
DOCBr2 - DOCBc2
DOCCr2 - DOCCc2

% DOC comparison for maximum range
% Roskam
DOCfinalAr = routeCost(wa,ra,va,w0a,wea)/ra
DOCfinalBr = routeCost(wb,rb,vb,w0b,web)/rb
DOCfinalCr = routeCost(wc,rc,vc,w0c,wec)/rc
% Thesis (Raymer)
DOCfinalAc = (fa + (2*la/va)*ra)/ra
DOCfinalBc = (fb + (2*lb/vb)*rb)/rb
DOCfinalCc = (fc + (2*lc/vc)*rc)/rc