function [Airport,X,D,LF,DIST,HDG]=Airportdata(n);

% AIRPORT DATA

Airport(1).name='GRU';
Airport(1).DEP_rwy='09L'
Airport(1).ARR_rwy='09R'
Airport(1).lat= -23.432075;
Airport(1).lon=	-46.469511;
Airport(1).elev=2459;
Airport(1).dmg=-20;
Airport(1).Reftemp=30;
Airport(1).TORA=3700;
Airport(1).TODA=3761;
Airport(1).ASDA=3761;
Airport(1).LDA=3000;
Airport(1).AVG_DEP_delay=10;
Airport(1).AVG_ARR_delay=5;

Airport(2).name='GIG'
Airport(2).DEP_rwy='10'
Airport(2).ARR_rwy='15'
Airport(2).lat= -22.808903;
Airport(2).lon=	-43.243647;
Airport(2).elev=28;
Airport(2).dmg=-21;
Airport(2).Reftemp=30;
Airport(2).TORA=4053;
Airport(2).TODA=4053;
Airport(2).ASDA=4053;
Airport(2).LDA=3180;
Airport(2).AVG_DEP_delay=10;
Airport(2).AVG_ARR_delay=5;

Airport(3).name='BSB'
Airport(3).DEP_rwy='11R'
Airport(3).ARR_rwy='11L'
Airport(3).lat=	-15.863500;
Airport(3).lon=	-47.927583;
Airport(3).elev=3497;
Airport(3).dmg=-20;
Airport(3).Reftemp=30;
Airport(3).TORA=3300;
Airport(3).TODA=3361;
Airport(3).ASDA=3361;
Airport(3).LDA=3200;
Airport(3).AVG_DEP_delay=10;
Airport(3).AVG_ARR_delay=5;

Airport(4).name='POA'
Airport(4).DEP_rwy='11'
Airport(4).ARR_rwy='11'
Airport(4).lat=	-29.994428;
Airport(4).lon=	-51.171428;
Airport(4).elev=11;
Airport(4).dmg=-15;
Airport(4).Reftemp=30;
Airport(4).TORA=2280;
Airport(4).TODA=2339;
Airport(4).ASDA=2339;
Airport(4).LDA=2280;
Airport(4).AVG_DEP_delay=3;
Airport(4).AVG_ARR_delay=3;

Airport(5).name='SSA'
Airport(5).DEP_rwy='10'
Airport(5).ARR_rwy='10'
Airport(5).lat=	-12.910994;
Airport(5).lon=	-38.331044;
Airport(5).elev=64;
Airport(5).dmg=-23;
Airport(5).Reftemp=30;
Airport(5).TORA=3005;
Airport(5).TODA=3068;
Airport(5).ASDA=3068;
Airport(5).LDA=3005;
Airport(5).AVG_DEP_delay=2;
Airport(5).AVG_ARR_delay=2;

% Route System (X=1 is existing connection)

X(1,:)=[0    1    1    1   1 ];
X(2,:)=[1    0    1    1   1 ];
X(3,:)=[1    1    0    0   1 ];
X(4,:)=[1    1    0    0   0 ];
X(5,:)=[1    1    1    0   0 ];

% Demand Matrix - passengers per day

D(1,:)=[0    350  100   100  200];
D(2,:)=[350  0    100   500  300];
D(3,:)=[100  150  0     300  150];
D(4,:)=[300  200  100     0  100];
D(5,:)=[300  200  200     0  200];

% Distances Matrix 

DIST(1,:)= [0	182	481	481	788];
DIST(2,:)= [192	0	510	620	600];
DIST(3,:)= [471	507	0	0	590];
DIST(4,:)= [481	614	0	0	0  ];
DIST(5,:)= [796	661	598	0	0  ];

% Load Factor Matrix 

LF(1,:)=[0    0.85 0.80 0.80 0.85];
LF(2,:)=[0.70 0    0.85 0.80 0.80];
LF(3,:)=[0.80 0.80 0    0.74 0.70];
LF(4,:)=[0.85 0.80 0.78 0    0.65];
LF(5,:)=[0.90 0.80 0.75 0    0.85];

% Distances and True Headings Matrixes %

% HEADING CALCULATION

[~,HDG]=distGC2(Airport);

DIST
HDG
