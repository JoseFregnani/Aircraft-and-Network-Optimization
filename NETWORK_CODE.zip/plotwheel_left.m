function plotwheel_left(x0,y0,z0,diametroe,largura)
% Desenha roda   
diametroi= 2*diametroe/3;
        npwheel =30;
        dxang   =2*pi/(npwheel-1);
        angwheel=(0:dxang:2*pi);
%       Bandagem externa (contato com o solo)
        y1roda1(1:npwheel)=y0;
        y2roda1(1:npwheel)=y0+largura;
        x1roda1=x0+diametroe*0.50*cos(angwheel);
        x2roda1=x1roda1;
        z1roda1=z0+diametroe*0.50*sin(angwheel);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','black');
        hold on       
%Face externa da roda
        y1roda1(1:npwheel)=y0+0.15*largura;
        y2roda1(1:npwheel)=y0;
        x1roda1=x0+diametroi*0.50*cos(angwheel);
        x2roda1=x1roda1;
        z1roda1=z0+diametroi*0.50*sin(angwheel);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','black');
        hold on  
        % Parte interna 
        dxangf=pi/(npwheel-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=x0+diametroi*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:npwheel)=y0+0.15*largura;
        y2froda1=y1froda1;
        z1froda1=z0 + diametroi*0.50*sin(angrodaf);
        z2froda1=z0 - diametroi*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','yellow');
        hold on
        % Lado voltado para dentro
        dxangf=pi/(npwheel-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=x0+diametroe*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:npwheel)=y0+largura;
        y2froda1=y1froda1;
        z1froda1=z0 + diametroe*0.50*sin(angrodaf);
        z2froda1=z0 - diametroe*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        hold on 
  % Bandagem lateral do pneu
        dxangf=2*pi/(npwheel-1);
        angrodaf=(0:dxangf:2*pi);
        x1froda1=x0+diametroe*0.50*cos(angrodaf);
        x2froda1=x0+diametroi*0.50*cos(angrodaf);
        y1froda1(1:npwheel)=y0;
        y2froda1=y1froda1;
        z1froda1=z0 + diametroe*0.50*sin(angrodaf);
        z2froda1=z0 + diametroi*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','black');
        hold on
  % parafusos
   nparaf= 6;
   
   deltaparang=2*pi/(nparaf-1);
   angpar=(0:deltaparang:2*pi);
   
   for i=1:nparaf
       x00=x0 + 0.60*diametroi*0.50*cos(angpar(i));
       z00=z0 +  0.60*diametroi*0.50*sin(angpar(i));
        y1roda1(1:npwheel)=y0;
        y2roda1(1:npwheel)=y0+0.75*largura;
        x1roda1=x00+0.05*diametroi*cos(angwheel);
        x2roda1=x1roda1;
        z1roda1=z00+0.05*diametroi*sin(angwheel);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','black','FaceColor','y');
        hold on          
  % face de topo do parafuso da roda
       x1froda1=x00+diametroi*0.05*cos(angrodaf);
       x2froda1=x1froda1;
       y1froda1(1:npwheel)=y0;
       y2froda1=y1froda1;
       z1froda1=z00 + diametroi*0.05*sin(angrodaf);
       z2froda1=z00 - diametroi*0.05*sin(angrodaf);
       xfroda1=[x1froda1;x2froda1];
       yfroda1=[y1froda1;y2froda1];
       zfroda1=[z1froda1;z2froda1];
       surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','black');
       hold on
   end
   
   axis equal