function [airxac_rel]=aerocenter(xle,Mach,PWing,wingCLa,wS,wAR,wTR,wSweep14,...
    wMAC,wYMAC,wSweepLE,Craiz,...
    PHT,ht,vt,pylon,...
    Fus_width,Fus_height,lf,PEng,EnginLength_m,EngineDe_m,dist_quebra)
%
rad          = pi/180;
%
B            = sqrt(1-(Mach^2));
wingb        = sqrt(wAR*wS);
Fus_diam     = sqrt(Fus_width*Fus_height);
%*********** horizontal tail
htperfilCla  = 4.6524; % NACA 63412
htperfilClaM = htperfilCla/B;
K            = htperfilClaM/(2*pi/B);
htCLa=2*pi*ht.AR/(2+(((ht.AR^2)*(B^2)/(K^2))*(1+((tan(ht.sweepC2*rad))^2)/(B^2))+4)^(0.5)); %[rad-1] pag 281 eq 8.22
%
htac_rel   = 0.25;
    if PHT == 1
    htxac=0.95*lf - ht.c0 + ht.ymac*tan(rad*ht.sweepLE)+...
        htac_rel*ht.mac;
    else
    htxac=0.95*lf-vt.c0+vt.b*tan(rad*vt.sweepLE)+...
        htac_rel*ht.mac+ht.ymac*tan(rad*ht.sweepLE);
    end
wingac_rel = 0.25;
wingxac  = xle + wYMAC*tan(rad*wSweepLE) + wingac_rel*wMAC;
lh       = htxac - wingxac;
%
switch PHT
    case 1
        nh = 0.90;
    case 2
        nh = 0.95;
end
%
if PWing == 1
    if PHT == 1
        hh = 3/4*Fus_height;
    else
        hh = Fus_height + vt.b;
    end
else % asa alta
    if PHT == 1
        hh = -1/4*Fus_height;
    else
        hh = vtb;
    end
end

Ka    = (1/wAR)-1/(1+(wAR^1.7));
Klamb = (10-3*wTR)/7;
Kh    = (1-(hh/wingb))/((2*lh/wingb)^(1/3)); % corrigir ymacv
de_da=4.44*((Ka*Klamb*Kh*sqrt(cos(wSweep14*rad)))^1.19)/B;
%CLawf eq 8.43 pag 305
Kwf=1+0.025*(Fus_diam/wingb)-0.25*((Fus_diam/wingb)^2);
fuselageCLa=wingCLa*Kwf; %[rad-1]
airplaneCLa=fuselageCLa+htCLa*nh*(ht.S/wS)*(1-de_da);  %[rad-1] eq 8.42 pag 305
% fuselage.xac=wing.xac+df1xac+df2xac;
dxh_c=ESDU76015(Mach,xle,wingCLa,wS,wAR,wTR,wMAC,wYMAC,wSweepLE,wSweep14,Craiz,....
    Fus_height,Fus_width,lf);
fuselageac_rel = wingac_rel - dxh_c;
% Efeito das nacelles
 if PEng == 2
 %     ESDU 78013
dxhn=ESDU78013(wS,wingb,wMAC,wYMAC,wAR,wSweep14,wSweepLE,wingCLa,lf,...
    EnginLength_m,EngineDe_m,vt.c0,xle,pylon,wingac_rel,fuselageac_rel);
 else
 % ESDU 77012
     dxhn=ESDU77012(xle,wingCLa,wS,wAR,wMAC,wYMAC,wSweepLE,...
    EnginLength_m,EngineDe_m,dist_quebra,wingac_rel,fuselageac_rel);
 end
fuselageac_rel = fuselageac_rel - dxhn;
%
airxac_rel=(fuselageCLa/airplaneCLa)*(fuselageac_rel)+nh*(ht.S/wS)*(htCLa/airplaneCLa)*(1-de_da)*(htac_rel);