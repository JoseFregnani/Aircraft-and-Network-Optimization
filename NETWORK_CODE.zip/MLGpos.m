function [X_TP2, yc_munhao, munhao_comp]=MLGpos(xle,sweepLE,longtras,Craiz,Cquebra,Cponta,...
         yraiz,yposeng,semispan,PEng,engdi,D0m_max,Lpist_m,tcroot)
% recalculo da posicao longitudinal do trem de pouso principal
rad      = pi/180;
yquebra  = yposeng*semispan;
esspraiz = tcroot*Craiz;
%
switch PEng
    case 1
    lref1=yposeng*semispan-engdi/2;
    lref3=esspraiz*0.50*0.80+engdi*1.1;
    munhao_comp=max(lref3,Lpist_m);

       if munhao_comp < (lref1-yraiz)
        yc_munhao=yraiz+munhao_comp;
       else
       yc_munhao=lref1;
       end
    case 2
    lref1=(yquebra-yraiz)*tan(rad*sweepLE);
    munhao_comp=max(lref1,Lpist_m);
    yc_munhao = max(0.10*semispan,0.55*yquebra);
        if (munhao_comp-D0m_max*0.50) < 0.55*yquebra-yraiz;
        munhao_comp=yc_munhao-yraiz+D0m_max*0.50;
        end
end

tanaux = tan(rad*sweepLE);
%
x1     = xle + yposeng*semispan*tanaux + longtras*Cquebra;
y1     = yposeng*semispan;
x2     = xle + semispan*tanaux         + longtras*Cponta;
y2     = semispan;

if x1 == x2
x075munhao_diant= x1;   
else
inclina=(y2-y1)/(x2-x1);
x075munhao_diant=((yc_munhao-y1)/inclina)+x1;
end

x1=xle+yposeng*semispan*tan(rad*sweepLE)+longtras*Cquebra;
y1=yposeng*semispan;

x2=xle+yraiz*tan(rad*sweepLE)+longtras*Craiz;
y2=yraiz;

if x2 < x1
    inclina=(y2-y1)/(x2-x1);
    xmunhao_tras=((yc_munhao-y1)/inclina)+x1;
    
else
    xmunhao_tras=x1;
end

X_TP2=0.50*(x075munhao_diant+xmunhao_tras)-0.10;

%%%%%%%%%%% fim do recalculo do X_TP2;
         