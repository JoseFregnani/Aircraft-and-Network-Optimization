function [Airport,RTE,NA,f,LF,DIST,HDG,NPAR]=NETWORKOPT_R04h(MAXPAX,AVGDOC,RANGE,SHARE,LFREF,TKTPRICE,K1,K2);

plotfig=1; % 0=NO FIGURES , 1: PLOT FIGURES

% INIT DATA
b1=MAXPAX(1);
b2=MAXPAX(2);
b3=MAXPAX(3);
c1=AVGDOC(1);
c2=AVGDOC(2);
c3=AVGDOC(3);
r1=RANGE(1);
r2=RANGE(2);
r3=RANGE(3);
%
MAXFREQ=10;
MINFREQ=2;
MAXHUB=3;
MINRANGE=100;
R=400; % Reference clustering radius (nm)
nacft=3;

% LOAD AIRPORTS AND DEMAND DATA
[Airport,f,LF,DIST,HDG]=LOADAPT(SHARE,LFREF);
n=size(DIST,1);
N=n*n-n;
frac1=0.5;
frac2=0.3/(N-2);
frac3=0.2/(2*(N-2));

% calculate fraction of demand
for i=1:n
    for j=1:n
      for t=1:n
        for l=1:n  
          if t==l  
            %  
            if i==j
              X(i,t,l,j)=0;
            else  
              if or(t==i,t==j)
                  X(i,t,l,j)=frac1;
              else
                  X(i,t,l,j)=frac2;
              end          
            end 
            %
          else
            %  
            if i==j
              X(i,t,l,j)=0;
            else  
              if t~=i
                  X(i,t,l,j)=frac3;
              end          
            end 
            %        
          end          
        end
      end
    end
end 

% Check
for i=1:n
   SUM=0;
   for j=1:n
     if i~=j  
       for t=1:n
         if t~=i
             SUM=SUM+X(i,t,t,j);
         end    
       end   
     end 
   end
   for j=1:n
     if i~=j  
       for t=1:n
         for l=1:n  
           if t~=i
             SUM=SUM+X(i,t,l,j);
           end    
         end
       end   
     end 
   end   
end   

% Objective function vector
fun=zeros(1,nacft*N);
k=1;
for a=1:nacft
    for i=1:n
      for j=1:n
          if i~=j
            switch a
                case 1                        
                   fun(k)=-(K1*TKTPRICE-K2*c1*DIST(i,j)/(b1*LFREF));                  
                case 2                         
                   fun(k)=-(K1*TKTPRICE-K2*c2*DIST(i,j)/(b2*LFREF));                  
                case 3 
                   fun(k)=-(K1*TKTPRICE-K2*c3*DIST(i,j)/(b3*LFREF)); 
            end
            k=k+1;
          end 
      end  
    end 
end

% Constraint vector 

% MATRIX A
PAX=zeros(1,nacft*N);
k=1;
 for a=1:nacft
    for i=1:n
      for j=1:n
        if i~=j  
          switch a
              case 1   
                PAX(k)=PAX(k)+b1*LF(i,j);
              case 2
                PAX(k)=PAX(k)+b2*LF(i,j);
              case 3
                PAX(k)=PAX(k)+b3*LF(i,j);  
          end      
%         PAX(k)=PAX(k)+(b1+b2+b3)*LF(i,j);
          k=k+1;
        end  
      end
    end   
end
%
A=zeros(1,nacft*N);
k=1;
for i=1:nacft*N
     A(i,i)=PAX(k);
     k=k+1;
end

% MATRIX B
B=zeros(1,nacft*N);
k=1;
for a=1:nacft
  for i=1:n
    for j=1:n
      if i~=j         
            B(k)=f(i,j);
            for t=1:n
               for l=1:n 
                 if l==t  
                   if t~=i 
                     B(k)=B(k)+(f(i,t)*X(i,j,l,t)+f(t,i)*X(t,i,l,j)-f(i,j)*X(i,t,l,j));             
                   end
                 else
                   if t~=i 
                     B(k)=B(k)+(f(l,j)*X(l,t,i,j)+f(i,t)*X(i,j,l,t)+f(l,t)*X(l,i,j,t)-f(i,j)*X(i,l,t,j));             
                   end  
                 end    
               end
            end;
            k=k+1;
        end;    
      end  
   end  
 end 

% Liner Programming 
for i=1:nacft*N
  lb(1,i)=0;
  ub(1,i)=MAXFREQ;
end
intcon=[1:nacft*N];
options = optimoptions('intlinprog','Display','iter','Heuristics','advanced')
[Y,fval]=intlinprog(fun,intcon,A,B,[],[],lb,ub,options);% MAXIMIZE PROFIT

% Route assignment 
k=1;
for a=1:nacft 
  for i=1:n
    for j=1:n    
          if i==j
            RTE(i,j,a)=0;
            NA(i,j,a)=0;
          else   
            if round(Y(k))>=MINFREQ && DIST(i,j)>=MINRANGE
               RTE (i,j,a)=1;
               NA(i,j,a)=round(Y(k));
            else
               RTE (i,j,a)=0;
               NA(i,j,a)=0;
            end  
            k=k+1;
            switch a
               case 1
                  MAXR=r1;
               case 2
                  MAXR=r2;
               case 3
                  MAXR=r3; 
            end  
            if or(DIST(i,j)>MAXR,DIST(i,j)<MINRANGE)
               RTE(i,j,a)=0;
               NA(i,j,a)=0;
            end   
          end       
      end
    end  
end

% Hub Locations
for a=1:nacft
    for i=1:n
       NA_dep=0; 
       for j=1:n    
         NA_dep=NA_dep+NA(i,j,a);
       end  
       Hub(i)=NA_dep;
    end
    for j=1:n
       NA_arr=0; 
       for i=1:n    
         NA_arr=NA_arr+NA(i,j,a);
       end  
       Hub(j)=Hub(j)+NA_arr;
    end
    for i=1:MAXHUB
      [M,k]=max(Hub);
      HNAME=Airport(k).name;
      HUBNAME(i,a)=string(HNAME);
      Hub(k)=0;
    end
end


% PLOT NETWORK

    for i=1:n
          LAT(i)=Airport(i).lat;
          LON(i)=Airport(i).lon;    
    end
    
 if plotfig==1
    figure (1)
    plot(LON,LAT,'go')
 end
 
 for a=1:nacft
        k=1;  
        for i=1:n   
          for j=1:n
              if i~=j
                if RTE(i,j,a)==1;  
                  LA1(k,a)=Airport(i).lat;
                  LO1(k,a)=Airport(i).lon;           
                  LA2(k,a)=Airport(j).lat;
                  LO2(k,a)=Airport(j).lon; 
                  X1= LO1(k,a);
                  X2= LO2(k,a);
                  Y1= LA1(k,a);
                  Y2= LA2(k,a);
                  X=[X1 X2];          
                  Y=[Y1 Y2];                          
                  k=k+1;
                  %
                  if plotfig==1
                      switch a
                              case 1
                                figure (1)
                                line(X,Y,'Color','blue');
                                hold on                        
                              case 2     
                                figure (2)  
                                line(X,Y,'Color','red');
                                hold on                              
                              case 3   
                                figure (3)  
                                line(X,Y,'Color','magenta');
                                hold on                        
                       end   
                  hold on 
                  end
                  %  
                end  
              end
          end 
       end  
   end 

% Kml generation

for a=1:nacft
    LAT1=LA1(:,a)';
    LAT2=LA2(:,a)';
    LON1=LO1(:,a)';
    LON2=LO2(:,a)'; 
    switch a
        case 1
          NETNAME='NETWORK_ACFT1.kml';
        case 2
          NETNAME='NETWORK_ACFT2.kml';   
        case 3
          NETNAME='NETWORK_ACFT3.kml';   
    end      
    RTEKML (LAT1,LON1,LAT2,LON2,NETNAME)
end

% NETWORK PARAMETERS
for a=1:nacft
    X=RTE(:,:,a);
    ACFT=NA(:,:,a);
    switch a
        case 1
            name='ACFT#1';
            DOCREF=c1;
            REF_RANGE=r1;
        case 2
            name='ACFT#2';
            DOCREF=c2;
            REF_RANGE=r2;
        case 3
            name='ACFT#3';
            DOCREF=c3;
            REF_RANGE=r3;
    end             
    [n,N,AVG_DON,L,ND,AVG_C]=NETWORKPAR(X,DIST,R,name);
    HUBS=strcat(HUBNAME(1,a),'/',HUBNAME(2,a),'/',HUBNAME(3,a));
    NPAR(a,1)=n;
    NPAR(a,2)=N;
    NPAR(a,3)=AVG_DON;
    NPAR(a,4)=L;
    NPAR(a,5)=ND;
    NPAR(a,6)=AVG_C;
    
    % Print Network parameters
    fprintf('\n');
    fprintf('\n ** NETWORK PARAMETERS : %s',name);
    fprintf('\n');
    fprintf('\n Number of Nodes (n)              : %6.0f',n);
    fprintf('\n Number of Arcs (N)               : %6.0f',N);
    fprintf('\n Average Degree of Nodes (AVG DON): %6.1f',AVG_DON);
    fprintf('\n Average Path Length (L)- nm      : %6.1f',L);
    fprintf('\n Network Density (ND)             : %6.2f',ND);
    fprintf('\n Average Clustering (AVG C)       : %6.2f',AVG_C);
    fprintf('\n HUBs                             : %s',HUBS);
    fprintf('\n');  
end



