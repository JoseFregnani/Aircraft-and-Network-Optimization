
% #########################################################################
% ##
% ##    function achatrat
% ##    fun��o usada para achar a raz�o de temperatura nas turbinas
% ##
% #########################################################################
function f = achatrat(x,a,b,c)
f = a - sqrt(x)*(1-(1-x)/b)^c;

%**************************************************************************
%
%   Fun��o para obter gamma em fun��o da temperatura(kelvin)
%   Retirado do c�digo fonte do software EngineSim da NASA
%   http://www.grc.nasa.gov/WWW/K-12/airplane/ngnsim.html
%
%   input: temperatura (K)
%   output: gamma
%
%**************************************************************************