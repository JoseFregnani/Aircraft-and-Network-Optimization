function [CDwing, CLout]=CDCLneural2(Mach, altitude,CL,alfag,Sref,AR,taper,LEsweep,...
    inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,fixed_AoA)
%
%fixed_AoA      = 0; % 1 for fixed AoA, otherwise will run for CLinput
CLinput        = CL;
%Carregando dados de entrada
input_nn(1,1)  = Mach;
input_nn(2,1)  = altitude;
input_nn(3,1)  = alfag*pi/180; % angulo de ataque
input_nn(4,1)  = AR; % alongamento da asa
input_nn(5,1)  = taper; % afilamento da asa
input_nn(6,1)  = LEsweep*pi/180; % Enflechamento bordo de ataque
input_nn(7,1)  = 3*pi/180;
input_nn(8,1)  = 5*pi/180;
input_nn(9,1)  = kink_position; % Posicao da quebra (% da semi-envergadura)
input_nn(10,1) = Sref; % area (m2)
input_nn(11,1) = inc_root*pi/180;
input_nn(12,1) = inc_kink*pi/180;
input_nn(13,1) = inc_tip*pi/180;

input_nn(14,1) = r0(1);
input_nn(15,1) = t_c(1);
input_nn(16,1) = phi(1);
input_nn(17,1) = X_tcmax(1);
input_nn(18,1) = theta(1);
input_nn(19,1) = epsilon(1);
input_nn(20,1) = Ycmax(1);
input_nn(21,1) = YCtcmax(1);
input_nn(22,1) = X_Ycmax(1);

input_nn(23,1) = r0(2);
input_nn(24,1) = t_c(2);
input_nn(25,1) = phi(2);
input_nn(26,1) = X_tcmax(2);
input_nn(27,1) = theta(2);
input_nn(28,1) = epsilon(2);
input_nn(29,1) = Ycmax(2);
input_nn(30,1) = YCtcmax(2);
input_nn(31,1) = X_Ycmax(2);

input_nn(32,1) = r0(3);
input_nn(33,1) = t_c(3);
input_nn(34,1) = phi(3);
input_nn(35,1) = X_tcmax(3);
input_nn(36,1) = theta(3);
input_nn(37,1) = epsilon(3);
input_nn(38,1) = Ycmax(3);
input_nn(39,1) = YCtcmax(3);
input_nn(40,1) = X_Ycmax(3);

% We can create multiple case with different Mach nubmers as follows:
%input_nn(:,2) = input_nn(:,1);
%input_nn(1,2) = 0.6;
%input_nn(:,3) = input_nn(:,1);
%input_nn(1,3) = 0.5;

%Usando as redes neurais para prever todos os coeficientes
[CLout, ~, CDfp, CDwave, CDind, ~, ~, ~, ~] = ...
    NN_aed_main(CLinput,input_nn, fixed_AoA,NNind,NNwav,NNcd0,NNCL);

%Calculando o arrasto total
CDfp   = 1.04*CDfp; % account for miscellaneous drag
CDwing = CDfp + CDwave + CDind;

end
%
function [CL, Alpha, CDfp, CDwave, CDind, grad_CL, grad_CDfp, ...
    grad_CDwave, grad_CDind] = NN_aed_main(CLinput,input_nn, CL_logical, ...
    NNind,NNwav,NNcd0,NNCL)

%%%%%%%%%%%%%%%%%%%
% Apr-09-2016
% Ney Rafael S?cco
% Bento Mattos
% Instituto Tecnol?gico de Aeron?utica
% ney@ita.br
% bmattos@ita.br

%HELP NN_aed
% INPUTS
% We consider that each airfoil has a trailing edge thickness of 0.0025 and
% a trailing edge height of 0.
%
% CLinput: desired lift coefficient (only used if CL_logical==1)
%
% CL_logical: if 1, solves the angle of attack to match CLinput. Otherwise, it will just get CL
%            for the given angle of attack specified at input_nn(3,:).
%
% input_nn: matrix (40xm) containing inputs for 40 variables and m cases. Each column represents
% a case, and each row represents a variable:
% ROW ||| VARIABLE ||| RANGES
% 1: Mach number (0.2 <> 0.85)
% 2: Altitude [m] (0 <> 13000)
% 3: Angle of attack [rad] (-5*pi/180 <> 10*pi/180) % Will be overwritten if CL_logical ~= 1
% 4: Wing aspect ratio (7 <> 12)
% 5: Wing taper ratio (0.2 <> 0.6)
% 6: Wing leading edge sweep [rad] (10*pi/180 <> 35*pi/180)
% 7: Inboard wing dihedral [rad] (0 <> 5*pi/180)
% 8: Outboard wing dihedral [rad] (5*pi/180 <> 10*pi/180)
% 9: Break position [in semi-span fractions] (0.3 <> 0.6)
% 10: Wing Area [m?] (50 <> 200)
% 11: Wing root airfoil incidence [rad] (0 <> 2*pi/180)
% 12: Wing break airfoil incidence [rad] (-1*pi/180 <> 1*pi/180)
% 13: Wing tip airfoil incidence [rad] (-3*pi/180 <> 0)
% 14: Root airfoil leading edge radius (0.05 <> 0.20) ||| rBA
% 15: Root airfoil thickness ratio (0.10 0.18) ||| t_c
% 16: Root airfoil thickness line angle at trailing edge (-0.24 0.10) ||| phi
% 17: Root airfoil maximum thickness chord-wise position (0.20 <> 0.46) ||| X_tcmax
% 18: Root airfoil camber line angle at leading edge (-0.2 <> 0.1) ||| theta
% 19: Root airfoil camber line angle at trailing edge (-0.300 -0.005) ||| epsilon
% 20: Root airfoil maximum camber (0.00 <> 0.03) ||| Ycmax
% 21: Root airfoil camber at maximum thickness chord-wise position (0.000 <> 0.025) ||| YCtcmax
% 22: Root airfoil maximum camber chord-wise position (0.50 <> 0.80) ||| X_Ycmax
% 23: Break airfoil leading edge radius (0.03 <> 0.20) ||| rBA
% 24: Break airfoil thickness ratio (0.08 0.125) ||| t_c
% 25: Break airfoil thickness line angle at trailing edge (-0.24 0.10) ||| phi
% 26: Break airfoil maximum thickness chord-wise position (0.20 <> 0.46) ||| X_tcmax
% 27: Break airfoil camber line angle at leading edge (-0.2 <> 0.1) ||| theta
% 28: Break airfoil camber line angle at trailing edge (-0.300 -0.005) ||| epsilon
% 29: Break airfoil maximum camber (0.00 <> 0.03) ||| Ycmax
% 30: Break airfoil camber at maximum thickness chord-wise position (0.000 <> 0.025) ||| YCtcmax
% 31: Break airfoil maximum camber chord-wise position (0.50 <> 0.80) ||| X_Ycmax
% 32: Tip airfoil leading edge radius (0.03 <> 0.15) ||| rBA
% 33: Tip airfoil thickness ratio (0.08 0.12) ||| t_c
% 34: Tip airfoil thickness line angle at trailing edge (-0.24 0.10) ||| phi
% 35: Tip airfoil maximum thickness chord-wise position (0.20 <> 0.46) ||| X_tcmax
% 36: Tip airfoil camber line angle at leading edge (-0.2 <> 0.1) ||| theta
% 37: Tip airfoil camber line angle at trailing edge (-0.300 -0.005) ||| epsilon
% 38: Tip airfoil maximum camber (0.00 <> 0.03) ||| Ycmax
% 39: Tip airfoil camber at maximum thichness chord-wise position (0.000 <> 0.025) ||| YCtcmax
% 40: Tip airfoil maximum camber chord-wise position (0.50 <> 0.80) ||| X_Ycmax
%
%
% OUTPUTS
% CL: line vector (1xm) containing the lift coefficient for each input case.
% CDfp: line vector (1xm) containing the parasite drag coefficient for each input case.
% CDwave: line vector (1xm) containing the wave drag coefficient for each input case.
% CDind: line vector (1xm) containing the induced drag coefficient for each input case.
% All coefficients are adimensionalized by the given wing area.

% Check if the number of inpt variables is correct
sizes = size(input_nn);
if sizes(1) ~= 40
    fprintf('\n The number of input variables should be 40.')
    fprintf('\n Check the size of input_nn columns.')
end

% Get number of cases
m = sizes(2);

% DEFINE VARIABLE BOUNDS
% Flight conditions
Mach = [0.2 0.85]; % 1 - Flight Mach number
Altitude = [0 13000]; % 2 - Flight altitude [m]
alpha = [-5 10]*pi/180; % 3 - Angle of attack [rad]

% Wing planform
A = [7 12]; % 4 - Aspect ratio
lambda = [0.2 0.6];% 5 - Taper ratio
phi = [10 35]*pi/180; % 6 - Leading edge sweep angle [rad]
di1 = [0 5]*pi/180; % 7 - Inner panel dihedral [rad]
di2 = [5 10]*pi/180; % 8 - Outer panel dihedral [rad]
xq = [0.3 0.6]; % 9 - Span-wise kink position [span fraction]
S = [50 200]; % 10 - Wing area [m?]

% Airfoil incidences (realtive to fuselage centerline)
inc_root = [0 2]*pi/180;% 11 - Root airfoil incidence [rad]
inc_kink = [-1 1]*pi/180;% 12 - Kink airfoil incidence [rad]
inc_tip = [-3 0]*pi/180;% 13 - Tip airfoil incidence [rad]

% Root airfoil
rBA_root = [0.02 0.20];% 14 - Leading edge radius
% EspBF_root = [0.0025 0.0025];%%% - Trailing edge thickness (constant)
t_c_root = [0.10 0.18];% 15 - Thickness ratio
phi_root = [-0.12 0.05]*2;% 16 - Thickness line angle at trailing edge
X_tcmax_root = [0.20 0.46];% 17 - Maximum thickness chord-wise position
theta_root = [-0.20 0.10];% 18 - Camber line angle at leading edge
epsilon_root = [-0.300 -0.005];% 19 - Camber line angle at trailing edge
Ycmax_root = [-0.05 0.03];% 20 - Maximum camber
YCtcmax_root = [-0.05 0.025];% 21 - Maximum camber at maximum thickness chord-wise position
% Hte_root = [0 0];%%% - Trailing edge height with respect to chord-line (constant)
X_Ycmax_root = [0.50 0.80];% 22 - Maximum camber chord-wise position

% Kink airfoil
rBA_kink = [0.03 0.20];% 23 - Leading edge radius
% EspBF_kink = [0.0025 0.0025];%%% - Trailing edge thickness (constant)
t_c_kink = [0.08 0.13];% 24 - Thickness ratio
phi_kink = [-0.12 0.05]*2;% 25 - Thickness line angle at trailing edge
X_tcmax_kink = [0.20 0.46];% 26 - Maximum thickness chord-wise position
theta_kink = [-0.20 0.10];% 27 - Camber line angle at leading edge
epsilon_kink = [-0.300 -0.005];% 28 - Camber line angle at trailing edge
Ycmax_kink = [0.00 0.03];% 29 - Maximum camber
YCtcmax_kink = [0.000 0.025];% 30 - Maximum camber at maximum thickness chord-wise position
% Hte_kink = [0 0]; - Trailing edge height with respect to chord-line (constant)
X_Ycmax_kink = [0.50 0.80];% 31 - Maximum camber chord-wise position


rBA_tip = [0.03 0.15];% 32 - Leading edge radius
% EspBF_tip = [0.0025 0.0025];%%% - Trailing edge thickness (constant)
t_c_tip = [0.08 0.12];% 33 - Thickness ratio
phi_tip = [-0.12 0.05]*2;% 34 - Thickness line angle at trailing edge
X_tcmax_tip = [0.20 0.46];% 35 - Maximum thickness chord-wise position
theta_tip = [-0.20 0.10];% 36 - Camber line angle at leading edge
epsilon_tip = [-0.300 -0.005];% 37 - Camber line angle at trailing edge
Ycmax_tip = [0.00 0.03];% 38 - Maximum camber
YCtcmax_tip = [0.000 0.025];% 39 - Maximum camber at maximum thickness chord-wise position
% Hte_tip = [0 0]; - Trailing edge height with respect to chord-line (constant)
X_Ycmax_tip = [0.50 0.80];% 40 - Maximum camber chord-wise position

% Gather intervals in a single matrix
intervals(1,1)=Mach(1);
intervals(1,2)=Mach(2);
intervals(2,1)=Altitude(1);
intervals(2,2)=Altitude(2);
intervals(3,1)=alpha(1);
intervals(3,2)=alpha(2);
intervals(4,1)=A(1);
intervals(4,2)=A(2);
intervals(5,1)=lambda(1);
intervals(5,2)=lambda(2);
intervals(6,1)=phi(1);
intervals(6,2)=phi(2);
intervals(7,1)=di1(1);
intervals(7,2)=di1(2);
intervals(8,1)=di2(1);
intervals(8,2)=di2(2);
intervals(9,1)=xq(1);
intervals(9,2)=xq(2);
intervals(10,1)=S(1);
intervals(10,2)=S(2);
intervals(11,1)=inc_root(1);
intervals(11,2)=inc_root(2);
intervals(12,1)=inc_kink(1);
intervals(12,2)=inc_kink(2);
intervals(13,1)=inc_tip(1);
intervals(13,2)=inc_tip(2);
intervals(14,1)=rBA_root(1);
intervals(14,2)=rBA_root(2);
intervals(15,1)=t_c_root(1);
intervals(15,2)=t_c_root(2);
intervals(16,1)=phi_root(1);
intervals(16,2)=phi_root(2);
intervals(17,1)=X_tcmax_root(1);
intervals(17,2)=X_tcmax_root(2);
intervals(18,1)=theta_root(1);
intervals(18,2)=theta_root(2);
intervals(19,1)=epsilon_root(1);
intervals(19,2)=epsilon_root(2);
intervals(20,1)=Ycmax_root(1);
intervals(20,2)=Ycmax_root(2);
intervals(21,1)=YCtcmax_root(1);
intervals(21,2)=YCtcmax_root(2);
intervals(22,1)=X_Ycmax_root(1);
intervals(22,2)=X_Ycmax_root(2);
intervals(23,2)=rBA_kink(1);
intervals(23,2)=rBA_kink(2);
intervals(24,1)=t_c_kink(1);
intervals(24,2)=t_c_kink(2);
intervals(25,1)=phi_kink(1);
intervals(25,2)=phi_kink(2);
intervals(26,1)=X_tcmax_kink(1);
intervals(26,2)=X_tcmax_kink(2);
intervals(27,1)=theta_kink(1);
intervals(27,2)=theta_kink(2);
intervals(28,1)=epsilon_kink(1);
intervals(28,2)=epsilon_kink(2);
intervals(29,1)=Ycmax_kink(1);
intervals(29,2)=Ycmax_kink(2);
intervals(30,1)=YCtcmax_kink(1);
intervals(30,2)=YCtcmax_kink(2);
intervals(31,1)=X_Ycmax_kink(1);
intervals(31,2)=X_Ycmax_kink(2);
intervals(32,2)=rBA_tip(1);
intervals(32,2)=rBA_tip(2);
intervals(33,1)=t_c_tip(1);
intervals(33,2)=t_c_tip(2);
intervals(34,1)=phi_tip(1);
intervals(34,2)=phi_tip(2);
intervals(35,1)=X_tcmax_tip(1);
intervals(35,2)=X_tcmax_tip(2);
intervals(36,1)=theta_tip(1);
intervals(36,2)=theta_tip(2);
intervals(37,1)=epsilon_tip(1);
intervals(37,2)=epsilon_tip(2);
intervals(38,1)=Ycmax_tip(1);
intervals(38,2)=Ycmax_tip(2);
intervals(39,1)=YCtcmax_tip(1);
intervals(39,2)=YCtcmax_tip(2);
intervals(40,1)=X_Ycmax_tip(1);
intervals(40,2)=X_Ycmax_tip(2);
%     A; lambda; phi; di1; di2; xq; S; ...
%     inc_root; inc_kink; inc_tip; ...
%     rBA_root; t_c_root; phi_root; X_tcmax_root; theta_root; epsilon_root; Ycmax_root; YCtcmax_root; X_Ycmax_root; ...
%     rBA_kink; t_c_kink; phi_kink; X_tcmax_kink; theta_kink; epsilon_kink; Ycmax_kink; YCtcmax_kink; X_Ycmax_kink; ...
%     rBA_tip; t_c_tip; phi_tip; X_tcmax_tip; theta_tip; epsilon_tip; Ycmax_tip; YCtcmax_tip; X_Ycmax_tip]

% Checking variable bounds for each input case
for case_index = 1:m
    for var_index = 1:33
        if input_nn(var_index, case_index) < intervals(var_index,1) || ...
                input_nn(var_index, case_index) > intervals(var_index,2)
            % fprintf('\n ==> Warning: variable %d of case %d out of boundary limits  \n', var_index, case_index)
        end
    end
end

%%%%%%%%%%%%%%%%%%%

%Initializing outputs
%Alpha = zeros(1,m);

%LIFT COEFFICIENT
%Uploading NN
% cd networks
% load NN_CL
% cd ..

if CL_logical == 1 % alfa given
    
    %Using NN
    [output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNCL);
    
    %Gathering outputs
    CL = output_nn{1};
    grad_CL = grad_nn{1};
    Alpha = input_nn(3,:);
    
    
else  % CL given
    
    % First we need to adjust all angles of attack
%     options=optimset('Display','off');
%     for case_index = 1:m
%         alfai=input_nn(3,case_index);
%         Alpha(case_index)=fsolve(@(alfa) calcalfa(alfa,input_nn(:,case_index),NNCL,CLinput),alfai,options);
%         input_nn(3,case_index)=Alpha(case_index);
%     end
%     
%     %Using NN with the correct AoA
%     [output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNCL);
%     
%     %Gathering outputs
%     CL = output_nn{1};
%     grad_CL = grad_nn{1};
    Alpha = input_nn(3,:);
    [output_nn, ~] = NN_internal_use_nn(input_nn, NNCL);
    CL1        = output_nn{1};
    input_nn(3,:) = Alpha + pi/180;
    [output_nn, ~] = NN_internal_use_nn(input_nn, NNCL);
    CL2        = output_nn{1};
    CLalpha    = (CL2-CL1)/(pi/180);
    CL0        = CL1-CLalpha*Alpha;
    Alphades   =( CLinput-CL0)/CLalpha;
    input_nn(3,:) = Alphades;
    [output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNCL);
    CL         = output_nn{1};
    grad_CL    = grad_nn{1};
    
end

clear output_nn grad_nn

%WAVE DRAG COEFFICIENT
%Uploading NN
% cd networks
% load NN_CDwave
% cd ..

%Using NN
[output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNwav);

%Gathering outputs
CDwave = output_nn{1};
CDwave = max(CDwave,zeros(size(CDwave))); %Eliminate negative wave drag
grad_CDwave = grad_nn{1};
grad_CDwave = grad_CDwave.*(ones(size(grad_CDwave,1),1)*logical(CDwave));%Eliminate gradients for negative wave drag cases
clear output_nn grad_nn

%PARASITE DRAG COEFFICIENT
%Uploading NN
% cd networks
% load NN_CDfp
% cd ..

%Using NN
[output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNcd0);

%Gathering outputs
CDfp = output_nn{1};
grad_CDfp = grad_nn{1};
clear output_nn grad_nn

%INDUCED DRAG COEFFICIENT
%Uploading NN
% cd networks
% load NN_CDind
% cd ..

%Using NN
[output_nn, grad_nn] = NN_internal_use_nn(input_nn, NNind);

%Gathering outputs
CDind = output_nn{1};
grad_CDind = grad_nn{1};
clear output_nn grad_nn

end

% AUXILIARY FUNCTION TO MATCH CL

function deltaalfa=calcalfa(alfa,input_nn,NN,CLinput)

%Gathering outputs
input_nn(3,1)=alfa;
[output_nn, grad_nn] = NN_internal_use_nn(input_nn, NN);
CL = output_nn{1};

deltaalfa=CL-CLinput;
end
function [output, doutput_dinput] = NN_internal_use_nn(input, NN)

% Oct-02-2013
% Ney Rafael S?cco
% Instituto Tecnol?gico de Aeron?utica
% ney@ita.br

output = cell(length(NN),1);
doutput_dinput = cell(length(NN),1);

for nn_index = 1:length(NN)
    [output{nn_index}, doutput_dinput{nn_index}] = feedfoward_grads(input, NN(nn_index).theta1, NN(nn_index).theta2, NN(nn_index).theta3, NN(nn_index).Norm_struct);
end

end

%%%%%%%%%%

function [output, doutput_dinput] = feedfoward_grads(input, theta1, theta2, theta3, Norm_struct)

%Normalizing inputs
input_norm = normalize_internal(input, Norm_struct.Mean_input, Norm_struct.Range_input);

%Gathering number of cases
m = size(input_norm,2);

%Feed foward
if ~isempty(theta3)
	a0 = [ones(1,m); input_norm];
	z1 = theta1*a0;
	a1 = [ones(1,m); 2./(1+exp(-2*z1))-1]; %%%
	z2 = theta2*a1;
	a2 = [ones(1,m); 2./(1+exp(-2*z2))-1]; %%%
	output_norm = theta3*a2;
else
	a0 = [ones(1,m); input_norm];
	z1 = theta1*a0;
	a1 = [ones(1,m); 2./(1+exp(-2*z1))-1]; %%%
	output_norm = theta2*a1;
end

%Back propagation
doutput_norm_da2 = theta3(:,2:end)'*ones(1,m);
doutput_norm_da1 = theta2(:,2:end)'*(doutput_norm_da2.*(1-a2(2:end,:).*a2(2:end,:)));
doutput_norm_da0 = theta1(:,2:end)'*(doutput_norm_da1.*(1-a1(2:end,:).*a1(2:end,:)));

output = denormalize_internal(output_norm, Norm_struct.Mean_output, Norm_struct.Range_output);

doutput_dinput = doutput_norm_da0.*(repmat(Norm_struct.Range_output*ones(1,m),40,1))./(Norm_struct.Range_input*ones(1,m));

end

%%%%%%%%%%

function X_norm = normalize_internal(X, Mean, Range)

%Number of training sets
m = size(X,2);
%Normalization
X_norm = 2*(X - Mean*ones(1,m))./(Range*ones(1,m));
%
end

%%%%%%%%%%

function X = denormalize_internal(X_norm, Mean, Range)

%Number of training sets
m = size(X_norm,2);

%Denormalization
X = X_norm.*(Range*ones(1,m))/2 + Mean*ones(1,m);

end