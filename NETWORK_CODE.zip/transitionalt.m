function [TA]=transitionalt(M,CAS,ISADEV)

% ISADEV: delta temperature from standard (ISA atmosphere).
% CAS: calibrated airspeed in knots.
% M:Mach Number;

f=0;
h=0;
while f<=0
       [TR, PR, DR, a] = atmos(h,ISADEV);
       K1=1/PR;
       K2=CAS/a;
       M1=sqrt(5*((K1*((1+0.2*K2^2)^3.5-1)+1)^(1/3.5)-1));
       if (M1>=M) 
         f=1;
         TA=h;
       end  
       h=h+100;
end

