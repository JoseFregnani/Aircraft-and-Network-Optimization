function y=NETWORKARRAYS(M);
    
   lin=size(M,1); 
   col=size(M,2); 
   
   L=strings(lin,1);
   for i=1:lin
       for j=1:col           
               L(i,1)=strcat(L(i,1),num2str(round(M(i,j),1)),',');
       end
   end    
   y=L;