function dout=subida1(h,X,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
      S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,CASCLB,MACHCLB,...
      NNind,NNwav,NNcd0,NNCL)
%
W=X(2);
m2feet=3.28083;
g=9.80665;
altm=h/m2feet;
%
[~, PR, ~, ~] = atmos(h,ISADEV);
%
    if CASCLB>0
        CAS=CASCLB;
        [M]=CAS2MACH(CASCLB,PR);
        [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
        Fn=Fn/g;
        %[facCAS,facMach]=acelfac(M,h,ISADEV);
        ToW=n*Fn/W;
        [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
        W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
        %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,CAS,0,h,ISADEV);
    else
        M=MACHCLB;
        [CAS]=MACH2CAS(M,PR);
        [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
        Fn=Fn/g;
        %[facCAS,facMach]=acelfac(M,h,ISADEV);
        ToW=n*Fn/W;
        [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
        W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
        %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,0,M,h,ISADEV);
    end 
    
    distodt=(TAS/60);
    disodh = distodt/RC;
    dfuelodt = (n*FF/60);
    dWodt=-dfuelodt;
    dWodh=dWodt*1/RC;
    dtodh=1/RC;
    dout=[dtodh; dWodh; disodh];
