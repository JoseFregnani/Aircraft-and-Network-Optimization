function [T,Wf,CRZALT]=TF(TOW,DISTTOT,ORIGALT,DESTALT,ISADEV,HDG,CLBCAS,CLBMACH,CRZCAS,CRZMACH,DESCAS,DESMACH,RCMIN,BUFFMARGIN,MINCRZTIME,MMO,VMO,MTOW,cieling)

tic

% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% GEOMECTRIC PARAMETERS

S=72.72;
b=25;
WAR=8.6;
afil=0.235;
tcroot = 0.145; 
tctip  = 0.11;  
tc=(3*tcroot+2*tctip)/5;
tr=0.285;
df=3.3;
phi14=23.5;
CLMAX=1.6;
PWing=1;
VTarea=16.2;
VTAR=0.89;
VTTR=0.740;
VTSweep=41;
HTarea=23.35;
HTAR=4.35;
HTTR=0.4;
PHT=1;
FusDiam=3.5;
NPax=78;
NCorr=1;
NSeat=4;
ncrew= 5;
AisleWidth=0.49;
CabHeightm=2;
Kink_semispan=0.34;
SEATwid=0.46;
widthreiratio=1.1;

%ENGINE PARAMETERS

n=2;
PEng = 1; % 1= two underwing engines; 2= two engines at rear fuselage
MAXRATE=13400;

if PEng == 1
    nedebasa=n;
else
    nedebasa=0;
end

maneted=1;
ebypass= 5;    
ediam= 1.36;  
efanpr= 1.425;
eopr= 28.5;    
eTIT= 1240; 

Engine_data(1)     = maneted;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;


% CUSTOS

ct=25; % $/min
cf=1;  % $/kg

% WET AREA CALCULATION

swet2=502;
%swet2=wettedarea(CRZMACH,FusDiam,NPax,NCorr,NSeat,SEATwid,AisleWidth,Kink_semispan,S,WAR,tr,phi14,PWing,Engine_data,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT);

% MAX & OPT ALTITUDE CALCULATION

initalt=ORIGALT;
hf=cieling;
step=100;

[HMAX,RCRES]=MAXALT(S,b,afil,tc,df,swet2,phi14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN);
[HOPT,SRMAX]=optalt(S,b,afil,tc,df,swet2,phi14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN);

% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK

g_sub=4/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=10*CRZMACH*MINCRZTIME;
K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>cieling
  HMAX2=cieling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt=HOPT;
else
    finalalt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 

finalalt= 1000*(fix (finalalt/1000));
FL=finalalt/100;

ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        %fprintf('\n ODD',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-2000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        %fprintf('\n EVEN',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-2000;
        end 
    end
end    

% CLIMB CALCULATION

maneted=0.95;
initalt=ORIGALT+1500;
[dclb,tclb,fclb,hf]=CALC_CLB(S,b,afil,tc,df,swet2,phi14,nedebasa,maneted,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN);

% fprintf('\n CLIMB:');
% fprintf('\n => GWi  = %5.0f',TOW);
% fprintf('\n => GWf  = %5.0f',TOW-fclb);
% fprintf('\n => ALTi = %5.0f',initalt);
% fprintf('\n => ALTf = %5.0f',finalalt);
% fprintf('\n => OPTALT = %5.0f',HOPT);
% fprintf('\n => MAXALT = %5.0f',HMAX);
% fprintf('\n => CAS = %5.0f',CLBCAS);
% fprintf('\n => Mach= %5.3f',CLBMACH);
% fprintf('\n => AVG RC= %5.0f',(finalalt-initalt+1500)/tclb);
% fprintf('\n => RES RC= %5.0f',RCRES);
% fprintf('\n => OPT SR= %6.4f',SRMAX);
% fprintf('\n');
% fprintf('\n => time = %5.1f',tclb);
% fprintf('\n => dist = %5.1f',dclb);
% fprintf('\n => fuel = %5.1f',fclb);
% fprintf('\n => AVGFF = %5.1f',fclb/tclb*60);   

% CRUISE & DESCENT ALGORITHM 

WTOC=TOW-fclb;
INITCRZALT=finalalt;
h=INITCRZALT;

K=0;
dcrz=DISTTOT-dclb-K;
flag=1;

while flag==1
    
    % CRUISE
    
    [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
    [TR, PR, DR, a] = atmos(h,ISADEV);

    if h<=10000
        M=CAS2MACH(250,PR);
    end
    if and(h>10000,h<=TA)
        M=CAS2MACH(CRZCAS,PR);
    end
    if h>TA
        M=CRZMACH;
    end
    
    [tcrz,fcrz]=CALC_CRZ(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,WTOC,h,M,dcrz,ISADEV);
    
    WTOD=WTOC-fcrz;
    FINALCRZALT=h;
    
    % DESCENT

    FINALCRZALT=INITCRZALT;
    initalt=FINALCRZALT;
    finalalt=DESTALT+1500;
    maneted=0.55;

    [ddes,tdes,fdes]=CALC_DES(S,b,afil,tc,df,swet2,phi14,nedebasa,maneted,ebypass,ediam,efanpr,eopr,eTIT,WTOD,initalt,finalalt,DESCAS,DESMACH,ISADEV,RCMIN);

    dTOT=dclb+dcrz+ddes;
    e=abs(DISTTOT-dTOT);
    if e<=0.05;
       flag=0;
%        fprintf('\n => DTOT= %5.0f',dTOT);
    else   
       dcrz=dcrz-e*0.8; 
    end    
end

TOTFUEL = fclb+fdes+fcrz;
TOTTIME = tclb+tdes+tcrz;
TOTDIST = dclb+ddes+dcrz;

DOC=ct*TOTTIME+cf*TOTFUEL;
COSTF=DOC/TOTDIST;

% fprintf('\n');
% fprintf('\n CRUISE:');
% fprintf('\n => GWi  = %5.0f',WTOC);
% fprintf('\n => GWf  = %5.0f',WTOD);
% fprintf('\n => ALTi = %5.0f',INITCRZALT);
% fprintf('\n => ALTf = %5.0f',FINALCRZALT);
% fprintf('\n => CAS = %5.0f',CRZCAS);
% fprintf('\n => Mach= %5.3f',M);
% fprintf('\n => time = %5.1f',tcrz);
% fprintf('\n => dist = %5.1f',dcrz);
% fprintf('\n => fuel = %5.1f',fcrz);   
% fprintf('\n => AVGFF = %5.1f',fcrz/tcrz*60);   
% fprintf('\n => maneted = %5.2f',maneted);   
% fprintf('\n');
% fprintf('\n DESCENT:');
% fprintf('\n => GWi  = %5.0f',WTOD);
% fprintf('\n => GWf  = %5.0f',WTOD-fdes);
% fprintf('\n => ALTi = %5.0f',initalt);
% fprintf('\n => ALTf = %5.0f',finalalt);
% fprintf('\n => CAS = %5.0f',DESCAS);
% fprintf('\n => Mach= %5.3f',DESMACH);
% fprintf('\n => AVG RD= %5.0f',(finalalt-initalt+1500)/tdes);
% fprintf('\n');
% fprintf('\n => time = %5.1f',tdes);
% fprintf('\n => dist = %5.0f',ddes);
% fprintf('\n => fuel = %5.1f',fdes);
% fprintf('\n => AVGFF = %5.1f',fdes/tdes*60);   
% fprintf('\n');
% fprintf('\n TOTAL:');
% fprintf('\n => time = %5.1f',TOTTIME);
% fprintf('\n => dist = %5.1f',TOTDIST);
% fprintf('\n => fuel = %5.1f',TOTFUEL);
% fprintf('\n => FFAVG = %5.1f',TOTFUEL/TOTTIME*60);
% fprintf('\n');
% fprintf('\n => DOC = %5.1f',DOC);
% fprintf('\n => COST FUNCTION = %5.1f',COSTF);
% fprintf('\n');
% fprintf('\n => elapsed time = %5.1f',toc);

Wf=TOTFUEL;
T=TOTTIME;
CRZALT=INITCRZALT;

end

