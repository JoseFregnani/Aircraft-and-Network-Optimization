%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - Network Fixed Analysis 
% (Mode Frontier Module)
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 1.0 / December 2016
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
close all

% DESIGN VARIABLES - FROM BASELINE ACFT

% wSweep14     = 23.5;
% wAR          = 8.6;
% wTR          = 0.285;
% MAXPAX       = 78;
% wS           = 72.72;
% ediam        = 1.36; 
% ebypass      = 5;   
% eopr         = 28.5;
% wTwist       = -3.5;
% Kink_semispan= 0.34;
 
% DESIGN VARIABLES - FROM OPTIMIZER(MODE FRONTIER)

wSweep14=X1;
wAR=X2;
wTR=X3;
MAXPAX=X4;
wS=X5;
ediam=X6;
ebypass=X7;
eopr=X8;
wTwist=X9;
Kink_semispan=X10;

% INIT VARIABLES;

ISADEV=0;
n=5;
PAXWT=110;
MAXUTIL=12;
TURNAROUND=30;
TIT=5;
TOT=10;
ID=30;
TO_ALLOWANCE=200;
ARR_ALLOWANCE=100;
avg_ticket=200;
K1=1.3;
K2=1.1;
NCorr=1;
NSeat=6;

% PRE CALCULATION

PRECALC(wS,wAR,wTR,wSweep14,NSeat,NCorr,MAXPAX,ediam,ebypass,eopr,wTwist,Kink_semispan);

% MTOW and OEW CALCULATION - INSERT FUNCTION HERE

% MAIN_MTOW

MTOW=37500;
OEW =18000;

% DESIGN DIAGRAM CHECK - INSERT FUNCTION HERE

design=0;

% MAIN LOOP

if design==0;
     
    % Retrieve Airport and Demand Data

    [Airport,X,D,LF,DIST,HDG]=Airportdata(n);

    % Construct Frequencies Matrix

        TOTDEMAND=0;
        for i=1:n
          for j=1:n
             if i==j
               f=0;
             else  
               f=round(D(i,j)/(MAXPAX*LF(i,j)));
             end
             FREQ(i,j)=f;  
             TOTDEMAND=TOTDEMAND+D(i,j)*X(i,j);
          end
        end

     % CONSTRUCT Wf,T and CF 

        for i=1:n
            for j=1:n
               if i~j;
                   if X(i,j)~0;
                     DISTANCE=DIST(i,j);
                     DISTALT=DIST(j,i);  
                     NPAX=LF(i,j)*MAXPAX;
                     PAYLOAD=NPAX*PAXWT;
                     dep=Airport(i).name;
                     arr=Airport(j).name;
                     Origelev=Airport(i).elev;
                     Destelev=Airport(j).elev;
                     Altelev=Airport(i).elev;
                     TH=HDG(i,j);
                     THA=HDG(j,i);
                     [Wf(i,j),T(i,j),CF(i,j)]=Mission3_MF(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,MAXPAX,MTOW,OEW);                        
                     T(i,j)=(T(i,j)+TIT+TOT+TURNAROUND+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)/60; 
                     Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
                   end
               end 
            end
        end    

     % TOTAL DOC

        TOTCOST=0;
        TOTDIST=0;
        TOTALFREQ=0;
        TOTALPAX=0;
        TOTTIME=0;
        TOTFLIGHTS=0;
        
     % FINAL CALCULATIONS

        for i=1:n
            for j=1:n
                if X(i,j)~0
                    TOTCOST=TOTCOST+DIST(i,j)*CF(i,j)*FREQ(i,j)+ID*(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
                    TOTDIST=TOTDIST+DIST(i,j)*FREQ(i,j);
                    TOTALPAX=TOTALPAX+LF(i,j)*MAXPAX*FREQ(i,j);
                    TOTTIME=TOTTIME+FREQ(i,j)*T(i,j);
                    TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);         
                end    
            end    
        end
       
        DOC=TOTCOST/TOTDIST
        CASK=K1*DOC/TOTALPAX;
        RASK=K2*avg_ticket/TOTDIST;
        YIELD=RASK-CASK               
        NACFT=TOTTIME/MAXUTIL      
        
end
