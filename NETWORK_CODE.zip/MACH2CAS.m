function [CAS]=MACH2CAS(M,PR)

K1=0.2*M^2+1;
CAS=1479.1*sqrt((PR*((K1^3.5)-1)+1)^(1/3.5)-1);