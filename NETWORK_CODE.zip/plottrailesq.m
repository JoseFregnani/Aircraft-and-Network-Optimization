function plottrailesq(orix,oriy,dzfloor,FUSELAGE_nrails_esq,FUSELAGE_drails_esq,FUSELAGE_dseat_seat_rail)

railthick=0.02;
% ++ 1o trilho
% 1o trilho coord x
trail.x(1)=orix - FUSELAGE_dseat_seat_rail;
trail.x(2)=orix - FUSELAGE_dseat_seat_rail - railthick;
trail.x(3)=trail.x(2);
trail.x(4)=trail.x(1);
trail.x(5)=trail.x(1);
% 1o trilho coord y
trail.y(1)=dzfloor;
trail.y(2)=dzfloor;
trail.y(3)=oriy;
trail.y(4)=oriy;
trail.y(5)=trail.y(1);

plot(trail.x,trail.y,'k')
hold on

% ++ Trilhos restantes

for j=1:(FUSELAGE_nrails_esq-1)
trail.x(1:5) =trail.x(1:5)-FUSELAGE_drails_esq;  
plot(trail.x,trail.y,'k')
hold on
end

% Apoio transversal
xt(1) = orix - FUSELAGE_dseat_seat_rail - railthick;
xt(2) = xt(1) - (FUSELAGE_nrails_esq-1)*FUSELAGE_drails_esq + railthick;

yt(1)= 0.50*(dzfloor+oriy);
yt(2) = yt(1);
plot(xt,yt,'k')
hold on

return