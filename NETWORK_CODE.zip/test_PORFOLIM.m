clc

% AICRAFT DATA
A.MTOW          =55000;
A.MLW           =32000;   
A.wS            =100;
A.wAR           =11;
A.wTR           =0.40;
A.wSweepLE      =23.5;
A.inc_root      =2; 
A.inc_kink      =0; 
A.inc_tip       =-1; 
A.Kink_semispan =0.32;
A.r0            =[0.0153 0.0150 0.0150];
A.t_c           =[0.1228 0.1055 0.0982];
A.phi           =[-0.0799 -0.1025 -0.1553];
A.tcmax         =[0.3738 0.3585 0.3590];
A.theta         =[0.0787 -0.0295 0.1000];
A.epsilon       =[-0.0549 -0.2101 -0.0258];
A.Ycmax         =[-4.0000e-04 0.0185 0.0104];
A.YCtcmax       =[-6.0000e-04 0.0028 0.0109];
A.X_Ycmax       =[0.6188 0.7870 0.5567];
A.X_tcmax       =[0.3738 0.3585 0.3590];
A.wTCmed        =0.1100;     
A.Airp_SWET     =485;
A.wingSwet      =122.5;
A.longtras      =0.6;
A.CLmax         =1.8;
A.VTarea        =16.2;           
A.VTSweep       =41;
A.ediam         =1.425;
A.ebypass       =5.0;
A.MAXRATE       =22000;
A.CLmax         =1.6;
A.n             =2;
% LOAD NEURAL NETWORK
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');

% OPS DATA
ASDA    =2560;
LDA     =2000;
TO_elev =2500;
LD_elev =2500;
TO_TREF =30;
LD_TREF =28;
           
[RTOW,RLW]=PERFOLIM(A,NNind,NNwav,NNcd0,NNCL,ASDA,LDA,TO_elev,LD_elev,TO_TREF,LD_TREF);