function [ALTOPT,SRMAX]=optalt(S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,W,initalt,finalalt,step,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL)

% CONSTANTS
%kg2lb=2.2046;
m2feet=3.28083;
g=9.8067;
%
[TA]=transitionalt(CLBMACH,CLBCAS,ISADEV);
t=0;
d=0;
fuel=0;
RC=9999;
HOPT=0;

% CLIMB TO 10000 ft with 250KCAS
hi=initalt+1500;
h=hi;
hf=10000;
SROPT=0;

while and(RC>RCMIN, h<hf)
            
    %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/m2feet;
    [~, PR, ~, ~] = atmos(h,ISADEV);
    [M]=CAS2MACH(250,PR);    
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    ToW=n*Fn/W;
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,250,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
    %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,250,M,h,ISADEV);
    
   
    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
    
    SR=TAS/FF;
    if SR>SROPT
       SROPT=SR;
       HOPT=h;
    end  
   
end

deltaalt=0;
h=10000+deltaalt;
hf=TA;

% CLIMB TO TA with CONSTANT CAS

while and(RC>RCMIN, h<=hf)

     %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/m2feet;
    [~, PR, ~, ~] = atmos(h,ISADEV);
    [M]=CAS2MACH(CLBCAS,PR);    
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    ToW=n*Fn/W;
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CLBCAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
    %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,CLBCAS,0,h,ISADEV);
    
    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
    
    SR=TAS/FF;
    if SR>SROPT
       SROPT=SR;
       HOPT=h;
    end   

end

% CLIMB TO TA with CONSTANT MACH
hf            = finalalt;
[~, PR, ~, ~] = atmos(h,ISADEV);
[M]           = CAS2MACH(CLBCAS,PR); 
while and(RC>RCMIN, h<=hf)

    %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/3.28083;
    [~, PR, ~, ~] = atmos(h,ISADEV);
    [CAS]=MACH2CAS(M,PR);
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    ToW=n*Fn/W;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,0,M,h,ISADEV);
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
    
    SR=TAS/FF;
    if SR>SROPT
       SROPT=SR;
       HOPT=h;
    end   
end

ALTOPT=HOPT-100;
SRMAX=SROPT;


