function [FFHOLD]=HOLD(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,W,h,ISADEV)

[TR,PR,DR,a] = atmos(h,ISADEV);

TASi=150;
f=0;
CDoCLmin=9999;
VHOLD=0;

TAS=TASi;
while f==0;
  M=TAS/a;  
  [CDoCL]=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,M,ISADEV,TR);
  if CDoCL<=CDoCLmin
      VHOLD=TAS;
      CDoCLmin=CDoCL;
  else
      f=1;
  end    
  TAS=TAS+1;
end  

[TSFC,CDoCL,FF]=SFCCRZ(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,W,h,M,ISADEV);

FFHOLD=2*FF;


