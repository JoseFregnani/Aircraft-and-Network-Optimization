clc
%clear all
close all

CLBCAS=X1; % 250 to 340 KIAS%
CLBMACH=X2;  % 0.5 to 0.82
CRZMACH=X3; % 0.5 to 0.82
CRZCAS=X4; % 250 to 340 KIAS%
DESCAS=X5; % 250 to 340 KIAS%
DESMACH=X6; % 0.5 to 0.82
DISTTOT=X7; % 500 to 4000 %
TOW=X8; % 28000 to 37500 %

%
% *******  load neural networks  **********
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');
%
tic
% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% GEOMECTRIC PARAMETERS
wS       = 72.72;
wSft2    = wS*m2feet*m2feet;
wAR      = 8.6;
wTR      = 0.285;
wSweep14 = 23.5;
wTwist   = -3.5;
CLMAX    = 1.6;
PWing    = 1;
VTarea   = 16.2;
VTAR     = 0.89;
VTTR     = 0.740;
VTSweep  = 41;
HTarea   = 23.35;
HTAR     = 4.35;
HTTR     = 0.4;
PHT      = 1;
container_type = 'None';
NPax           = 78;
NCorr          = 1;
NSeat          = 4;
ncrew          = 5;
AisleWidth     = 0.49;
CabHeightm     = 2;
Kink_semispan  = 0.34;
SEATwid        = 0.46;
widthreiratio  = 1.15;
%
inc_root           = 2;
inc_kink           = 0;
inc_tip            = inc_root + wTwist;
%ENGINE PARAMETERS
PEng = 1; % 1= two underwing engines; 2= two engines at rear fuselage
MAXRATE=13400;
%
switch PEng
    case 1
        n= 2;
        nedebasa=2;
    case 2
        n=2;
        nedebasa=0;
    case 3
        n=3;
        nedebasa=2;
    case 4
        n=4;
        nedebasa=4;
end
%
ebypass= 5;    
ediam= 1.36;  
efanpr= 1.425;
eopr= 28.5;    
eTIT= 1240; 
%
Engine_data(1)     = PEng;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;

% OPERATIONS PARAMETERS

% DISTTOT=2000;
HDG=0;
ORIGALT=0;
DESTALT=0;
ceiling=41000;
ALTDIST=200;
HOLDTIME=30;
ISADEV=0;
RCMIN=300;
BUFFMARGIN=1.3;
MINCRZTIME=3;
MMO=0.82;
VMO=340;
% wing span
b=sqrt(wAR*wS);

% CUSTOS

ct=25; % $/min
cf=1;  % $/kg

% Sobiescki parameters for three wing airfoils

[r0, t_c, phi, X_tcmax, theta, epsilon, ...
    Ycmax, YCtcmax, X_Ycmax]=airfoilcoeff();
wTCmed = (t_c(1)+t_c(2)+t_c(3))/3; 

%Fuselage cross-section sizing
% [fus_width, fus_height]=fuscrosssect02(container_type,NCorr,NSeat,CabHeightm,...
%     SEATwid,AisleWidth,widthreiratio);
% FusDiam = sqrt(fus_width*fus_height);

FusDiam=5.5;

% WET AREA CALCULATION
[Airp_SWET, wingSwet,lf ,lco, ~ , ~ ,wMAC, wSweepLE, ~ ,...
    ~ , ~,~,~,~, ~,~,~,Ccentro,Craiz,Cquebra, Cponta, ...
    xutip, yutip, xltip, yltip,...
    xukink,yukink,xlkink,ylkink, xuroot,yuroot,xlroot,ylroot,T0]...
    = wettedarea(...
    MMO,FusDiam,...
    NPax,NCorr,NSeat,SEATwid,AisleWidth,...
    Kink_semispan,wS,wAR,wTR,wSweep14,wTwist,...
    PWing,Engine_data,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT);

swet2=Airp_SWET; % [m2]
%
% TOW     = MTOWi;
initalt = ORIGALT;
hf      = ceiling;
step    = 100;

% MAX & OPT ALTITUDE CALCULATION
[HMAX,RCRES]=MAXALT(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,step,hf,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
%
[HOPT,SRMAX]=optalt(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

%[HMAX,RCRES]=MAXALT(wS,b,wTR,wTCmed,FusDiam,swet2,wSweep14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN);
%[HOPT,SRMAX]=optalt(wS,b,wTR,wTCmed,FusDiam,swet2,wSweep14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN);

% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK

g_sub=4/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=10*CRZMACH*MINCRZTIME;
K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>ceiling
  HMAX2=ceiling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt=HOPT;
else
    finalalt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 

finalalt= 1000*(fix (finalalt/1000));
FL=finalalt/100;

ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        %fprintf('\n ODD',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        %fprintf('\n EVEN',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end 
    end
end    

% CLIMB CALCULATION

maneted=0.95;
initalt=ORIGALT+1500;
%[dclb,tclb,fclb,hf]=CALC_CLB(wS,b,wTR,wTCmed,FusDiam,swet2,wSweep14,nedebasa,maneted,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN);
[dclb,tclb,fclb,hf]=CALC_CLB_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);
%
% CRUISE & DESCENT ALGORITHM 
WTOC=TOW-fclb;
INITCRZALT=finalalt;
h=INITCRZALT;

K=0;
dcrz=DISTTOT-dclb-K;
flag=1;

while flag==1
    
    % CRUISE
    
    [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
    [TR, PR, DR, a] = atmos(h,ISADEV);

    if h<=10000
        M=CAS2MACH(250,PR);
    end
    if and(h>10000,h<=TA)
        M=CAS2MACH(CRZCAS,PR);
    end
    if h>TA
        M=CRZMACH;
    end
    
    %[tcrz,fcrz,~]=CALC_CRZ(wS,b,wTR,wTCmed,FusDiam,swet2,wSweep14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,WTOC,h,M,dcrz,ISADEV);
    %
      [tcrz,fcrz,mancrz]=CALC_CRZ(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,n,ebypass,ediam,efanpr,eopr,eTIT,...
    WTOC,h,M,dcrz,ISADEV,NNind,NNwav,NNcd0,NNCL);
    
   %
    WTOD=WTOC-fcrz;
    FINALCRZALT=h;
    
    % DESCENT

    FINALCRZALT=INITCRZALT;
    initalt=FINALCRZALT;
    finalalt=DESTALT+1500;
    maneted=0.55;
    %
 [ddes,tdes,fdes]=CALC_DES_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
         inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
        WTOD,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,NNind,NNwav,NNcd0,NNCL);
    %[ddes,tdes,fdes]=CALC_DES(wS,b,wTR,wTCmed,FusDiam,swet2,wSweep14,nedebasa,maneted,ebypass,ediam,efanpr,eopr,eTIT,WTOD,initalt,finalalt,DESCAS,DESMACH,ISADEV,RCMIN);

    dTOT=dclb+dcrz+ddes;
    e=abs(DISTTOT-dTOT);
    if e<=0.05;
       flag=0;
%        fprintf('\n => DTOT= %5.0f',dTOT);
    else   
       dcrz=dcrz-e*0.8; 
    end    
end

%
TOTFUEL = fclb+fdes+fcrz;
TOTTIME = tclb+tdes+tcrz;
TOTDIST = dclb+ddes+dcrz;

DOC=ct*TOTTIME+cf*TOTFUEL;
COSTF=DOC/TOTDIST;
ALW=TOW-TOTFUEL;

RESF=RES(ALW,ALTDIST,HOLDTIME);

TOF=RESF+TOTFUEL;
AZFW=TOW-TOF;
CRZALT=FINALCRZALT;

fprintf('\n CLIMB:');
fprintf('\n => GWi  = %5.0f kg',TOW);
fprintf('\n => GWf  = %5.0f kg',TOW-fclb);
fprintf('\n => ALTi = %5.0f ft',initalt);
fprintf('\n => ALTf = %5.0f ft',finalalt);
fprintf('\n => OPTALT = %5.0f',HOPT);
fprintf('\n => MAXALT = %5.0f',HMAX);
fprintf('\n => CAS = %5.0f',CLBCAS);
fprintf('\n => Mach= %5.3f',CLBMACH);
fprintf('\n => AVG RC= %5.0f',(finalalt-initalt+1500)/tclb);
fprintf('\n => RES RC= %5.0f',RCRES);
fprintf('\n => OPT SR= %6.4f',SRMAX);
fprintf('\n');
fprintf('\n => time = %5.1f',tclb);
fprintf('\n => dist = %5.1f',dclb);
fprintf('\n => fuel = %5.1f',fclb);
fprintf('\n => AVGFF = %5.1f',fclb/tclb*60);   

fprintf('\n');
fprintf('\n CRUISE:');
fprintf('\n => GWi  = %5.0f kg',WTOC);
fprintf('\n => GWf  = %5.0f kg',WTOD);
fprintf('\n => ALTi = %5.0f ft',INITCRZALT);
fprintf('\n => ALTf = %5.0f ft',FINALCRZALT);
fprintf('\n => CAS = %5.0f',CRZCAS);
fprintf('\n => Mach number = %5.3f',M);
fprintf('\n => time = %5.1f',tcrz);
fprintf('\n => dist = %5.1f',dcrz);
fprintf('\n => fuel = %5.1f',fcrz);   
fprintf('\n => AVGFF = %5.1f',fcrz/tcrz*60);   
fprintf('\n => maneted = %5.2f',maneted);   
fprintf('\n');
fprintf('\n DESCENT:');
fprintf('\n => GWi  = %5.0f kg',WTOD);
fprintf('\n => GWf  = %5.0f kg',WTOD-fdes);
fprintf('\n => ALTi = %5.0f ft',initalt);
fprintf('\n => ALTf = %5.0f ft',finalalt);
fprintf('\n => CAS = %5.0f',DESCAS);
fprintf('\n => Mach number = %5.3f',DESMACH);
fprintf('\n => AVG RD= %5.0f',(finalalt-initalt+1500)/tdes);
fprintf('\n');
fprintf('\n => time = %5.1f',tdes);
fprintf('\n => dist = %5.0f',ddes);
fprintf('\n => fuel = %5.1f',fdes);
fprintf('\n => AVGFF = %5.1f',fdes/tdes*60);   
fprintf('\n');
fprintf('\n TOTAL:');
fprintf('\n => time = %5.1f',TOTTIME);
fprintf('\n => dist = %5.1f',TOTDIST);
fprintf('\n => fuel = %5.1f',TOTFUEL);
fprintf('\n => FFAVG = %5.1f',TOTFUEL/TOTTIME*60);
fprintf('\n');
fprintf('\n => DOC = %5.1f',DOC);
fprintf('\n => COST FUNCTION = %5.1f',COSTF);
fprintf('\n => LW  = %5.0f',ALW);
fprintf('\n => TOF = %5.0f',TOF);
fprintf('\n => ZFW = %5.0f',AZFW);
fprintf('\n');
fprintf('\n => elapsed time = %5.1f',toc);

