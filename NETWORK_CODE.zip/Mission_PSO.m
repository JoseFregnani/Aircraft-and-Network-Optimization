clc

lb     =[250 0.65 0.65 250 250 0.65 250 0.65 0.65 250 250 0.65];
ub     =[320 0.80 0.80 320 320 0.80 320 0.80 0.80 320 320 0.80];
initpop=[280 0.78 0.78 280 280 0.78 250 0.74 0.74 250 250 0.74];

options = optimoptions('particleswarm','SwarmSize',20,'HybridFcn',@fmincon);
[x,fval,exitflag,output] = particleswarm(@Mission2_OPT,12,lb,ub,options)

Mission2_OPT(x)

