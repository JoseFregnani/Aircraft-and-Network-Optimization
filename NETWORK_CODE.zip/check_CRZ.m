% function check_CRZ()
% cfe     = 0.003;
%  clear all
%  clc
% wSweep14           = 23.5;
% wS                 = 72.72;
% wTR                = 0.285;
% wAR                = 8.6;
% wTCmed             = (0.145+0.11)/2;
% MTOW=37500;
% W_climb_final = 0.985*MTOW;
% Engine_data(1)     = 1;
% Engine_data(2)     = 5;
% Engine_data(3)     = 1.36;
% Engine_data(4)     = 1.425;
% Engine_data(5)     = 28.5;
% Engine_data(6)     = 1240;
% Ceiling =41000;
% T0=14300;
% FusDiam =3.1;
% MMO=0.82;
% SWET=480;
% %
% TWreq_crz=check_CRZ1(Ceiling,MMO,MTOW,W_climb_final,wS,wAR,wTR,...
%     wSweep14,wTCmed,SWET,FusDiam,Engine_data,T0)
% end
function TWreq_crz=check_CRZ(Ceiling,Mach,MTOW,W_climb_final,wS,wAR,wTR,...
    wLEsweep,SWET,sWingSwet,Engine_data,T0,inc_root,inc_kink,inc_tip,...
    kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,cfe)
%
g       = 9.80665;
N2lbf   = 1/4.448221615;
ft2m    = 1/3.28;
%
MMO     = Mach - 0.02;
%PEng    = Engine_data(1); % 1= two underwing engines; 2= two engines at rear fuselage
ebypass = Engine_data(2); % Engine by-pass ratio
ediam   = Engine_data(3); % Fan diameter [m]
efanpr  = Engine_data(4); % Fan pressure ratio
eopr    = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT    = Engine_data(6); % Turbine Inlet Temperature [K]
%
%fatorw      = W_climb_final/MTOW;
%
[tracioncruisefull,~]=engine_main(Ceiling*ft2m,...
    MMO,efanpr,eopr,ebypass,0.98,ediam,eTIT);
%
Tcrz        = tracioncruisefull*N2lbf;
%
atm=atmosfera(Ceiling,0);
rho         = atm(6); % Air density [kg/m3]
va          = atm(7); % Sound speed [m/s]
%
pdyn_CRZ    = 0.5*rho*((va*MMO)^2);
clcrz       = (W_climb_final*g)/(wS*pdyn_CRZ);
alfagdummy  = 1;
% Swetairplanenew  = Swet - Swetwbaseline + Swetwcalc;
% bw          = sqrt(wS*wAR);
% V           = MMO*va;
[CDwing, ~]=CDCLneural2(MMO, Ceiling*ft2m,clcrz, alfagdummy,wS,wAR,wTR,wLEsweep,...
    inc_root,inc_kink,inc_tip,kink_position,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
Areamolhada  = (SWET - sWingSwet);
CD0          = cfe*Areamolhada/wS;
cdcrz        = CDwing + CD0;
LDcrz        = clcrz/cdcrz;
TWreq_crz    = 1/LDcrz;
% correcao para valores na tecolagem

TWreq_crz    = TWreq_crz*(T0/Tcrz)*(W_climb_final/MTOW);
%
end