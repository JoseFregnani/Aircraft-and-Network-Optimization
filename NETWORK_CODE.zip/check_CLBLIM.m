function ToW=check_CLBLIM(A,NNind,NNwav,NNcd0,NNCL,cfe,dflecflaptakeoff,ISADEV,elev)

% Roskam (1997). Preliminary Sizing of Airplanes. Part I (pg.144)
% Based on FAR 25.121 take-off climb

% LOAD AIRCRAFT DATA
MTOW            =A.MTOW;   
wS              =A.wS;
wAR             =A.wAR;
wTR             =A.wTR;
wSweepLE        =A.wSweepLE;
inc_root        =A.inc_root; 
inc_kink        =A.inc_kink; 
inc_tip         =A.inc_tip; 
Kink_semispan   =A.Kink_semispan;
r0              =A.r0;
t_c             =A.t_c;
phi             =A.phi;
theta           =A.theta;
epsilon         =A.epsilon;
Ycmax           =A.Ycmax;
YCtcmax         =A.YCtcmax;
X_Ycmax         =A.X_Ycmax;
X_tcmax         =A.X_tcmax;
Airp_SWET       =A.Airp_SWET;
wingSwet        =A.wingSwet;
longtras        =A.longtras;
CLmax_clean     =A.CLMAX;
VTarea          =A.VTarea;           
VTSweep         =A.VTSweep;
ediam           =A.ediam;
ebypass         =A.ebypass;
neng            =A.n;

%
ft2m    =0.3048;
kt2ms   =0.5144;
g       =9.80665;
rad     =pi/180;
h       =elev+400;

% Atmospheric calculation
[~, ~, sigma, a] = atmos(h,ISADEV);
rho=1.225*sigma;
a  =kt2ms*a;

cl2seg              = CLmax_clean+0.6;
V                   = 1.2*sqrt(MTOW*g/(cl2seg*wS*0.50*rho));
M                   = V/a;

%
[CDwing, ~]=CDCLneural2(0.2, 0.,cl2seg, 1,wS,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);

%
[CD0_ubrige]        = cfe*(Airp_SWET-wingSwet)/wS;

% Drag increase due to flaps and rudder deflection
dcdflapetakeoff     = CD_flap(dflecflaptakeoff,longtras);
dcdrudder           = 0.0020*cos(rad*VTSweep)*(VTarea/wS); 

% Windmilling drag(Torenbeek) 
jmach            = M;
VN               = 0.92; 
if ebypass < 3.5
  VN = 0.42;
end   
AN=pi*ediam*ediam/4;
term1=2/(1+0.16*jmach*jmach);
cdwindmilli=0.0785*(ediam*ediam)+term1*AN*VN*(1-VN);
cd2seg=CDwing+CD0_ubrige+dcdflapetakeoff+dcdrudder+(cdwindmilli/wS);
ld2seg=cl2seg/cd2seg;

%
switch neng
    case 2 
      ToW =2*(1/ld2seg+sin(0.024));
    case 3
      ToW =(3/2)*(1/ld2seg+sin(0.027));
    case 4
      ToW =(4/3)*(1/ld2seg+sin(0.030));
end
