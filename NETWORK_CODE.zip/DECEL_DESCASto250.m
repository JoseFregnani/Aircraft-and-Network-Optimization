function [deltat,deltas,deltaf,deltah]=DECEL_DESCASto250(fanpr,opr,bpr,diamfan,TIT,DESCAS,ISADEV,RC,nedebasa,maneted)

%ACCEL FORM 250kt to CLBCAS

    fpm2mps=0.005;
    kt2ms=0.514;
    g=9.8065;
    deltahi=1500;
    deltah=0;
    err=abs(deltah-deltahi);
    RC=RC*fpm2mps;
     
    while err>100
        [TR1, PR1, DR1, a1] = atmos(10000,ISADEV);
        [TR2, PR2, DR2, a2] = atmos(10000,ISADEV);
        [M1]=CAS2MACH(DESCAS,PR1);
        [V1]=a1*M1*kt2ms;
        [M2]=CAS2MACH(250,PR2);
        [V2]=a2*M2*kt2ms;
        [facCAS1,facMach1]=acelfac(M1,10000+deltahi,ISADEV);
        [facCAS2,facMach2]=acelfac(M2,10000+deltahi,ISADEV);
        [FN1,FF1] = engine_main(10000,M1,fanpr,opr,bpr,maneted,diamfan,TIT);
        [FN2,FF2] = engine_main(10000+deltahi,M2,fanpr,opr,bpr,maneted,diamfan,TIT); 
        a1=g*(RC*(1+facCAS1))/V1;
        a2=g*(RC*(1+facCAS2))/V2;
        avga=(a1+a2)/2;
        avgFF=(FF1+FF2)/2;
        deltas=((V2^2-V1^2)/(2*avga))/1852;
        deltat=((V2-V1)/avga)/60;
        deltah=(RC/fpm2mps)*deltat;
        deltaf=nedebasa*(avgFF/60)*deltat;
        err=abs(deltah-deltahi);
        deltahi=deltah;
    end
    