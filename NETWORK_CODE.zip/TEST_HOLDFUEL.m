clc

%LOAD ACFT
X1=rand(1);
X2=rand(1);
X3=rand(1);          
[ACFT,~,~,~,~,~,~,~,~]=LOADDATABANK2b(X1,X2,X3,1);
% LOAD NEURAL NETWORK
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat')

% TEST DATA
ALTELEV=0;
HOLDMIN=20;
ISADEV=10;
GW=ACFT.MLW;

[Wf_hold]=HOLDINGFUEL(ACFT,GW,ALTELEV,ISADEV,NNind,NNwav,NNcd0,NNCL,HOLDMIN)

