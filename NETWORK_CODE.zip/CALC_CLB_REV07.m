function [d,time,fuel,finalalt]=CALC_CLB_REV07(S,wAR,wTR,...
    swet2,wingSwet,wSweepLE,...
n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
W,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL)

% CONSTANTS
% kg2lb  = 2.2046;
% m2feet = 3.28083;
% fpm2mps = 0.005;
% kt2ms   = 0.514;
% g       = 9.80665;
%
RC=500;
timesub1=0;
timesub2=0;
timesub3=0;
%
[TA]=transitionalt(CLBMACH,CLBCAS,ISADEV);
%fprintf('\n => TA   = %5.0f',TA);
%
t=0;
d=0;
fuel1=0;
fuel2=0;
fuel3=0;

if finalalt>=TA
   flag1=1;
   flag2=1;
   flag3=1;
end
if and(finalalt>=10000,finalalt<TA)
   flag1=1;
   flag2=1;
   flag3=0;
end
if finalalt<10000
   flag1=1;
   flag2=0;
   flag3=0;
end

if flag1==1
    
    % CLIMB TO 10000ft with 250KCAS
    
    if finalalt<10000
      hf=finalalt;
    else
      hf=10000;
    end  
    hi=initalt+1500;
    Hspan=[hi hf];
    IC=[0; W; 0]; 
%
    [h, T]= ode45(@(h,t) subida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
       inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax, ...
    S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,250,0,NNind,NNwav,NNcd0,NNCL),Hspan,IC);

    nstep    = size(T,1);
    timesub1 = T(nstep,1);
    Wf       = T(nstep,2);
    d        = T(nstep,3);
    fuel1    = W - Wf;

    %fprintf('\n');
    %fprintf('\n => ALTi = %5.0f',hi);
    %fprintf('\n => ALTf = %5.0f',hf);
    %fprintf('\n => Wi   = %5.0f',W);
    %fprintf('\n => Wf   = %5.0f',Wf);
    %fprintf('\n => time = %5.1f',timesub1);
    %fprintf('\n => dist = %5.1f',d);
    %fprintf('\n => fuel = %5.1f',fuel1);
  
    % ACCEL FORM 250kt to CLBCAS

    [~,~,~,deltah]=ACEL250toCLBCAS_REV07(efanpr,eopr,ebypass,ediam,eTIT,CLBCAS,ISADEV,RC,n,maneted);

    %fprintf('\n => deltas = %5.1f',deltas);
    %fprintf('\n => deltat = %5.1f',deltat);
    %fprintf('\n => deltaf = %5.1f',deltaf);
    %fprintf('\n => deltah = %5.1f',deltah);
end    
%
if flag2==1
    
    % CLIMB TO TA with CONSTANT CAS
%
    W = Wf;
    hi=10000+deltah;
    hf=TA;
    Hspan=[hi hf];
    IC=[timesub2; W;d];
    [h, T]= ode45(@(h,t) subida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
       inc_root,inc_kink,inc_tip,Kink_semispan,...
       r0,t_c,phi,X_tcmax,theta,epsilon,...
       Ycmax,YCtcmax,X_Ycmax, ...
       S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,CLBCAS,0,NNind,NNwav,NNcd0,NNCL),Hspan,IC);
%    
%   
    %[h, T]= ode45(@(h,t) subida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
     %   S,b,afil,tc,df,swet2,phi14,n,nedebasa,ISADEV,CLBCAS,0,RCMIN),Hspan,IC);
%
    nstep=size(T,1);
    timesub2= T(nstep,1);
    Wf      = T(nstep,2);
    d       = T(nstep,3);
    fuel2   = (W - Wf);

    %fprintf('\n');
    %fprintf('\n => ALTi = %5.0f',hi);
    %fprintf('\n => ALTf = %5.0f',hf);
    %fprintf('\n => Wi   = %5.0f',W);
    %fprintf('\n => Wf   = %5.0f',Wf);
    %fprintf('\n => time = %5.1f',timesub2);
    %fprintf('\n => dist = %5.1f',d);
    %fprintf('\n => fuel = %5.1f',fuel2);
end

if flag3==1

    % CLIMB TO TA with CONSTANT MACH

    W = Wf;
    hi=TA;
    hf=finalalt;
    Hspan=[hi hf];
    IC=[timesub3; W;d]; 
    
    [h, T]= ode45(@(h,t) subida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
       inc_root,inc_kink,inc_tip,Kink_semispan,...
       r0,t_c,phi,X_tcmax,theta,epsilon,...
       Ycmax,YCtcmax,X_Ycmax, ...
       S,wAR,wTR,swet2,wingSwet,wSweepLE,n,ISADEV,0,CLBMACH,NNind,NNwav,NNcd0,NNCL),Hspan,IC);
    
%     [h, T]= ode45(@(h,t) subida1(h,t,efanpr,eopr,ebypass,maneted,ediam,eTIT,...
%         S,b,afil,tc,df,swet2,phi14,n,nedebasa,ISADEV,0,CLBMACH,RCMIN),Hspan,IC);

    nstep=size(T,1);
    timesub3= T(nstep,1);
    Wf      = T(nstep,2);
    d       = T(nstep,3);
    fuel3   = W - Wf;

end

fuel   = fuel1 + fuel2 + fuel3;
time   = timesub1+timesub2+timesub3;

%fprintf('\n');
%fprintf('\n => ALTi = %5.0f',hi);
%fprintf('\n => ALTf = %5.0f',hf);
%fprintf('\n => Wi   = %5.0f',W);
%fprintf('\n => Wf   = %5.0f',Wf);
%fprintf('\n => time = %5.1f',timesub3);
%fprintf('\n => dist = %5.1f',d);
%fprintf('\n => fuel = %5.1f',fuel3);
