
function dwdt=loiter(t,x,hLoiter,MLoiter,Sref,ISADEV,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
     Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,SWET,wingSwet,...
     n,efanpr,eopr,ebypass,ediam,eTIT)
g       = 9.80665;
m2feet  = 3.28083;
%
atm=atmosfera(hLoiter,ISADEV);
%
rho  = atm(6); % [kg/m3]
vsom = atm(7); % [m/s]
%
V    = MLoiter*vsom; %[ms]
%
q    = 0.50*rho*V*V;
%
W    = x;
CL   = W*g/(q*Sref);
alfagdummy=1;
%
[CDwing, ~]=CDCLneural2(MLoiter, hLoiter/m2feet,CL,alfagdummy,Sref,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
     Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
 cfe         = 0.0030;
[CD0_ubrige] = cfe*(SWET-wingSwet)/Sref;
CD           = CDwing + CD0_ubrige;
LD      = CL/CD;
CDoCL   = 1/LD;
%
FnR     =(W*g)*(CDoCL);
maneted = 0.3;
stepman = 0.01;
T       = 0;
altm    = hLoiter/m2feet;
%
  while and(T<FnR,maneted<=1)
  [Fn,FF] = engine_main(altm,MLoiter,efanpr,eopr,ebypass,maneted,ediam,eTIT);
  TSFC=FF/(Fn/g);
  T=n*Fn;
  maneted=maneted+stepman;
  end  
%

dwdt         =-W*TSFC/(60*LD);
