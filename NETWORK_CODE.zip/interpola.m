function inter=interpola(N,x,y,z)

n=(length(N)/4)-1; 
for i=0:n-1 
        if z>=N{1,i*4+3} & z<N{1,(i+1)*4+3}
            if x<=max(N{1,i*4+1})
                if y<=max(N{1,i*4+2})
                    int1=interp2(N{1,i*4+1},N{1,i*4+2},N{1,i*4+4},x,y);
                else 
                    ymin=max(N{1,i*4+2});
                    int1=interp2(N{1,i*4+1},N{1,i*4+2},N{1,i*4+4},x,ymin);
                end
            else
                xmin=max(N{1,i*4+1});
                if y<=max(N{1,i*4+2})
                    int1=interp2(N{1,i*4+1},N{1,i*4+2},N{1,i*4+4},xmin,y);
                else 
                    ymin=max(N{1,i*4+2});
                    int1=interp2(N{1,i*4+1},N{1,i*4+2},N{1,i*4+4},xmin,ymin);
                end
            end
            if x<=max(N{1,4*(i+1)+1})
                if y<=max(N{1,(i+1)*4+2})
                    int2=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},x,y);
                else
                    ymin=max(N{1,(i+1)*4+2});
                    int2=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},x,ymin);
                end
            else
                xmin=max(N{1,4*(i+1)+1});
                if y<=max(N{1,(i+1)*4+2})
                    int2=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},xmin,y);
                else
                    ymin=max(N{1,(i+1)*4+2});
                    int2=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},xmin,ymin);
                end                    
            end 
            int3D=int1-(N{1,i*4+3}-z)*(int1-int2)/(N{1,i*4+3}-N{1,(i+1)*4+3});
        elseif z>=N{1,(i+1)*4+3}
            if x<=max(N{1,(i+1)*4+1})
                if y<=max(N{1,(i+1)*4+2})
                    int3D=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},x,y);
                else 
                    ymin=max(N{1,(i+1)*4+2});
                    int3D=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},x,ymin);
                end
            else
                xmin=max(N{1,(i+1)*4+1});
                if y<=max(N{1,(i+1)*4+2})
                    int3D=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},xmin,y);
                else 
                    ymin=max(N{1,(i+1)*4+2});
                    int3D=interp2(N{1,(i+1)*4+1},N{1,(i+1)*4+2},N{1,(i+1)*4+4},xmin,ymin);
                end
            end
        end
end
inter=int3D;