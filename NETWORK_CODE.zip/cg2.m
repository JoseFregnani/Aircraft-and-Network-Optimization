function [xcg_fwd, xcg_aft]=cg2(weight,xle,slat,...
    fus_width,lf,lco,lcab,rearsparloc,PEng,...
    wS,wAR,wMAC,wYMAC,wSweepLE,PHT,ht,vt,pylon,Ccentro,Cponta,...
    EnginLength_m,EngineDe_m,yEng,PWing,posxmunhao,xcgtanques,NPax,Nseat,fuelcgkg,...
    SeatPitch,Aislewidth,SeatWidth)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%CENTER OF GRAVITY%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LIVRO 2
%Distancias do cg pag 252 ver tabela pag 251!!!! 
% * Alteracao em 29 nov 2010 ==> considera posicao da asa para calculo do xcg
%      MLG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%wing%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
rad         = pi/180;
kg2lb       = 2.2046;
%
wingb       = sqrt(wS*wAR);
%**************************************************************************
% *********************** wing 37-42 MAC% *********************************
%**************************************************************************
    switch slat
    case 0  % sem slat
    deltaxw     = 0.50*(0.10+rearsparloc);
    otherwise % com slat
    deltaxw     = 0.50*(0.15+rearsparloc);
    end
xcg.wing    = xle + wYMAC*tan(rad*wSweepLE)+deltaxw*wMAC;
%ycg.wing    = wYMAC;
moment.wing = weight.wing*xcg.wing;
%**************************************************************************
%                                HT
%**************************************************************************
    if PHT == 1
    xcg.ht=0.95*lf - ht.c0 + ht.ymac*tan(rad*ht.sweepLE)+...
    0.30*ht.mac;
    else
    xcg.ht=0.95*lf-vt.c0+vt.b*tan(rad*vt.sweepLE)+...
        0.30*ht.mac+ht.ymac*tan(rad*ht.sweepLE);
    end
%ycg.ht = ht.ymac;
moment.ht = weight.ht*xcg.ht;
%**************************************************************************
%                                VT
%**************************************************************************
% vt 30%
xcg.vt = 0.98*lf - (vt.c0-(0.30*vt.mac+(vt.ymac*tan(vt.sweepLE*rad))));
%ycg.vt = 0;
moment.vt = weight.vt*xcg.vt;
%**************************************************************************
%                                FUSELAGE
%**************************************************************************
switch PEng
	case 1
	xcg.fuselage = 0.43*lf;
	case 2
	xcg.fuselage = 0.47*lf;
	case 3
	xcg.fuselage = 0.48*lf;
	case 4
	xcg.fuselage = 0.43*lf;
end
%ycg.fuselage =0;
moment.fuselage = weight.fuselage*xcg.fuselage;
%**************************************************************************
%                                ENGINES
%**************************************************************************
% engine 30% of its length
NEng = max(2,PEng);
switch PEng
    case 1
        xcg.engine     = xle+yEng*wingb/2*tan(rad*wSweepLE)-0.10*EnginLength_m; 
        xcg.engine2    = 0;
        moment.engine  = NEng*weight.engine*xcg.engine;
        moment.engine2 = 0;
        %ycg.engine     = (yEng*wingb)/2;
        %Propulsion system
        xcg.propulsion     = xle+yEng*wingb/2*tan(rad*wSweepLE);
        moment.propulsion  = weight.propulsion*xcg.propulsion;
        moment.propulsion2 = 0;
    case 2
        xcg.engine = 0.98*lf-vt.c0-EnginLength_m + 0.3*EnginLength_m;
        xcg.engine2 = 0;
        %ycg.engine = Fus_width/2+ pylon.b+ EngineDe_m/2;
        moment.engine = NEng*weight.engine*xcg.engine;
        moment.engine2 = 0;
        %Propulsion system
        moment.propulsion = weight.propulsion*xcg.engine;
        moment.propulsion2 = 0;
    case 3
        xcg.engine  = xle+yEng*wingb/2*tan(rad*wSweepLE) - ...
            0.25*EnginLength_m+0.30*EnginLength_m;
        xcg.engine2 = lf-vt.c0-EnginLength_m + 0.3*EnginLength_m;
        moment.engine = (2/3)*NEng * weight.engine*xcg.engine;
        moment.engine2 = (1/3)*NEng * weight.engine*xcg.engine2;
        %Propulsion system
        moment.propulsion = (2/3)*weight.propulsion*xcg.engine;
        moment.propulsion2 = (1/3)*weight.propulsion*xcg.engine2;
    case 4
         xcg.engine = xle+yEng*wingb/2*tan(rad*wSweepLE) - 0.25*EnginLength_m+0.30*EnginLength_m;
         xcg.engine2 = xle+0.70*wingb/2*tan(rad*wSweepLE) - 0.25*EnginLength_m+0.30*EnginLength_m;
         moment.engine = 0.5*NEng * weight.engine*xcg.engine;
         moment.engine2 = 0.5*NEng * weight.engine*xcg.engine2;
         %Propulsion system
         moment.propulsion = (0.5)*weight.propulsion*xcg.engine;
         moment.propulsion2 = (0.5)*weight.propulsion*xcg.engine2;
end
%**************************************************************************
%                                NACELLES
%**************************************************************************
switch PEng
    case 1
    xcg.nacelle = xle+yEng*(wingb/2)*tan(rad*wSweepLE) + 0.40*EnginLength_m; 
    moment.nacelle = xcg.nacelle*weight.nacelle;
    case 2
    xcg.nacelle = 0.97*lf-vt.c0-EnginLength_m + 0.35*EnginLength_m;
    moment.nacelle = xcg.nacelle*weight.nacelle;
    %moment.nacelle =0;
    case 3
    xcg.nacelle = xle+yEng*wingb/2*tan(rad*wSweepLE) + 0.40*EnginLength_m; 
    moment.nacelle = xcg.nacelle*weight.nacelle;
    case 4
end
%**************************************************************************
%                            LANDING GEAR
%**************************************************************************
% trem de pouso
    % 5% de carga no NG
    % eq 9.1 e 9.2 pag 233
% %%%%%   Nose landing gear %%%%%%%
xcg.nlg  = (1/2)*lco;
moment.nlg = weight.nlg*xcg.nlg;
% %%%%%%% Main landing gear %%%%%%%%
if PWing ==1
xcg.mlg=xle+posxmunhao;
else
xcg.mlg = xcg.wing + 0.20*wMAC;
end
moment.mlg = weight.mlg*xcg.mlg;
%**************************************************************************
%                            FUEL SYSTEM
%**************************************************************************
%Fuel System
xcg.fuelsys = xle - wYMAC*tan(rad*wSweepLE) + Ccentro*0.5; % no meio da asa
moment.fuelsys = weight.fuelsys*xcg.fuelsys;
%Flight Control
xcg.fcw = xle - wYMAC*tan(rad*wSweepLE) + (wingb*tan(wSweepLE*rad) + Cponta)/2; % no meio da asa
moment.fcw = 0.5*weight.flightcontrol*xcg.fcw;
xcg.fct = xcg.vt;
moment.fct = 0.5*weight.flightcontrol*xcg.fct;
%Hidraulic
xcg.hyd = xle + 0.60*Ccentro;
    %xcg.hidw = xcg.fcw;
    %xcg.hidt = xcg.fct;
%Eletrical System
xcg.electricsys = xle - wYMAC*tan(rad*wSweepLE) + (Ccentro); %no final da asa
moment.eletricsys = weight.electricsys*xcg.electricsys;

%Avionics
xcg.avionics = 0.4 * lco; % 40% do nariz;
moment.avionics = weight.avionics*xcg.avionics;

%Air
xcg.pressuresys = xle-wYMAC*tan(rad*wSweepLE) + (wYMAC*tan(wSweepLE*rad)/2); % no meio da parte frontal da asa
moment.pressuresys = weight.pressuresys*xcg.pressuresys;
%Oxygen
xcg.oxygensys = lco + (xle-wYMAC*tan(rad*wSweepLE) - lco)/2; % no meio da parte frontal fuselagem 
moment.oxygensys = weight.oxygensys*xcg.oxygensys;

%APU
%xcg.apu = xcg.vt;
xcg.apu=lf-2.0;
moment.apu = weight.apu*xcg.apu;

%Furnishing
xcg.furnishing = lco + (lcab/2); % no meio da cabine de passageiros
% xcg.furnishing = lf/2; % no meio da cabine de passageiros
moment.furnishing = weight.furnishing*xcg.furnishing;
%Paint
xcg.paint = 0.51*lf; % No meio da fuselagem
moment.paint = weight.paint*xcg.paint;

% Combust�vel nas asas
xcg.tanqueasa = xle+ xcgtanques; % xcgtanques foi obtido na rotina winglay dentro da rotina dimensionamentoi
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
pesototal = weight.wing + weight.ht + weight.vt + weight.fuselage + ...
    weight.powerplant + weight.nacelle + weight.mlg + ...
    weight.nlg + weight.hyd + weight.flightcontrol + weight.electricsys +...
weight.oxygensys + weight.apu + weight.furnishing + weight.paint + ...
weight.avionics + weight.pressuresys + weight.safety + weight.handling + ...
weight.pressuresys;
%%%%%%%%%%%%%%%%%%%%%%%%%%CG EMPTY%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
xcg.empty = (moment.wing+moment.ht+moment.vt+moment.fuselage+moment.engine+moment.engine2+moment.propulsion+...
moment.propulsion2+moment.nacelle+xcg.hyd+...
               moment.mlg+moment.nlg+moment.fuelsys+moment.fcw+moment.fct+moment.eletricsys+moment.avionics+moment.pressuresys+...
               moment.oxygensys+moment.apu+moment.furnishing+moment.paint)/pesototal;
%deltaxcg.empty = (xcg.empty_m - (xle + (wingref.mac*0.25)))/wingref.mac;
xcg.empty_mac = xcg.empty/wMAC;
%
massa_crew_cock    = 2*75*kg2lb;
xcg_crew_cock      = lco/2;
momentum_crew_cock = massa_crew_cock*xcg_crew_cock;
%
massa_crew_cabi    = 3*75*kg2lb;
xcg_crew_cabi      = lco + lcab;
momentum_crew_cabi = massa_crew_cabi*xcg_crew_cabi;
%
mass_fuel_resi     = 0.005*fuelcgkg*kg2lb;
xcg_fuel_resi      = xle + xcgtanques;
momentum_fuel_resi = mass_fuel_resi*xcg_fuel_resi;
%
momentum_oew       = pesototal*xcg.empty + momentum_crew_cock + ...
                      momentum_crew_cabi + momentum_fuel_resi;
mass_oew           = pesototal + massa_crew_cabi + massa_crew_cock + ...
    mass_fuel_resi;
%
mass_fuel          = fuelcgkg*kg2lb;
xtanques           = xle + xcgtanques;
momentum_fuel      = mass_fuel*xtanques;
%
mass_pax           = NPax*100*kg2lb;
xcg_pax            = lco + lcab/2;
momentum_pax       = mass_pax*xcg_pax;
%
mass1              = mass_oew;
conta1             = momentum_oew;
conta1             = conta1/mass1;
%
mass2              = mass1 + mass_fuel;
conta2             = momentum_oew + momentum_fuel;
conta2             = conta2/mass2;
%
mass3              = mass1 + mass_fuel + mass_pax;
conta3             = momentum_oew + momentum_fuel + momentum_pax;
conta3             = conta3/mass3;
%
mass4              = mass1 + mass_pax;
conta4             = momentum_oew + momentum_pax;
conta4             = conta4/mass4;
%
xcgp(1)         = conta1;
%ycgp(1)         = mass1;
xcgp(2)         = conta2;
%ycgp(2)         = mass2;
xcgp(3)         = conta3;
%ycgp(3)         = mass3;
xcgp(4)         = conta4;
%ycgp(4)         = mass4;
%
xcg_fwd         = min(xcgp);
xcg_aft         = max(xcgp);
passeio         = (xcg_aft-xcg_fwd)/wMAC*100;
%
% plot(xcgp,ycgp,'-k')
% hold on
% axis square
%
fuselage.df     = fus_width;
fuselage.length = lf;
fuselage.lco    = lco;
fuselage.lcab   = lcab;
%
engine.length   = EnginLength_m;
engine.de       = EngineDe_m;
wing.b          = sqrt(wS*wAR);
wing.s1         = yEng*wing.b/2;
wing.c0         = Ccentro;
wing.ct         = Cponta;
wing.sweepLE    = wSweepLE;
%
plot_airplanetopview(xle,fuselage,ht,vt,wing,engine,pylon,PEng,PHT)
%
fprintf('\n CG range: %4.2f %s CMA \n',passeio,'%')
%xlabel('x (m)');
%nomecg=['fig/','cg',num2str(ivt),'.jpg'];
%print(fig2,nomecg,'-djpeg','-r300')
clear wing fuselage 
%