function [output, doutput_dinput] = ann_feedfoward_grads(input, theta1, theta2, theta3, Norm_struct)

%Normalizing inputs
input_norm = ann_normalize_internal(input, Norm_struct.Mean_input, Norm_struct.Range_input);

%Gathering number of cases
m = size(input_norm,2);

%Feed foward
if ~isempty(theta3)
	a0 = [ones(1,m); input_norm];
	z1 = theta1*a0;
	a1 = [ones(1,m); 2./(1+exp(-2*z1))-1]; %%%
	z2 = theta2*a1;
	a2 = [ones(1,m); 2./(1+exp(-2*z2))-1]; %%%
	output_norm = theta3*a2;
else
	a0 = [ones(1,m); input_norm];
	z1 = theta1*a0;
	a1 = [ones(1,m); 2./(1+exp(-2*z1))-1]; %%%
	output_norm = theta2*a1;
end

%Back propagation
doutput_norm_da2 = theta3(:,2:end)'*ones(1,m);
doutput_norm_da1 = theta2(:,2:end)'*(doutput_norm_da2.*(1-a2(2:end,:).*a2(2:end,:)));
doutput_norm_da0 = theta1(:,2:end)'*(doutput_norm_da1.*(1-a1(2:end,:).*a1(2:end,:)));

output = ann_denormalize_internal(output_norm, Norm_struct.Mean_output, Norm_struct.Range_output);

doutput_dinput = doutput_norm_da0.*(repmat(Norm_struct.Range_output*ones(1,m),40,1))./(Norm_struct.Range_input*ones(1,m));

end