function [DIST,HDG]=distGC2(Airport);

fac=1.03;
n=length(Airport);
for i=1:n
  for j=1:n
   if i==j
     DIST(i,j)=0;     
   else  
     lat1=Airport(i).lat;
     lat2=Airport(j).lat;
     lon1=Airport(i).lon;
     lon2=Airport(j).lon;
     dmg1=Airport(i).dmg;
     dmg2=Airport(j).dmg;
     DIST(i,j)=fac*greatcircle(lat1,lon1,lat2,lon2)/1.852;
     [~,~,~,BEARING]=greatcircle(lat1,lon1,lat2,lon2);   
     HDG(i,j)=BEARING(1)-(dmg1+dmg2)/2;  
     if (HDG(i,j)<0)  
         HDG(i,j)=HDG(i,j)+360;
     end    
    end   
  end
end
