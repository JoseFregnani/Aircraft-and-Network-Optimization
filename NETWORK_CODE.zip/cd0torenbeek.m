function [CD0] = cd0torenbeek(nmach,V,swm2,bw,afil,tc,df,h,swet2,ISADEV)
% Calculo do CD0 de acordo com metodo proposto por Torenbeek:
% Torenbeek, E., "Advanced Aircraft Design," 1st Edition, 2013, pg 123-125.
% Entradas:
% V:  TAS
% mtowlb: peso maximo de decolagem em libras
% swm2:   area da asa em metros ao quadrado
% bw:     envergadura da asa em metros
% afil:   afilamento da asa
% tc:     espessura relativa media da asa
% df:     diametro da fuselagem em metros
% h:      altitude em pes
% swetm2: area molhada do aviao em metros ao quadrados
%--------------------------------------------
%
atm   = atmosfera(h,ISADEV);
ni    = atm(8)/atm(6);
reybar = V*swet2/bw/ni;
rphi   = 3.5;% rphi = 4 TURBOPROP; = 3,5 JETENGINES
croot=2*swm2/((1+afil)*bw);
ctip=croot*afil;
cmed=0.60*ctip+0.40*croot;
sfront = pi*df^2/4 +2*(cmed*tc*bw/2);
knid=1+255*(reybar^-0.35); % Page 104 Torenbeek (jet airplanes)
cfval=cfflatpla(reybar,nmach,h,ISADEV);
CD0=cfval*knid*(swet2+rphi*sfront)/swm2;
CD0=1.04*CD0; %(miscellaneous drag)
%fprintf('\n => CD0 = %5.4f',CD0)