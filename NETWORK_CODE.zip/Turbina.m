%% DESCRI��O E AUTORIA %%
%Turbina  - Rotina para estimativa do ruido de turbina de motores a rea��o
%autores  - Daniel ...
%           Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP          - altitude-press�o [ft]
%                   DISA        - varia��o da temperatura em rela��o � ISA [�C]
%                   RH          - relative humidity [%]
%                   vairp       - velocidade do avi�o [m/s]
%                   teta        - dire��o para avalia��o do ru�do [deg]
%                   fi          - eleva��o para avalia��o do ru�do [deg]
%                   R           - dist�ncia para avalia��o do ru�do [m]
%                   mdot        - vaz�o m�ssica atrav�s do fan [kg/s]
%                   Tturbsaida  - temperatura de sa�da da turbina [K]
%                   nturb       - velocidade angular da turbina [rpm]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Daniel ...                              Vers�o original (Turbina)
%2.0        Paulo Eduardo Cypriano      21-08-09    Remo��o da plotagem de gr�ficos
%3.0        Paulo Eduardo Cypriano      19-01-13    Uniformiza��o dos calculos atmosfericos
%4.0        Paulo Eduardo Cypriano      18-03-13    Corre��es nos c�lculos


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft, ruidoTurbinat] = Turbina(HP,DISA,RH,vairp,teta,fi,R,mdot,nturb,Tturbsaida,MTRturb,nrotor,RSSturb)


%% Vari�veis globais
%global f
f                  = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];

%% Fatores de convers�o
%global m2ft deg2rad
m2ft    = 3.28084;
deg2rad = pi/180;

%% Tabelas para interpola��o
tetatab             = [00    10    20    30    40    50    60    70    80    90    100   110   120   130   140   150   160   170   180.1];
F1tab               = [-37.0 -33.0 -29.0 -25.0 -21.0 -17.0 -13.0 -10.0 -07.0 -04.0 -1.25 00.00 -01.4 -05.0 -09.0 -14.0 -19.0 -24.0 -29.0];
F3tab               = [-48.2 -42.9 -37.6 -32.3 -27.0 -21.7 -18.0 -14.0 -10.0 -05.5 -02.3 00.00 -02.1 -08.0 -14.0 -20.0 -26.0 -32.0 -38.0];


%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
v0                  = vairp;                                                % velocidade da aeronave [m/s]
epsilon             = fi;
radialdistance      = R;                                                    % dist�ncia para avalia��o do ru�do [m]

%% Dados da atmosfera %%
atm                 = atmosfera(HP*m2ft,DISA);                              % propriedades da atmosfera
T                   = atm(1);                                               % temperatura ambiente [K]
vsom                = atm(7);                                               % velocidade do som [m/s]


%% C�lculos iniciais %%
M0                  = v0/vsom;                                              % n�mero de Mach da aeronave

%% Ruido da turbina %%
F1                  = interp1(tetatab,F1tab,teta,'linear','extrap');
F3                  = interp1(tetatab,F3tab,teta,'linear','extrap');

%% Ruido banda larga %%
termo1              = ((MTRturb*vsom/0.305)*(340.3/vsom))^3;
termo2              = (mdot/0.4536);
termo3              = (1-M0*cos(epsilon*deg2rad));
SPLpeak             = 10*log10(termo1*termo2*termo3^-4)+F1-10;
f0                  = nrotor*nturb/60/termo3;
if f0>10000
    f0 = 10000;
end
Fb                  = 10.*log10(f/f0).*(f<f0)-20.*log10(f/f0).*(f>=f0);
SPLbl               = SPLpeak+Fb;


%% Ruido discreto %%
termo1              = (MTRturb*vsom/0.305)^0.6*(340.3/vsom)^3;
termo2              = (mdot/0.4536);
termo3              = (RSSturb/100);
termo4              = (1-M0*cos(epsilon*deg2rad));
%
SPLtone             = 10*log10(termo1*termo2*termo3*termo4^-4)+F3+56;
%
f1                  = f./2^(1/6);
f2                  = f.*2^(1/6);
k                   = 1:10000/f0;
SPLdisc             = SPLtone-10*(k-1);
%
%% Coloca��o dos tons %%
% ftom = zeros(size(f));
for j=1:10000/f0
    ftom(:,j)       = f.*((j*f0)>f1 & (j*f0)<f2);                           % acha as frequencias em que deve ser colocado o tom, em formato de j colunas
end
ftons               = sum(ftom,2);                                          % acha as frequencias em formato de uma coluna
ftons               = ftons';                                               % transpoe a matriz e obtem um vetor 1x24
SPLd                = zeros(1,24);
i                   = find(ftons);                                          % retorna as posi��es dos valores de ftons que n�o s�o zeros
I1                  = max(size(i));                                         % avalia a quantidade de frequ�ncias nas quais devem ser colocados os tons
I2                  = max(size(SPLdisc));                                   % avalia a quantidade de tons
I3                  = I1/I2;                                                % verifica se � um m�ltiplo inteiro
I4                  = floor(I1/I2);                                         % verifica se � um m�ltiplo inteiro
if I1>I2                                                                    % verifica se h� mais frequ�ncias que tons
    if (I3-I4)==0                                                           % verifica se � um m�ltiplo inteiro
        for ai2=1:I2
            for ai1=1:I3
                SPLdisca(I2*(ai2-1)+ai1) = SPLdisc(ai2);                    % redimensiona a matriz de tons
            end
        end
    end
    SPLdisc         = SPLdisca;                                             % redimensiona a matriz de tons
end

SPLd(i)             = SPLd(i)+SPLdisc;                                      % coloca os tons


%% Soma dos ruidos discreto e banda larga %%
SPLturb             = 10.*log10(10.^(0.1*SPLbl)+10.^(0.1*SPLd));

%% Amortecimento atmosf�rico %%
[ft, alfaamortt, amorttott, amortatm, SPLrt] = amort(T,RH,radialdistance,f);

%% Extrapolando o espectro para um metro %%
deltaLamort1m       = alfaamortt'*45.72/100;                                 % para transformar em um metro
amortatm1m          = interp1(f,deltaLamort1m,f,'linear','extrap');
ruido1m             = SPLturb+33.2+amortatm1m;                              % 33.2=20*log10(45.72)


%% DADOS DE SAIDA %%
ruidoTurbina        = ruido1m-amortatm'-SPLrt';
ft                  = f';
ruidoTurbinat       = ruidoTurbina';
a1                  = length(ruidoTurbinat);
for ia1=1:a1
    if ruidoTurbinat(ia1)<1
        ruidoTurbinat(ia1) = 1;
    end
end


%% VERIFICA��ES EM DEBUG
% figure()
% semilogx(f,SPLbl,'o-b',f,SPLd,'o-g',f,SPLturb,'o-r');
% grid on;
% legend('broadband','discrete','All turb');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - NASA TM X-73566 - Interim prediction method for turbine noise (1976)
%2 - ESDU77022 - Atmospheric properties