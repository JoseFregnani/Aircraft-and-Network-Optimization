function f=RES(LW,ALTDIST,HOLDMIN,ISADEV);

% SIMPLE CALCULATION %

    % ref ACFT: ERJ145LR
    RefFF=1000;
    RefWT=22000;
    RefMach=0.78;% Mach 0.78 @ FL330
    %
    [~, ~,~,a] = atmos(33000,ISADEV);
    RefTAS=RefMach*a;
    FF_HOLD=0.8*(RefFF/60)*(LW/RefWT); 
    SR_ALT=(RefTAS/RefFF)*(22000/LW); 
    ALTFUEL=ALTDIST/SR_ALT;
    HOLD=FF_HOLD*HOLDMIN;
    f=ALTFUEL+HOLD;

end
