function [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3]=LOADDATABANK(X1,X2,X3)

ACFT = readtable('ACFTDATABANK.xlsx','ReadVariableNames',true);  
n=size(ACFT,1);

for i=1:n
    A(i).wS =table2array(ACFT(i,'wS'));
    A(i).wAR=table2array(ACFT(i,'wAR'));
    A(i).wTR=table2array(ACFT(i,'wTR'));
    A(i).wSweep14=table2array(ACFT(i,'wSweep14'));
    A(i).wTwist=table2array(ACFT(i,'wTwist'));
    A(i).Kink_semispan=table2array(ACFT(i,'Kink_semispan'));
    A(i).ebypass=table2array(ACFT(i,'ebypass'));
    A(i).ediam=table2array(ACFT(i,'ediam'));
    A(i).eopr=table2array(ACFT(i,'eopr'));
    A(i).eTIT=table2array(ACFT(i,'eTIT'));
    A(i).NPax=table2array(ACFT(i,'NPax'));
    A(i).NAisle=table2array(ACFT(i,'NAisle'));
    A(i).NSeat=table2array(ACFT(i,'NSeat'));
    A(i).Range=table2array(ACFT(i,'Range'));
end    

MAXPAX=0;
MINPAX=999;
for i=1:n
   PAX=A(i).NPax;
   if PAX<=MINPAX
      MINPAX=PAX;
   end
   if PAX>=MAXPAX
      MAXPAX=PAX;
   end
end   
LIM1=round(MINPAX+(MAXPAX-MINPAX)/3);
LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3);
LIM3=MAXPAX;

k1=1;
k2=1;
k3=1;
for i=1:n
    PAX=A(i).NPax;
    if PAX<LIM1
       A1(k1).wS=A(i).wS;
       A1(k1).wAR=A(i).wAR;
       A1(k1).wTR=A(i).wTR;
       A1(k1).wSweep14=A(i).wSweep14;
       A1(k1).wTwist=A(i).wTwist;
       A1(k1).Kink_semispan=A(i).Kink_semispan;
       A1(k1).ebypass=A(i).ebypass;
       A1(k1).ediam=A(i).ediam;
       A1(k1).eopr=A(i).eopr;
       A1(k1).eTIT=A(i).eTIT;
       A1(k1).NPax= A(i).NPax;
       A1(k1).NAisle=A(i).NAisle;
       A1(k1).NSeat=A(i).NSeat;
       A1(k1).Range=A(i).Range;
       %
       k1=k1+1;
    end
    if and(PAX>LIM1,PAX<=LIM2)
       A2(k2).wS=A(i).wS;
       A2(k2).wAR=A(i).wAR;
       A2(k2).wTR=A(i).wTR;
       A2(k2).wSweep14=A(i).wSweep14;
       A2(k2).wTwist=A(i).wTwist;
       A2(k2).Kink_semispan=A(i).Kink_semispan;
       A2(k2).ebypass=A(i).ebypass;
       A2(k2).ediam=A(i).ediam;
       A2(k2).eopr=A(i).eopr;
       A2(k2).eTIT=A(i).eTIT;
       A2(k2).NPax= A(i).NPax;
       A2(k2).NAisle=A(i).NAisle;
       A2(k2).NSeat=A(i).NSeat;
       A2(k2).Range=A(i).Range;
       %
       k2=k2+1;
    end   
    if and(PAX>LIM2,PAX<=LIM3)
       A3(k3).wS=A(i).wS;
       A3(k3).wAR=A(i).wAR;
       A3(k3).wTR=A(i).wTR;
       A3(k3).wSweep14=A(i).wSweep14;
       A3(k3).wTwist=A(i).wTwist;
       A3(k3).Kink_semispan=A(i).Kink_semispan;
       A3(k3).ebypass=A(i).ebypass;
       A3(k3).ediam=A(i).ediam;
       A3(k3).eopr=A(i).eopr;
       A3(k3).eTIT=A(i).eTIT;
       A3(k3).NPax= A(i).NPax;
       A3(k3).NAisle=A(i).NAisle;
       A3(k3).NSeat=A(i).NSeat;
       A3(k3).Range=A(i).Range;
       %
       k3=k3+1;
    end               
end    

% Choose aircrafts from the list
l1=size(A1,2);
l2=size(A2,2);
l3=size(A3,2);
n1=ceil(X1*l1);
n2=ceil(X2*l2);
n3=ceil(X3*l3);
%
ACFT1.wS =A1(n1).wS;
ACFT1.wAR=A1(n1).wAR;
ACFT1.wTR=A1(n1).wTR;
ACFT1.wSweep14=A1(n1).wSweep14;
ACFT1.wTwist=A1(n1).wTwist;
ACFT1.Kink_semispan=A1(n1).Kink_semispan;
ACFT1.ebypass=A1(n1).ebypass;
ACFT1.ediam=A1(n1).ediam;
ACFT1.eopr=A1(n1).eopr;
ACFT1.eTIT=A1(n1).eTIT;
ACFT1.NPax= A1(n1).NPax;
ACFT1.NAisle=A1(n1).NAisle;
ACFT1.NSeat=A1(n1).NSeat;
ACFT1.Range=A1(n1).Range;
%
ACFT2.wS =A2(n2).wS;
ACFT2.wAR=A2(n2).wAR;
ACFT2.wTR=A2(n2).wTR;
ACFT2.wSweep14=A2(n2).wSweep14;
ACFT2.wTwist=A2(n2).wTwist;
ACFT2.Kink_semispan=A2(n2).Kink_semispan;
ACFT2.ebypass=A2(n2).ebypass;
ACFT2.ediam=A2(n2).ediam;
ACFT2.eopr=A2(n2).eopr;
ACFT2.eTIT=A2(n2).eTIT;
ACFT2.NPax= A2(n2).NPax;
ACFT2.NAisle=A2(n2).NAisle;
ACFT2.NSeat=A2(n2).NSeat;
ACFT2.Range=A2(n2).Range;
%
ACFT3.wS =A3(n3).wS;
ACFT3.wAR=A3(n3).wAR;
ACFT3.wTR=A3(n3).wTR;
ACFT3.wSweep14=A3(n3).wSweep14;
ACFT3.wTwist=A3(n3).wTwist;
ACFT3.Kink_semispan=A3(n3).Kink_semispan;
ACFT3.ebypass=A3(n3).ebypass;
ACFT3.ediam=A3(n3).ediam;
ACFT3.eopr=A3(n3).eopr;
ACFT3.eTIT=A3(n3).eTIT;
ACFT3.NPax= A3(n3).NPax;
ACFT3.NAisle=A3(n3).NAisle;
ACFT3.NSeat=A3(n3).NSeat;
ACFT3.Range=A3(n3).Range;







