function kprocess = achatom(k)


kprocess = zeros(1,24);

for ik =2:24
    if k(ik)==k(ik-1)
        kprocess(ik) = 0;
    else
        kprocess(ik) = k(ik);
    end
end


end