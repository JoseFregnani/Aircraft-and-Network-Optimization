function [FFHOLD]=HOLD2(wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2,W,h,ISADEV)

NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');

[TR,PR,DR,a] = atmos(h,ISADEV);

TASi=150;
f=0;
CDoCLmin=9999;
VHOLD=0;

TAS=TASi;
while f==0;
 
  %[CDoCL]=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,M,ISADEV,TR);
  [CDoCL]=CDCL_mod (wS,wAR,wTR,swet2,wingSwet,wSweep14, ...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
   
  if CDoCL<=CDoCLmin
      VHOLD=TAS;
      CDoCLmin=CDoCL;
  else
      f=1;
  end    
  TAS=TAS+1;
end  

 M=TAS/a;
[TSFC,CDoCL,FF]=SFCCRZ_REV08(wS,wAR,wTR,...
    swet2,wingSwet,wSweep14,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,ebypass,ediam,efanpr,eopr,eTIT,W,h,M,ISADEV,NNind,NNwav,NNcd0,NNCL);

FFHOLD=2*FF;


