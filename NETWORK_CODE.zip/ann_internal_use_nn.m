function [output, doutput_dinput] = ann_internal_use_nn(input, NN)

% Oct-02-2013
% Ney Rafael Secco
% Instituto Tecnol?gico de Aeron?utica
% ney@ita.br

output = cell(length(NN),1);
doutput_dinput = cell(length(NN),1);

for nn_index = 1:length(NN)
    [output{nn_index}, doutput_dinput{nn_index}] = ann_feedfoward_grads(input, NN(nn_index).theta1, NN(nn_index).theta2, NN(nn_index).theta3, NN(nn_index).Norm_struct);
end

end