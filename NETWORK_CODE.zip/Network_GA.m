clc

lb     =[0.05 0.05 0.05];
ub     =[1 1 1];
options = gaoptimset('PopulationSize',10,'PlotFcns',{@gaplotparetodistance,@gaplotpareto,@gaplotrankhist});
[x,fval,exitflag,output] = gamultiobj(@NETWORK3_GA,3,[],[],[],[],lb,ub,options)





