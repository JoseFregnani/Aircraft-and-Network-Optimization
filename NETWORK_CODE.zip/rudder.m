% function rudder()
% clc
% clear all
% ruddert(2,4,1.5,41)
%)
function [x,y,z]=rudder(ctipvt,crootvt,arv,sweepLEvt,ydes)
% calcula quatro pontos de definicao do leme da VT
% Referencia: bordo de ataque da raiz(0,0)
%
rad = pi/180;
%
fchord_rudder = 0.25;
%
fbleme = 0.80; 
flow = (1- fbleme)/2;
fupp = (1 -flow);
bvt = (ctipvt+crootvt)*arv/2;
cbase = crootvt+ flow*(ctipvt-crootvt);
ctopo = crootvt+ fupp*(ctipvt-crootvt);
x(1) = bvt*flow*tan(rad*sweepLEvt) + cbase;
y(1) = 0;
z(1) = bvt*flow;
x(2) = x(1)- fchord_rudder*cbase;
y(2) = ydes*cbase;
z(2) = z(1);
x(3) = bvt*fupp*tan(rad*sweepLEvt)+(1-fchord_rudder)*ctopo;
y(3) = ydes*ctopo;
z(3) = bvt*fupp;
x(4) = bvt*fupp*tan(rad*sweepLEvt) + ctopo;
y(4) = 0;
z(4) = z(3);
x(5) = x(1);
y(5) = y(1);
z(5) = z(1);
%fill(x,z,'k')
%hold on
%
% xvt(1)=0;
% zvt(1)=0;
% xvt(2)= bvt*tan(rad*sweepLEvt);
% zvt(2)= bvt;
% xvt(3)= xvt(2)+ctipvt;
% zvt(3)= bvt;
% xvt(4)= crootvt;
% zvt(4)= 0;
% plot(xvt,zvt,'b')
%
