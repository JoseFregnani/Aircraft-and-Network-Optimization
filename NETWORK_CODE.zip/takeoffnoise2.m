%% DESCRI��O E AUTORIA %%
%takeoffnoise2 - Rotina para c�lculo do ru�do ao longo da decolagem
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   timehistory - trajet�ria da aeronave
%                   ACTGEO      - geometria da aeronave
%                       (1)     - SH - �rea de refer�ncia da empenagem horizontal [m�]
%                       (2)     - bH - envergadura da empenagem horizontal [m]
%                       (3)     - SV - �rea de refer�ncia da empenagem vertical [m�]
%                       (4)     - bV - envergadura da empenagem vertical [m]
%                       (5)     - SF - �rea total dos flapes [m�]
%                       (6)     - bF - envergadura total dos flapes [m]
%                       (7)     - deltafTO - deflex�o dos flapes - decolagem [deg]
%                       (8)     - deltafLD - deflex�o dos flapes - pouso [deg]
%                       (9)     - dmtyre - di�metro do pneu - trem de pouso principal [m]
%                       (10)     - dntyre - di�metro do pneu - trem de pouso dianteiro [m]
%                       (11)    - nmgear - n�mero de unidades no trem de pouso principal
%                       (12)    - nmgear - n�mero de unidades no trem de pouso dianteiro
%                       (13)    - lmgear - comprimento da perna do trem de pouso principal [m]
%                       (14)    - lngear - comprimento da perna do trem de pouso dianteiro [m]
%                       (15)    - nmwheel - n�mero de pneus por trem principal 
%                       (16)    - nnwheel - n�mero de pneus por trem dianteiro
%                       (17)    - fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
%                       (18)    - fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
%                       (19)    - fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
%                       (20)    - fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
%                       (21)    - fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
%                       (22)    - nslots - n�mero de slots no flape
%                       (23)    - fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
%                       (24)    - fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
%                       (25)    - hprec - altitude no ponto de medi��o
%                       (26)    - disarec - temperatura no ponto de medi��o [�C]
%                   ENGPAR      - par�metros do motor
%                       (1)     - fanpr = raz�o de press�o no fan
%                       (2)     - opr = raz�o de press�o total do motor
%                       (3)     - bpr = raz�o de deriva��o do motor
%                       (4)     - maneted = percentual da tra��o m�xima (0 a 1)
%                       (5)     - diamfan = di�metro do fan do motor [m]
%                   DISA        - varia��o da temperatura padr�o [�C]
%                   SW          - �rea alar [m�]
%                   bW          - envergadura [m]
%                   RH          - umidade relativa [%]
%                   dlat        - dist�ncia lateral [m]
%                   XA          - dist�ncia longitudinal [m]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o
%                   OASPLhistory - hist�rico do ru�do [dB]
%                   tetaout     - dire��o do ru�do em rela��o ao receptor [deg]
%                   tempo       - hist�rico do tempo [s]
%                   distancia   - hist�rico da distancia [m]
%                   altura      - hist�rico da altura [m]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -
%1.1        Paulo Eduardo Cypriano      30-03-13    Revis�o C - reordena��o dos c�lculos parciais para utiliza��o na otimiza��o
%1.2        Paulo Eduardo Cypriano      01-04-13    Revis�o D - adapta��o das vari�veis comuns para c�lculo integrado eotimiza��o


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [f OASPLhistory tetaout tempo distancia altura] = ...
    takeoffnoise2(timehistory,maneted,DISA,RH,dlat,XA,ACTGEO,SW,bW,NEng,ENGPAR)


%% Vari�veis globais
%global var
%global ACTGEO


%% Fatores de convers�o
%global deg2rad rad2deg
deg2rad = pi/180;
rad2deg = 1/deg2rad;

%% CORPO DA FUN��O %%
%% Manipula��es iniciais %%
[a1, ~]            = size(timehistory);
tempo               = timehistory(:,1);
distancia           = timehistory(:,3);
altura              = timehistory(:,5);
%% C�lculo do ru�do %%
for i1=1:a1
    H1              = timehistory(i1,5);
    XB              = timehistory(i1,3);
    gamma           = timehistory(i1,7);
    L1              = abs(XB-XA);
    R               = (H1^2+L1^2+dlat^2)^0.5;
    termo1          = (((H1-L1*tan(abs(gamma*deg2rad)))^2+dlat^2)/R^2)^0.5;
    if XB>XA
        teta        = rad2deg*asin(termo1);
    elseif XB==XA
        teta        = 90;
    else
        teta        = 180-rad2deg*asin(termo1);
    end
    vairp           = timehistory(i1,2);
    N1              = timehistory(i1,8);
    N2              = timehistory(i1,9);
    fi              = atan(H1/dlat)*rad2deg;
    if vairp==0
        vairp       = 0.1;
    end
    FPhase          = 1;
    if H1 >= 100                                                            % recolhimento dos trens de pouso
        ACTGEO(23) = 2;
        ACTGEO(24) = 2;
    else
        ACTGEO(23) = 1;
        ACTGEO(24) = 1;
    end
    saidatemp       = ruidoaero(ACTGEO,H1,DISA,RH,vairp,teta,fi,R,SW,bW,FPhase);
    [ft, OASPLENG]  = noiseng2(H1,DISA,RH,vairp,teta,fi,R,maneted,N1,N2,ENGPAR);
    f               = saidatemp(:,1);
    tetaout(i1)     = teta;
    airframe(:,i1)  = saidatemp(:,2);
    engine(:,i1)    = OASPLENG;
    SPL(:,i1)       = 10*log10(10.^(0.1*airframe(:,i1))+NEng*10.^(0.1*engine(:,i1)));
end


%% SA�DA DA FUN��O %%
OASPLhistory        = SPL;


%% FINAL DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1989)
%2 - ESDU77022 - Atmospheric properties