function [ALTOPT,SRMAX]=optalt2(S,b,afil,tc,df,swet2,phi14,nedebasa,n,maneted,ebypass,ediam,efanpr,eopr,eTIT,W,initalt,finalalt,CAS,M,ISADEV,RCMIN)

% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.8067;

t=0;
d=0;
fuel=0;
RC=9999;
HOPT=0;
step=100;
SROPT=0;
deltafuel=0;


% CLIMB TO TA with CONSTANT MACH

hi=initalt;
hf=finalalt;
h=hi;
  
while h<=hf

    %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/3.28083;
    [TR, PR, DR, a] = atmos(h,ISADEV);
    [Fn,FF] = enginedeck(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    ToW=n*Fn/W;
    [facCAS,facMach]=acelfac(M,h,ISADEV);
    [RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,0,M,h,ISADEV);

    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(n*FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
    
    SR=TAS/(n*FF)
    if SR>SROPT
       SROPT=SR;
       HOPT=h;
    end   
       
   end

ALTOPT=HOPT-100;
SRMAX=SROPT;


