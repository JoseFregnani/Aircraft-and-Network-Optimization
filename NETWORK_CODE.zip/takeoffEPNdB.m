%% DESCRI��O E AUTORIA %%
%takeoffEPNdB - Rotina para c�lculo do ru�do EPNdB na decolagem
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   timehistory - trajet�ria da aeronave
%                   ACTGEO      - geometria da aeronave
%                       (1)     - SH - �rea de refer�ncia da empenagem horizontal [m�]
%                       (2)     - bH - envergadura da empenagem horizontal [m]
%                       (3)     - SV - �rea de refer�ncia da empenagem vertical [m�]
%                       (4)     - bV - envergadura da empenagem vertical [m]
%                       (5)     - SF - �rea total dos flapes [m�]
%                       (6)     - bF - envergadura total dos flapes [m]
%                       (7)     - deltafTO - deflex�o dos flapes - decolagem [deg]
%                       (8)     - deltafLD - deflex�o dos flapes - pouso [deg]
%                       (9)     - dmtyre - di�metro do pneu - trem de pouso principal [m]
%                       (10)     - dntyre - di�metro do pneu - trem de pouso dianteiro [m]
%                       (11)    - nmgear - n�mero de unidades no trem de pouso principal
%                       (12)    - nmgear - n�mero de unidades no trem de pouso dianteiro
%                       (13)    - lmgear - comprimento da perna do trem de pouso principal [m]
%                       (14)    - lngear - comprimento da perna do trem de pouso dianteiro [m]
%                       (15)    - nmwheel - n�mero de pneus por trem principal 
%                       (16)    - nnwheel - n�mero de pneus por trem dianteiro
%                       (17)    - fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
%                       (18)    - fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
%                       (19)    - fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
%                       (20)    - fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
%                       (21)    - fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
%                       (22)    - nslots - n�mero de slots no flape
%                       (23)    - fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
%                       (24)    - fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
%                       (25)    - hprec - altitude no ponto de medi��o
%                       (26)    - disarec - temperatura no ponto de medi��o [�C]
%                   ENGPAR      - par�metros do motor
%                       (1)     - fanpr = raz�o de press�o no fan
%                       (2)     - opr = raz�o de press�o total do motor
%                       (3)     - bpr = raz�o de deriva��o do motor
%                       (4)     - maneted = percentual da tra��o m�xima (0 a 1)
%                       (5)     - diamfan = di�metro do fan do motor [m]
%                   DISA        - varia��o da temperatura padr�o [�C]
%                   SW          - �rea alar [m�]
%                   bW          - envergadura [m]
%                   RH          - umidade relativa [%]
%                   dlat        - dist�ncia lateral [m]
%                   XA          - dist�ncia longitudinal [m]
%Dados de saida  : 
%                   TOEPNdB     - ru�do da aeronave na decolagem [EPNdB]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -
%2.0        Paulo Eduardo Cypriano      18-08-13    Otimiza��o de entradas


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [TOEPNdB] = takeoffEPNdB(timehistory,maneted,DISA,RH,dlat,XA,ACTGEO,SW,bW,ENGPAR,NEng)


%% CORPO DA FUN��O %%
%% C�lculo do hist�rico do ru�do de decolagem %%
[f, SPL, tetaout, tempo, distancia, altura] =...
    takeoffnoise2(timehistory,maneted,DISA,RH,dlat,XA,ACTGEO,SW,bW,NEng,ENGPAR);
%% Elimina��o dos pontos n�o calculados %%
[a1 a2]             = size(SPL);
for i1 = 1:a1
    for i2 = 1:a2
        if SPL(i1,i2)<0 || isnan(SPL(i1,i2))
            SPL(i1,i2) = 0;
        end
    end
end
%% Transforma��o de SPL para NOY %%
[f,NOY]             = calcNOY(f,SPL);
% VERIFICA��O EM DEBUG
% x                   = tempo;
% y                   = f(3:24);
% figure()
% surf(x,y,NOY);
% grid on
% shading interp

%% C�lculo de Perceived Noise Level (PNL) %%
[PNL]               = calcPNL(f,NOY);

%% C�lculo da corre��o de tom para PNL %%
[~, a2]             = size(SPL);
for i1 = 1:a2
    C(i1)           = calcPNLT(f,SPL(:,i1));
end
%% C�lculo de Perceived Noise Level - tone corrected (PNLT) %%
PNLT                = PNL+C;
% VERIFICA��O EM DEBUG
% x                   = tempo;
% figure()
% plot(x,PNL,'-b',x,PNLT,'-r');
% grid on

%% C�lculo de Effective Perceived Noise Level (EPNdB) %%
TOEPNdB             = calcEPNdB(tempo,PNLT);
%% FINAL DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1989)
%2 - ESDU77022 - Atmospheric properties