function [TSFC,CDoCL,FF,maneted]=SFCCRZ(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,W,h,M,ISADEV)

% CONSTANTS
g= 9.80665;
ft2m=1/3.28;

[TR, PR, DR, a] = atmos(h,ISADEV);
TAS=a*M;
[CDoCL]=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,M,ISADEV,TR);
FnR=(W*g)*(CDoCL);

maneted=0.7;
step=0.01;
T=0;
altm=h*ft2m;

while and(T<FnR,maneted<=1)
  [Fn,FF] = enginedeck(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
  TSFC=FF/(Fn/g);
  T=nedebasa*Fn;
  maneted=maneted+step;
end  

%fprintf('\n => FnR   = %5.1f',FnR);
%fprintf('\n => Fn    = %5.1f',Fn);
%fprintf('\n => T     = %5.1f',T);
%fprintf('\n => FF    = %5.1f',FF);
%fprintf('\n => FFtot = %5.1f',2*FF);
%fprintf('\n => maneted  = %5.2f',maneted);