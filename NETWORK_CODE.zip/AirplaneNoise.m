%% DESCRI��O E AUTORIA %%
%AirplaneNoise - Rotina para c�lculo do ru�do para otimiza��o multidisciplinar e multiobjetivo do proejto de avi�es
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de saida  : 
%                   TOnoise     - ru�do da aeronave na decolagem [EPNdB]
%                   SLnoise     - ru�do da aeronave na decolagem - sideline [EPNdB]
%                   LDnoise     - ru�do da aeronave no pouso [EPNdB]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -
%1.1        Paulo Eduardo Cypriano      01-04-13    Utiliza��o de vari�veis comuns
%1.2        Paulo Eduardo Cypriano      23-06-13    Elimina��o de inputs
%1.3        Paulo Eduardo Cypriano      15-08-13    Racionaliza��o de inputs


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [TOnoise SLnoise LDnoise] = AirplaneNoise(TOPAR,LDPAR,ACTPAR,ACTGEO,ENGPAR,RWYPAR,NOPAR)

NEng = TOPAR(11);
SW   = LDPAR(4);
bW   = LDPAR(5);
VRVS = TOPAR(5);
%% CORPO DA FUN��O %%
disp('AIRPLANE NOISE ESTIMATION FUNCTION...');
%% RU�DO DE DECOLAGEM E SIDELINE%%
%% C�lculo da trajet�ria de decolagem %%
disp('Calculating the takeoff flight-path...');
[BFLstatus, ParAEO, ParOEI, timehistory, ~] = takeoff(TOPAR,...
    LDPAR,ACTPAR,RWYPAR,ENGPAR);       
                                                                            % Trajet�ria de decolagem
%% C�lculo do ru�do - EPNdB %%
disp('Calculating the fly-over noise...');
maneted             = 1.0;                                                  % Tra��o de decolagem
[TOnoise]           = takeoffEPNdB(timehistory,maneted,TOPAR(2),NOPAR(1),NOPAR(4),NOPAR(7),ACTGEO,SW,bW,ENGPAR,NEng);
                                                                            % Ru�do de decolagem (fly over)
disp('Calculating the sideline noise...');
[SLnoise,~] = sidelineEPNdB(timehistory,maneted,TOPAR(2),TOPAR(12),NOPAR(1),NOPAR(3),ACTGEO,SW,bW,ENGPAR,NEng);
                                                                            % Ru�do de decolagem (sideline)


%% RU�DO DE APROXIMA��O E POUSO %%
%% C�lculo da trajet�ria de aproxima��o %%
disp('Calculating the approach flight-path...');
[saida]          = approachfp(LDPAR,ACTPAR,SW,NEng,VRVS);                                            % Trajet�ria de pouso

%% C�lculo do ru�do - EPNdB %%
disp('Calculating the approach noise...');
[LDnoise]        = approachEPNdB(saida,LDPAR(2),LDPAR(9),NOPAR(1),NOPAR(2),NOPAR(5),ACTGEO,SW,bW);
                                                                            % Ru�do de aproxima��o


%% Resultado da fun��o
disp('Fly-over noise...');
disp(strcat('TOnoise=',num2str(TOnoise,'%5.1f'),'(EPNdB)'));
disp('Sideline noise...');
disp(strcat('SLnoise=',num2str(SLnoise,'%5.1f'),'(EPNdB)'));
disp('Approach noise...');
disp(strcat('LDnoise=',num2str(LDnoise,'%5.1f'),'(EPNdB)'));


%% FINAL DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1986)
%2 - ESDU77022 - Atmospheric properties