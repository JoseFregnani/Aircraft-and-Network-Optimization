function [n,N,AVG_DON,L,ND,AVG_C] = NETWORKPAR(X,D,R);
   
% Number of Arcs (N)
n=size(X,2);
N=0;
for i=1:n
    for j=1:n
        if X(i,j)==1
            N=N+1;
        end    
    end
end

% Degree of node DON(i): Number of Airports having direct flight with node i
DON=zeros(1,n);
for i=1:n
      DON(i)=0;
      if i~=j
          for j=1:n
              if X(i,j)==1
                  DON(i)=DON(i)+1;
              end    
          end 
      end
end
AVG_DON=mean(DON);

% AVERAGE PATH LENGHT (L): Average Distance Between all node Pairs
DT=0;
TOT=0;
for i=1:n
    for j=1:n
        if i~=j
            if X(i,j)==1
               DT=DT+D(i,j); 
               TOT=TOT+1;
            end
        end
    end
end
if DT>0
   L=DT/TOT;
else
   L=0;
end   
ND=N/(n*n-n);

% CLUSTERING COEFFICIENT C(i):ratio of the actual connection number and the maximum possible conection edges between this node and adjacent nodes
C=zeros(1,n);
for i=1:n
    CON=0;
    MAXCON=0;
    for j=1:n
        if i~=j
            if D(i,j)<=R
               MAXCON=MAXCON+1;
               if X(i,j)==1
                  CON=CON+1;          
               end    
            end
        end
    end
    if MAXCON>0
      C(i)=CON/MAXCON;
    else
      C(i)=0;
    end  
end             
AVG_C=mean(C);

