function[TR, PR, DR, a] = atmos(h,ISADEV)

% h: pressure altitue in ft.
% ISADEV: delta temperature from standard (ISA atmosphere).

TROPO=(71.5+ISADEV)/0.0019812;
a0=661.4786;
if (h<TROPO)
    TR=(288.15-0.0019812*h+ISADEV)/288.15;
    PR=((288.15-0.0019812*h)/288.15)^5.2588;
    DR=PR/TR;  
elseif (h>=TROPO)
    TR= (216.69+ISADEV)/288.15;
    PR=0.22336*exp((TROPO-h)/20805.7);
    DR=PR/TR;
end
a=a0*sqrt(TR);
 
