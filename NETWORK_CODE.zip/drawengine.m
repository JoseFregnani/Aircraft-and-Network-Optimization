 function [engdiam_m_f]=drawengine(x0,y0,z0,engdiamo_m,engleno_m)
 %function drawengine()
% engdiam_m=1.3;
% x0=0;
% y0=0;
% z0=0;
file_to_read='jetengine.stl';
engdiam_m=engdiamo_m;
englen_m=engleno_m;
%z0=z0-engdiam_m;
%% 3D Model Demo
% This is short demo that loads and renders a 3D model of a human femur. It
% showcases some of MATLAB's advanced graphics features, including lighting and
% specular reflectance.

% Copyright 2011 The MathWorks, Inc.

%% Load STL mesh
% Stereolithography (STL) files are a common format for storing mesh data. STL
% meshes are simply a collection of triangular faces. This type of model is very
% suitable for use with MATLAB's PATCH graphics object.
%
% Import an STL mesh, returning a PATCH-compatible face-vertex structure
[fac, vert] = stlread(file_to_read);
% nfac = size(fac,1);
% nvert = size(vert,1);
vert=vert/1000;
xmin=min(vert(:,1));
xmax=max(vert(:,1));
ymin=min(vert(:,2));
ymax=max(vert(:,2));
zmin=min(vert(:,3));
zmax=max(vert(:,3));
%
%xmed = 0.50*(xmin+xmax);
ymed = 0.50*(ymin+ymax);
zmed = 0.50*(zmin+zmax);
%
dx=xmax-xmin;
dz=zmax-zmin;
%
% scale = 1;
% scalex =1;
scale      = engdiam_m/dz;
scalex     = englen_m/dx;
%
vert(:,1)  = vert(:,1) - xmin;
vert(:,2)  = vert(:,2) - ymed;
vert(:,3)  = vert(:,3) - zmed;
%
verts(:,2) = vert(:,2)*scale;
verts(:,3) = vert(:,3)*scale;
verts(:,1) = vert(:,1)*scalex;
% descobre diametro frontal (que eh menor do que o diametro maximo)
xmin_f=min(verts(:,1));
npverts=size(verts(:,1),1);
zmin_f=1e6;
zmax_f=-1e06;
for j=1:npverts
    if verts(j,1) == xmin_f
        if verts(j,3) > zmax_f
            zmax_f = verts(j,3);
        end
        if verts(j,3) < zmin_f
            zmin_f = verts(j,3);
        end
    end
end
engdiam_m_f=zmax_f-zmin_f;
%fprintf('\n engdi: %5.3f  engdi_frontal: %5.3f \n',engdiam_m,engdiam_m_f)
%
verts(:,1)=verts(:,1) + x0;
verts(:,2)=verts(:,2) + y0;
verts(:,3)=verts(:,3) + z0;
%fv = struct('faces',fac,'vertices',vert);
fv1=struct('faces',fac,'vertices',verts);
%% Render
% The model is rendered with a PATCH graphics object. We also add some dynamic
% lighting, and adjust the material properties to change the specular
% highlighting.

% patch(fv,'FaceColor',       [0.8 0.8 1.0], ...
%          'EdgeColor',       'none',        ...
%          'FaceLighting',    'gouraud',     ...
%          'AmbientStrength', 0.15,...
%          'LineStyle','none');
% 
% hold on
patch(fv1,'FaceColor',       [0.8 0.6 0.2], ...
         'EdgeColor',       'none',        ...
         'FaceLighting',    'gouraud',     ...
         'AmbientStrength', 0.125,...
         'LineStyle','none');
hold on
% % Add a camera light, and tone down the specular highlighting
camlight('headlight');
material('metal');
axis equal
% 
% Export to STL format
%stlwrite(filename,fv1,'TRIANGULATION','x')
% % Fix the axes scaling, and set a nice view angle
%  axis('image');
%  xlabel('x');
%  zlabel('z');
% view([-135 35]);
clear np xmin xmax ymin ymax zmin zmax ymed zmed
clear vert verts fv1
 end
%
