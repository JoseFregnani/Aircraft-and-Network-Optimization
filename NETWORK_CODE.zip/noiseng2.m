%% DESCRI��O E AUTORIA %%
%noiseng  - Rotina para estimativa do ruido de motores tipo turbofan
%autores  - Daniel ...
%           Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP          - altitude-press�o [ft]
%                   DISA        - varia��o da temperatura em rela��o � ISA [�C]
%                   RH          - relative humidity [%]
%                   vairp       - velocidade do avi�o [m/s]
%                   teta        - dire��o para avalia��o do ru�do [deg]
%                   fi          - eleva��o para avalia��o do ru�do [deg]
%                   R           - dist�ncia para avalia��o do ru�do [m]
%                   maneted     - posi��o da manete de tra��o (1.0 = 100%)
%                   N1          - rota��o do spool #1 (Fan + compressor LP  + Turbina LP)
%                   N2          - rota��o do spool #2 (Compressor HP  + Turbina HP)
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
% VERS�O    AUTOR                       DATA            DESCRI��O DAS MODIFICA��ES
% 1.0       Daniel ...                                  Vers�o original (noiseng)
% 2.0       Paulo Eduardo Cypriano      17-08-09        Inser��o da rotina do motor
%                                                       Utiliza��o dos dados do motor
%                                                       Remo��o da plotagem de gr�ficos
% 3.0       Paulo Eduardo Cypriano      15-01-13        Uniformiza��o da nomenclatura
% 3.1       Paulo Eduardo Cypriano      19-01-13        Uniformiza��o da rotina das propriedades atmosfericas                                      


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft, OASPLENG] = noiseng2(HP,DISA,RH,vairp,teta,fi,R,maneted,N1,N2,ENGPAR)


%% Vari�veis globais
global engine2 engine3 engine4 engine5 engine6
%global f
%global var
f                   = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];

%% CORPO DA FUN��O
%% Dados da atmosfera %%
atm                 = atmosfera(HP,DISA);                                   % propriedades da atmosfera
Machd               = vairp/atm(7);                                         % Numero de Mach

%% Dados do motor %%
[FN,FF]             = motor(HP,Machd,ENGPAR(1),ENGPAR(2),ENGPAR(3),maneted,ENGPAR(5),ENGPAR(8));     % Aten��o: N1 e N2

%% Ru�do do fan e compressor %%
ratT                = engine3(8)/engine3(3);
mponto              = engine5(2);
nfan                = N1;
MTRd                = 1.3;
nrotor              = 38;
nstat               = 80;
RSS                 = 200;
IGV                 = 0;
[~, ruidoFant]      = Fan2(HP,DISA,RH,vairp,teta,fi,R,ENGPAR(5),ratT,mponto,nfan,MTRd,nrotor,nstat,RSS,IGV);


%% Ruido da c�mara de combust�o %%
mdot                = engine5(1);
T3K                 = engine3(4);
T4K                 = engine3(5);
P3                  = engine2(4);
RH                  = 70;
[~, ruidocamarat]  = Camaracomb(HP,DISA,RH,vairp,teta,fi,R,mdot,T3K,T4K,P3);


%% Ruido da turbina %%
Tturbsaida           = engine3(5);
nturb                = N1;
MTRturb              = 0.50;
nrotor               = 76;
RSSturb              = 50;
[~, ruidoTurbinat]  = Turbina(HP,DISA,RH,vairp,teta,fi,R,mdot,nturb,Tturbsaida,MTRturb,nrotor,RSSturb);


%% Ruido de Jato %%
ACJ                 = engine4(2);
ABJ                 = engine4(3);
h                   = 0.150;
DCJ                 = 2*ACJ/(pi*h)+h/2;
VCJ                 = engine6(1);
VBJ                 = engine6(2);
TCJ                 = engine3(7);
TBJ                 = engine3(8);
roCJ                = 0.561;
roBJ                = 1.210;
plug                = 1.0;
coaxial             = 1.0;
[~, ruidoJatot]     = Bocal3(HP,DISA,RH,vairp,teta,fi,R,plug,coaxial,ACJ,ABJ,h,DCJ,VCJ,VBJ,TCJ,TBJ,roCJ,roBJ);


%% Ruido total %%
ruidoTotal          = 10*log10(10.^(0.1*ruidoFant)+10.^(0.1*ruidocamarat)+10.^(0.1*ruidoTurbinat)+10.^(0.1*ruidoJatot));


%% DADOS DE SAIDA %%
OASPLENG            = ruidoTotal;
ft                  = f';


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - ESDU90023 - Airframe noise prediction
%2 - ESDU77022 - Atmospheric properties