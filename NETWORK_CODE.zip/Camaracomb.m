%% DESCRI��O E AUTORIA %%
%Camaracomb - Rotina para estimativa do ruido da c�mara de combust�o de motores a rea��o
%autores    - Daniel ...
%             Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP            - altitude-press�o [ft]
%                   DISA          - varia��o da temperatura em rela��o � ISA [�C]
%                   RH            - relative humidity [%]
%                   vairp         - velocidade do avi�o [m/s]
%                   teta          - dire��o para avalia��o do ru�do [deg]
%                   fi            - eleva��o para avalia��o do ru�do [deg]
%                   R             - dist�ncia para avalia��o do ru�do [m]
%                   mdot          - vaz�o m�ssica atrav�s do fan [kg/s]
%                   TcombentradaK - temperatura de entrada da c�mara de combust�o [K]
%                   TcombsaidaK   - temperatura de sa�da da c�mara de combust�o [K]
%                   PcombentradaK - press�o de entrada da c�mara de combust�o [Pa]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Daniel ...                              Vers�o original (Camaracomb)
%2.0        Paulo Eduardo Cypriano      21-08-09    Remo��o da plotagem de gr�ficos
%3.0        Paulo Eduardo Cypriano      19-01-13    Uniformiza��o dos calculos atmosfericos
%4.0        Paulo Eduardo Cypriano      18-03-13    Corre��es nos c�lculos


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft ruidocamarat] = Camaracomb(HP,DISA,RH,vairp,teta,fi,R,mdot,TcombentradaK,TcombsaidaK,Pcombentrada)


%% Vari�veis globais
%global f
f                   = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];

%% Fatores de convers�o
%global m2ft deg2rad
m2ft = 3.28084;
deg2rad = pi/180;

%% Tabelas para interpola��o
tetatab             = [0     10    20    30    40    50    60    70    80    90    100   110   120   130   140   150   160   170   180];
OASPLPWLtab         = [-32.4 -30.8 -29.6 -28.0 -26.6 -25.0 -24.0 -23.4 -22.3 -20.8 -19.6 -18.8 -18.6 -18.5 -18.7 -19.0 -19.0 -19.1 -19.2];


%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
v0                  = vairp;                                                % velocidade da aeronave [m/s]
radialdistance      = R;                                                    % dist�ncia para avalia��o do ru�do [m]

%% Dados da atmosfera %%
atm                 = atmosfera(HP*m2ft,DISA);                              % propriedades da atmosfera
T                   = atm(1);                                               % temperatura ambiente [K]
p0                  = atm(5);                                               % press�o ambiente [Pa]
vsom                = atm(7);                                               % velocidade do som [m/s]


%% C�lculos iniciais %%
M0                  = v0/vsom;                                              % n�mero de Mach da aeronave

%% Ruido da c�mara de combust�o %%
epsilon             = fi;
OAPWL               = 56.5+10*log10((mdot/0.4536)*((TcombsaidaK-TcombentradaK)*(Pcombentrada/p0)*(T/TcombentradaK))); %colocar temperatura total
OASPLPWL            = interp1(tetatab,OASPLPWLtab,teta);
OASPLtr             = OAPWL+OASPLPWL-20*log10(radialdistance);              % SPLr est� inclu�do
fp                  = 740*sqrt((0.4536/mdot)*(Pcombentrada/101325)*sqrt(288.15/TcombsaidaK));
if (fp<300) || (fp>1000)
    fp=400;
end
if f<=fp
    SPLf            = 15.02.*(log10(f/fp)).^6+65.92.*(log10(f/fp)).^5+108.33.*(log10(f/fp)).^4+75.37.*(log10(f/fp)).^3+2.96.*(log10(f/fp)).^2+1.48.*log10(f/fp)-10;
else
    SPLf            = 0.20.*(log10(f/fp)).^6-1.02.*(log10(f/fp)).^5+1.21.*(log10(f/fp)).^4+2.72.*(log10(f/fp)).^3-11.54.*(log10(f/fp)).^2-1.30.*log10(f/fp)-10;
end
SPLftr              = SPLf+OASPLtr;


%% Amortecimento atmosf�rico %%
[ft alfaamortt amorttott amortatm SPLrt] = amort(T,RH,radialdistance,f);

%% Efeito doppler %%
deltaLdoppler       = -40*log10(1-M0*cos(epsilon*deg2rad));


%% DADOS DE SAIDA %%
Ruidocamara         = SPLftr-amortatm'+deltaLdoppler;
ft                  = f';
ruidocamarat        = Ruidocamara';
a1                  = length(ruidocamarat);
for ia1=1:a1
    if ruidocamarat(ia1)<1
        ruidocamarat(ia1) = 1;
    end
end


%% VERIFICA��ES EM DEBUG
% figure()
% semilogx(f,SPLftr,'o-b');
% grid on;
% legend('core noise');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - NASA TM X-71627 - Interim prediction method for low frequency core engine noise (1974)
%2 - ESDU05001 - Prediction of combustor noise from gas turbine engines (2005) 