function [Vhold_kt,CDoCL,FF_hold]= BESTHOLDSPEED(ACFT,W,ALT,ISADEV,NNind,NNwav,NNcd0,NNCL)

%  CONSTANTS
g=9.8061;

% AIRCRAFT DATA
OEW=ACFT.OEW;
MSTOW=ACFT.MTOW;
MSLW=ACFT.MLW;
MZFW=ACFT.MZFW;
MAXFUEL=ACFT.MAXFUEL;
MMO=ACFT.MMO; 
VMO=ACFT.VMO; 
%
wS=ACFT.wS;
wSft2=ACFT.wSft2;
wAR=ACFT.wAR;
wTR=ACFT.wTR;
wSweep14=ACFT.wSweep14;
wTwist=ACFT.wTwist;
CLMAX=ACFT.CLMAX;
PWing=ACFT.PWing;
Kink_semispan=ACFT.Kink_semispan;
inc_root=ACFT.inc_root; 
inc_kink=ACFT.inc_kink; 
inc_tip=ACFT.inc_tip; 
wMAC=ACFT.wMAC;
wSweepLE=ACFT.wSweepLE;
%
VTarea=ACFT.VTarea;
VTAR=ACFT.VTAR;
VTTR=ACFT.VTTR;
VTSweep=ACFT.VTSweep;
%
HTarea=ACFT.HTarea;
HTAR=ACFT.HTAR;
HTTR=ACFT.HTTR;
PHT=ACFT.PHT;
%
container_type=ACFT.container_type;
NPax=ACFT.NPax;
NCorr=ACFT.NCorr;
NSeat=ACFT.NSeat;
ncrew=ACFT.ncrew;
AisleWidth=ACFT.AisleWidth;
CabHeightm=ACFT.CabHeightm;    
SEATwid=ACFT.SEATwid;  
fus_width=ACFT.fus_width;
fus_height=ACFT.fus_height;
FusDiam=ACFT.FusDiam;
%
PEng=ACFT.PEng; 
MAXRATE=ACFT.MAXRATE;
T0=ACFT.T0;
n=ACFT.n;  
nedebasa=ACFT.nedebasa; 
ebypass=ACFT.ebypass;
ediam=ACFT.ediam;
efanpr=ACFT.efanpr;
eopr=ACFT.eopr;
eTIT=ACFT.eTIT;
%
r0=ACFT.r0;
t_c=ACFT.t_c;
phi=ACFT.phi;
X_tcmax=ACFT.X_tcmax;
theta=ACFT.theta;
epsilon=ACFT.epsilon;
Ycmax=ACFT.Ycmax;
YCtcmax=ACFT.YCtcmax;
X_Ycmax=ACFT.X_Ycmax;
wTCmed=ACFT.wTCmed;
%
Airp_SWET=ACFT.Airp_SWET;
wingSwet=ACFT.wingSwet;
lf=ACFT.lf;
lco=ACFT.lco;
%
Ccentro=ACFT.Ccentro;
Craiz=ACFT.Craiz;
Cquebra=ACFT.Cquebra;
Cponta=ACFT.Cponta;
xutip=ACFT.xutip;
yutip=ACFT.yutip;
xltip=ACFT.xltip;
yltip=ACFT.yltip;
xukink=ACFT.xukink;
yukink=ACFT.yukink;
xlkink=ACFT.xlkink;
ylkink=ACFT.ylkink;
xuroot=ACFT.xuroot;
yuroot=ACFT.yuroot;
xlroot=ACFT.xlroot;
ylroot=ACFT.ylroot;
swet2=ACFT.Airp_SWET;

% CALCULATION
[TR, PR, DR, a] = atmos(ALT,ISADEV);
dens=DR*1.225;
Mi=0.10;
step=0.005;
M=Mi;
h=ALT;
W=MSTOW-1000;
MinCDoCL=10;
MMin=0;

for i=1:18    
    M=M+step;
    TAS=M*a;
    q=(1/2)*dens*(TAS^2);
    CL=(W*g)/(q*wS);        
    [CDoCL]= CDCL_mod (wS,wAR,wTR,swet2,wingSwet,wSweepLE, ...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);     
    if CDoCL<MinCDoCL
      MMin=M; 
      MinCDoCL=CDoCL;
    end
    Table(i,1)=M;
    Table(i,2)=CDoCL;
end
%
Mhold=1.3*MMin;
Vhold=Mhold*a;
Vhold_kt=Vhold*(3.6/1.852);

[TSFC,CDoCL,FF,maneted]=SFCCRZ_REV07(wS,wAR,wTR,...
    swet2,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,ebypass,ediam,efanpr,eopr,eTIT,W,h,Mhold,ISADEV,NNind,NNwav,NNcd0,NNCL);

FF_hold=FF/60;