function TWreq_takeoff=check_takeoff(clmaxt,takeofffl,MTOW,wS)
% Required takeoff thrust-to-weight ratio
%
kto               = 2.34; % Takeoff parameter
%
wingloadi         = MTOW/wS;
graddecol         = kto/(clmaxt*takeofffl);
TWreq_takeoff     = graddecol*wingloadi;
end