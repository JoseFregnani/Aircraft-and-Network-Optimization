function [M]=CAS2MACH(CAS,PR)

K1=1/PR;
K2=CAS/661.4786;    
M=sqrt(5*((K1*((1+0.2*K2^2)^3.5-1)+1)^(1/3.5)-1));