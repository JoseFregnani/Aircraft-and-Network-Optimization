%% DESCRI��O E AUTORIA %%
%takeoff  - Rotina para c�lculo da decolagem AEO com trajet�ria de subida e decolagem OEI balanceada
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP          - altitude do aeroporto [ft]
%                   DISA        - varia��o da temperatura-padr�o ISA [�C]
%                   W           - peso de decolagem da aeronave [N]
%                   ACTPAR      - par�metros da aeronave
%                       (1)     - SW = �rea alar [m�]
%                       (2)     - CLMAX = coeficiente de sustenta��o m�ximo
%                       (3)     - CL3P = coeficiente de sustenta��o no solo (3 pontos)
%                       (4)     - CLAIR = coeficiente de sustenta��o no ar
%                       (5)     - CD3P = coeficiente de arrasto no solo (3 pontos)
%                       (6)     - CDAIRGDN = coeficiente de arrasto no ar (trem-de-pouso baixado)
%                       (7)     - CDAIRGUP = coeficiente de arrasto no ar (trem-de-pouso recolhido)
%                   RWYPAR      - par�metros da pista de decolagem
%                       (1)     - coeficiente de atrito de rolamento
%                       (2)     - coeficiente de atrito de frenagem
%                   ENGPAR      - par�metros do motor
%                       (1)     - fanpr = raz�o de press�o no fan
%                       (2)     - opr = raz�o de press�o total do motor
%                       (3)     - bpr = raz�o de deriva��o do motor
%                       (4)     - maneted = percentual da tra��o m�xima (0 a 1)
%                       (5)     - diamfan = di�metro do fan do motor [m]
%                       (6)     - N1 de refer�ncia [rpm]
%                       (7)     - N2 de refer�ncia [rpm]
%                       (8)     - Turbine Inlet Temperature (TIT) [K]
%                   lambda      - �ngulo da tra��o em rela��o � dire��o da velocidade [deg]
%                   K1          - raz�o VR/VS
%                   K2          - raz�o V2/VS
%                   time1       - tempo entre VEF e V1
%                   SH          - altura do osbst�culo no final da pista [ft]
%                   tstep       - intervalo de tempo para integra��o [s]
%                   time2       - tempo entre VLO e VOBS [s]
%                   nmot        - n�mero de motores da aeronave
%                   distmax     - dist�ncia m�xima para gera��o da trajet�ria [m]
%Dados de saida  : 
%                   BFLstatus   - flag de converg�ncia do c�lculo de BFL
%                   PARAEO      - par�metros da decolagem AEO
%                       (1)     - velocidade de rota��o [m/s]
%                       (2)     - velocidade no final do flare [m/s]
%                       (3)     - dist�ncia at� a rota��o [m]
%                       (4)     - dist�ncia no final do flare [m]
%                       (5)     - tempo at� a rota��o [s]
%                       (6)     - tempo at� o final do flare [s]
%                   PAROEI      - par�metros da decolagem OEI
%                   timehistory - trajet�ria de decolagem
%                       (1)     - tempo [s]
%                       (2)     - velocidade [m/s]
%                       (3)     - dist�ncia a partir da partida [m]
%                       (4)     - velocidade horizontal [m/s]
%                       (5)     - altura em rela��o ao solo [m]
%                       (6)     - velocidade vertical [m/s]
%                       (7)     - �ngulo da trajet�ria [deg]
%                   saidateste  - hist�rico da itera��o para c�lculo de BFL
%                       (1)
%                       (2)
%                       (3)
%                       (4)
%                       (5)
%                       (6)
%                       (7)
%                       (8)
%                       (9)
%                       (10)
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%   SW              - �rea alar [m�]
%   CLMAX           - coeficiente de sustenta��o m�ximo
%   CL3P            - coeficiente de sustenta��o no solo (3 pontos)
%   CLAIR           - coeficiente de sustenta��o no ar
%   CD3P            - coeficiente de arrasto no solo (3 pontos)
%   CDAIR           - coeficiente de arrasto no ar


%% DECLARA��O DA FUN��O %%
function [BFLstatus ParAEO ParOEI timehistory saidateste] = ...
    takeoff(TOPAR,LDPAR,ACTPAR,RWYPAR,ENGPAR)


%% Vari�veis globais
global engine1 engine7
%global g
%global VRVS V2VS                                                            % Rela��es de velocidade
%global var
global N1ref N2ref
%global TOPAR
% Constantes
g=9.81;

%% CORPO DA FUN��O %%
%% C�lculo dos par�metros da atmosfera %%
atm                 = atmosfera(TOPAR(1),TOPAR(2) );                       % par�metros da atmosfera
rho                 = atm(6);                                              % densidade do ar [kg/m�]
a                   = atm(7);                                              % velocidade do som [m/s]
%% Atribui��o dos par�metros para a integra��o %%
DATARY(1)           = g;                                                   % acelera��o da gravidade [m/s�]
DATARY(2)           = rho;                                                 % densidade do ar [kg/m�]
DATARY(3)           = TOPAR(3);                                            % peso de decolagem [N]
DATARY(4)           = LDPAR(4);                                            % �rea alar [m�]
DATARY(5)           = LDPAR(6);                                            % coeficiente de sustenta��o m�ximo
DATARY(6)           = LDPAR(11);                                           % coefidiente de sustenta��o no solo (3 pontos)
DATARY(7)           = ACTPAR(4);                                           % coeficiente de sustenta��o no ar
DATARY(8)           = ACTPAR(5);                                           % coeficiente de arrasto no solo (3 pontos)
DATARY(9)           = ACTPAR(6);                                           % coeficiente de arrasto no ar (trem-de-pouso baixado)
DATARY(10)          = RWYPAR(1);                                           % coeficiente de atrito de rolamento
DATARY(11)          = RWYPAR(2);                                           % coeficiente de atrito de frenagem
DATARY(12)          = TOPAR(4);                                            % �ngulo de deflex�o da tra��o [deg]
DATARY(13)          = TOPAR(5);                                            % raz�o entre VR e VS
DATARY(14)          = TOPAR(7);                                            % tempo entre falha do motor e frenagem em RTO [s]
DATARY(15)          = TOPAR(8)*0.3048;                                     % altura do obst�culo [m]
DATARY(16)          = (TOPAR(11)-1)/TOPAR(11);                             % percentual de tra��o remanescente ap�s a falha de um dos motores
DATARY(23)          = TOPAR(9);                                            % intervalo de tempo para determina��o da trajet�ria
DATARY(24)          = TOPAR(10);                                           % tempo de rota��o [s]
DATARY(25)          = TOPAR(12);                                           % m�xima dist�ncia para determina��o das trajet�rias [m]
ERR                 = 1.E-6;                                               % erro para determina��o da dist�ncia balanceada
WTO                 = TOPAR(3);                                            % Peso de decolagem [N]
SW                  = LDPAR(4);                                            % AREA ALAR [m2]
CLMAX               = ACTPAR(2);
VRVS                = TOPAR(5);
V2VS                = TOPAR(6);
N1ref               = ENGPAR(6);
N2ref               = ENGPAR(7);
CLAIR               = ACTPAR(4);
CDAIRGUP            = ACTPAR(7);
CDAIRGDN            = ACTPAR(6);
tstep               = TOPAR(9);
NEng                = TOPAR(11);
distmax             = TOPAR(12);
%% C�lculos inciais %%
VR                  = VRVS * sqrt((2.*WTO)/(rho*SW*CLMAX));  % velocidade de rota��o [m/s]
V2                  = V2VS * sqrt((2.*WTO)/(rho*SW*CLMAX));  % velocidade de seguran�a na decolagem [m/s]
V35                 = V2 + 10/1.9438;                                      % velocidade de subida [m/s]
velo                = [0, (V2+20)/2 ,(V2+20)];                              % vetor de velocidades [m/s]
macv                = velo/(a);                                             % vetor com os valores do n�mero de Mach na decolagem
for i1=1:3                                                                 % vetor de tra��es [N]
    [FN,~]         = motor(TOPAR(1),macv(i1),ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
    thrust(i1)      = NEng*FN;
end
[T0 T1 T2]          = QINTRP(velo,thrust);                                 % coeficientes da equa��o de tra��o

%% DECOLAGEM AEO %%
disp('   ...Calculating the AEO takeoff...');
%% Defini��o das vari�veis iniciais %%
RPARM(1)            = DATARY(2);                                            % densidade do ar [kg/m�]
RPARM(2)            = DATARY(3);                                            % peso de decolagem [N]
RPARM(3)            = DATARY(4);                                            % �rea alar [m�]
RPARM(4)            = DATARY(6);                                            % coefidiente de sustenta��o no solo (3 pontos)
RPARM(5)            = DATARY(8);                                            % coeficiente de arrasto no solo (3 pontos)
RPARM(6)            = DATARY(10);                                           % coeficiente de atrito de rolamento
RPARM(7)            = T0;                                                   % coeficiente de tra��o
RPARM(8)            = T1;                                                   % coeficiente de tra��o
RPARM(9)            = T2;                                                   % coeficiente de tra��o
RPARM(10)           = DATARY(12);                                           % �ngulo de deflex�o da tra��o [deg]
RPARM(11)           = DATARY(1);                                            % acelera��o da gravidade [m/s�]
RPARM(12)           = ENGPAR(1);                                          % raz�o de press�o no fan
RPARM(13)           = ENGPAR(2);                                           % raz�o de press�o total
RPARM(14)           = ENGPAR(3);                                               % raz�o de deriva��o
RPARM(15)           = 1.0;                                                  % regime de tra��o
RPARM(16)           = ENGPAR(5);                                             % di�metro do fan [m]
RPARM(17)           = N1ref;                                                % N1 de refer�ncia [rpm]
RPARM(18)           = N2ref;                                                % N2 de refer�ncia [rpm]
%% Corrida no solo at� VR %%
NEQ                 = 2;                                                    % n�mero de equa��es para solu��o por Runge-Kutta
Y4(1)               = 0.;                                                   % dist�ncia inicial [m]
Y4(2)               = 0.;                                                   % velocidade horizontal inicial [m/s]
Y4(3)               = 0.;                                                   % altura inicial [m]
Y4(4)               = 0.;                                                   % velocidade vertical inicial [m/s]
Y4(5)               = 0.;                                                   % �ngulo de trajet�ria inicial [rad]
T                   = 0.;                                                   % tempo inicial [s]
mach                = Y4(2)/(a);                                            % vetor com os valores do n�mero de Mach na decolagem
[FN,FF]             = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
i2                  = 1;                                                    % contador
timehistory(i2,:)   = [T 0 0 0 0 0 0 engine7(1) engine7(2)];                % vetor com a evolu��o dos par�metros [T,V,d,VH,h,VV,gama,N1,N2]
for I = 1:1000
	i2              = i2+1;                                                 % avan�o do contador
    TINI            = T;                                                    % tempo inicial da integra��o [s]
    TFIN            = T + DATARY(23);                                       % tempo final da integra��o [s]
    Y1INI           = Y4(1);                                                % dist�ncia inicial da integra��o [m]
    Y2INI           = Y4(2);                                                % velocidade inicial da integra��o [m/s]
    [Y4, Y3, TFIN, DYDX] = ADPTRK('GROUND',T,TFIN,Y4,NEQ,RPARM,ERR);           % integra��o por Runge-Kutta
    if (Y4(2)<VR)
        mach = Y4(2)/(a);                                                   % vetor com os valores do n�mero de Mach na decolagem
        [FN,FF]     = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [TFIN,Y4(2),Y4(1),Y4(2),0,0,0,engine7(1),engine7(2)];
    else                                                                    % interpola��o dos par�metros, caso T35 n�o seja m�ltiplo de tstep
    	TEMP1       = LINTRP(VR,Y2INI,Y4(2),TINI,TFIN);                     % interpola��o do tempo
        TEMP2       = LINTRP(VR,Y2INI,Y4(2),Y1INI,Y4(1));                   % interpola��o da dist�ncia
        mach        = VR/(a);                                               % vetor com os valores do n�mero de Mach na decolagem
        [FN,FF]     = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [TEMP1,sqrt(VR^2),TEMP2,VR,0,0,0,engine7(1),engine7(2)];
        TR          = TEMP1;                                                % tempo para VR [s]
        XR          = TEMP2;                                                % dist�ncia para VR [m]
        T           = TEMP1;                                                % tempo para VR [s]
        X           = TEMP2;                                                % dist�ncia para VR [m]
        break                                                               % interrompe a execu��o do c�lculo - VR foi atingida
	end
    T               = TFIN;                                                 % tempo final no solo [s]
end
%% Corrida no solo de VR a V35 %%
NEQ                 = 2;                                                    % n�mero de equa��es para solu��o por Runge-Kutta
Y4(1)               = XR;                                                   % dist�ncia inicial [m]
Y4(2)               = VR;                                                   % velocidade horizontal inicial [m/s]
Y4(3)               = 0.;                                                   % altura inicial [m]
Y4(4)               = 0.;                                                   % velocidade vertical inicial [m/s]
Y4(5)               = 0.;                                                   % �ngulo de trajet�ria inicial [rad]
TINI                = TR;                                                   % tempo inicial [s]
i2                  = i2+1;
if floor(TR)==ceil(TR-tstep)
	TFIN            = floor(TR)+tstep;
else
	TFIN            = ceil(TR);
end
[Y4 Y3 TFIN DYDX]   = ADPTRK('GROUND',TINI,TFIN,Y4,NEQ,RPARM,ERR);          % integra��o por Runge-Kutta
mach                = Y4(2)/(a);                                            % vetor com os valores do n�mero de Mach na decolagem
[FN,FF]             = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
timehistory(i2,:)   = [TFIN,Y4(2),Y4(1),Y4(2),0,0,0,engine7(1),engine7(2)]; % trajet�ria
T                   = TFIN;
for I = 1:1000
	i2              = i2+1;                                                 % avan�o do contador
    TINI            = T;                                                    % tempo inicial da integra��o [s]
    TFIN            = T + DATARY(23);                                       % tempo final da integra��o [s]
    Y1INI           = Y4(1);                                                % dist�ncia inicial da integra��o [m]
    Y2INI           = Y4(2);                                                % velocidade inicial da integra��o [m/s]
    [Y4 Y3 TFIN DYDX] = ADPTRK('GROUND',T,TFIN,Y4,NEQ,RPARM,ERR);           % integra��o por Runge-Kutta
    if (Y4(2)<V35)
        mach = Y4(2)/(a);                                                   % vetor com os valores do n�mero de Mach na decolagem
        [FN,FF]     = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [TFIN,Y4(2),Y4(1),Y4(2),0,0,0,engine7(1),engine7(2)];
    else                                                                    % interpola��o dos par�metros, caso T35 n�o seja m�ltiplo de tstep
    	TEMP1       = LINTRP(V35,Y2INI,Y4(2),TINI,TFIN);                    % interpola��o do tempo
        TEMP2       = LINTRP(V35,Y2INI,Y4(2),Y1INI,Y4(1));                  % interpola��o da dist�ncia
        mach        = V35/(a);                                              % vetor com os valores do n�mero de Mach na decolagem
        [FN,FF]     = motor(TOPAR(1),mach,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [TEMP1,sqrt(V35^2),TEMP2,V35,0,0,0,engine7(1),engine7(2)];
        T35         = TEMP1;                                                % tempo para V35 [s]
        X35         = TEMP2;                                                % dist�ncia para V35 [m]
        T           = TEMP1;                                                % tempo para V35 [s]
        X           = TEMP2;                                                % dist�ncia para V35 [m]
        break                                                               % interrompe a execu��o do c�lculo - V35 foi atingida
	end
    T               = TFIN;                                                 % tempo final no solo [s]
end
%% Flare to 35ft %%
i2                  = i2+1;                                                 % atualiza��o do contador
RPARM(4)            = DATARY(7);                                            % coeficiente de sustenta��o no ar
RPARM(5)            = DATARY(9);                                            % coeficiente de arrasto no ar
NEQ                 = 5;                                                    % n�mero de equa��es para solu��o por Runge-Kutta
% Defini��o da altura final do flare [ft]
ALTHP               = 100;
DH                  = 0;
ALTFLARE            = ALTHP-DH;
VT                  = V35;
for p1 = 1:100
    Y4(1)           = X35;                                                  % dist�ncia inicial para a integra��o (V35) [m]
    Y4(2)           = VT;                                                   % velocidade horizontal inicial para a integra��o (V35) [m/s]
    Y4(3)           = 0;                                                    % altura inicial para a integra��o (V35) [m]
    Y4(4)           = 0;                                                    % velocidade vertical inicial para a integra��o (V35) [m/s]
    Y4(5)           = 0;                                                    % �ngulo de trajet�ria inicial para a integra��o (V35) [rad]
    i3              = 1;
    atm             = atmosfera(ALTFLARE,0);                                % par�metros da atmosfera
    a               = atm(7);                                               % velocidade do som [m/s]
    VMACH           = VT/(a);
    [FN,FF]         = motor(TOPAR(1),VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
    TNET            = 2*engine1(1);      
    SENGAMA         = TNET/WTO-CDAIRGDN/CLAIR;
    GAMARAD         = atan(SENGAMA);
    GAMAREF         = 180/pi*GAMARAD;
    T               = 0;
    dmy             = 0;
    [DYDX]          = AIR2(dmy,Y4,RPARM,ENGPAR,NEng);
    Y4(1)           = Y4(1)+DYDX(1)*tstep;
    Y4(2)           = Y4(2)+DYDX(2)*tstep;
    Y4(3)           = Y4(3)+DYDX(3)*tstep;
    Y4(4)           = Y4(4)+DYDX(4)*tstep;
    Y4(5)           = Y4(5)+DYDX(5)*tstep;
    timedummy(i3,:) = [T,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),Y4(5)*180/pi,engine7(1),engine7(2)];
    for I = 1:1000
        i3          = i3+1;
        TOUT        = T + DATARY(23);
        TOLD        = T;
        Y1OLD       = Y4(1);
        Y2OLD       = Y4(2);
        Y3OLD       = Y4(3);                                                      
        Y4OLD       = Y4(4);   
        Y5OLD       = Y4(5);
        [DYDX]      = AIR2(dmy,Y4,RPARM,ENGPAR,NEng);
        Y4(1)       = Y1OLD+DYDX(1)*tstep;
        Y4(2)       = Y2OLD+DYDX(2)*tstep;
        Y4(3)       = Y3OLD+DYDX(3)*tstep;
        Y4(4)       = Y4OLD+DYDX(4)*tstep;
        Y4(5)       = Y5OLD+DYDX(5)*tstep;
        if (Y4(5) < GAMARAD)
            VMACH   = sqrt(Y4(2)^2+Y4(4)^2)/(a);
            [FN,FF] = motor(ALTFLARE,VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        	timedummy(i3,:) = [TOUT,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),Y4(5)*180/pi,engine7(1),engine7(2)];
        else
        	T       = LINTRP(GAMARAD,Y5OLD,Y4(5),TOLD,TOUT);
            Y4(1)   = LINTRP(GAMARAD,Y5OLD,Y4(5),Y1OLD,Y4(1));
            Y4(2)   = LINTRP(GAMARAD,Y5OLD,Y4(5),Y2OLD,Y4(2));
            Y4(3)   = LINTRP(GAMARAD,Y5OLD,Y4(5),Y3OLD,Y4(3));
            Y4(4)   = LINTRP(GAMARAD,Y5OLD,Y4(5),Y4OLD,Y4(4));
            VMACH   = sqrt(Y4(2)^2+Y4(4)^2)/(a);
            [FN,FF] = motor(ALTFLARE,VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
            timedummy(i3,:) = [T,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),GAMAREF,engine7(1),engine7(2)];
            TOBS    = T;
            XOBS    = Y4(1);
            VT      = sqrt(Y4(2)^2+Y4(4)^2);
            VOBS    = VT;
            break
        end
        T           = TOUT;
    end
    if (ALTFLARE*0.3048-Y4(4))>1e-1                                         % Aten��o!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        DH          = 0.5/0.3048*(ALTFLARE*0.3048-Y4(4));
        timedummy   = zeros(20,9);
        GAMARAD     = 0;
        ALTFLARE    = ALTFLARE-DH;
    else
        break
    end
end
Y4(1)               = X35;                                                  % dist�ncia inicial para a integra��o (V35) [m]
Y4(2)               = V35;                                                  % velocidade horizontal inicial para a integra��o (V35) [m/s]
Y4(3)               = 0;                                                    % altura inicial para a integra��o (V35) [m]
Y4(4)               = 0;                                                    % velocidade vertical inicial para a integra��o (V35) [m/s]
Y4(5)               = 0;                                                    % �ngulo de trajet�ria inicial para a integra��o (V35) [rad]
TLO                 = T35;
VLO                 = V35;
XLO                 = X35;
if floor(TLO)==ceil(TLO-tstep)
	T               = floor(TLO)+tstep;
else
	T               = ceil(TLO);
end
dmy                 = 0;
[DYDX]              = AIR2(dmy,Y4,RPARM,ENGPAR,NEng);
Y4(1)               = Y4(1)+DYDX(1)*tstep;
Y4(2)               = Y4(2)+DYDX(2)*tstep;
Y4(3)               = Y4(3)+DYDX(3)*tstep;
Y4(4)               = Y4(4)+DYDX(4)*tstep;
Y4(5)               = Y4(5)+DYDX(5)*tstep;
atm                 = atmosfera(Y4(3),0);                                   % par�metros da atmosfera
a                   = atm(7);                                               % velocidade do som [m/s]
VMACH               = sqrt(Y4(2)^2+Y4(4)^2)/(a);
[FN,FF]             = motor(Y4(3),VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
timehistory(i2,:)   = [T,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),Y4(5)*180/pi,engine7(1),engine7(2)];
for I = 1:1000
	i2              = i2+1;
    TOUT            = T + DATARY(23);
    TOLD            = T;
    Y1OLD           = Y4(1);
    Y2OLD           = Y4(2);
    Y3OLD           = Y4(3);                                                      
    Y4OLD           = Y4(4);   
    Y5OLD           = Y4(5);
    [DYDX]          = AIR2(dmy,Y4,RPARM,ENGPAR,NEng);
    Y4(1)           = Y1OLD+DYDX(1)*tstep;
    Y4(2)           = Y2OLD+DYDX(2)*tstep;
    Y4(3)           = Y3OLD+DYDX(3)*tstep;
    Y4(4)           = Y4OLD+DYDX(4)*tstep;
    Y4(5)           = Y5OLD+DYDX(5)*tstep;
    if (Y4(5) < GAMARAD)
        atm         = atmosfera(Y4(3),0);                                   % par�metros da atmosfera
        a           = atm(7);                                               % velocidade do som [m/s]
        VMACH       = sqrt(Y4(2)^2+Y4(4)^2)/(a);
        [FN,FF]     = motor(Y4(3),VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [TOUT,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),Y4(5)*180/pi,engine7(1),engine7(2)];
    else
    	T           = LINTRP(GAMARAD,Y5OLD,Y4(5),TOLD,TOUT);
        Y4(1)       = LINTRP(GAMARAD,Y5OLD,Y4(5),Y1OLD,Y4(1));
        Y4(2)       = LINTRP(GAMARAD,Y5OLD,Y4(5),Y2OLD,Y4(2));
        Y4(3)       = LINTRP(GAMARAD,Y5OLD,Y4(5),Y3OLD,Y4(3));
        Y4(4)       = LINTRP(GAMARAD,Y5OLD,Y4(5),Y4OLD,Y4(4));
        atm         = atmosfera(Y4(3),0);                                   % par�metros da atmosfera
        a           = atm(7);                                               % velocidade do som [m/s]
        VMACH       = sqrt(Y4(2)^2+Y4(4)^2)/(a);
        [FN,FF]     = motor(Y4(3),VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
        timehistory(i2,:) = [T,sqrt(Y4(2)^2+Y4(4)^2),Y4(1),Y4(2),Y4(3),Y4(4),GAMAREF,engine7(1),engine7(2)];
        TOBS        = T;
        XOBS        = Y4(1);
        VOBS        = V35;
        break
	end
    T               = TOUT;
end
%% Subida ap�s a decolagem %%
if floor(T)==ceil(T-tstep)                                                  % ajuste do tempo
    T               = floor(T)+tstep;
else
    T               = ceil(T);
end
DIST                = timehistory(i2,3);                                    % dist�ncia ap�s o final do flare [m]
ALT                 = timehistory(i2,5);                                    % altura ap�s o final do flare [m]
VV                  = timehistory(i2,6);                                    % velocidade vertical [m/s]
VH                  = timehistory(i2,4);                                    % velocidade horizontal [m/s]
i2                  = i2+1;                                                 % atualiza��o do contador
V35                 = sqrt(VV^2+VH^2);
VOBS                = V35;                                                  % velocidade no final do flare [m/s]
ALTHP               = TOPAR(1)+ALT/0.3048;                                        % altitude [ft]
atm                 = atmosfera(ALTHP,TOPAR(2));                                % par�metros da atmosfera
a                   = atm(7);                                               % velocidade do som [m/s]
VMACH               = V35/(a);                                              % n�mero de Mach
[FN,FF]             = motor(ALTHP,VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
TNET                = NEng*engine1(1);                                      % tra��o total [N]
N1                  = engine7(1);                                           % rota��o do fan [rpm]
N2                  = engine7(2);                                           % rota��o do compressor [rpm]
if ALT<=100
    GAMMA           = atan(TNET/WTO-CDAIRGDN/CLAIR);                          % �ngulo de subida [rad]
else
    GAMMA           = atan(TNET/WTO-CDAIRGUP/CLAIR);                          % �ngulo de subida [rad]
end
ROCMS               = V35*sin(GAMMA);                                       % velocidade vertical [m/s]
DELTAH              = ROCMS*DATARY(23);                                     % incremento de altura [m]
DELTAD              = V35*DATARY(23)*cos(GAMMA);                            % incremento de dist�ncia
timehistory(i2,:)   = [T,V35,DIST+DELTAD,V35*cos(GAMMA),ALT+DELTAH,ROCMS,GAMMA*180/pi,N1,N2];
for I=1:1000
	T               = T+DATARY(23);
    DIST            = timehistory(i2,3);                                    % dist�ncia [m]
    ALT             = timehistory(i2,5);                                    % altura [m]
    i2              = i2+1;                                                 % atualiza��o do contador
    ALTHP           = TOPAR(1)+ALT/0.3048;                                        % altitude [ft]
    atm             = atmosfera(ALTHP,TOPAR(2));                                % par�metros da atmosfera
    a               = atm(7);                                               % velocidade do som [m/s]
    VMACH           = V35/(a);                                              % n�mero de Mach
    [FN,FF]         = motor(ALTHP,VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
    TNET            = NEng*engine1(1);                                      % tra��o total [N]
    N1              = engine7(1);                                           % rota��o do fan [rpm]
    N2              = engine7(2);                                           % rota��o do compressor [rpm]
    if ALT<=100
        GAMMA       = atan(TNET/WTO-CDAIRGDN/CLAIR);                          % �ngulo de subida [rad]
    else
        GAMMA       = atan(TNET/WTO-CDAIRGUP/CLAIR);                          % �ngulo de subida [rad]
    end
    ROCMS           = V35*sin(GAMMA);                                       % velocidade vertical [m/s]
    DELTAH          = ROCMS*DATARY(23);                                     % incremento de altura [m]
    DELTAD          = V35*DATARY(23)*cos(GAMMA);                            % incremento de dist�ncia [m]
    timehistory(i2,:) = [T,V35,DIST+DELTAD,V35*cos(GAMMA),ALT+DELTAH,ROCMS,GAMMA*180/pi,N1,N2];
    if DIST+DELTAD>distmax                                                  % verifica dist�ncia m�xima
    	break
    end
end
%% Par�metros AEO
ParAEO              = [[VR,V35],[XR,X35],[TR,T35]];                         % par�metros da decolagem AEO  

%% DECOLAGEM OEI %%
disp('   ...Calculating the OEI takeoff...');
%% Dist�ncia de decolagem balanceada %%
%     FIND THE BALANCED FIELD LENGTH
%     Find the critical engine failure velocity, Vcrit
%     Set the inital Vcrit guess velocities
TGES1               = 0.25*TR;
TGES2               = 1.00*TR;
%     Solve for engine out takeoff at both guess times and use the
%     bisection method to iterate and converge on Xbrak = XOEI
%     Iterate to converge on Vcrit
for K = 1:50
%     Iterate through two guesses for bisection routine
    for ONETWO      = 1:2
        if (ONETWO == 1)
            TGES    = TGES1;
        else
            TGES    = TGES2;
        end
%% Corrida no solo monomotor %%
%% Corrida no solo de V=0 a V=Vcrit (Falha de motor) %%
        RPARM(1)    = DATARY(2);
        RPARM(2)    = DATARY(3);
        RPARM(3)    = DATARY(4);
        RPARM(4)    = DATARY(6);
        RPARM(5)    = DATARY(8);
        RPARM(6)    = DATARY(10);
        RPARM(7)    = T0;
        RPARM(8)    = T1;
        RPARM(9)    = T2;
        RPARM(10)   = DATARY(12);
        RPARM(11)   = DATARY(1);
        NEQ         = 2;
        Y4(1)       = 0.;
        Y4(2)       = 0.;
        Y4(3)       = 0.;
        Y4(4)       = 0.;
        T           = 0.;
        [Y4, Y3, TGES, DYDX] = ADPTRK('GROUND',T,TGES,Y4,NEQ,RPARM,ERR);
        XCRIT       = Y4(1);
        VCRIT       = Y4(2);
        TCRIT       = TGES;
        D1          = XCRIT;
%% Corrida no solo de V=Vcrit (Falha de motor) a V=VR %%
        RPARM(7)    = T0*DATARY(16);
        RPARM(8)    = T1*DATARY(16);
        RPARM(9)    = T2*DATARY(16);
        TOLD        = TCRIT;
        for I = 1:1000
            T       = TOLD + 0.5;
            Y1OLD   = Y4(1);
            Y2OLD   = Y4(2);
            [Y4 Y3 T DYDX] = ADPTRK('GROUND',TOLD,T,Y4,NEQ,RPARM,ERR);
            if (Y4(2) >= VR)
                TEMP1 = LINTRP(VR,Y2OLD,Y4(2),Y1OLD,Y4(1));
                TEMP2 = VR;
                TEMP3 = LINTRP(VR,Y2OLD,Y4(2),TOLD,T);
                T   = TEMP3;
                break
            end
            TOLD    = T;
        end
        TRM         = T;
        XRM         = Y4(1);
        VRM         = Y4(2);
        D2          = XRM-XCRIT;
%% Corrida no solo de V=VR a V=VLO (Rota��o OEI) %%
        Y4(1)       = XRM;
        Y4(2)       = VRM;
        T           = TRM;
        TOUT        = T + DATARY(24);
        [Y4, Y3, TOUT, DYDX] = ADPTRK('GROUND',T,TOUT,Y4,NEQ,RPARM,ERR);
        TLOM        = TOUT;
        XLOM        = Y4(1);
        VLOM        = Y4(2);
        D3          = XLOM-XRM;
%% Flare OEI %%
        NEQ         = 4;
        Y4(3)       = 0.;
        Y4(4)       = 0.;
        RPARM(4)    = DATARY(7);
        RPARM(5)    = DATARY(9);
        for I = 1:1000
            TOLD    = T;
            T       = T + .5;
            Y1OLD   = Y4(1);
            Y3OLD   = Y4(3);
            [Y4 Y3 T DYDX] = ADPTRK('AIR',TOLD,T,Y4,NEQ,RPARM,ERR);
            if (Y4(3) >= DATARY(15))
                XDIF = LINTRP(DATARY(15),Y3OLD,Y4(3),Y1OLD,Y4(1));
                TOBSM = LINTRP(DATARY(15),Y3OLD,Y4(3),TOLD,TOUT);
                VHOEI = LINTRP(DATARY(15),Y3OLD,Y4(3),Y2OLD,Y4(2));
                VVOEI = LINTRP(DATARY(15),Y3OLD,Y4(3),Y4OLD,Y4(4));
                break
            end
        end
        VOBS        = sqrt(VHOEI^2+VVOEI^2);
        TODM        = XDIF;
        D4          = TODM-XLOM;
%% Frenagem OEI %%
%% Corrida no solo de V=Vcrit a V=V1 (Velocidade de decis�o) %%
        NEQ         = 2;
        RPARM(4)    = DATARY(6);
        RPARM(5)    = DATARY(8);
        Y4(1)       = XCRIT;
        Y4(2)       = VCRIT;
        T           = TCRIT;
        TDESC       = T + DATARY(14);
        [Y4 Y3 T DYDX] = ADPTRK('GROUND',T,TDESC,Y4,NEQ,RPARM,ERR);
        for I = 1:1000
            TOLD    = T;
            T       = T + .5;
            Y1OLD   = Y4(1);
            Y2OLD   = Y4(2);
            [Y4 Y3 T DYDX] = ADPTRK('GROUND',TOLD,T,Y4,NEQ,RPARM,ERR);
            if (T >= TDESC)
                Y4(1) = LINTRP(TDESC,TOLD,T,Y1OLD,Y4(1));
                Y4(2) = LINTRP(TDESC,TOLD,T,Y2OLD,Y4(2));
                break
            end
        end
        XDESC       = Y4(1);
        VDESC       = Y4(2);
        D5          = XDESC-XCRIT;
%% Frenagem de V=V1 a V=0 %%
% Assume-se tra��o igual a 0. e coeficiente de atrito igual ao de frenagem
        RPARM(7)    = 0.;
        RPARM(8)    = 0.;
        RPARM(9)    = 0.;
        RPARM(6)    = DATARY(11);
        T           = TGES + DATARY(14);
        T           = TDESC;
        for I = 1:1000
            TOLD    = T;
            T       = T + .5;
            Y1OLD   = Y4(1);
            Y2OLD   = Y4(2);
            [Y4 Y3 T DYDX] = ADPTRK('GROUND',TOLD,T,Y4,NEQ,RPARM,ERR);
            if (Y4(2) <= 0.)
                Y4(1) = LINTRP(0.,Y2OLD,Y4(2),Y1OLD,Y4(1));
                TFL = LINTRP(0.,Y2OLD,Y4(2),TOLD,T);
                break
            end
        end
        ASDM        = Y4(1);
        D6          = ASDM-XDESC;
%% Verifica��o TODM x ASDM %%
        if (ONETWO == 1) 
            XDIF1   = TODM-ASDM;
        else
            XDIF2   = TODM-ASDM;
        end
    end
    KX              = min(TODM,ASDM)/max(TODM,ASDM);
    K3              = max(0.8,KX);
    saidateste(K,:) = [K TODM ASDM KX XDIF1 XDIF2 TGES TGES1 TGES2];
    if (abs(XDIF2)<= 1 || KX>0.99)
        BFL         = max(TODM,ASDM);
        break
    else
        BFL         = 0;
        TEMP1       = K3*LINTRP(0.,XDIF1,XDIF2,TGES1,TGES2);
        TEMP2       = LINTRP(0.,XDIF1,XDIF2,TGES1,TGES2);
    end
    TGES1           = TEMP1;
	TGES2           = TEMP2;
end

if (K == 50) 
	s               = 'BFL CALCULATION DID NOT CONVERGE!';
    BFLstatus       = 1;
else
	BFLstatus       = 0;
end
%% Par�metros OEI
ParOEI              = [[VCRIT VDESC VRM VLOM VOBS V2] [XCRIT XDESC XRM XLOM BFL] TCRIT TDESC TRM TLOM TOBSM];


%% SA�DA DOS DADOS %% 
if BFLstatus == 1;
    ParAEO          = 9999999;
    ParOEI          = 9999999;
    timehistory     = 9999999;
end

%% TRAJET�RIA PARA DEBUG
% figure()
% plot(timehistory(:,3),timehistory(:,5),'-b');
% grid on


%% FINAL DA ROTINA %%
end




%% DESCRI��O E AUTORIA %%
%QINTERP  - Rotina para determina��o dos coeficientes de tra��o para interpola��o
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   V           - vetor com as velocidades [m/s]
%                   T           - vetor com as velocidades [N]
%Dados de saida  : 
%                   [T0 T1 T2]  - coeficientes de interpola��o da tra��o
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.

%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -

%% NOMENCLATURA ADOTADA NO C�LCULO %%
%

%% DECLARA��O DA FUN��O %%
function [T0 T1 T2] = QINTRP(V,T)

%% CORPO DA FUN��O
A                   = T(1);
B                   = (T(2) - T(1))/(V(2)-V(1));
C                   = ((T(3)-T(2))/(V(3)-V(2))-(T(2)-T(1))/(V(2)-V(1)))/(V(3)-V(1));
T0                  = T(1) - B*V(1) + C*V(1)*V(2);
T1                  = B - C*(V(1)+V(2));
T2                  = C;

%% FINAL DA ROTINA %%
end




%% DESCRI��O E AUTORIA %%
%LINTRP   - Rotina para interpola��o linear
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   XIN         - valor desejado para a vari�vel de entrada
%                   X1          - valor inferior para a vari�vel de entrada
%                   X2          - valor superior para a vari�vel de entrada
%                   Y1          - valor inferior para a vari�vel de sa�da
%                   Y2          - valor superior para a vari�vel de sa�da
%Dados de saida  : 
%                   YIN         - valor desejado para a vari�vel de sa�da
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.

%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -

%% NOMENCLATURA ADOTADA NO C�LCULO %%
%

%% DECLARA��O DA FUN��O %%
function [YIN] = LINTRP(XIN,X1,X2,Y1,Y2)

%% CORPO DA FUN��O %%
YIN                 = Y1 + ((Y2-Y1)/(X2-X1))*(XIN-X1);

%% FINAL DA FUN��O %%
end




%% semiadaptive differential equation solve %%
function [Y4 Y3 XOUT DYDX] = ADPTRK(F,X,XOUT,Y4,NEQ,RPARM,ERR)
%     Save the initial conditions otherwise if APERR is .GT. ERR the
%     initial conditions end up being run through twice
for I = 1:NEQ
    TEMPY(I)        = Y4(I);
end
%     Ensure that the user input error tolerance is positive
      ERR           = abs(ERR);
%     Get an initial a posteriori error estimate (APERR)
%      CALL RK34 (F,X,XOUT,TEMPY,Y3,DYDX,NEQ,IPARM,RPARM,APERR)
[XOUT Y4 Y3 DYDX APERR] = feval('RK34',F,X,XOUT,TEMPY,NEQ,RPARM,ERR);
%     Decide whether error is too large and find new step size if it is
if (APERR > ERR)
         H          = (XOUT - X)/single(floor(sqrt(sqrt(APERR/ERR)))+1);
         N          = floor(sqrt(sqrt(APERR/ERR)))+1;
        for I = 1:N
            XEND    = X+ H;
%            CALL RK34(F,X,XEND,Y4,Y3,DYDX,NEQ,IPARM,RPARM,APERR)
            [XEND Y4 Y3 DYDX APERR] = feval('RK34',F,X,XEND,TEMPY,NEQ,RPARM,APERR);
            X       = XEND;
            TEMPY   = Y4;
        end
%else
%        for I = 1:NEQ
%            Y4(I) = TEMPY(I);
%        end
end
end

%% Runge-Kutta
function [XOUT Y4 Y3 DYDX ERR] = RK34(F, X, XOUT, Y4, NEQ, RPARM, ERR)

      H             = XOUT - X;                                                         %Calculate the step size
      H2            = .5*H;                                                            %Calculate H/2
%     Calculate the K values for the functions K(Jth eqn,#of K)
%     Find K1
      [DYDX]        = feval(F,X,Y4,RPARM);
      for J = 1:NEQ
         K(J,1)     = DYDX(J);
      end
%     Find K2
      for J = 1:NEQ;
         TEMPY(J)   = Y4(J) + H2*K(J,1);
      end
      TEMPX         = X + H2;
      [DYDX]        = feval(F,TEMPX,TEMPY,RPARM);
      for J = 1:NEQ
         K(J,2)     = DYDX(J);
      end
%     Find K3
      for J = 1:NEQ
         TEMPY(J)   = Y4(J) + .75*H*K(J,2);
      end
      TEMPX         = X + .75*H;
      [DYDX]        = feval(F,TEMPX,TEMPY,RPARM);
      for J = 1:NEQ
         K(J,3)     = DYDX(J);
      end
%     Find K4
      for J = 1:NEQ
         TEMPY(J)   = Y4(J) + H2*K(J,2);
      end
      TEMPX         = X + H2;
      [DYDX]        = feval(F,TEMPX,TEMPY,RPARM);
      for J = 1:NEQ
         K(J,4)     = DYDX(J);
      end
%     Find K5
      for J = 1:NEQ
         TEMPY(J)   = Y4(J) + H*K(J,4);
      end
      TEMPX         = X + H;
      [DYDX]        = feval(F,TEMPX,TEMPY,RPARM);
      for J = 1:NEQ
         K(J,5)     = DYDX(J);
      end
%     Calculate the function values at XOUT by RK3
      for J = 1:NEQ
         Y3(J)      = Y4(J) + H*(2.*K(J,1) + 3.*K(J,2) + 4.*K(J,3))/9.;
      end
%     Calculate the function values at XOUT by RK4
      for J = 1:NEQ
         Y4(J)      = Y4(J) + H*(K(J,1) + 2.*K(J,2) + 2.*K(J,4)+ K(J,5))/6.;
      end
%     Calculate the MAX a posteriori error estimate for RK3
%     Since Y values for RK4 are output, this is the worst case error
      ERR           = 0.;
      for J = 1:NEQ
         TEMPX      = abs(Y4(J) - Y3(J));
         if (TEMPX > ERR) 
            ERR     = TEMPX;
         end
      end
end
      
      
      
      
%% DESCRI��O E AUTORIA %%
%GROUND   - Rotina para c�lculo da velocidade e da (des)acelera��o no solo
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   X           -
%                   Y           -
%                   RPARM       -
%Dados de saida  : 
%                   DYDX        - 
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.

%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -

%% NOMENCLATURA ADOTADA NO C�LCULO %%
%

%% DECLARA��O DA FUN��O %%
function [DYDX] = GROUND(X,Y,RPARM)

%% CORPO DA FUN��O 
%% C�lculos iniciais
CONST               = cos(RPARM(10)) + RPARM(6)*sin(RPARM(10));
K0                  = RPARM(7)*CONST - RPARM(6)*RPARM(2);
K1                  = RPARM(8)*CONST;
K2                  = RPARM(9)*CONST + .5*RPARM(1)*RPARM(3)*(RPARM(6)*RPARM(4) - RPARM(5));
%% C�lculo das derivadas
DYDX(1)             = Y(2);
DYDX(2)             = RPARM(11)/RPARM(2)*(K0+K1*Y(2)+K2*Y(2)*Y(2));

%% FINAL DA FUN��O %%
end




%% Dist�ncia no ar %%
%function [DYDX]=AIR(X,Y,RPARM)
%     These are the equations for CLIMB segment
%IPARM(1) = 0;
%DUMMY = X;
%     Equations are of the form:  du/dt = g/W*[k11+k12*V+k13*V*V]
%                                 dv/dt = g/W*[k21+k22*V+k23*V*V]
%     where, V = sqrt (u*u + v*v) and tan gamma = v/u
%GAMMA = atan(Y(4)/Y(2));
%VSQR = Y(4)*Y(4) + Y(2)*Y(2);
%TNET = RPARM(7)+RPARM(8)*sqrt(VSQR)+RPARM(9)*VSQR;
%GAMMA = atan(TNET/RPARM(2)-RPARM(5)/RPARM(4));
%%K11 = RPARM(7)*cos(RPARM(10) + GAMMA);
%%K12 = RPARM(8)*cos(RPARM(10) + GAMMA);
%%K13 = RPARM(9)*cos(RPARM(10) + GAMMA) - .5*RPARM(1)*RPARM(3)*(RPARM(5)*cos(GAMMA)+RPARM(4)*sin(GAMMA));
%%K21 = RPARM(7)*sin(RPARM(10) + GAMMA) - RPARM(2);
%%K22 = RPARM(8)*sin(RPARM(10) + GAMMA);
%%K23 = RPARM(9)*sin(RPARM(10) + GAMMA) + .5*RPARM(1)*RPARM(3)*(RPARM(4)*cos(GAMMA)-RPARM(5)*sin(GAMMA));
%%DYDX(1) = Y(2);
%DYDX(1) = sqrt(VSQR)*cos(GAMMA);
%%DYDX(2) = (RPARM(11)/RPARM(2))*(K11 + K12*sqrt(VSQR) + K13*VSQR);
%DRAG = 0.5*RPARM(1)*VSQR*RPARM(3)*RPARM(5);
%LIFT = 0.5*RPARM(1)*VSQR*RPARM(3)*RPARM(4);
%DYDX(2) = RPARM(11)/RPARM(2)*(TNET-DRAG-RPARM(2)*sin(GAMMA));
%%DYDX(3) = Y(4);
%DYDX(3) = sqrt(VSQR)*sin(GAMMA);
%%DYDX(4) = (RPARM(11)/RPARM(2))*(K21 + K22*sqrt(VSQR) + K23*VSQR);     
%DYDX(4) = RPARM(11)/RPARM(2)*(LIFT-RPARM(2)*cos(GAMMA));

function [DYDX] = AIR(X,Y,RPARM)
%     These are the equations for CLIMB segment
      IPARM(1)      = 0;
      DUMMY         = X;
%     Equations are of the form:  du/dt = g/W*[k11+k12*V+k13*V*V]
%                                 dv/dt = g/W*[k21+k22*V+k23*V*V]
%     where, V = sqrt (u*u + v*v) and tan gamma = v/u
      GAMMA         = atan(Y(4)/Y(2));
      VSQR          = Y(4)*Y(4) + Y(2)*Y(2);
      K11           = RPARM(7)*cos(RPARM(10) + GAMMA);
      K12           = RPARM(8)*cos(RPARM(10) + GAMMA);
      K13           = RPARM(9)*cos(RPARM(10) + GAMMA) - .5*RPARM(1)*RPARM(3)*(RPARM(5)*cos(GAMMA)+RPARM(4)*sin(GAMMA));
      K21           = RPARM(7)*sin(RPARM(10) + GAMMA) - RPARM(2);
      K22           = RPARM(8)*sin(RPARM(10) + GAMMA);
      K23           = RPARM(9)*sin(RPARM(10) + GAMMA) + .5*RPARM(1)*RPARM(3)*(RPARM(4)*cos(GAMMA)-RPARM(5)*sin(GAMMA));
      DYDX(1)       = Y(2);
      DYDX(2)       = (RPARM(11)/RPARM(2))*(K11 + K12*sqrt(VSQR) + K13*VSQR);
      DYDX(3)       = Y(4);
      DYDX(4)       = (RPARM(11)/RPARM(2))*(K21 + K22*sqrt(VSQR) + K23*VSQR);     
end

%% DESCRI��O E AUTORIA %%
%AIR2     - Rotina para c�lculo do flare AEO
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   X           -
%                   Y           -
%                   RPARM       -
%Dados de saida  : 
%                   DYDX        - 
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.

%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -

%% NOMENCLATURA ADOTADA NO C�LCULO %%
%

%% DECLARA��O DA FUN��O %%
function [DYDX] = AIR2(X,Y,RPARM,ENGPAR,NEng)


%% VARI�VEIS GLOBAIS
%global var

%% CORPO DA FUN��O %%
%% C�lculos iniciais 
VSQR                = Y(4)*Y(4) + Y(2)*Y(2);                                % velocidade resultante [m/s]
GAMMA               = Y(5);                                                 % �ngulo inicial da trajet�ria [rad]
ALTHP               = Y(3)/0.3048;                                          % altitude [ft]
atm                 = atmosfera(ALTHP,0);                                   % par�metros da atmosfera
a                   = atm(7);                                               % velocidade do som [m/s]
VMACH               = sqrt(VSQR)/(a);                                       % n�mero de Mach
%% Determina��o da Tra��o %%
[FN,FF]             = motor(ALTHP,VMACH,ENGPAR(1),ENGPAR(2),ENGPAR(3),1.0,ENGPAR(5),ENGPAR(8));
TNET                = NEng*FN;                                          % tra��o total [N]
%% C�lculo das for�as aerodin�micas
DRAG                = 0.5*RPARM(1)*VSQR*RPARM(3)*RPARM(5);                  % arrasto [N]
LIFT                = 0.5*RPARM(1)*VSQR*RPARM(3)*RPARM(4);                  % sustenta��o [N]
%% C�lculo das derivadas
DYDX(1)             = sqrt(VSQR)*cos(GAMMA);                                % velocidade horizontal [m/s]
DYDX(2)             = RPARM(11)/RPARM(2)*(TNET-DRAG-RPARM(2)*sin(GAMMA))*cos(GAMMA)-RPARM(11)*(1.30-cos(GAMMA))*sin(GAMMA);
DYDX(3)             = sqrt(VSQR)*sin(GAMMA);                                % velocidade vertical [m/s]
DYDX(4)             = RPARM(11)*(1.30-cos(GAMMA))*cos(GAMMA)+RPARM(11)/RPARM(2)*(TNET-DRAG-RPARM(2)*sin(GAMMA))*sin(GAMMA);
DYDX(5)             = (RPARM(11)/sqrt(VSQR))*(1.30-cos(GAMMA));             % varia��o do �ngulo de subida [rad/s]

%% FINAL DA FUN��O %%
end