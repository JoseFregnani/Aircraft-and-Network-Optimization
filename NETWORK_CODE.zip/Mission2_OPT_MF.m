% clc
% clear all
% close all

% LOAD PRECALCULATION PARAMETERS

[wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2]=LOADDATA();

% *******  load neural networks  **********
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');
%
tic

% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% OPERATIONS PARAMETERS

HOLDTIME=30;
RCMIN=300;
BUFFMARGIN=1.3;
MINCRZTIME=3;
ct=25; % $/min
cf=1;  % $/kg
RPKM=0.05;% $ Ticket Price /(PAX*km)
TAXITIME=15;
TAXIFF=10;
TAXIFUEL=200;
EXTRA=0;
CONTPCT=0.1;
THOLD=30;
%
HDG=0;
HDG_ALT=0;
ORIGALT=0;
DESTALT=0;
ALTELEV=0;
ALTDIST=200;
ISADEV=0;% 
CLBCAS=280;

% CLBMACH=0.78;
% CRZMACH=0.78;
% CRZCAS=310;
% DESCAS=280;
% DESMACH=0.78;
% CLBCAS_ALT=250;
% CLBMACH_ALT=0.74;
% CRZMACH_ALT=0.74;
% CRZCAS_ALT=270;
% DESCAS_ALT=250;
% DESMACH_ALT=0.72;
% DISTTOT=1000;
% x
CLBCAS=X1;
CLBMACH=X2;
CRZMACH=X3;
CRZCAS=X4;
DESCAS=X5;
DESMACH=X6;
CLBCAS_ALT=X7;
CLBMACH_ALT=X8;
CRZMACH_ALT=X9;
CRZCAS_ALT=X10;
DESCAS_ALT=X11;
DESMACH_ALT=X12;
DISTTOT=X13;

% OPERATIONAL LIMITS

MAXPAX=78;
ceiling=41000;
MMO=0.82;
VMO=340;
MTOWS=37500;
MLW=34000;
MZFW=31500;
MAXFUEL=9400;
MAXCERTALT=41000;
MTOWP=37500;
BOW=18000;
MAXPAYLOAD=MZFW-BOW;

% LOADING DATA => APPLICABLE TO CALCULATION TYPE=0
LF=1;
CGO=0;
%
PAXWT=110;
NPAX=round(LF*MAXPAX);
PAXWTMAX=MAXPAX*PAXWT;
PAYLOAD=CGO+NPAX*PAXWT;

%******************************************************************************************************
% CALCULATION LOOP
%******************************************************************************************************

typecalc=0; % CALCULATION TYPE:  0=GIVEN PAYLOAD or 1=MTOW LIMITED (Structural,Peroformance,MZFW or MLW) 
int=1;

if typecalc==1; 
   % TOW LIMIT
    fprintf('\n ** CALCULATION TYPE: TOW LIMIT **');
    fprintf('\n ');
   if MTOWP<MTOWS 
     TOW=MTOWP;
   else
     TOW=MTOWS;
   end
   
else
   % GIVEN PAYLOAD 
   fprintf('\n ** CALCULATION TYPE: PAYLOAD GIVEN **');
   fprintf('\n ');
   if PAYLOAD>MAXPAYLOAD
     PAYLOAD=MAXPAYLOAD;
   end  
   ZFW=BOW+PAYLOAD;
   TOW=ZFW+MAXFUEL;   
   if TOW>MTOWS 
     TOW=MTOWS;
   end
   if TOW>MTOWP 
     TOW=MTOWP;
   end
 end   
 

% CALCULATION LOOP

   f=0;
   TIMETOT=0;
   
   while f==0 
      
         
   % MAX & OPT ALTITUDE CALCULATION
 
   tic
            initalt = ORIGALT;
            hf      = ceiling;
            step    = 100;
            [HMAX,RCRES]=MAXALT(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
                inc_root,inc_kink,inc_tip,Kink_semispan,...
                r0,t_c,phi,X_tcmax,theta,epsilon,...
                Ycmax,YCtcmax,X_Ycmax,...
                n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,step,hf,...
                CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
            %
                [HOPT,SRMAX]=optalt(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
                inc_root,inc_kink,inc_tip,Kink_semispan,...
                r0,t_c,phi,X_tcmax,theta,epsilon,...
                Ycmax,YCtcmax,X_Ycmax,...
                n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW,initalt,hf,step,...
                CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

            % MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK

            g_sub=4/1000;
            g_des=3/1000;
            K1=g_sub+g_des;
            Dmin=10*CRZMACH*MINCRZTIME;
            K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
            HMAX2=K2/K1;

            if HMAX2>ceiling
              HMAX2=ceiling;
            end
            if HMAX>HMAX2
               HMAX=HMAX2;
            end
            if HOPT<HMAX
                finalalt=HOPT;
            else
                finalalt=HMAX;
            end   

            % NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 

            finalalt= 1000*(fix (finalalt/1000));
            FL=finalalt/100;

            ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
            EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
            if and(HDG>0,HDG<=180)
                C=ismember([FL],[ODDFL]);
                if C==0
                    finalalt=finalalt+1000;
                    if finalalt>=HMAX
                        finalalt=finalalt-2000;
                    end    
                end
            elseif and(HDG>180,HDG<=360)
                C=ismember([FL],[EVENFL]);
                if C==0
                    finalalt=finalalt+1000;
                    if finalalt>=HMAX
                        finalalt=finalalt-2000;
                    end 
                end
            end    
            
fprintf('\n * ALT ');
toc           
TIMETOT=TIMETOT+toc;

            % CLIMB CALCULATION
tic
            maneted=0.95;
            initalt=ORIGALT+1500;
            [dclb,tclb,fclb,hf]=CALC_CLB_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
                n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
                inc_root,inc_kink,inc_tip,Kink_semispan,...
                r0,t_c,phi,X_tcmax,theta,epsilon,...
                Ycmax,YCtcmax,X_Ycmax,...
                TOW,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);

fprintf('\n * CLB ');
toc
TIMETOT=TIMETOT+toc;

            % CRUISE & DESCENT ALGORITHM 
tic           
            WTOC=TOW-fclb;
            INITCRZALT=finalalt;
            h=INITCRZALT;
            K=0;
            dcrz=DISTTOT-dclb-K;
            flag=1;
           
            while flag==1

                % CRUISE

                [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
                [TR, PR, DR, a] = atmos(h,ISADEV);

                if h<=10000
                    M=CAS2MACH(250,PR);
                end
                if and(h>10000,h<=TA)
                    M=CAS2MACH(CRZCAS,PR);
                end
                if h>TA
                    M=CRZMACH;
                end

               [tcrz,fcrz,mancrz]=CALC_CRZ(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
                                  inc_root,inc_kink,inc_tip,Kink_semispan,...
                                  r0,t_c,phi,X_tcmax,theta,epsilon,...
                                  Ycmax,YCtcmax,X_Ycmax,n,ebypass,ediam,efanpr,eopr,eTIT,...
                                  WTOC,h,M,dcrz,ISADEV,NNind,NNwav,NNcd0,NNCL);
               %
                WTOD=WTOC-fcrz;
                FINALCRZALT=h;
                
fprintf('\n * CRZ ');
toc
TIMETOT=TIMETOT+toc;

                % DESCENT
                
tic                
                FINALCRZALT=INITCRZALT;
                initalt=FINALCRZALT;
                finalalt=DESTALT+1500;
                maneted=0.55;
                %
               [ddes,tdes,fdes]=CALC_DES_REV07(wS,wAR,wTR,Airp_SWET,wingSwet,wSweepLE,...
                     inc_root,inc_kink,inc_tip,Kink_semispan,...
                    r0,t_c,phi,X_tcmax,theta,epsilon,...
                    Ycmax,YCtcmax,X_Ycmax,...
                    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
                    WTOD,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,NNind,NNwav,NNcd0,NNCL);
            
                dTOT=dclb+dcrz+ddes;
                e=abs(DISTTOT-dTOT);
                if e<=0.5;
                   flag=0;
                else   
                   dcrz=dcrz-e; 
                end    
            end

            %
            CRZALT=FINALCRZALT;
            Wf = fclb+fdes+fcrz;
            T = tclb+tdes+tcrz;
            D = dclb+ddes+dcrz;
            DOC=ct*T+cf*Wf;
            LW=TOW-Wf;
            
fprintf('\n * DES ');
toc
TIMETOT=TIMETOT+toc;

tic 
%         RESF=RES(LW,ALTDIST,HOLDTIME);% SIMPLIFIED METHOD

          RESF=RES2(LW,DESTALT,ISADEV,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
                container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
                inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
                r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
                Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
                xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2,...
                ALTDIST,ALTELEV,CLBCAS_ALT,CLBMACH_ALT,CRZCAS_ALT,CRZMACH_ALT,DESCAS_ALT,DESMACH_ALT,HDG_ALT,...
                ceiling,HOLDTIME,RCMIN,BUFFMARGIN,MINCRZTIME);

fprintf('\n * RES ');
toc          
TIMETOT=TIMETOT+toc;
tic
            CONT=CONTPCT*Wf;
            F=RESF+CONT
            ZFW=LW-F;
            TOF=Wf+F;
            TAXIFUEL=TAXITIME*TAXIFF;
            FOB=TOF+TAXIFUEL;
                                 
            % TOW LIMIT CHECK
            
            if PAYLOAD>PAXWTMAX
               PAXLOAD=PAXWTMAX;
               CGOWT=PAYLOAD-PAXLOAD;
            else
               PAXLOAD=PAYLOAD;
               CGOWT=0;
            end
    
            PAX=round(PAXLOAD/PAXWT);
%           COSTF=DOC/(1.852*D*PAX);
            COSTF=DOC/(1.852*D*PAX);
            delta1=0;
            delta2=0;
            delta3=0;
            delta=0;
            flw=1;
            fzf=1;
            ffc=1;
          
             if LW>MLW
                flw=0;
                delta1=LW-MLW;        
             end
             if ZFW>MZFW
                fzf=0;
                delta2=ZFW-MZFW;
             end
             if TOF>MAXFUEL
                ffc=0;
                delta3=TOF-MAXFUEL;                
             end;   
     
             f=flw*fzf*ffc;
             if f==0
               A=[delta1 delta2 delta3];  
               delta=max(A);
               fprintf('\n WT_ADJ = %5.0f',delta);
               fprintf('\n');
               TOW=TOW-delta;               
             end 
             if delta<100
               f=1;
             end
             
    TIMETOT=TIMETOT+toc;         
             
   end

 
fprintf('\n * CALCULATION TIME= %5.2f',TIMETOT);       

% OUTPUT

fprintf('\n');
fprintf('\n * LOADING DATA *');
fprintf('\n => TOW  = %5.0f',TOW);
fprintf('\n    MTOWP= %5.0f',MTOWP);
fprintf('\n => TOF  = %5.0f',TOF);
fprintf('\n    MFUEL= %5.0f',MAXFUEL);
fprintf('\n => LW   = %5.0f',LW);
fprintf('\n    MLW  = %5.0f',MLW);
fprintf('\n => ZFW  = %5.0f',ZFW);
fprintf('\n    MZFW = %5.0f',MZFW);
fprintf('\n => BOW  = %5.0f',BOW);
fprintf('\n => PLD  = %5.0f',PAYLOAD);
fprintf('\n => PAXWT= %5.0f',PAXLOAD);
fprintf('\n => PAX  = %5.0f',PAX);
fprintf('\n => CGOWT= %5.0f',CGOWT);
fprintf('\n');
fprintf('\n * FUEL DATA *');
fprintf('\n => TRIPFUEL = %5.0f',Wf);
fprintf('\n => RESFUEL  = %5.0f',RESF);
fprintf('\n => CONT     = %5.0f',CONT);
fprintf('\n => TOF      = %5.0f',TOF);
fprintf('\n => TAXIFUEL = %5.0f',TAXIFUEL);
fprintf('\n => FOB      = %5.0f',FOB);
fprintf('\n');
fprintf('\n * TIME DATA *');
fprintf('\n => TRIPTIME = %5.0f',T);
fprintf('\n => HOLDTIME = %5.0f',THOLD);
fprintf('\n => TAXITIME = %5.0f',TAXITIME);
fprintf('\n');
fprintf('\n * TRIP DATA *');
fprintf('\n => CRZALT   = %5.0f',CRZALT);
fprintf('\n => TRIPDIST = %5.0f',D);
fprintf('\n => CLBCAS   = %5.0f',CLBCAS);
fprintf('\n => CLBMach  = %5.3f',CLBMACH);
fprintf('\n => CRZCAS   = %5.0f',CRZCAS);
fprintf('\n => CRZMach  = %5.3f',CRZMACH);
fprintf('\n => DESCAS   = %5.0f',DESCAS);
fprintf('\n => DESMach  = %5.3f',DESMACH);
fprintf('\n => COST/RPK = %6.4f',COSTF);
fprintf('\n');
fprintf('\n * ALTERNATE DATA *');
fprintf('\n => ALTDIST  = %5.0f',ALTDIST);
fprintf('\n => CLBCAS   = %5.0f',CLBCAS_ALT);
fprintf('\n => CLBMach  = %5.3f',CLBMACH_ALT);
fprintf('\n => CRZCAS   = %5.0f',CRZCAS_ALT);
fprintf('\n => CRZMach  = %5.3f',CRZMACH_ALT);
fprintf('\n => DESCAS   = %5.0f',DESCAS_ALT);
fprintf('\n => DESMach  = %5.3f',DESMACH_ALT);

% f(1)=COSTF;
