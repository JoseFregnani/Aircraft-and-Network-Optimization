% function check_ROC()
% clear all
% clc
% wSweep14           = 23.5;
% wS                 = 72.72;
% wTR                = 0.285;
% wAR                = 8.6;
% wTCmed             = (0.145+0.11)/2;
% MTOW=37500;
% W_climb_final = 0.985*MTOW;
% Engine_data(1)     = 1;
% Engine_data(2)     = 5;
% Engine_data(3)     = 1.36;
% Engine_data(4)     = 1.425;
% Engine_data(5)     = 28.5;
% Engine_data(6)     = 1240;
% Ceiling =41000;
% T0=14300;
% FusDiam =3.1;
% MMO=0.82;
% SWET=480;
% 
% TWreq_roc=check_ROC1(wS,wAR,wTR,W_climb_final,MMO,Engine_data,wTCmed,...
%     wSweep14,SWET,Ceiling,T0,MTOW,FusDiam)
% end
function TWreq_roc=check_ROC(wS,wAR,wTR,W_climb_final,MMO,Engine_data,tcmed,...
    wSweep14,SWET,Ceiling,T0,MTOW,FusDiam)
%
N2lbf   = 1/4.448221615;
ft2m    = 1/3.28;
g       = 9.80665;
%
ROC     = 300; % [ft/min]
%
atm=atmosfera(Ceiling,0);
rho = atm(6);
va  = atm(7);
%
PEng    = Engine_data(1); % 1= two underwing engines; 2= two engines at rear fuselage
ebypass = Engine_data(2); % Engine by-pass ratio
ediam   = Engine_data(3); % Fan diameter [m]
efanpr  = Engine_data(4); % Fan pressure ratio
eopr    = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT    = Engine_data(6); % Turbine Inlet Temperature [K]
%
switch PEng 
case 1
    n        = 2;
    nedebasa = 2;
case 2
    n        = 2;
    nedebasa = 0;
case 3
    n        = 3;
    nedebasa = 2;
case 4
    n        = 4;
    nedebasa = 4;        
end
%
W           = W_climb_final;
fatorw      = 0.995*W/MTOW;
[tracioncruisefull,~]=engine_main(Ceiling*ft2m,...
    MMO,efanpr,eopr,ebypass,0.98,ediam,eTIT);
clear fuelflowcr
TW           = n*tracioncruisefull/(W*g);
bw           = sqrt(wS*wAR);
Mach         = MMO;
delta        = 1000;
while delta > 0.001
Machi        = 1;
while abs(Mach-Machi) > 0.005
eosfaviao    = oswaldf(Mach,wAR,wSweep14,wTR,tcmed,nedebasa);
k            = 1/(pi*wAR*eosfaviao);
V            = Mach*va;
cdzero       = cd0torenbeek(Mach,V,wS,bw,wTR,tcmed,FusDiam,Ceiling,SWET,0);
cdw          = 0.001;
cd_cte       = cdzero+cdw;
% lift coeffcient for best rate of climb
cl_best_roc  = (-TW + sqrt((TW)^2 +12*cd_cte*k))/(2*k);
V_best_roc   = sqrt((W*g)/(0.50*rho*wS*cl_best_roc));
Mach         = min(MMO,V_best_roc/va);
Machi        = 0.50*(Mach+Machi);
V_best_roc   = Machi*va;

end
V            = V_best_roc;
CL           = (W*g)/(0.50*rho*(V^2)*wS);
cd_best_roc  = cd_cte + k*(CL^2);
D            = cd_best_roc*0.50*rho*(V^2)*wS;
TWnew        = (ROC*ft2m/(60*V))+D/(W*g);
delta        = abs(TW-TWnew)/TW;
TW           = 0.50*(TWnew+TW);
end
fatort       = tracioncruisefull*N2lbf/T0;
TWreq_roc    = TW/(fatorw*fatort); % cirrect for mass and altitude
end