function [TOnoise SLnoise LDnoise]=Noise_Calculation(HP,DISA,TakeoM,LandM,...
    NEng,SW,bW,SEH,bEH,SEV,bEV,AirplaneCLmaxLandi,AirplaneCLmaxTakeo,...
	K_IND,CD0_Land,BPR,ediam,efanpr,eopr,D0m_max, D0n_max)
%Dados de entrada: 
%                   HP          - altitude do aeroporto [ft]
%                   DISA        - varia��o da temperatura-padr�o ISA [�C]
%                   TakeoM      - peso de decolagem da aeronave [kg]
%                   ACTPAR      - par�metros da aeronave
%                       (1)     - SW = �rea alar [m�]
%                       (2)     - CLMAX = coeficiente de sustenta��o m�ximo
%                       (3)     - CL3P = coeficiente de sustenta��o no solo (3 pontos)
%                       (4)     - CLAIR = coeficiente de sustenta��o no ar
%                       (5)     - CD3P = coeficiente de arrasto no solo (3 pontos)
%                       (6)     - CDAIRGDN = coeficiente de arrasto no ar (trem-de-pouso baixado)
%                       (7)     - CDAIRGUP = coeficiente de arrasto no ar (trem-de-pouso recolhido)
%                   RWYPAR      - par�metros da pista de decolagem
%                       (1)     - coeficiente de atrito de rolamento
%                       (2)     - coeficiente de atrito de frenagem
%                   ENGPAR      - par�metros do motor
%                       (1)     - fanpr = raz�o de press�o no fan
%                       (2)     - opr = raz�o de press�o total do motor
%                       (3)     - bpr = raz�o de deriva��o do motor
%                       (4)     - maneted = percentual da tra��o m�xima (0 a 1)
%                       (5)     - diamfan = di�metro do fan do motor [m]
%                       (6)     - N1 de refer�ncia [rpm]
%                       (7)     - N2 de refer�ncia [rpm]
%                       (8)     - Turbine Inlet Temperature (TIT) [K]
%                   lambda      - �ngulo da tra��o em rela��o � dire��o da velocidade [deg]
%                   K1          - raz�o VR/VS
%                   K2          - raz�o V2/VS
%                   time1       - tempo entre VEF e V1
%                   SH          - altura do osbst�culo no final da pista [ft]
%                   tstep       - intervalo de tempo para integra��o [s]
%                   time2       - tempo entre VLO e VOBS [s]
%                   nmot        - n�mero de motores da aeronave
%                   distmax     - dist�ncia m�xima para gera��o da trajet�ria [m]
%Dados de saida  : 
%                   BFLstatus   - flag de converg�ncia do c�lculo de BFL
%                   PARAEO      - par�metros da decolagem AEO
%                       (1)     - velocidade de rota��o [m/s]
%                       (2)     - velocidade no final do flare [m/s]
%                       (3)     - dist�ncia at� a rota��o [m]
%                       (4)     - dist�ncia no final do flare [m]
%                       (5)     - tempo at� a rota��o [s]
%                       (6)     - tempo at� o final do flare [s]
%                   PAROEI      - par�metros da decolagem OEI
%                   timehistory - trajet�ria de decolagem
%                       (1)     - tempo [s]
%                       (2)     - velocidade [m/s]
%                       (3)     - dist�ncia a partir da partida [m]
%                       (4)     - velocidade horizontal [m/s]
%                       (5)     - altura em rela��o ao solo [m]
%                       (6)     - velocidade vertical [m/s]
%                       (7)     - �ngulo da trajet�ria [deg]
%                   saidateste  - hist�rico da itera��o para c�lculo de BFL
%                       (1)
%                       (2)
%                       (3)
%                       (4)
%                       (5)
%                       (6)
%                       (7)
%                       (8)
%                       (9)
%                       (10)

%% NOMENCLATURA ADOTADA NO C�LCULO %%
%   SW              - �rea alar [m�]
%   CLMAX           - coeficiente de sustenta��o m�ximo
%   CL3P            - coeficiente de sustenta��o no solo (3 pontos)
%   CLAIR           - coeficiente de sustenta��o no ar
%   CD3P            - coeficiente de arrasto no solo (3 pontos)
%   CDAIR           - coeficiente de arrasto no ar
%**************************************************************************
%  Constants
g = 9.8065;
%**************************************************************************
tic
TakeoW   = TakeoM*g; % [N]
LandW    = LandM*g;  % [N]
%TOPAR  = [HP DISA WTO       lambda K1    K2    time1   SH tstep  time2  nmot  distmax];
TOPAR   = [HP,  DISA,  TakeoW, 0,   1.10, 1.20,  3.0,   35, 0.5,   3.0,  NEng,   10000];
%
%LDPAR  = [HP DISA      WLD    SW  bW        CLMAX            CD0        CDL   gamma nmot    CL3P   CD3P murol  mubrk ttrans  g nflare];
LDPAR   = [HP,  DISA, LandW,   SW, bW,  AirplaneCLmaxLandi,  CD0_Land,  K_IND,  -3,    2,    0.30,  0.08, 0.03, 0.30,  1.00,  g, 1.1];
%ACTPAR = [SW        CLMAX          CL3P  CLAIR  CD3P  CDAIRGDN CDAIRGUP];
ACTPAR  = [SW, AirplaneCLmaxTakeo,  0.30, 1.65, 0.0800, 0.1110, 0.0810];
%
%ACTGEO = [SH      bH    SV    bV     SF     bF    deltafTO deltafLD dmtyre    dntyre   nmgear nngear lmgear lngear nmwheel nnwheel fwtype1 fwtype2 fslats fhtype fvtype nslots fmgear fngear hprec disarec];
%ACTGEO = [  1      2     3     4     5      6        7       8        9        10        11     12     13     14     15      16      17       18     19     20      21    22     23     24     25    26 ];
ACTGEO  = [SEH,    bEH,  SEV,  bEV, 21.10, 22.28,  10,      35,       D0m_max, D0n_max,    2,     1,  1.88,   1.21,   2,      2,     1,       0,     1,      1,      1,    2,     1,     1,     0,     0];
%ENGPAR = [fapr   opr  bpr   maneted dfan  N1ref N2ref TIT];
ENGPAR  = [efanpr eopr BPR   1.000   ediam 4952  14950 1410];
%RWYPAR = [murol mubrk];
RWYPAR  = [0.03  0.30];
%NOPAR  = [RH dlatLD dlatSL dlatTO XALD XASL XATO];
NOPAR   = [70 1      450    1      2000   0  6500];
%
%cd Noise
[TOnoise SLnoise LDnoise] = AirplaneNoise(TOPAR,LDPAR,ACTPAR,...
    ACTGEO,ENGPAR,RWYPAR,NOPAR);
%cd ..
toc
end