clc

%LOAD ACFT
X1=rand(1);
X2=rand(1);
X3=rand(1);          
[ACFT,~,~,~,~,~,~,~,~]=LOADDATABANK2b(X1,X2,X3,1);
% LOAD NEURAL NETWORK
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat')

% TEST DATA
ALT=35000;
ISADEV=10;
ORIGALT=2500;
DESTALT=0;
ASDA   =3000;
LDA    =2500;
DEP_TREF =30;
ARR_TREF =32;
ISADEV   =10;
DISTTOT  =400;
HDG      =030;
LW=ACFT.MLW;

[Wf_alt] = ALTERNATEFUEL2(ACFT,NNind,NNwav,NNcd0,NNCL,LW,ORIGALT,DESTALT,ASDA,LDA,DEP_TREF,ARR_TREF,ISADEV,DISTTOT,HDG)

