clc

% Test data
LW=32000;
wS =90;
ISADEV=0;
elev=2500;
CLmax_clean=1.6;

REQUIRED_LANDING_DISTANCE=LD(LW,wS,ISADEV,elev,CLmax_clean)



