%% DESCRI��O E AUTORIA %%
%calcPNLT - Rotina para covers�o de perceived noise level, tone corrected
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   f           - freq��ncias-padr�o
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%Dados de saida  : 
%                   C           - corre��o [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-08-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [Cfin] = calcPNLT(f,SPL)


%% CORPO DA FUN��O %%
%% Defini��o das irregularidades no espectro
%step 1
for i1 = 4:24
    s(i1)           = SPL(i1)-SPL(i1-1);
end
%step 2
for i1=1:3
    dels(i1)        = 0;
end
for i1 = 5:24
    dels(i1)        = abs(s(i1)-s(i1-1));
end
for i1=1:24
    sc(i1)          = 0;
    if dels(i1)>5
        sc(i1)      = 1;
    end
end
%step 3
for i1 = 1:24
    SPLC(i1)        = 0;
    if sc(i1)==1
        if s(i1)>0 && s(i1)>s(i1-1)
            SPLC(i1) = 1;
        end
        if s(i1)<=0 && s(i1-1)>0
            SPLC(i1-1) = 1;
        end
    end
end
%step 4
for i1 = 1:24
    if SPLC(i1)~=1
        SPLl(i1)    = SPL(i1);
    else
        if i1<24
            SPLl(i1) = 0.5*(SPL(i1-1)+SPL(i1+1));
        else
            SPLl(i1) = SPL(i1)+s(i1);
        end
    end
end
%step 5
for i1 = 4:24
    sl(i1)          = SPLl(i1)-SPLl(i1-1);
end
sl(3)               = sl(4);
sl(25)              = sl(24);
%step 6
for i1 = 3:23
    sbar(i1)        = 1/3*(sl(i1)+sl(i1+1)+sl(i1+2));
end
%step 7
SPLll(3)            = SPL(3);
for i1 = 4:24
    SPLll(i1)       = SPLll(i1-1)+sbar(i1-1);
end
%step 8
for i1 = 1:3
    F(i1)           = 0;
end
for i1 = 4:24
    F(i1)           = 0;
    if (SPL(i1)-SPLll(i1))>0
        F(i1)       = SPL(i1)-SPLll(i1);
    end
end

%% Defini��o do valor da corre��o %%
for i1 = 1:24
    C(i1)           = 0;
    if F(i1)>=1.5
        if f(i1)>=50 && f(i1)<500
            if F(i1) >= 1.5 && F(i1) < 3.0
                C(i1) = F(i1)/3-0.5;
            end
            if F(i1) >= 3.0 && F(i1) < 20.0
                C(i1) = F(i1)/6;
            end
            if F(i1) >= 20.0
                C(i1) = 3+1/3;
            end
        end
        if f(i1)>=500 && f(i1)<5000
            if F(i1) >= 1.5 && F(i1) < 3.0
                C(i1) = 2*F(i1)/3-1.0;
            end
            if F(i1) >= 3.0 && F(i1) < 20.0
                C(i1) = F(i1)/3;
            end
            if F(i1) >= 20.0
                C(i1) = 6+2/3;
            end
        end
        if f(i1)>=5000 && f(i1)<10000
            if F(i1) >= 1.5 && F(i1) < 3.0
                C(i1) = F(i1)/3-0.5;
            end
            if F(i1) >= 3.0 && F(i1) < 20.0
                C(i1) = F(i1)/6;
            end
            if F(i1) >= 20.0
                C(i1) = 3+1/3;
            end
        end
    end
end


%% DADOS DE SAIDA %%
Cfin                = max(C);


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T. Aircraft Noise (1989)
%2 - ICAO - Annex 16 - Environmental Protection ()