%% DESCRI��O E AUTORIA %%
%bocal    - Rotina para avalia��o do amortecimento atmosf�rico do ru�do
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   T0          - temperatura ambiente [�C]
%                   HR          - umidade relativa [%]
%                   R           - dist�ncia [m]
%                   f           - frequ�ncias [Hz]
%Dados de saida  : 
%                   ft          - frequ�ncias [Hz]
%                   alfaamort   - 
%                   amorttott   -
%                   amortatmt   -
%                   SPLrt       - 
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-08-09    Vers�o original


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft alfaamortt amorttott amortatmt SPLrt] = amort(T0,HR,R,f)

%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
T                   = T0;                                                   % temperatura para avalia��o da atenua��o [�C]
H                   = HR;                                                   % umidade relativa do ar para avalia��o da atenua��o [%]
radialdistance      = R;                                                    % dist�ncia para avalia��o do ru�do [m]
Terzbandfreq        = f;                                                    % freq��ncias para c�lculo da atenua��o [Hz]

%% Declara��o de constantes %%
deltaamorttab       = [0 0.25 0.5 0.6 0.7 0.8 0.9 1 1.1 1.2 1.3 1.5 1.7 2 2.3 2.5 2.8 3 3.3 3.6 4.15 4.45 4.8 5.25 5.7 6.05 6.5 7];
etaamorttab         = [0 0.315 0.7 0.84 0.93 0.975 0.996 1 0.97 0.9 0.84 0.75 0.67 0.57 0.495 0.45 0.4 0.37 0.33 0.3 0.26 0.245 0.23 0.22 0.21 0.205 0.2 0.2];
f0tab               = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 4500 5600 7100 9000];

%% C�lculo da atenua��o atmosf�rica %%
deltaamort          = sqrt(1010./f0tab)*10^(log10(H)-1.328924+3.179768e-2*(T-273)-2.173716e-4*(T-273)^2+1.7496e-6*(T-273)^3);
etaamort            = interp1(deltaamorttab,etaamorttab,deltaamort,'linear','extrap');
alfaamort           = 10.^(2.05*log10(f0tab/1000)+1.1394e-3*(T-273)-1.916984)+etaamort.*10.^(log10(f0tab)+8.42994e-3*(T-273)-2.755624);
deltaLamort         = alfaamort*radialdistance/100;
amortatm            = interp1(Terzbandfreq,deltaLamort,f,'linear','extrap');

%% C�lculo da atenua��o devido � dist�ncia %%
SPLr                = 20*log10(radialdistance);                             % dB

%% C�lculo da atenua��o total %%
amorttot            = amortatm+SPLr;
% amorttot            = 10*log10(10.^(0.1*amortatm)+10.^(0.1*SPLr));


%% DADOS DE SAIDA %%
ft                  = f';
alfaamortt          = alfaamort';
amorttott           = amorttot';
amortatmt           = amortatm';
SPLrt               = SPLr';


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - Schmid, Michael - Entwickung eines Programmmoduls zur Prognose des L�rms von Strahltriebwerken im Flugzeugvorentwurf (2001)