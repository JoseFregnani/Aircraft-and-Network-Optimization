%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - NETWORK MODULE
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 5.0 / December 2018 - Network optimiztion with 3 aircraft + NPV
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic

clc
close all
clear all

calctype=2;% 1:RANDOM SAMPLE  2:KNOWN SAMPLE 3:BASIC AIRCRAFT
mode=1;% acft seletiom method: PAX:mode=1, RANGE:mode=2
rvar=0;% random distribution of delay: off=0, on=1
NA=3; %Number of Aircraft types
bal=1;% trimmed demand to smaller aircraft: consider=1, disregard=0

% LOAD AIRCRAFT DATA
switch calctype
    case 1 
         X1=rand(1);
         X2=rand(1);
         X3=rand(1);          
         [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3,n1,n2,n3]=LOADDATABANK2b(X1,X2,X3,mode);   
    case 2              
         n1=7;
         n2=16;
         n3=4;
        [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3]=LOADDATABANK3b(n1,n2,n3,mode);  
    case 3
        [ACFT]=LOADDATABANK_BASIC();
        ACFT1=ACFT;
        ACFT2=ACFT;
        ACFT3=ACFT;
        LIM1=130;
        LIM2=130;
        LIM3=130;
        n1=1;
        n2=1;
        n3=1;
end
%
s0=date;
name1=int2str(n1);
name2=int2str(n2);
name3=int2str(n3);
NAME=strcat('NETWORK_',s0,'_',name1,'_',name2,'_',name3,'.txt');
%
LIN=strings(2000,1);
[LIN]=ACFTLIN(ACFT1,ACFT2,ACFT3,LIN,1);
lin=86;
%
RANGE1=ACFT1.RANGE;
RANGE2=ACFT2.RANGE;
RANGE3=ACFT3.RANGE;
NPax1 =round(ACFT1.NPax);
NPax2 =round(ACFT2.NPax);
NPax3 =round(ACFT3.NPax);
MTOW1 =round(ACFT1.MTOW);
MTOW2 =round(ACFT2.MTOW);
MTOW3 =round(ACFT3.MTOW);
wS1 =ACFT1.wS;
wS2 =ACFT2.wS;
wS3 =ACFT3.wS;
wAR1 =ACFT1.wAR;
wAR2 =ACFT2.wAR;
wAR3 =ACFT3.wAR;
ebypass1 =ACFT1.ebypass;
ebypass2 =ACFT2.ebypass;
ebypass3 =ACFT3.ebypass;
ediam1 =ACFT1.ediam;
ediam2 =ACFT2.ediam;
ediam3 =ACFT3.ediam;
Tmax1  =ACFT1.MAXRATE;
Tmax2  =ACFT2.MAXRATE;
Tmax3  =ACFT3.MAXRATE;

% SETUP PARAMETERS
ISADEV=10;         % ISA DEVIATION [oC]
PAXWT=110;         % PASSENGER's WEIGHT [kg]
MAXUTIL=14;        % MAXIMUM DAILY UTILIZATION [h]
TURNAROUND=45;     % TURN AROUND TIME  [min]
AVGTIT=5;          % AVG TAXI IN TIME  [min]
AVGTOT=10;         % AVG TAXI OUT TIME [min]
avg_ticket=150;    % AVERAGE TIKET PRICE [$/pax]
SHARE=0.15;        % LH DOMESTIC MARKET SHARE IN 2017 WAS 10%   
LFREF=0.80;        % REFERENCE LOAD FACTOR  
K1=1.2;            % TOTAL REVENUE TO TICKET REVENUE FACTOR  
K2=1.1;            % TOTAL COST TO DOC FACTOR
ACFT_Mkt_Share=0.6;% ACFT Market Share
IR=0.05;           % Interest rate  
p=15;              % life cycle (years) 
KVA=75;            % Electrical system AC Power
USD2EUR = 0.90;    % DOLLAR TO EURO CONVERSION

% NPV CALCULATION
[NPV1,CASHFLOW1,PV1,IRR1,BE1,Price1]=NPV(ACFT_Mkt_Share,IR,p,MTOW1,wS1,2,Tmax1,ediam1,NPax1,KVA);
[NPV2,CASHFLOW2,PV2,IRR2,BE2,Price2]=NPV(ACFT_Mkt_Share,IR,p,MTOW2,wS2,2,Tmax2,ediam2,NPax1,KVA);
[NPV3,CASHFLOW3,PV3,IRR3,BE3,Price3]=NPV(ACFT_Mkt_Share,IR,p,MTOW3,wS3,2,Tmax3,ediam3,NPax3,KVA);
NPV1=USD2EUR*NPV1;
NPV2=USD2EUR*NPV2;
NPV3=USD2EUR*NPV3;
TOTNPV=NPV1+NPV2+NPV3;
      
% REFERENCE DOC CALCULATION
PAYLOAD1=round(NPax1*PAXWT*LFREF);
PAYLOAD2=round(NPax2*PAXWT*LFREF);
PAYLOAD3=round(NPax3*PAXWT*LFREF);
[~,~,DOC1,CRZMACH1,~,~]=Mission5g(0,0,0,0,0,RANGE1,200,3000,2500,2500,15,15,15,ISADEV,PAYLOAD1,ACFT1,5,10,0,0,0); 
[~,~,DOC2,CRZMACH2,~,~]=Mission5g(0,0,0,0,0,RANGE2,200,3000,2500,2500,15,15,15,ISADEV,PAYLOAD2,ACFT2,5,10,0,0,0);
[~,~,DOC3,CRZMACH3,~,~]=Mission5g(0,0,0,0,0,RANGE3,200,3000,2500,2500,15,15,15,ISADEV,PAYLOAD2,ACFT3,5,10,0,0,0);
DOC1=DOC1*USD2EUR;
DOC2=DOC2*USD2EUR;
DOC3=DOC3*USD2EUR;
%
fprintf('\n ** REFERENCE VALUES FOR NETWORK DESIGN **');
fprintf('\n'); 
fprintf('\n CRZMACH1                 : %5.3f',CRZMACH1);
fprintf('\n CRZMACH2                 : %5.3f',CRZMACH2);
fprintf('\n CRZMACH3                 : %5.3f',CRZMACH3);
fprintf('\n RANGE1 (nm)              : %5.0f',RANGE1);
fprintf('\n RANGE2 (nm)              : %5.0f',RANGE2);
fprintf('\n RANGE3 (nm)              : %5.0f',RANGE3);
fprintf('\n DOC1   ($/nm)            : %5.2f',DOC1);
fprintf('\n DOC2   ($/nm)            : %5.2f',DOC2);
fprintf('\n DOC3   ($/nm)            : %5.2f',DOC3);
fprintf('\n PAX1                     : %5.0f',NPax1);
fprintf('\n PAX2                     : %5.0f',NPax2);
fprintf('\n PAX3                     : %5.0f',NPax3);
fprintf('\n NPV1   (x1E9 $)          : %5.1f',NPV1/1E9);
fprintf('\n NPV2   (x1E9 $)          : %5.1f',NPV2/1E9);
fprintf('\n NPV3   (x1E9 $)          : %5.1f',NPV3/1E9);
fprintf('\n Price1 (x1E6 $)          : %5.1f',Price1/1E6);
fprintf('\n Price2 (x1E6 $)          : %5.1f',Price2/1E6);
fprintf('\n Price3 (x1E6 $)          : %5.1f',Price3/1E6);
fprintf('\n Average fare ($)         : %5.0f',avg_ticket);
fprintf('\n Average Load Factor (pct): %5.1f',LFREF*100);
fprintf('\n Average Market Share(pct): %5.1f',SHARE*100);
fprintf('\n'); 
%
LIN(lin+1,1)='** REFERENCE VALUES FOR NETWORK DESIGN **';
LIN(lin+2,1)=' '; 
LIN(lin+3,1)=strcat('CRZMACH1                 : ',num2str(CRZMACH1,1));
LIN(lin+4,1)=strcat('CRZMACH2                 : ',num2str(CRZMACH2,2));
LIN(lin+5,1)=strcat('CRZMACH3                 : ',num2str(CRZMACH3,3));
LIN(lin+6,1)=strcat('RANGE1 (nm)              : ',int2str(RANGE1));
LIN(lin+7,1)=strcat('RANGE2 (nm)              : ',int2str(RANGE2));
LIN(lin+8,1)=strcat('RANGE3 (nm)              : ',int2str(RANGE3));
LIN(lin+9,1)=strcat('DOC1   ($/nm)            : ',num2str(DOC1,2));
LIN(lin+10,1)=strcat('DOC2   ($/nm)            : ',num2str(DOC2,2));
LIN(lin+11,1)=strcat('DOC3   ($/nm)            : ',num2str(DOC3,2));
LIN(lin+12,1)=strcat('PAX1                     : ',int2str(NPax1));
LIN(lin+13,1)=strcat('PAX2                     : ',int2str(NPax2));
LIN(lin+14,1)=strcat('PAX3                     : ',int2str(NPax3));
LIN(lin+15,1)=strcat('NPV1   (x1E9 $)          : ',num2str(NPV1/1E9));
LIN(lin+16,1)=strcat('NPV2   (x1E9 $)          : ',num2str(NPV2/1E9));
LIN(lin+17,1)=strcat('NPV3   (x1E9 $)          : ',num2str(NPV3/1E9));
LIN(lin+18,1)=strcat('Price1 (x1E6 $)          : ',num2str(Price1/1E6));
LIN(lin+19,1)=strcat('Price2 (x1E6 $)          : ',num2str(Price2/1E6));
LIN(lin+20,1)=strcat('Price3 (x1E6 $)          : ',num2str(Price3/1E6));
LIN(lin+21,1)=strcat('Average fare ($)         : ',num2str(avg_ticket));
LIN(lin+22,1)=strcat('Average Load Factor (pct): ',num2str(LFREF*100));
LIN(lin+22,1)=strcat('Average Marketshare (pct): ',num2str(SHARE*100));
LIN(lin+23,1)=' '; 
lin=lin+24;

% NETWORK OPTIMIZATION
VPAX=[NPax1 NPax2 NPax3]';
VDOC=[DOC1 DOC2 DOC3]'; 
VRANGE=[RANGE1 RANGE2 RANGE3]';
[Airport,X,FREQ,f,DIST,HDG,NPAR,HUBS]=NETWORKOPT_R04h(VPAX,VDOC,VRANGE,SHARE,LFREF,avg_ticket,K1,K2);
%
LIN(lin,1)='** NETWORK PRE-COMPUTATION **'; 
LIN(lin+1,1)=' '; 
APT='';
n=size(Airport,2);
for i=1:n
    if i<n
      APT=strcat(APT,Airport(i).name,',');
    else
      APT=strcat(APT,Airport(i).name); 
    end  
end
LIN(lin+2,1)=strcat('AIRPORT ARRAY: ',APT);
LIN(lin+3,1)=' ';
lin=lin+4;
%
LIN(lin,1)='* DAILY DEMAND *';  
lin=lin+1;
L=NETWORKARRAYS(f);
n=size(L,1);
for i=1:n
   LIN(lin,1)=L(i);
   lin=lin+1;
end
LIN(lin+1,1)='';
lin=lin+2;
%
LIN(lin,1)='* DISTANCES *';  
lin=lin+1;
L=NETWORKARRAYS(DIST);
n=size(L,1);
for i=1:n
   LIN(lin,1)=L(i,1);
   lin=lin+1;
end
LIN(lin+1,1)=' ';
lin=lin+2;
%
LIN(lin,1)='* HEADINGS *';  
lin=lin+1;
[L]=NETWORKARRAYS(HDG');
n=size(L,2);
for i=1:n
   LIN(lin)=L(i,1);
   lin=lin+1;
end
LIN(lin+1,1)=' ';
lin=lin+2;
%
n=size(X,2);
for a=1:NA
    fprintf('\n');   
    switch a
        case 1           
            ACFT=ACFT1;
            NPax=NPax1;
            MTOW=MTOW1;
            ACFTSTR='ACFT#1';
            RANGE=RANGE1;
            POS=n1;
        case 2          
            ACFT=ACFT2;
            NPax=NPax2;
            MTOW=MTOW2; 
            ACFTSTR='ACFT#2';
            RANGE=RANGE2;
            POS=n2;
        case 3            
            ACFT=ACFT3;
            NPax=NPax3;
            MTOW=MTOW3;
            ACFTSTR='ACFT#3';
            RANGE=RANGE3;
            POS=n3;
    end
    %
    fprintf('\n'); 
    fprintf(strcat('** MISSION ANALYSIS ** ',ACFTSTR,'**'));
    fprintf('\n'); 
    fprintf('\n *ACFT DATA*');  
    fprintf('\n DB POS#  : %5.0f',POS);
    fprintf('\n RANGE(nm): %5.0f',RANGE);
    fprintf('\n PAX      : %5.0f',NPax);
    fprintf('\n MTOW     : %5.0f',MTOW);
    fprintf('\n');   
    fprintf('\n *NETWORK DATA*');    
    fprintf('\n Number of Nodes (n)              : %6.0f',NPAR(a,1));
    fprintf('\n Number of Arcs (N)               : %6.0f',NPAR(a,2));
    fprintf('\n Average Degree of Nodes (AVG DON): %6.1f',NPAR(a,3));
    fprintf('\n Average Path Length (L)- nm      : %6.1f',NPAR(a,4));
    fprintf('\n Network Density (ND)             : %6.2f',NPAR(a,5));
    fprintf('\n Average Clustering (AVG C)       : %6.2f',NPAR(a,6));
    fprintf('\n HUBs                             : %s',HUBS(a));
    fprintf('\n');     
    %   
    LIN(lin,1)=' ';
    LIN(lin+1,1)=strcat('**',ACFTSTR,'**'); 
    LIN(lin+2,1)=' ';
    LIN(lin+3,1)='*ACFT DATA*';
    LIN(lin+4,1)=strcat('DB POS#  : ',int2str(POS));
    LIN(lin+5,1)=strcat('RANGE(nm): ',int2str(RANGE));
    LIN(lin+6,1)=strcat('PAX      : ',int2str(NPax));
    LIN(lin+7,1)=strcat('MTOW(kg) : ',int2str(MTOW));
    LIN(lin+8,1)=' ';
    LIN(lin+9,1)='*NETWORK DATA*';
    LIN(lin+10,1)=strcat('Number of Nodes (n)              :',int2str(NPAR(a,1)));
    LIN(lin+11,1)=strcat('Number of Arcs (N)               :',int2str(NPAR(a,2)));
    LIN(lin+12,1)=strcat('Average Degree of Nodes (AVG DON):',num2str(NPAR(a,3)));
    LIN(lin+13,1)=strcat('Average Path Length (L)- nm      :',num2str(NPAR(a,4)));
    LIN(lin+14,1)=strcat('Network Density (ND)             :',num2str(NPAR(a,5)));
    LIN(lin+15,1)=strcat('Average Clustering (AVG C)       :',num2str(NPAR(a,6)));
    LIN(lin+15,1)=strcat('HUBS                             :',HUBS(a));
    LIN(lin+16,1)=' ';
    
    TO_ALLOWANCE=200*MTOW/22000;  % TAKEOFF ALLOWANCE FUEL [kg]
    ARR_ALLOWANCE=100*MTOW/22000; % APPROACH ALLOWANCE FUEL [kg]
    RMK='';
    
    fprintf('\n');    
    fprintf('\n SECTOR  ZFW   FOB  TAXI  TOF   TOW    TRIP  LW    REM   DIST    HDG    ALT  TIME  DOC   RTOW  RLW  CRZM  FREQ PAX LF');
    fprintf('\n         [kg]  [kg] [kg]  [kg]  [kg]   [kg]  [kg]  [kg]  [nm]   [deg]   [FL] [min] [$/nm][kg]  [kg]                [pct]');
    %
    LIN(lin+17,1)=" ";
    LIN(lin+18,1)='SECTOR  ZFW   FOB  TAXI  TOF   TOW    TRIP  LW    REM   DIST    HDG    ALT  TIME  DOC   RTOW  RLW  CRZM  FREQ PAX LF';
    LIN(lin+19,1)='        [kg]  [kg] [kg]  [kg]  [kg]   [kg]  [kg]  [kg]  [nm]   [deg]   [FL] [min] [$/nm][kg]  [kg]                [pct]';
    lin=lin+20;
    %
    for i=1:n       
        for j=1:n
           if i~=j;
               if X(i,j,a)~=0;                
                 DISTANCE=DIST(i,j);
                 [DISTALT]=MINALTDIST(DIST,i);
                 NPAX(i,j,a)=round(LFREF*NPax);
                 %
                 if bal==1  % LOAD REMAINING PAX DEMAND IN THE SMALLEST ACFT LIMITED TO ITS CAPACITY
                     if a==1                         
                        diff=f(i,j)-FREQ(i,j,3)*(LFREF*NPax3)-FREQ(i,j,2)*(LFREF*NPax2);
                        PAX1=round(LFREF*NPax1)*FREQ(i,j,1);
                        if diff>PAX1
                           if diff>=NPax1*FREQ(i,j,1) 
                              NPAX(i,j,a)=NPax1; 
                           else
                              NPAX(i,j,a)=round(diff/FREQ(i,j,1));
                           end   
                        else
                           if diff>0
                             if diff<NPax1
                                NPAX(i,j,a)=diff;
                                FREQ(i,j,a)=1;
                             else   
                                NPAX(i,j,a)=round(diff/FREQ(i,j,1));
                             end   
                           else
                             NPAX(i,j,a)=0;
                             FREQ(i,j,a)=0;
                           end  
                        end                     
                     end                
                 end
                 PAYLOAD=NPAX(i,j,a)*PAXWT;
                 %
                if PAYLOAD>0
                  
                 dep=Airport(i).name;
                 arr=Airport(j).name;
                 sector=string(strcat(dep,'/',arr));   
                 fprintf('\n');                     
                 fprintf('%s ',sector);
                 Origelev=Airport(i).elev;
                 Destelev=Airport(j).elev;
                 Altelev=Airport(i).elev;                
                 ASDA=Airport(i).ASDA;
                 LDA=Airport(j).LDA;
                 ALT_LDA=Airport(i).LDA;
                 DEP_TREF=Airport(i).Reftemp;
                 ARR_TREF=Airport(j).Reftemp;
                 ALT_TREF=Airport(i).Reftemp;               
                 %                                
                 if rvar==1
                   randTIT = -5 + 10*rand(1);  % RANDOM VARIATION FOR TAXI IN TIME (+-5 min )
                   randTOT = -3 + 6*rand(1);   % RANDOM VARIATION FOR TAXI OUT TIME(+-3 min )                  
                 else
                   randTIT=0;
                   randTOT=0;  
                 end   
                 %
                 TIT=randTIT+AVGTIT;
                 TOT=randTOT+AVGTOT;
                 TH=HDG(i,j);
                 THA=HDG(j,i);                  
                 [Wf(i,j,a),T(i,j,a),CF(i,j,a),CRZMACH(i,j,a),PAX_calc,RMK,S]=Mission5g(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ASDA,LDA,ALT_LDA,DEP_TREF,ARR_TREF,ALT_TREF,ISADEV,PAYLOAD,ACFT,TIT,TOT,1,TO_ALLOWANCE,ARR_ALLOWANCE);  
                 if PAX_calc<NPAX(i,j,a);
                    NPAX(i,j,a)=PAX_calc;
                 end    
                 T(i,j,a)=T(i,j,a)+TIT+TOT;
                 Wf(i,j,a)=Wf(i,j,a)+TO_ALLOWANCE+ARR_ALLOWANCE;
                 %
                 fprintf('%3.0f ',FREQ(i,j,a));
                 fprintf('%3.0f ',PAX_calc);
                 fprintf('%5.1f ',(NPAX(i,j,a)/NPax)*100);   
                 fprintf('%s ',RMK);  
                 s1=int2str(FREQ(i,j,a));
                 s2=int2str(PAX_calc);
                 s3=num2str((NPAX(i,j,a)/NPax)*100);
                 LIN(lin)=strcat(sector,',',S,',',s1,',',s2,',',s3);
                 lin=lin+1;  
                end                               
             end
           end 
        end
    end 
     
% TOTAL NETWORK RESULTS  

    TOTCOST(a)=0;
    TOTDIST(a)=0;
    TOTALFREQ(a)=0;
    TOTALPAX(a)=0; 
    TOTTIME(a)=0;
    TOTFUEL(a)=0;
    TOTFLIGHTS(a)=0;
    AVGMACH(a)=0;
    AVGDOC(a)=0;
    NF(a)=0;
    AVA=24.253+0.0009*MTOW; % ARRIVAL DELAY COST [$/min]
    AVD=9.8308+0.0007*MTOW; % DEPARTURE DELAY COST [$/min]    
    
    % CONSOLIDATE DATA 
    for i=1:n
        for j=1:n
            if X(i,j,a)==1
                TOTCOST(a)   =TOTCOST(a)+FREQ(i,j,a)*(DIST(i,j)*CF(i,j,a)+AVD*Airport(i).AVG_DEP_delay+AVA*Airport(j).AVG_ARR_delay);
                TOTDIST(a)   =TOTDIST(a)+FREQ(i,j,a)*DIST(i,j);
                TOTALPAX(a)  =TOTALPAX(a)+FREQ(i,j,a)*round(LFREF*NPAX(i,j,a));
                TOTTIME(a)   =TOTTIME(a)+FREQ(i,j,a)*(T(i,j,a)+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay+TURNAROUND);
                TOTFLIGHTS(a)=TOTFLIGHTS(a)+FREQ(i,j,a);
                TOTFUEL(a)   =TOTFUEL(a)+FREQ(i,j,a)*Wf(i,j,a);
                NF(a)        =NF(a)+FREQ(i,j,a);                
                AVGMACH(a)   =AVGMACH(a)+FREQ(i,j,a)*CRZMACH(i,j,a);
                AVGDOC(a)    =AVGDOC(a)+FREQ(i,j,a)*CF(i,j,a);
            end    
        end    
    end
    %
    AVGMACH(a)=AVGMACH(a)/NF(a);
    AVGDOC(a)=AVGDOC(a)/NF(a);
    COST(a)=K2*TOTCOST(a);
    REV(a)=K1*TOTALPAX(a)*avg_ticket;
    PROFIT(a)=REV(a)-COST(a);
    CASK(a)=COST(a)/(TOTALPAX(a)*TOTDIST(a));
    RASK(a)=REV(a)/(TOTALPAX(a)*TOTDIST(a));
    NP(a)=RASK(a)-CASK(a);               
    NACFT(a)=round(TOTTIME(a)/(MAXUTIL*60));   
    CO2EFF(a)=3.15*TOTFUEL(a)/(TOTALPAX(a)*TOTDIST(a)*1.852);
    %
    fprintf('\n');
    fprintf('\n ** NETWORK RESULTS **');
    fprintf('\n'); 
    fprintf('\n Average Cruise Mach      : %10.3f',AVGMACH(a));
    fprintf('\n TOTAL FUEL (kg)          : %10.2f',TOTFUEL(a));
    fprintf('\n TOTAL CO2  (kg)          : %10.2f',TOTFUEL(a)*3.15);
    fprintf('\n CO2 EFF(kg/PAX.km)       : %6.4E',CO2EFF(a));
    fprintf('\n TOTAL DIST (nm)          : %10.2f',TOTDIST(a));
    fprintf('\n TOTAL PAX                : %10.0f',TOTALPAX(a));
    fprintf('\n TOTAL COST    ($)        : %10.2f',COST(a));
    fprintf('\n TOTAL REVENUE ($)        : %10.2f',REV(a));
    fprintf('\n TOTAL PROFIT  ($)        : %10.2f',PROFIT(a));
    fprintf('\n MARGIN        (pct)      : %10.2f',100*PROFIT(a)/COST(a)); 
    fprintf('\n AVG DOC ($/nm)           : %6.2E',AVGDOC(a));
    fprintf('\n NRASK ($/pax.nm)         : %6.4E',RASK(a));
    fprintf('\n NCASK ($/pax.nm)         : %6.4E',CASK(a));
    fprintf('\n NP    ($/pax.nm)         : %6.4E',NP(a));
    fprintf('\n NUM OF FREQUENCIES       : %4.0f',NF(a));
    fprintf('\n NUM OF ACFT              : %3.0f',NACFT(a));
    fprintf('\n SECTORS PER ACFT         : %3.0f',NF(a)/NACFT(a));
    %    
    LIN(lin+1,1)=" ";
    LIN(lin+2,1)='** NETWORK RESULTS **';
    LIN(lin+3,1)=" ";
    LIN(lin+4,1)=strcat('Average Cruise Mach      : ',num2str(AVGMACH(a),3));
    LIN(lin+5,1)=strcat('TOTAL FUEL (kg)          : ',int2str(TOTFUEL(a)));
    LIN(lin+6,1)=strcat('TOTAL CO2  (kg)          : ',num2str(TOTFUEL(a)*3.15));
    LIN(lin+7,1)=strcat('CO2 EFF(kg/PAX)          : ',num2str(CO2EFF(a)));
    LIN(lin+8,1)=strcat('TOTAL DIST (nm)          : ',int2str(TOTDIST(a)));
    LIN(lin+9,1)=strcat('TOTAL PAX                : ',int2str(TOTALPAX(a)));
    LIN(lin+10,1)=strcat('TOTAL COST    ($)        : ',num2str(COST(a)));
    LIN(lin+11,1)=strcat('TOTAL REVENUE ($)        : ',num2str(REV(a)));
    LIN(lin+12,1)=strcat('TOTAL PROFIT  ($)        : ',num2str(PROFIT(a)));
    LIN(lin+13,1)=strcat('MARGIN        (pct)      : ',num2str(100*PROFIT(a)/COST(a)));
    LIN(lin+14,1)=strcat('AVGDOC ($/nm)            : ',num2str(AVGDOC(a)));
    LIN(lin+15,1)=strcat('NRASK ($/pax.nm)         : ',num2str(RASK(a)));
    LIN(lin+16,1)=strcat('NCASK ($/pax.nm)         : ',num2str(CASK(a)));
    LIN(lin+17,1)=strcat('NP    ($/pax.nm)         : ',num2str(NP(a)));
    LIN(lin+18,1)=strcat('NUM OF FREQUENCIES       : ',int2str(NF(a)));
    LIN(lin+19,1)=strcat('NUM OF ACFT              : ',int2str(NACFT(a)));
    LIN(lin+20,1)=strcat('SECTORS PER ACFT         : ',num2str(NF(a)/NACFT(a)));
    lin=lin+21;
end
lin=lin+1;

% TOTAL RESULTS
MCOST=0;
MTOTCOST=0;
MTOTDIST=0;
MREV    =0;
MTOTALPAX=0;
MACFT=0;
MTOTFUEL=0;
MFREQ=0;
%
for a=1:NA
   MCOST    = MCOST+COST(a);  
   MTOTDIST = MTOTDIST+TOTDIST(a);
   MREV     = MREV+REV(a);
   MTOTALPAX= MTOTALPAX+TOTALPAX(a);
   MACFT    = MACFT+NACFT(a);
   MTOTFUEL = MTOTFUEL+TOTFUEL(a);    
   MFREQ    = MFREQ+NF(a);
end
%
MDOC=(AVGDOC(1)*NACFT(1)+AVGDOC(2)*NACFT(2)+AVGDOC(3)*NACFT(3))/MACFT;
MPROFIT=MREV-MCOST;
MCASK=MCOST/(MTOTALPAX*MTOTDIST);
MRASK=MREV/ (MTOTALPAX*MTOTDIST);
MNP=MRASK-MCASK;
%
NN1=NPAR(1,2);
NN2=NPAR(2,2);
NN3=NPAR(3,2);
DON1=NPAR(1,3);
DON2=NPAR(2,3);
DON3=NPAR(3,3);
AVL1=NPAR(1,4);
AVL2=NPAR(2,4);
AVL3=NPAR(3,4);
ND1=NPAR(1,5);
ND2=NPAR(2,5);
ND3=NPAR(3,5);
NC1=NPAR(1,6);
NC2=NPAR(2,6);
NC3=NPAR(3,6);
AVG_NC=(NC1+NC2+NC3)/3;
AVG_NN=(NN1+NN2+NN3)/3;
AVG_ND=(ND1+ND2+ND3)/3;
AVG_L =(AVL1+AVL2+AVL3)/3;
AVG_DON=(DON1+DON2+DON3)/3;
%
CRZMACH1=AVGMACH(1);
CRZMACH2=AVGMACH(2);
CRZMACH3=AVGMACH(3);
CO2EFF1 =CO2EFF(1);
CO2EFF2 =CO2EFF(2);
CO2EFF3 =CO2EFF(3); 
MTOTCO2EFF =3.15*MTOTFUEL/(MTOTDIST*MTOTALPAX*1.852);
%
fprintf('\n');
fprintf('\n ** ALL NETWORKS RESULTS **');
fprintf('\n'); 
fprintf('\n TOTAL DIST (nm)        : %10.2f',MTOTDIST);
fprintf('\n TOTAL FUEL (ton)       : %10.2f',MTOTFUEL);
fprintf('\n TOTAL CO2  (ton)       : %10.2f',MTOTFUEL*3.15);
fprintf('\n CO2 EFF (kg/PAX.km)    : %6.4E',MTOTCO2EFF);
fprintf('\n TOTAL PAX              : %10.0f',MTOTALPAX);
fprintf('\n TOTAL COST    ($)      : %10.2f',MCOST);
fprintf('\n TOTAL REVENUE ($)      : %10.2f',MREV);
fprintf('\n TOTAL PROFIT  ($)      : %10.2f',MPROFIT);
fprintf('\n MARGIN        (pct)    : %10.2f',100*MPROFIT/MCOST);
fprintf('\n NDOC  ($/nm)           : %6.2E',MDOC);
fprintf('\n NRASK ($/pax.nm)       : %6.4E',MRASK);
fprintf('\n NCASK ($/pax.nm)       : %6.4E',MCASK);
fprintf('\n NP    ($/pax.nm)       : %6.4E',MNP);
fprintf('\n NPV   ($)              : %6.4E',TOTNPV);
fprintf('\n NUM OF ACFT            : %3.0f',MACFT);
fprintf('\n NUM OF FREQUENCIES     : %4.0f',MFREQ);
fprintf('\n AVG NETWORK DENSITY    : %5.2f',AVG_ND);
fprintf('\n AVG NETWORK CLUSTERING : %5.2f',AVG_NC);
fprintf('\n AVG DEGREE ON NODES    : %5.2f',AVG_DON);
fprintf('\n AVG PATH LENGTH        : %5.2f',AVG_L);
fprintf('\n SECTORS PER ACFT       : %3.0f',MFREQ/MACFT);
fprintf('\n');
CT=toc/60;
FREQ
fprintf('\n');
fprintf('\n COMPUTING TIME [min]   : %5.1f',CT);
%
LIN(lin,1)=" ";
LIN(lin+1,1)='** ALL NETWORKS RESULTS **';
LIN(lin+2,1)='';
LIN(lin+3,1)=strcat('TOTAL DIST (nm)        : ',int2str(MTOTDIST));
LIN(lin+4,1)=strcat('TOTAL FUEL (ton)       : ',int2str(MTOTFUEL));
LIN(lin+5,1)=strcat('TOTAL CO2  (ton)       : ',num2str(MTOTFUEL*3.15));
LIN(lin+6,1)=strcat('CO2 EFF (kg/PAX.km)    : ',num2str(MTOTCO2EFF));
LIN(lin+7,1)=strcat('TOTAL PAX              : ',int2str(MTOTALPAX));
LIN(lin+8,1)=strcat('TOTAL COST    ($)      : ',num2str(MCOST));
LIN(lin+9,1)=strcat('TOTAL REVENUE ($)      : ',num2str(MREV));
LIN(lin+10,1)=strcat('TOTAL PROFIT  ($)      : ',num2str(MPROFIT));
LIN(lin+11,1)=strcat('MARGIN        (pct)    : ',num2str(100*MPROFIT/MCOST));
LIN(lin+12,1)=strcat('NDOC  ($/nm)           : ',num2str(MDOC));
LIN(lin+13,1)=strcat('NRASK ($/pax.nm)       : ',num2str(MRASK));
LIN(lin+14,1)=strcat('NCASK ($/pax.nm)       : ',num2str(MCASK));
LIN(lin+15,1)=strcat('NP    ($/pax.nm)       : ',num2str(MNP));
LIN(lin+16,1)=strcat('NPV   ($)              : ',num2str(TOTNPV));
LIN(lin+17,1)=strcat('NUM OF ACFT            : ',int2str(MACFT));
LIN(lin+18,1)=strcat('NUM OF FREQUENCIES     : ',int2str(MFREQ));
LIN(lin+19,1)=strcat('AVG NETWORK DENSITY    : ',num2str(AVG_ND));
LIN(lin+20,1)=strcat('AVG NETWORK CLUSTERING : ',num2str(AVG_NC));
LIN(lin+21,1)=strcat('AVG DEGREE ON NODES    : ',num2str(AVG_DON));
LIN(lin+22,1)=strcat('AVG PATH LENGTH        : ',num2str(AVG_L));
LIN(lin+23,1)=strcat('SECTORS PER ACFT       : ',num2str(MFREQ/MACFT));
LIN(lin+24,1)=" ";
lin=lin+25;
% 
LIN(lin,1)='** FREQUENCIES MATRIX **'; 
lin=lin+1; 
%
for a=1:3
    switch a
        case 1   
           ACFTSTR='ACFT#1';       
        case 2      
           ACFTSTR='ACFT#2';           
        case 3       
          ACFTSTR='ACFT#3';
    end
    LIN(lin,1)=strcat('*',ACFTSTR,'*'); 
    lin=lin+1;
    n=size(FREQ,1);
    for i=1:n
        for j=1:n            
          M(i,j)=FREQ(i,j,a);
        end
    end    
    L=NETWORKARRAYS(M);
    n=size(L,1);
    for i=1:n
       LIN(lin,1)=L(i,1);
       lin=lin+1;
    end
    LIN(lin+1,1)='';
    lin=lin+1;
end   
lin=lin+1;
%
LIN(lin,1)=strcat('COMPUTING TIME [min]   : ',num2str(CT));
LIN(lin+1,1)=" ";
lin=lin+2;

% SAVE RESULTS IN TEXT FILE
%! del *NETWORK*.txt
N=lin;
fid=fopen(NAME,'w+');
for i=1:N 
     fprintf(fid,'%s\n',LIN(i));
end
fclose(fid);

% SAVE ROUTES IN KML
%! del *.kml
for a=1:3    
    k=1;
    for i=1:n   
      for j=1:n
          if i~=j
            if FREQ(i,j,a)>0  
              LA1(k,a)=Airport(i).lat;
              LO1(k,a)=Airport(i).lon;           
              LA2(k,a)=Airport(j).lat;
              LO2(k,a)=Airport(j).lon;
              k=k+1;
            end
          end  
      end   
    end
end
for a=1:3
    LAT1=LA1(:,a)';
    LAT2=LA2(:,a)';
    LON1=LO1(:,a)';
    LON2=LO2(:,a)'; 
    switch a
        case 1
          NETNAME=strcat('ACFT#1_',name1,'_',date(),'.kml');
        case 2
          NETNAME=strcat('ACFT#2_',name2,'_',date(),'.kml');   
        case 3
          NETNAME=strcat('ACFT#3_',name3,'_',date(),'.kml');   
    end      
    try         
      RTEKML (LAT1,LON1,LAT2,LON2,NETNAME);
    catch
      fprintf('** NO KML GENERATED **'); 
    end  
end