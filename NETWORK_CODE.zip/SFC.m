function [TSFC]=SFC(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,W,h,M,dist,ISADEV)

% CONSTANTS
fpm2mps=0.005;
kt2ms=0.514;
g= 9.8067;
m2feet=3.28083;
altm=h/m2feet;
n=nedebasa;

[TR, PR, DR, a] = atmos(h,ISADEV);
TAS=a*M;
CDoCL=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,M,ISADEV,TR);
FnREQ=g*W*CDoCL;

maneted=0.1
step=0.01
Fn=0;

while Fn<FnREQ
  [Fn,FF] = engine_main(Altm,CRZMACH,efanpr,eopr,ebypass,maneted,diamfan,TIT);
  if Fn<FnREQ
      manedted=maneted+step;
  end
end  
TSFC=FF/Fn