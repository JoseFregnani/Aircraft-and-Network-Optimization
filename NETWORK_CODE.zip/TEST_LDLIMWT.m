clc

% Test data
MLW=37000;
wS =90;
ISADEV=10;
elev=2500;
BPR=5.0;
LFL=1400;

LANDING_LIMIT_WT=INVLD(MLW,LFL,wS,ISADEV,elev,CLmax_clean)