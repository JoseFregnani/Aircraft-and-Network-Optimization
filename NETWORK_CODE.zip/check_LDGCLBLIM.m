function ToW=check_LDGCLBLIM(A,NNind,NNwav,NNcd0,NNCL,cfe,appflap,ISADEV,elev)

% Roskam (1997). Preliminary Sizing of Airplanes. Part I (pg.144)
% Based on FAR 25.121 landing climb

% LOAD AIRCRAFT DATA
MLW             =A.MLW;   
wS              =A.wS;
wAR             =A.wAR;
wTR             =A.wTR;
wSweepLE        =A.wSweepLE;
inc_root        =A.inc_root; 
inc_kink        =A.inc_kink; 
inc_tip         =A.inc_tip; 
Kink_semispan   =A.Kink_semispan;
r0              =A.r0;
t_c             =A.t_c;
phi             =A.phi;
theta           =A.theta;
epsilon         =A.epsilon;
Ycmax           =A.Ycmax;
YCtcmax         =A.YCtcmax;
X_Ycmax         =A.X_Ycmax;
X_tcmax         =A.X_tcmax;
Airp_SWET       =A.Airp_SWET;
wingSwet        =A.wingSwet;
longtras        =A.longtras;
CLMAX_LD        =A.CLMAX.LD;
VTarea          =A.VTarea;           
VTSweep         =A.VTSweep;
ediam           =A.ediam;
ebypass         =A.ebypass;
neng            =A.n;

%
g                =9.80665;
rad              =pi/180;
h                =elev;

% Atmospheric calculation
[~, ~, sigma, a] =atmos(h,ISADEV);
rho=1.225*sigma;
a  =kt2ms*a;

%
clldclb             = CLMAX_LD;
V                   = 1.3*sqrt(MLW*g/(clldclb*wS*0.50*rho));
M                   = V/a;

%
[CDwing, ~]=CDCLneural2(0.2, h,cl2seg, 1,wS,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);

%
[CD0_ubrige]        = cfe*(Airp_SWET-wingSwet)/wS;

% Drag increase due to flaps and rudder deflection
dcdflap             = CD_flap(appflap,longtras);
dcdrudder           = 0.0020*cos(rad*VTSweep)*(VTarea/wS); 

% Drag increase due to gear down
dcdlg=0.0150

%
cd=CDwing+CD0_ubrige+dcdflap+dcdrudder+dcdlg;
ld=clldclb/cd;

%
ToW =(1/ld+sin(0.032));

