function [tracaonewt,FF] = enginedeck(Altd,Machd,fanpr,opr,bpr,maneted,diamfan,TIT)
% #########################################################################
% ##
% ##    function motor
% ##    fun��o usada para modelar o funcionamento de um motor turbofan
% ##
% ##    INPUTS: Altitude (m)
% ##            Mach
% ##            Raz�o de compress�o proporcionada pelo fan
% ##            Raz�o de press�o do compressor
% ##            Bypass Ratio
% ##            Posi��o da manete de pot�ncia (0-1)
% ##            Di�metro do fan (m)
% ##            TIT: Turbine inlet temperature (K)
% ##
% ##    OUTPUTS: Tra��o NET (N)
% ##             Fuel Flow (kg/h)
% ##
% #########################################################################
%
%
% ----- MOTOR DATA INPUT --------------------------------------------------
afan   = pi*(diamfan^2)/4;
prfan  = fanpr;      % raz�o de press�o do fan
prc    = opr/fanpr;  % taxa de compress�o fornecida pelo compressor
prcomb = 0.99;     % raz�o de press�o do combustor
tt4        = TIT;     % temperatura na entrada da turbina
tt4takeoff = TIT; % at takeoff 10% increase in turbine temperatute for 5 min
PC         = 43260000;   % Poder calor�fico (J/kg) 

% ----- DESIGN POINT ------------------------------------------------------

Mach=0;
Alt = 0;      
manete = 1.0;

% ------ EFICI�NCIAS ------------------------------------------------------
eta(1:15) = 1;       % inicializa o vetor de eficic�ncias
eta(2) = 0.98;          % inlet (inlet pressure recovery)
eta(3) = 0.85;          % compressor
eta(4) = 0.99;          % c�mara de combust�o
eta(5) = 0.90;          % turbina
eta(7) = 0.98;          % nozzle
eta(13) = 0.97;         % fan

% Atualizado tabela acima em setembro de 2013 de acordo com as anotacoes
% de aula do Ney
% ------ TEMPERATURE RATIOS -----------------------------------------------
trat(1:15) = 1;

% #########################################################################
% #########  G E T  T H E R M O - DESIGN MODE #############################

% ------ PRESSURE RATIOS --------------------------------------------------
prat(2) = eta(2);    % raz�o de press�o = efici�ncia do inlet
prat(3) = prc;       % raz�o de press�o no compressor
prat(4) = prcomb;    % raz�o de press�o do combustor
prat(13) = prfan;    % raz�o de press�o no fan

% ------ FREE STREAM ------------------------------------------------------
gama = 1.4;                             % gamma do programa
R = 287.2933;                           % R do programa
[T_0,P_0] = atmosfera2(Alt);
T0_0 = (1 + (gama-1)/2*Mach^2)*T_0;     % temperatura total
P0_0 = P_0*(T0_0/T_0)^(gama/(gama-1));  % press�o total
a0 = sqrt(gama*R*T_0);                  % velocidade do som
u0 = Mach*a0;                           % velocidade de v�o

% ------ TEMPERATURE RATIOS -----------------------------------------------
trat(1:15) = 1;

% ----- ENTRADA DE AR -----------------------------------------------------
P0_1 = P0_0;
T0_1 = T0_0;

% ----- INLET -------------------------------------------------------------
T0_2 = T0_1;
P0_2 = P0_1*prat(2);

% ----- FAN ---------------------------------------------------------------
gama2 = getgamma(T0_2);
cp2 = getcp(T0_2);
del_h_fan = cp2*T0_2/eta(13)*((prat(13))^((gama2-1)/gama2)-1);
del_t_fan = del_h_fan/cp2;
T0_13 = T0_2 + del_t_fan;
P0_13 = P0_2 * prat(13);
trat(13) = T0_13 / T0_2;

% ----- COMPRESSOR --------------------------------------------------------
gama13 = getgamma(T0_13);
cp13 = getcp(T0_13);
del_h_c = cp13*T0_13/eta(3)*(prat(3)^((gama13-1)/gama13)-1);
del_t_c = del_h_c/cp13;
T0_3 = T0_13 + del_t_c;
P0_3 = P0_13 * prat(3);
trat(3) = T0_3 / T0_13;
cp3 = getcp(T0_3);

% ----- COMBUSTOR ---------------------------------------------------------
T0_4 = manete * tt4takeoff;    % ponto de projeto
P0_4 = P0_3 * prat(4);
trat(4) = T0_4 / T0_3;

% ----- HIGHT TURBINE -----------------------------------------------------
gama4 = getgamma(T0_4);
cp4 = getcp(T0_4);
del_h_ht = del_h_c;
del_t_ht = del_h_ht / cp4;

T0_5 = T0_4 - del_t_ht;
prat(5) = (1-del_h_ht/(cp4*T0_4*eta(5)))^(gama4/(gama4-1));
P0_5 = P0_4 * prat(5);
trat(5) = T0_5 / T0_4;

% ----- LOWER TURBINE -----------------------------------------------------
gama5 = getgamma(T0_5);
cp5 = getcp(T0_5);
del_h_lt = (1 + bpr)*del_h_fan;
del_t_lt = del_h_lt / cp5;

T0_15 = T0_5 - del_t_lt;
prat(15) = (1-del_h_lt/(cp5*T0_5*eta(5)))^(gama5/(gama5-1));
P0_15 = P0_5 * prat(15);
trat(15) = T0_15 / T0_5;

epr = prat(2)*prat(3)*prat(4)*prat(5)*prat(13)*prat(15);
etr = trat(2)*trat(3)*trat(4)*trat(5)*trat(13)*trat(15);
% #########################################################################


% ########### G E T    G E O M E T R Y  ###################################
acore = afan/(bpr+1);                   % �rea do n�cleo

%  ---- a8rat = a8 / acore ---- 
a8rat = min(0.75*sqrt(etr/trat(2))/epr*prat(2),1.0);   
% OBS: divide por prat(2) pois ele n�o � considerado no c�lculo do EPR e
% ETR acima no applet original

a8 = a8rat * acore;
a4 = a8 * prat(5)*prat(15)/sqrt(trat(5)*trat(15));
a4p = a8 * prat(15)/sqrt(trat(15));
a8d = a8;

if ((Mach==Machd) && (Alt==Altd) && (manete==maneted))
    designpoint = 1;
else
    designpoint = 0;
end

if ~designpoint
    % #########################################################################
    % #########  G E T  T H E R M O - WIND TUNNEL TEST ########################
    % disp('passei aqui designpoint');
    Mach = Machd;
    manete = maneted;

    % ------ FREE STREAM ------------------------------------------------------
    gama = 1.4;                             % gamma do programa
    R = 287.2933;                           % R do programa
    [T_0,P_0] = atmosfera2(Altd);

    T0_0 = (1 + (gama-1)/2*Mach^2)*T_0;     % temperatura total
    P0_0 = P_0*(T0_0/T_0)^(gama/(gama-1));  % press�o total
    a0 = sqrt(gama*R*T_0);                  % velocidade do som
    u0 = Mach*a0;                           % velocidade de v�o

    % ----- ENTRADA DE AR -----------------------------------------------------
    P0_1 = P0_0;
    T0_1 = T0_0;

    % ----- INLET -------------------------------------------------------------
    T0_2 = T0_1;
    P0_2 = P0_1*prat(2);

    % ----- COMBUSTOR ---------------------------------------------------------
    T0_4 = manete*tt4;
    gama4 = getgamma(T0_4);
    cp4 = getcp(T0_4);

    % ----- HIGHT TURBINE -----------------------------------------------------
    trat(5) = fzero(@(x) achatrat(x,a4p/a4,eta(5),-gama4/(gama4-1)),1.0);

    T0_5 = T0_4*trat(5);
    gama5 = getgamma(T0_5);
    cp5 = getcp(T0_5);
    del_t_ht = T0_5 - T0_4;
    del_h_ht = del_t_ht*cp4;
    prat(5) = (1-(1-trat(5))/eta(5))^(gama4/(gama4-1));

    % ----- LOWER TURBINE -----------------------------------------------------
    trat(15) = fzero(@(x) achatrat(x,a8d/a4p,eta(5),-gama5/(gama5-1)),1.0);

    T0_15 = T0_5 * trat(15);
    gama15 = getgamma(T0_15);
    cp15 = getcp(T0_15);
    del_t_lt = T0_15 - T0_5;
    del_h_lt = del_t_lt*cp5;
    prat(15) = (1-(1-trat(15))/eta(5))^(gama5/(gama5-1));

    % ----- FAN ---------------------------------------------------------------
    del_h_fan = del_h_lt / (1+bpr);
    del_t_fan = -del_h_fan / cp2;
    T0_13 = T0_2 + del_t_fan;
    gama13 = getgamma(T0_13);
    cp13 = getcp(T0_13);

    trat(13) = T0_13 / T0_2;
    prat(13) = (1-(1-trat(13))*eta(13))^(gama2/(gama2-1));

    % ----- COMPRESSOR --------------------------------------------------------
    del_h_c = del_h_ht;
    del_t_c = -del_h_c / cp13;

    T0_3 = T0_13 + del_t_c;
    gama3 = getgamma(T0_3);
    cp3 = getcp(T0_3);
    trat(3) = T0_3 / T0_13;
    prat(3) = (1-(1-trat(3))*eta(3))^(gama13/(gama13-1));
    trat(4) = T0_4 / T0_3;


    % ----- total pressures definition ----------------------------------------
    P0_13 = P0_2 * prat(13);
    P0_3 = P0_13 * prat(3);
    P0_4 = P0_3 * prat(4);
    P0_5 = P0_4 * prat(5);
    P0_15 = P0_5 * prat(15);

    % ----- overall pressure & temperature ratios -----------------------------
    epr = prat(2)*prat(3)*prat(4)*prat(5)*prat(13)*prat(15);
    etr = trat(2)*trat(3)*trat(4)*trat(5)*trat(13)*trat(15);

end

% ########### G E T   P E R F O R M A N C E  ##############################
gamae = getgamma(T0_5);                 % gamma de sa�da (T0_5 ???)
Re = (gamae-1)/gamae*getcp(T0_5);       % Constante R de sa�da
g = 32.2;

P0_8 = P0_0 * epr;                      
T0_8 = T0_0 * etr;

fact2 = -0.5*(gamae+1)/(gamae-1);
fact1 = (1 + 0.5*(gamae-1))^fact2;
mdot = a8*sqrt(gamae)*P0_8*fact1/sqrt(T0_8*Re); % fluxo m�ssico [kg/s]

npr = max(P0_8 / P_0,1);

fact1 = (gamae-1)/gamae;
uexit = sqrt(2*R/(gamae-1)*gamae*T0_8*eta(7)*(1-(1/npr)^fact1)); % ????

if (npr<=1.893)
    pexit = P_0;
else
    pexit = 0.52828*P0_8;
end

fgros = uexit + (pexit-P_0)*a8/mdot/g;

% ------ contribui��o do fan -------------------------------------------
snpr = P0_13 / P_0;
fact1 = (gama-1)/gama;
ues = sqrt(2*R/fact1*T0_13*eta(7)*(1-1/snpr^fact1));

if (snpr<=1.893)
    pfexit = P_0;
else
    pfexit = 0.52828*P0_13;
end

fgros = fgros + bpr*ues + (pfexit-P_0)*bpr*acore/mdot/g;

dram = u0*(1+bpr);
fnet = fgros - dram;
fuel_air = (trat(4)-1)/(eta(4)*PC/(cp3*T0_3)-T0_4/T0_3);

% ####### Estimativa de Peso ##############################################
ncomp = min(15,round(1+prc/1.5));
nturb = 2 + floor(ncomp/4);
dfan = 293.02;          % fan density
dcomp = 293.02;         % comp density
dburn = 515.2;          % burner density
dturb = 515.2;          % turbine density
conv1 = 10.7639104167;  % convers�o de acore para ft^2

weight = 4.4552*0.0932*acore*conv1*sqrt(acore*conv1/6.965)*...
    ((1+bpr)*dfan*4 + dcomp*(ncomp-3) + 3*dburn + dturb*nturb); %[N]

% ###### SUBROUTINE OUTPUTS ###############################################
%weightkgf = weight/9.8;
%tracaokgf = fnet*mdot/9.8;  %[kgf]
tracaonewt = fnet*mdot; %[tracao em Newtons]
FF = 1.15*fuel_air*mdot*3600;  %[kg/h]   % corre��o de 15% baseado em dados de motores reais


% ------ Printing----------------------------------------------------------
iprint=0;
if iprint == 1
fprintf('Turbofan: \n');
fprintf('  Bypass Ratio  = %3.1f \n',bpr);
fprintf('  Diameter  = %5.3f m \n',sqrt(4*afan/pi));
fprintf('  Estimated Weight  = %8.3f N \n',weight);
fprintf(' \n');

fprintf('Flight Conditions: \n');
fprintf('  Mach = %3.2f,  V0 =%4.0f km/h \n',Mach,u0*3.6);
fprintf('  Alt =%6.0f m \n',Altd);
fprintf('  p0 =%7.3f,  pt0 =%7.3f kPa \n',P_0/1000,P0_0/1000);
fprintf('  T0 =%4.0f,  Tt0 =%4.0f K  \n',T_0,T0_0);
fprintf('   \n');

fprintf('Engine Thrust and Fuel Flow:   \n');
fprintf('  F gross = %5.0f,  D ram =%5.0f,  F net = %5.0f N \n',fgros*mdot,dram*mdot,fnet*mdot);
fprintf('  Fuel Flow =%4.0f kg/hr \n',FF);
fprintf('  Thrust/Weight =%5.3f \n',fnet*mdot/weight);
fprintf('   \n');

fprintf('Engine Performance   \n');
fprintf('  Throttle  = %4.1f %%, core airflow (m)  =%7.3f kg/s \n',manete*100,mdot);
fprintf('  EPR =%6.3f,  ETR =%6.3f,  fuel/air = %6.3f  \n',epr,etr,fuel_air);
fprintf('  Nozzle Pressure Ratio =%6.3f,  Vexit = %4.0f m/s \n',npr,uexit);
fprintf('  Fg/m =%9.3f,  Dram/m =%7.2f,  Fn/m =%9.3f N/(kg/s)  \n',fgros,dram,fnet);
fprintf('   \n');

fprintf('Component Performance:  \n');
fprintf('   Variable     Inlet   Fan     Comp    Burn    H-Tur   L-Tur   Noz     Exhast\n');
fprintf(' Efficiency     ');
fprintf('%-8.3g',eta(2),eta(13),eta(3),eta(4),eta(5),eta(5),eta(7));
fprintf('\n');
fprintf(' Press Rat      ');
fprintf('%-8.3g',prat(2),prat(13),prat(3),prat(4),prat(5),prat(15),prat(7));
fprintf('\n');
fprintf(' Press - p      ');
fprintf('%-8.3f',P0_2/1000,P0_13/1000,P0_3/1000,P0_4/1000,P0_5/1000,P0_15/1000,P0_8/1000);
fprintf('\n');
fprintf(' Temp Rat       ');
fprintf('%-8.3g',trat(2),trat(13),trat(3),trat(4),trat(5),trat(15),trat(7));
fprintf('\n');
fprintf(' Temp - T       ');
fprintf('%-8.0f',T0_2,T0_13,T0_3,T0_4,T0_5,T0_15,T0_8);
fprintf('\n');
end

% #########################################################################
% ##
% ##    function achatrat
% ##    fun��o usada para achar a raz�o de temperatura nas turbinas
% ##
% #########################################################################
function f = achatrat(x,a,b,c)
f = a - sqrt(x)*(1-(1-x)/b)^c;

%**************************************************************************
%
%   Fun��o para obter gamma em fun��o da temperatura(kelvin)
%   Retirado do c�digo fonte do software EngineSim da NASA
%   http://www.grc.nasa.gov/WWW/K-12/airplane/ngnsim.html
%
%   input: temperatura (K)
%   output: gamma
%
%**************************************************************************
function gamma = getgamma(temp)

tempr = temp*1.8;      % converte de kelvin para rankine

a =  -7.6942651e-13;
b =  1.3764661e-08;
c =  -7.8185709e-05;
d =  1.436914;

gamma = a*tempr^3 + b*tempr^2 + c*tempr + d;

%**************************************************************************
%
%   Fun��o para obter cp em fun��o da temperatura
%   Retirado do c�digo fonte do software EngineSim da NASA
%   http://www.grc.nasa.gov/WWW/K-12/airplane/ngnsim.html
%
%   input: temperatura [K]
%   output: Cp [J/(kg*K)]
%
%**************************************************************************

function cp = getcp(temp)

tempr = temp*1.8;      % converte de kelvin para rankine

a =  -4.4702130e-13;
b =  -5.1286514e-10;
c =   2.8323331e-05;
d =  0.2245283;
      
cp = a*tempr^3 + b*tempr^2 + c*tempr + d; % btu/(lb*R)

cp = cp*4187.65276736494;    % J/(kg*K)

%**************************************************************************
%
%   Fun��o para obter mach em fun��o da vaz�o m�ssica por �rea (mdot_a)
%   Retirado do c�digo fonte do software EngineSim da NASA
%   http://www.grc.nasa.gov/WWW/K-12/airplane/ngnsim.html
%
%   input:  mdot_a [kg/(s.m^2)]
%           gama
%           P - Total Pressure [Pa]
%           T - Total Temperature [K]
%   output: Mach
%
%**************************************************************************
%function Mach=getmach(mdot_a,gama,P,T,R)

% f fun is parameterized, you can use anonymous functions to capture the problem-dependent parameters. For example, suppose you want to find a zero of the function myfun defined by the following M-file function.
% function f = flow(mach,mdot_a,gama,P,T,R)
% f = ......
% Note that myfun has an extra parameter a, so you cannot pass it directly to fzero. To optimize for a specific value of a, such as a = 2.
% % Assign the value to a. 
% a = 2; % define parameter first% 
% Call fzero with a one-argument anonymous function that captures that value of a and calls myfun with two arguments:
% x = fzero(@(x) flow(mach,mdot_a,gama,P,T,R),0.1)

%Mach = fzero(@(Mach) flow(Mach,mdot_a,gama,P,T,R),[0 1]); 

% function f=fflow(mach,mdot_a,gama,P,T,R)
% 
% fator1 = -0.5*(gama+1)/(gama-1);
% fator2 = (1 + 0.5*(gama-1)*mach^2)^fator1;
% f = mdot_a - P*sqrt(gama/(R*T))*mach*fator2;
