function GW=INVBFL(A,TOFL,ISADEV,elev,TO_FLAP)

MAXRATE=A.MAXRATE;
MTOW=A.MTOW;
wS  =A.wS;
BPR =A.ebypass;
CLmax_clean=A.CLMAX;

flag=0;
TOW=MTOW;
while flag==0
  FL=BFL(TOW,wS,MAXRATE,BPR,ISADEV,elev,CLmax_clean);
  if FL>TOFL
     TOW=TOW-10;
  else
     flag=1;
  end
end
GW=TOW;