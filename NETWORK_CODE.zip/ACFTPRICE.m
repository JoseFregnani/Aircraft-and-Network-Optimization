function y=ACFTPRICE(MTOW,Share)

% RefPrice=23000000;
% MTOWfac=MTOW/22000;
% WTADJPrice=RefPrice*MTOWfac;
% Price     =(1+(0.3-0.5*Share))*WTADJPrice;

Yref=0.3;
Xref=0.6;

% Model derived from Airbus price list (Narrow Bodies,1 aisle) @ 23/12/2018
y0=3.3383;
mu=0.0013;
WTADJPrice=y0+mu*MTOW; 
DESC      =Yref/Xref*Share
Price     =WTADJPrice*(1-DESC)
y=Price*1E6;