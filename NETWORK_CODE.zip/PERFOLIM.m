function [RTOW,RLW]=PERFOLIM(A,NNind,NNwav,NNcd0,NNCL,ASDA,LDA,TO_elev,LD_elev,TO_TREF,LD_TREF);
 
% Takoff ISA deviation     
TO_h=TO_elev;
[theta, ~, ~, ~] = atmos(TO_h,0);
T0=288.15*theta-273.15;
TO_ISADEV=TO_TREF-T0;
  
% Landing ISA deviation
LD_h=LD_elev;
[theta, ~, ~, ~] = atmos(LD_h,0);
T0=288.15*theta-273.15;
LD_ISADEV=LD_TREF-T0;

TOFIELD_LIM_WT=INVBFL(A,ASDA,TO_ISADEV,TO_elev);
SECSEG_LIM_WT =INVCLB(A,NNind,NNwav,NNcd0,NNCL,TO_ISADEV,TO_elev);
A1=[A.MTOW TOFIELD_LIM_WT SECSEG_LIM_WT];
%
LDFIELD_LIM_WT=INVLD(A,LDA,LD_ISADEV,LD_elev);
APPCLB_LIM_WT =INVAPPCLB(A,NNind,NNwav,NNcd0,NNCL,LD_ISADEV,LD_elev);
LDGCLB_LIM_WT =INVLDGCLB(A,NNind,NNwav,NNcd0,NNCL,LD_ISADEV,LD_elev);
A2=[A.MLW LDFIELD_LIM_WT APPCLB_LIM_WT LDGCLB_LIM_WT];
RTOW=min(A1);
RLW=min(A2);

%
% fprintf('\n');
% fprintf('\n ** TAKEOFF PERFORMANCE **');
% fprintf('\n MTOW        (kg) : %10.0f',A.MTOW);
% fprintf('\n FIELD LIMIT (kg) : %10.0f',TOFIELD_LIM_WT);
% fprintf('\n 2nd SEG CLB (kg) : %10.0f',SECSEG_LIM_WT);
% fprintf('\n RTOW        (kg) : %10.0f',RTOW);
% fprintf('\n');
% fprintf('\n ** LANDING PERFORMANCE **');
% fprintf('\n MLW          (kg): %10.0f',A.MLW);
% fprintf('\n FIELD LIMIT  (kg): %10.0f',LDFIELD_LIM_WT);
% fprintf('\n APPROACH CLB (kg): %10.0f',APPCLB_LIM_WT);
% fprintf('\n LANDING CLB  (kg): %10.0f',LDGCLB_LIM_WT);
% fprintf('\n RLW          (kg): %10.0f',RLW);
% fprintf('\n');



