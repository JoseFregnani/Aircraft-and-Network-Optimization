function [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3,n1,n2,n3]=LOADDATABANK2b(X1,X2,X3,mode)

% X1=rand(1);
% X2=rand(1);
% X3=rand(1);
% mode=1;% 1=divide em 3 grups de NPAX, 2= divide em 3 grupos de alcances

DB_name={'airplane_3_77170039512_737288.dat','airplane_13_92220051407_737289.dat',...
         'airplane_14_92220047152_737289.dat','airplane_21_116190055196_737290.dat','airplane_25_90180045891_737290.dat'...
         'airplane_32_112220059399_737291.dat','airplane_36_101150045925_737291.dat','airplane_40_74183038461_737293.dat',...
         'airplane_41_80180039754_737294.dat','airplane_42_80180040300_737294.dat','airplane_43_80180039355_737294.dat',...
         'airplane_44_144180062766_737295.dat','airplane_45_144180064218_737295.dat','airplane_48_124190057146_737295.dat',...
         'airplane_49_84180041649_737295.dat','airplane_57_100160047689_737296.dat','airplane_60_105160049229_737296.dat',...
         'airplane_80_90190042454_737296.dat','airplane_81_174155068530_737298.dat','airplane_82_174160068601_737298.dat',...
         'airplane_86_104190049500_737298.dat','airplane_88_88160040677_737299.dat','airplane_92_110190050213_737299.dat',...
         'airplane_93_72180037256_737299.dat','airplane_94_50140024105_737303.dat','airplane_95_50140024224_737303.dat',...
         'airplane_96_50140025716_737303.dat','airplane_97_70150034555_737303.dat','airplane_98_70180035936_737303.dat',...
         'airplane_99_44140024044_737303.dat','airplane_101_110180047671_737303.dat','airplane_106_95160042056_737304.dat',...
         'airplane_107_100100045029_737304.dat','airplane_108_100100041380_737304.dat','airplane_111_120190056656_737305.dat',...
         'airplane_121_116220054624_737305.dat','airplane_200_60160031390_737306.dat','airplane_201_60160032344_737306.dat',...
         'airplane_205_60160031847_737307.dat','airplane_206_70160035002_737307.dat','airplane_501_75160042506_737292.dat',...
         'airplane_508_120180055735_737293.dat','airplane_514_126160060140_737294.dat','airplane_516_73180040188_737294.dat',...
         'airplane_527_133195058348_737295.dat','airplane_528_120190058750_737295.dat','airplane_552_130190058556_737299.dat',...
         'airplane_556_100180048101_737299.dat','airplane_558_115200052989_737299.dat'};

% PAX CAPACITY GROUP LIMIT     
%% paper
% LIM1=80;
% LIM2=90;
% LIM3=110;    
%% cluster analysis
LIM1=70;
LIM2=110;
LIM3=180;    
auto=0; % auto=1 choses limits ccording to the sample distribution

% 2D Airfoils parameters
r0      =[0.0153 0.0150 0.0150];
t_c     =[0.1228 0.1055 0.0982];
phi     =[-0.0799 -0.1025 -0.1553];
X_tcmax =[0.3738 0.3585 0.3590];
theta   =[0.0787 -0.0295 0.1000];
epsilon =[-0.0549 -0.2101 -0.0258];
Ycmax   =[-4.0000e-04 0.0185 0.0104];
YCtcmax =[-6.0000e-04 0.0028 0.0109];
X_Ycmax =[0.6188 0.7870 0.5567];
wTCmed  =0.1100;  
% initialize vector with airfoils coordinates
xutip   =zeros(1,51);
yutip   =zeros(1,51);
xltip   =zeros(1,51);
yltip   =zeros(1,51);
xukink  =zeros(1,51);
yukink  =zeros(1,51);
xlkink  =zeros(1,51);
ylkink  =zeros(1,51);
xuroot  =zeros(1,51);
yuroot  =zeros(1,51);
xlroot  =zeros(1,51);
ylroot  =zeros(1,51);        
     
n=size(DB_name,2); 

for i=1:n
       %
       filename=char(DB_name(i));       
       [Range,DOC,MMO,Ceiling, MTOW_kg, OEW_kg,MLW,...
         MZFW,PEng, PHT,PWing,slat,lco,ltail,lf,...
		 fus_w,fus_h,FUSELAGE_Dz_floor, FusSwet_m2,container_type,...
		 NSeat, NPax,NCorr,CabHeightm,AisleWidth,...
		 SEATwid,SeatPitch,fuselagefuelcapacity_kg,...
		 wS,wAR,wTR, Ccentro, Craiz, Cquebra,Cponta,...
		 iroot, ikink, itip, tcroot,tckink,tctip,...
		 wingb, yposeng, wingdi, xle, wSweepLE,...
		 wSweep14,wingSwet,bflap, posaileron, longtras,...
		 flap_area_m2, Flap_def_take, Flap_def_land,...
		 wingfuelcapacity_kg,arh, sweepLEht, crootht,...
		 ctipht, arv, sweepLEvt,crootvt, ctipvt,...
		 EnginLength_m, BPR, OPR, FANPR, DFAN, eTIT,...
		 DX_Eng, ESwet, DZ_Pylon,mlg,nlg,wlet_present,...
         SweepLE_winglet, AR_winglet, TR_winglet,...
		 CantAngle_wlet,Twist_wlet]= read_parameters(filename);
      %
        A(i).PEng=PEng;
        A(i).PHT=PHT;
        A(i).PWing=PWing;
        A(i).wlet_present=wlet_present;
        %
        A(i).RANGE=Range;
        A(i).DOCref=DOC;
        A(i).MMO=MMO; 
        A(i).VMO=340; 
        A(i).Ceiling=Ceiling;
        %
        Clmax=1.6;
        CLMAX=0.9*Clmax*cos(wSweep14/180*pi());
        A(i).CLMAX=CLMAX;
        A(i).CLMAX_TO=CLMAX+0.6;
        A(i).CLMAX_LD=CLMAX+1.2;
        %
        A(i).OEW=OEW_kg;
        A(i).MTOW=MTOW_kg;
        A(i).MLW=MLW;
        A(i).MZFW=MLW*0.98;
        WFC=wingfuelcapacity_kg(1,1);
        FFC=fuselagefuelcapacity_kg;
        MAXFUEL=WFC+FFC;
        A(i).MAXFUEL=MAXFUEL;
        %
        A(i).wS =wS;
        A(i).wSft2 =10.76*wS;
        A(i).wAR=wAR;
        A(i).wTR=wTR;
        A(i).wingb=wingb;
        A(i).wSweep14=wSweep14;
        A(i).wSweepLE=wSweepLE;
        A(i).wingSwet=wingSwet;
        A(i).wingdi=wingdi;
        A(i).wTwist=itip-iroot;
        A(i).Kink_semispan=yposeng;
        A(i).inc_root=iroot; 
        A(i).inc_kink=ikink; 
        A(i).inc_tip=itip; 
        A(i).tc_root=tcroot; 
        A(i).tc_kink=tckink; 
        A(i).tc_tip=tctip;        
        A(i).Ccentro=Ccentro;
        A(i).Craiz=Craiz;
        A(i).Cquebra=Cquebra;
        A(i).Cponta=Cponta;
        A(i).wMAC=(2/3)*Ccentro*(1+wTR+wTR^2)/(1+wTR);
        A(i).xle=xle;
        A(i).slat=slat;
        A(i).bflap=bflap;
        A(i).flap_area_m2=flap_area_m2;
        A(i).Flap_def_take=Flap_def_take;
        A(i).Flap_def_land=Flap_def_land;
        A(i).posaileron=posaileron;
        A(i).longtras=longtras;
        %
        A(i).VTarea=(arv*(ctipvt+crootvt)^2)/4;
        A(i).VTAR=arv;
        A(i).VTTR=ctipvt/crootvt;
        A(i).VTSweep=sweepLEvt;
        %
        A(i).HTarea=(arh*(ctipht+crootht)^2)/4;
        A(i).HTAR=arh;
        A(i).HTTR=ctipht/crootht;
        A(i).HTSweep=sweepLEht;
        %
        A(i).container_type=container_type;
        A(i).NPax=round(NPax);
        A(i).NCorr=round(NCorr);
        A(i).NSeat=round(NSeat);
        A(i).SeatPitch=SeatPitch;
        A(i).ncrew=5;
        A(i).AisleWidth=AisleWidth;
        A(i).CabHeightm=CabHeightm;    
        A(i).SEATwid=SEATwid; 
        %     
        A(i).lf=lf;
        A(i).lco=lco;
        A(i).ltail=ltail;
        A(i).widthratio=fus_w/fus_h; 
        A(i).fus_width=fus_w;
        A(i).FusDiam=(fus_w+fus_h)/2;
        A(i).fus_height=fus_h;
        A(i).FUSELAGE_Dz_floor=FUSELAGE_Dz_floor;
        A(i).FusSwet_m2=FusSwet_m2;
        %
        A(i).mlg=mlg;
        A(i).nlg=nlg;
        %
        %A(i).MAXRATE=(MTOW_kg/22000)*8895; 
        A(i).MAXRATE= 0.3264*MTOW_kg + 2134.8 %regression 
        A(i).T0=A(i).MAXRATE*0.95;        
        A(i).n=2; 
        A(i).nedebasa=1;
        A(i).ebypass=BPR;
        A(i).ediam=DFAN;
        A(i).efanpr=FANPR;
        A(i).eopr=OPR;
        A(i).eTIT=eTIT;
        A(i).EnginLength_m=EnginLength_m;        
        A(i).DX_Eng=DX_Eng;
        A(i).ESwet=ESwet;
        A(i).DZ_Pylon=DZ_Pylon;
        %
        A(i).SweepLE_winglet=SweepLE_winglet;
        A(i).AR_winglet=AR_winglet;
        A(i).TR_winglet=TR_winglet;
        A(i).CantAngle_wlet=CantAngle_wlet;
        A(i).Twist_wlet=Twist_wlet;
        %  
        A(i).Airp_SWET=wingSwet+FusSwet_m2;
                %
        A(i).r0=r0;
        A(i).t_c=t_c;
        A(i).phi=phi;
        A(i).X_tcmax=X_tcmax;
        A(i).theta=theta;
        A(i).epsilon=epsilon;
        A(i).Ycmax=Ycmax;
        A(i).YCtcmax=YCtcmax;
        A(i).X_Ycmax=X_Ycmax;
        A(i).wTCmed=wTCmed;
        %
        A(i).xutip=xutip;
        A(i).yutip=yutip;
        A(i).xltip=xltip;
        A(i).yltip=yltip;
        A(i).xukink=xukink;
        A(i).yukink=yukink;
        A(i).xlkink=xlkink;
        A(i).ylkink=ylkink;
        A(i).xuroot=xuroot;
        A(i).yuroot=yuroot;
        A(i).xlroot=xlroot;
        A(i).ylroot=ylroot;
        
end    

if mode==1
       % SELECTION USING PAX CAPACITY  
        MAXPAX=0;
        MINPAX=999;
        for i=1:n
           PAX=A(i).NPax;
           if PAX<=MINPAX
              MINPAX=round(PAX);
           end
           if PAX>=MAXPAX
              MAXPAX=round(PAX);
           end
        end 
        
        if auto==1
            LIM1=round(MINPAX+(MAXPAX-MINPAX)/3)
            LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3)
            LIM3=MAXPAX
        else
            LIM1
            LIM2
            LIM3
        end 
        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            PAX=A(i).NPax;
            if PAX<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(PAX>LIM1,PAX<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(PAX>LIM2,PAX<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end    
    
else  
        % SELECTION USING RANGE 
        MAXRANGE=0;
        MINRANGE=999;
        for i=1:n
           RANGE=A(i).RANGE;
           if RANGE<=MINRANGE
              MINRANGE=round(RANGE);
           end
           if RANGE>=MAXRANGE
              MAXRANGE=round(RANGE);
           end
        end   
        if auto==1
            LIM1=round(MINPAX+(MAXPAX-MINPAX)/3)
            LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3)
            LIM3=MAXPAX
        else
            LIM1
            LIM2
            LIM3
        end      
        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            RANGE=A(i).RANGE;
            if RANGE<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(RANGE>LIM1,RANGE<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(RANGE>LIM2,RANGE<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end  
end 

% Choose aircrafts from the list
l1=size(A1,2);
l2=size(A2,2);
l3=size(A3,2);
n1=ceil(X1*l1);
n2=ceil(X2*l2);
n3=ceil(X3*l3);
ACFT1=A1(n1)
ACFT2=A2(n2)
ACFT3=A3(n3)
l1
l2
l3
