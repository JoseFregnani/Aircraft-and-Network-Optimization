%% DESCRI��O E AUTORIA %%
%ruidoaero - Rotina para estimativa do ruido de "airframe" de aeronaves
%autores   - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   ACTGEO      - geometria da aeronave
%                       (1)     - SH - �rea de refer�ncia da empenagem horizontal [m�]
%                       (2)     - bH - envergadura da empenagem horizontal [m]
%                       (3)     - SV - �rea de refer�ncia da empenagem vertical [m�]
%                       (4)     - bV - envergadura da empenagem vertical [m]
%                       (5)     - SF - �rea total dos flapes [m�]
%                       (6)     - bF - envergadura total dos flapes [m]
%                       (7)     - deltafTO - deflex�o dos flapes - decolagem [deg]
%                       (8)     - deltafLD - deflex�o dos flapes - pouso [deg]
%                       (9)     - dmtyre - di�metro do pneu - trem de pouso principal [m]
%                       (10)    - dntyre - di�metro do pneu - trem de pouso dianteiro [m]
%                       (11)    - nmgear - n�mero de unidades no trem de pouso principal
%                       (12)    - nmgear - n�mero de unidades no trem de pouso dianteiro
%                       (13)    - lmgear - comprimento da perna do trem de pouso principal [m]
%                       (14)    - lngear - comprimento da perna do trem de pouso dianteiro [m]
%                       (15)    - nmwheel - n�mero de pneus por trem principal 
%                       (16)    - nnwheel - n�mero de pneus por trem dianteiro
%                       (17)    - fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
%                       (18)    - fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
%                       (19)    - fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
%                       (20)    - fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
%                       (21)    - fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
%                       (22)    - nslots - n�mero de slots no flape
%                       (23)    - fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
%                       (24)    - fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
%                       (25)    - hprec - altitude no ponto de medi��o
%                       (26)    - disarec - temperatura no ponto de medi��o [�C]
%                   HP          - altitude-press�o [ft]
%                   DISA        - varia��o da temperatura em rela��o � ISA [�C]
%                   RH          - relative humidity [%]
%                   vairp       - velocidade do avi�o [m/s]
%                   teta        - dire��o para avalia��o do ru�do [deg]
%                   fi          - eleva��o para avalia��o do ru�do [deg]
%                   R           - dist�ncia para avalia��o do ru�do [m]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   SPL         - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-08-09    Vers�o inicial
%1.1        Paulo Eduardo Cypriano      10-10-10    Revis�o A - duplica��o da deflex�o do flape (TO & LD)
%1.2        Paulo Eduardo Cypriano      19-01-13    Revis�o B - otimiza��o de rotinas de c�lculo das propriedades atmosf�ricas
%1.3        Paulo Eduardo Cypriano      30-03-13    Revis�o C - reordena��o dos c�lculos parciais para utiliza��o na otimiza��o
%1.4        Paulo Eduardo Cypriano      01-04-13    Revis�o D - adapta��o das vari�veis comuns para c�lculo integrado e otimiza��o


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function saida = ruidoaero(ACTGEO,HP,DISA,RH,vairp,teta,fi,R,SW,bW,FPhase)


%% Vari�veis globais
%global f
% global landinggear
% global var
% global wing
% global ht
% global vt
%global ACTGEO


%% Fatores de convers�o
deg2rad = pi/180;

f                  = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];
%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
V                   = vairp;
% SW                  = var.S;
% bW                  = wing.b;
SH                  = ACTGEO(1);
bH                  = ACTGEO(2);
SV                  = ACTGEO(3);
bV                  = ACTGEO(4);
SF                  = ACTGEO(5);
bF                  = ACTGEO(6);
deltafTO            = ACTGEO(7);                                                    % deflex�o do flape de decolagem
deltafLD            = ACTGEO(8);                                                    % deflex�o do flape de pouso
dmtyre              = ACTGEO(9);
dntyre              = ACTGEO(10);
nmgear              = ACTGEO(11);
nngear              = ACTGEO(12);
lmgear              = ACTGEO(13);
lngear              = ACTGEO(14);
nmwheel             = ACTGEO(15);
nnwheel             = ACTGEO(16);
fwtype1             = ACTGEO(17);
fslats              = ACTGEO(19);
nslots              = ACTGEO(22);
fmgear              = ACTGEO(23);
fngear              = ACTGEO(24);
hpsrc               = HP;
hprec               = ACTGEO(25);
disasrc             = DISA;
disarec             = ACTGEO(26);
r                   = R;
FTOLD               = FPhase;
if FTOLD == 1
    deltaf          = deltafTO;
else
    deltaf          = deltafLD;
end

%% Dados da atmosfera %%
fir                 = fi;
pref                = 2e-5;
%Atmosfera na fonte
atm                 = atmosfera(hpsrc,disasrc);
presssrc            = atm(5);
c                   = atm(7);
Msrc                = V/c;
rhosrc              = atm(6);
oatsrc              = atm(1);
musrc               = atm(8);
v                   = musrc/rhosrc;
%Atmosfera no receptor
atm                 = atmosfera(hprec,disarec);
pressrec            = atm(5);


%% CALCULO DO RUIDO %%
%% Conventional / Delta Wing %%
if fwtype1==1
    if teta <90
        D           = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2*(1-cos(teta*deg2rad));
    else
        D           = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2;
    end
    Sr              = f.*0.37*(SW/bW)*((V/v)*(SW/bW))^(-0.2)*((1-Msrc*cos(teta*deg2rad))/V);
    FSr             = 0.613*(10*Sr).^5.*((10*Sr).^1.5+0.5).^-4;
    k1              = 4.464e-5;
    k2              = 5;
    k3              = 0.37*SW*((V/v)*(SW/bW))^(-0.2);
    Pbw2            = k1*k3*Msrc^k2;
    p2Wing          = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    SPLWing         = 10.*log10(p2Wing)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
else
    if teta <90
        D           = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2*(1-cos(teta*deg2rad));
    else
        D           = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2;
    end
    Sr              = f.*0.37*(SW/bW)*((V/v)*(SW/bW))^(-0.2)*((1-Msrc*cos(teta*deg2rad))/V);
    FSr             = 0.485*(10*Sr).^4.*((10*Sr).^1.35+0.5).^-4;
    k1              = 4.464e-5;
    k2              = 5;
    k3              = 0.37*SW*((V/v)*(SW/bW))^(-0.2);
    Pbw2            = k1*k3*Msrc^k2;
    p2Wing          = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    SPLWing         = 10.*log10(p2Wing)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
end
a1                  = length(SPLWing);
for ia1=1:a1
    if SPLWing(ia1)<0
        SPLWing(ia1) = 0;
    end
end

%% Horizontal tail %%
D                   = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2;
Sr                  = f.*0.37*(SH/bH)*((V/v)*(SH/bH))^(-0.2)*((1-Msrc*cos(teta*deg2rad))/V);
FSr                 = 0.613*(10*Sr).^4.*((10*Sr).^1.5+0.5).^-4;
k1                  = 4.464e-5;
k2                  = 5;
k3                  = 0.37*SH*((V/v)*(SH/bH))^(-0.2);
Pbw2                = k1*k3*Msrc^k2;
p2HT                = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
SPLHT               = 10.*log10(p2HT)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
a1                  = length(SPLHT);
for ia1=1:a1
    if SPLHT(ia1)<0
        SPLHT(ia1) = 0;
    end
end

%% Vertical tail %%
D                   = 4*(cos(fir)*deg2rad)^2*(cos(teta*deg2rad/2))^2;
Sr                  = f.*0.37*(SV/bV)*((V/v)*(SV/bV))^(-0.2)*((1-Msrc*cos(teta*deg2rad))/V);
FSr                 = 0.613*(10*Sr).^4.*((10*Sr).^1.5+0.5).^-4;
k1                  = 4.464e-5;
k2                  = 5;
k3                  = 0.37*SV*((V/v)*(SV/bV))^(-0.2);
Pbw2                = k1*k3*Msrc^k2;
p2VT                = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
SPLVT               = 10.*log10(p2VT)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
a1                  = length(SPLVT);
for ia1=1:a1
    if SPLVT(ia1)<0
        SPLVT(ia1) = 0;
    end
end

%% Leading edge slats %%
if fslats==1
    D               = 4*(cos(fir*deg2rad))^2*(cos(teta*deg2rad/2))^2;
    Sr              = f.*0.37*(SW/bW)* ((V/v)*(SW/bW))^(-0.2) *((1-Msrc*cos(teta*deg2rad))/V);
    FSr             = 0.613*(2.19*Sr).^4.*((2.19*Sr).^1.5+0.5).^-4;
    k1              = 4.464e-5;
    k2              = 5;
    k3              = 0.37*SW*((V/v)*(SW/bW))^(-0.2);
    Pbw2            = k1*k3*Msrc^k2;
    p2Slat          = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    SPLSlat         = 10.*log10(p2Slat)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
    a1              = length(SPLSlat);
    for ia1=1:a1
        if SPLSlat(ia1)<0
            SPLSlat(ia1) = 0;
        end
    end
else
	SPLSlat              = zeros(size(f));
end
 
%% Single- and double-slotted trailing edge flaps %%
if nslots==1 || nslots==2
    D               = 3*(sin(deltaf*deg2rad)*cos(teta*deg2rad)+cos(deltaf*deg2rad)*sin(teta*deg2rad)*cos(fir*deg2rad))^2;
    if teta <90
        D           = D/1;
    else
        D           = D/(1-cos(teta*deg2rad))^(-4);
    end
    Sr              = (f./V)*(SF/bF)*(1-Msrc*cos(teta*deg2rad));
    FSr             = (Sr<2).*(0.0480*Sr)+(Sr>=2).*(0.1406*Sr.^-0.55);
    k1              = 2.787e-4;
    k2              = 6;
    k3              = SF*(sin(deltaf*deg2rad))^2;
    Pbw2            = k1*k3*Msrc^k2;
    p2Flap          = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    SPLFlap         = 10.*log10(p2Flap)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
else
    D               = 3*(sin(deltaf*deg2rad)*cos(teta*deg2rad)+cos(deltaf*deg2rad)*sin(teta*deg2rad)*cos(fir*deg2rad))^2;
    if teta <90
        D           = D/1;
    else
        D           = D/(1-cos(teta*deg2rad))^(-4);
    end
    Sr              = (f./V)*(SF/bF)*(1-Msrc*cos(teta*deg2rad));
    if Sr < 2
        FSr         = 0.0257*Sr;
    else
        FSr         = 0.0536*Sr.^-0.0625;
    end
    k1              = 3.509e-4;
    k2              = 6;
    k3              = SF*(sin(deltaf*deg2rad))^2;
    Pbw2            = k1*k3*Msrc^k2;
    p2Flap          = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    SPLFlap         = 10.*log10(p2Flap)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
end
a1                  = length(SPLFlap);
for ia1=1:a1
    if SPLFlap(ia1)<0
        SPLFlap(ia1) = 0;
    end
end

%% Main landing gear %%
if fmgear==1
    if nmwheel==1 || nmwheel==2
        if teta <90
            D       = 1.5*(sin(teta*deg2rad))^2;
        else
            D       = 1.5*(sin(teta*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dmtyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 13.59*Sr.^2.*(30.0+Sr.^2).^-2.25;
        k1          = 4.349e-4;
        k2          = 6;
        k3          = nmwheel*dmtyre^2;
        Pbw2        = k1*k3*Msrc^k2;
        p2G         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    else
        if teta <90
            D       = 1.5*(sin(teta*deg2rad))^2;
        else
            D       = 1.5*(sin(teta*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dmtyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 0.0577*Sr.^2.*(5.0+0.25*Sr.^2).^-1.5;
        k1          = 3.414e-4;
        k2          = 6;
        k3          = nmwheel*dmtyre^2;
        Pbw2        = k1*k3*Msrc^k2;
        p2G         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    end
    if nmwheel==1 || nmwheel==2
        if teta <90
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2;
        else
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dmtyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 5.325*Sr.^2.*(30.0+Sr.^2).^-1;
        k1          = 2.753e-4;
        k2          = 6;
        k3          = lmgear*dmtyre;
        Pbw2        = k1*k3*Msrc^k2;
        p2S         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    else
        if teta <90
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2;
        else
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dmtyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 1.280*Sr.^3.*(1.06+Sr.^2).^-3;
        k1          = 2.753e-4;
        k2          = 6;
        k3          = lmgear*dmtyre;
        Pbw2        = k1*k3*Msrc^k2;
        p2S         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    end
    p2MLG           = nmgear*(p2G+p2S);
    SPLMLG          = 10.*log10(p2MLG)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
    a1              = length(SPLMLG);
    for ia1=1:a1
        if SPLMLG(ia1)<0
            SPLMLG(ia1) = 0;
        end
    end
else
    SPLMLG          = zeros(size(f));
end

%% Nose landing gear %%
if fngear==1
    if nnwheel==1 || nnwheel==2
        if teta <90
            D       = 1.5*(sin(teta*deg2rad))^2;
        else
            D       = 1.5*(sin(teta*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dntyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 13.59*Sr.^2.*(30.0+Sr.^2).^-2.25;
        k1          = 4.349e-4;
        k2          = 6;
        k3          = nnwheel*dntyre^2;
        Pbw2        = k1*k3*Msrc^k2;
        p2G         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    else
        if teta <90
            D       = 1.5*(sin(teta*deg2rad))^2;
        else
            D       = 1.5*(sin(teta*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dntyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 0.0577*Sr.^2.*(5.0+0.25*Sr.^2).^-1.5;
        k1          = 3.414e-4;
        k2          = 6;
        k3          = nnwheel*dntyre^2;
        Pbw2        = k1*k3*Msrc^k2;
        p2G         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    end
    if nnwheel==1 || nnwheel==2
        if teta <90
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2;
        else
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dntyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 5.325*Sr.^2.*(30.0+Sr.^2).^-1;
        k1          = 2.753e-4;
        k2          = 6;
        k3          = lngear*dntyre;
        Pbw2        = k1*k3*Msrc^k2;
        p2S         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    else
        if teta <90
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2;
        else
            D       = 3*(sin(teta*deg2rad))^2*(sin(fir*deg2rad))^2*(1-cos(teta*deg2rad))^4;
        end
        Sr          = f.*(dmtyre/V)*(1-Msrc*cos(teta*deg2rad));
        FSr         = 1.280*Sr.^3.*(1.06+Sr.^2).^-3;
        k1          = 2.753e-4;
        k2          = 6;
        k3          = lngear*dmtyre;
        Pbw2        = k1*k3*Msrc^k2;
        p2S         = Pbw2*D*FSr/(4*pi*r^2*(1-Msrc*cos(teta*deg2rad))^4);
    end
    p2NLG           = nngear*(p2G+p2S);
    SPLNLG          = 10.*log10(p2NLG)+10*log10(rhosrc^2*c^4/pref^2)-20*log10(presssrc/pressrec);
    a1              = length(SPLNLG);
    for ia1=1:a1
        if SPLNLG(ia1)<0
            SPLNLG(ia1) = 0;
        end
    end
else
    SPLNLG          = zeros(size(f));
end


%% Global %%

SPLTotal            = 10.*log10(10.^(0.1*SPLWing)+10.^(0.1*SPLHT)+10.^(0.1*SPLVT)+10.^(0.1*SPLSlat)+10.^(0.1*SPLFlap)+10.^(0.1*SPLMLG)+10.^(0.1*SPLNLG));
a1                  = length(SPLTotal);
for ia1=1:a1
    if SPLTotal(ia1)<0
        SPLTotal(ia1) = 0;
    end
end

%% Atenua��o do ru�do na atmosfera %%
[ft, alfaamortt, amorttott, deltaLamort, SPLrt] = amort(oatsrc,RH,R,f);
SPLAC               = SPLTotal-deltaLamort';


%% DADOS DE SAIDA %%
saida               = [f', SPLAC'];


%% VERIFICA��ES EM DEBUG
% figure()
% semilogx(f,SPLWing,'o-b',f,SPLSlat,'o-m',f,SPLHT,'o-r',f,SPLVT,'o-g',f,SPLFlap,'s-b',f,SPLMLG,'s-m',f,SPLNLG,'s-r',f,SPLTotal,'o-k');
% grid on;
% legend('Wing noise','Slat noise','HT noise','VT noise','Flap','MLG','NLG','All Airplane');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - ESDU90023 - Airframe noise prediction
%2 - ESDU77022 - Atmospheric properties
%-------------------------------------------------------------------------------------------------------------------