%% DESCRI��O E AUTORIA %%
%motor    - Rotina para modelar o funcionamento de um motor tipo turbofan
%autores  - Vitor Loureiro
%           Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   Altd [m] - Altitude
%                   Machd
%                   fanpr    - Raz�o de press�es no fan
%                   opr      - Raz�o de press�o total no motor
%                   bpr      - Raz�o de deriva��o do fan (by-pass ratio)
%                   maneted  - posi��o da manete de tra��o
%                   dfan [m] - di�metro do fan
%Dados de saida  : 
%                   tracaonewt [N]  - Tra��o l�quida
%                   FF [kg/h]       - Vaz�o de combust�vel
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                                               DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Vitor Loureiro                                      XX-11-08    Vers�o original (noiseng)
%2.0        Paulo Eduardo Cypriano da Silva Magalhaes           7-08-09     Inser��o de coment�rios
%                                                                           Organiza��o da rotina 
%                                                                           Organiza��o dos dados de sa�da para uso nas rotinas de ru�do
%                                                                           Remo��o da sa�da de dados em arquivo


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [tracaonewt,FF] = motor(Altd,Machd,fanpr,opr,bpr,maneted,diamfan,TIT)


%% Vari�veis globais
%global var
global EINOx EICO2 EIH2O EISO2                                              % �ndices de emiss�es
global engine1 engine2 engine3 engine4 engine5 engine6 engine7
global N1ref N2ref
%global R                                                                    % Constante universal dos gases []

R = 287.2933;   
%% DEFINI��ES INICIAIS
%% Entrada de dados do motor
afan                = pi*(diamfan^2)/4;                                     % �rea do fan [m�]
prfan               = fanpr;                                                % raz�o de press�o do fan
prc                 = opr/fanpr;                                           % taxa de compress�o fornecida pelo compressor
prcomb              = 0.99;                                                  % raz�o de press�o do combustor
tt4                 = TIT;                                                  % temperatura na entrada da turbina [K]
PC                  = 43260000;                                             % Poder calor�fico (J/kg) 
%% Defini��o do ponto de projeto
Mach                = 0;                                                    % Velocidade
Alt                 = 0;                                                    % Altitude [m]
manete              = 1.0;                                                  % Regime de opera��o
%% Efici�ncias no ponto de projeto
eta(1:15)           = 1;                                                    % inicializa o vetor de eficic�ncias
eta(2)              = 0.999;                                                % inlet (inlet pressure recovery)
eta(3)              = 0.959;                                                % compressor
eta(4)              = 0.984;                                                % c�mara de combust�o
eta(5)              = 0.98;                                                 % turbina
eta(7)              = 0.99;                                                 % nozzle
eta(13)             = 0.90;                                                 % fan
%% Raz�es de temperatura
trat(1:15)          = 1;                                                    % inicializa o vetor de raz�es de temperatura


%% PONTO DE PROJETO (ON-DESIGN)
%% AN�LISE AEROTERMODIN�MICA
% Raz�es de press�o
prat(2)             = eta(2);                                               % raz�o de press�o = efici�ncia do inlet
prat(3)             = prc;                                                  % raz�o de press�o no compressor
prat(4)             = prcomb;                                               % raz�o de press�o do combustor
prat(13)            = prfan;                                                % raz�o de press�o no fan
% Escoamento n�o perturbado
gama                = 1.4;                                                  % gamma do programa
atm                 = atmosfera(Alt/0.3048,0);                              % propriedades da atmosfera
T_0                 = atm(1);                                               % temperatura [K]
P_0                 = atm(5)*1000;                                          % press�o [Pa]
T0_0                = (1 + (gama-1)/2*Mach^2)*T_0;                          % temperatura total
P0_0                = P_0*(T0_0/T_0)^(gama/(gama-1));                       % press�o total
a0                  = sqrt(gama*R*T_0);                                     % velocidade do som
u0                  = Mach*a0;                                              % velocidade de v�o
% Raz�es de temperatura
trat(1:15)          = 1;
% Entrada de ar -----------------------------------------------------------
P0_1                = P0_0;                                                 %press�o total na entrada da nacele
T0_1                = T0_0;                                                 %temperatura total na entrada da nacele
% Inlet -------------------------------------------------------------------
T0_2                = T0_1;                                                 %press�o total na entrada do fan
P0_2                = P0_1*prat(2);                                         %temperatura total na entrada do fan
% Fan ---------------------------------------------------------------------
gama2               = engine_getgamma(T0_2);                                       %raz�o de calores espec�ficos
cp2                 = engine_getcp(T0_2);                                          %calor espec�fico a press�o constante
del_h_fan           = cp2*T0_2/eta(13)*((prat(13))^((gama2-1)/gama2)-1);    %varia��o de entalpia atrav�s do fan
del_t_fan           = del_h_fan/cp2;                                        %varia��o de temperatura atrav�s do fan
T0_13               = T0_2 + del_t_fan;                                     %temperatura total na sa�da do fan
P0_13               = P0_2 * prat(13);                                      %press�o total na sa�da do fan
trat(13)            = T0_13 / T0_2;                                         %raz�o de temperaturas entre entrada e sa�da do fan
% Compressor --------------------------------------------------------------
taurR               = T0_0;
piclR               = prfan;
T0R                 = T_0;
gama13              = engine_getgamma(T0_13);                                      % raz�o de calores espec�ficos
cp13                = engine_getcp(T0_13);                                         % calor espec�fico a press�o constante
del_h_c             = cp13*T0_13/eta(3)*(prat(3)^((gama13-1)/gama13)-1);    % varia��o de entalpia atrav�s do compressor
del_t_c             = del_h_c/cp13;                                         % varia��o de temperatura atrav�s do compressor
T0_3                = T0_13 + del_t_c;                                      % temperatura total na sa�da do compressor
P0_3                = P0_13 * prat(3);                                      % press�o total na sa�da do compressor
trat(3)             = T0_3 / T0_13;                                         % raz�o de temperaturas entre entrada e sa�da do compressor
cp3                 = engine_getcp(T0_3);                                          % calor espec�fico a press�o constante
tauclR              = trat(13);
pichR               = prc;
% Combustor ---------------------------------------------------------------
T0_4                = manete * tt4;                                         % temperatura total na sa�da da c�mara de combust�o
P0_4                = P0_3 * prat(4);                                       % press�o total na sa�da da c�mara de combust�o
trat(4)             = T0_4 / T0_3;                                          % raz�o de temperaturas entre entrada e sa�da da c�mara de combust�o
% Turbina de alta  --------------------------------------------------------
gama4               = engine_getgamma(T0_4);                                       % raz�o de calores espec�ficos
cp4                 = engine_getcp(T0_4);                                          % calor espec�fico a press�o constante
del_h_ht            = del_h_c;                                              % varia��o de entalpia atrav�s da turbina (igual � do compressor)
del_t_ht            = del_h_ht / cp4;                                       % varia��o de temperatura atraves da turbina
T0_5                = T0_4 - del_t_ht;                                      % temperatura total na sa�da da turbina de alta
prat(5)             = (1-del_h_ht/(cp4*T0_4*eta(5)))^(gama4/(gama4-1));     % raz�o de press�es entre entrada e sa�da da turbina de alta
P0_5                = P0_4 * prat(5);                                       % press�o total na sa�da da turbina de alta
trat(5)             = T0_5 / T0_4;                                          % raz�o de temperaturas entre entrada e sa�da da turbina de alta
% Turbina de alta  --------------------------------------------------------
gama5               = engine_getgamma(T0_5);                                       % raz�o de calores espec�ficos
cp5                 = engine_getcp(T0_5);                                          % calor espec�fico a press�o constante
del_h_lt            = (1 + bpr)*del_h_fan;                                  % varia��o de entalpia atrav�s da turbina (relacionada � do fan)
del_t_lt            = del_h_lt / cp5;                                       % varia��o de temperatura atrav�s da turbina
T0_15               = T0_5 - del_t_lt;                                      % temperatura total na sa�da da turbina de baixa
prat(15)            = (1-del_h_lt/(cp5*T0_5*eta(5)))^(gama5/(gama5-1));     % raz�o de press�es entre entrada e sa�da da turbina de baixa
P0_15               = P0_5 * prat(15);                                      % press�o total na sa�da da turbina de baixa
trat(15)            = T0_15 / T0_5;                                         % raz�o de temperaturas entre entrada e sa�da da turbina de baixa
% Motor completo
epr                 = prat(2)*prat(3)*prat(4)*prat(5)*prat(13)*prat(15);    % raz�o global de press�o no motor
etr                 = trat(2)*trat(3)*trat(4)*trat(5)*trat(13)*trat(15);    % raz�o global de temperatura no motor
%% AN�LISE GEOM�TRICA
acore               = afan/(bpr+1);                                         % �rea frontal do compressor (entrada do n�cleo) [m�]
%  ---- a8rat = a8 / acore ---- 
a8rat               = min(0.75*sqrt(etr/trat(2))/epr*prat(2),1.0);          % raz�o entre a �rea do n�cleo e a �rea do fan
% OBS: divide por prat(2) pois ele n�o � considerado no c�lculo do EPR e
% ETR acima no applet original
a8                  = a8rat * acore;                                        % �rea da tubeira (sa�da do n�cleo) [m�]
a4                  = a8 * prat(5)*prat(15)/sqrt(trat(5)*trat(15));         % �rea da turbina de alta [m�]
a4p                 = a8 * prat(15)/sqrt(trat(15));                         % �rea da turbina de baixa [m�]
a8d                 = a8;

%% VERIFICA��O DA CONDI��O DE PROJETO
if ((Mach==Machd) && (Alt==Altd) && (manete==maneted))
    designpoint     = 1;
else
    designpoint     = 0;
end

%% PONTO DE OPERA��O (OFF-DESIGN)
taurA               = T0_0;
piclA               = prat(13);
T0A                 = T_0;
tauclA              = trat(13);
pichA               = prat(3);
%% Ponto de opera��o
%% Verifica��o do ponto de opera��o
if ~designpoint
    %% AN�LISE AEROTERMODIN�MICA
    Mach            = Machd;                                                % n�mero de Mach
    Alt             = Altd;                                                 % altitude (m)  (38000 ft)
    manete          = maneted;                                              % posi��o da manete
    % Escoamento n�o perturbado -------------------------------------------
    gama            = 1.4;                                                  % gamma do programa
    atm             = atmosfera(Alt/0.3048,0);                              % propriedades da atmosfera
    T_0             = atm(1);                                               % temperatura [K]
    P_0             = atm(5)*1000;                                          % press�o [Pa]
    T0_0            = (1 + (gama-1)/2*Mach^2)*T_0;                          % temperatura total
    P0_0            = P_0*(T0_0/T_0)^(gama/(gama-1));                       % press�o total
    a0              = sqrt(gama*R*T_0);                                     % velocidade do som
    u0              = Mach*a0;                                              % velocidade de v�o
    % Entrada de ar -------------------------------------------------------
    P0_1            = P0_0;                                                 % press�o total na entrada da nacele
    T0_1            = T0_0;                                                 % temperatura total na entrada da nacele
    % Inlet  --------------------------------------------------------------
    T0_2            = T0_1;                                                 % temperatura total na entrada do fan
    P0_2            = P0_1*prat(2);                                         % press�o total na entrada do fan
    % Combustor -----------------------------------------------------------
    T0_4            = manete*tt4;                                           % temperatura total na sa�da da c�mara de combust�o
    gama4           = engine_getgamma(T0_4);                                       % raz�o de calores espec�ficos
    cp4             = engine_getcp(T0_4);                                          % calor espec�fico a press�o constante
    % Turbina de alta -----------------------------------------------------
    trat(5)         = fzero(@(x) engine_achatrat(x,a4p/a4,eta(5),-gama4/(gama4-1)),1.0);   
                                                                            % raz�o de temperaturas entre entrada e sa�da da turbina de alta (c�lculo iterativo)
    T0_5            = T0_4*trat(5);                                         % temperatura total na sa�da da turbina de alta
    gama5           = engine_getgamma(T0_5);                                       % raz�o de calores espec�ficos
    cp5             = engine_getcp(T0_5);                                          % calor espec�fico a press�o constante
    del_t_ht        = T0_5 - T0_4;                                          % varia��o de temperatura atraves da turbina de alta
    del_h_ht        = del_t_ht*cp4;                                         % varia��o de entalpia atrav�s da turbina de alta
    prat(5)         = (1-(1-trat(5))/eta(5))^(gama4/(gama4-1));             % raz�o de press�es entre entrada e sa�da da turbina de alta
    % Turbina de baixa ----------------------------------------------------
    trat(15)        = fzero(@(x) engine_achatrat(x,a8d/a4p,eta(5),-gama5/(gama5-1)),1.0); 
                                                                            % raz�o de temperaturas entre entrada e sa�da da turbina de baixa (c�lculo iterativo)
    T0_15           = T0_5 * trat(15);                                      % temperatura total na sa�da da turbina de baixa
    gama15          = engine_getgamma(T0_15);                                      % raz�o de calores espec�ficos
    cp15            = engine_getcp(T0_15);                                         % calor espec�fico a press�o constante
    del_t_lt        = T0_15 - T0_5;                                         % varia��o de temperatura atraves da turbina de baixa
    del_h_lt        = del_t_lt*cp5;                                         % varia��o de entalpia atrav�s da turbina de baixa
    prat(15)        = (1-(1-trat(15))/eta(5))^(gama5/(gama5-1));            % raz�o de press�es entre entrada e sa�da da turbina de baixa
    % Fan  ----------------------------------------------------------------
    del_h_fan       = del_h_lt / (1+bpr);                                   % varia��o de entalpia atrav�s do fan
    del_t_fan       = -del_h_fan / cp2;                                     % varia��o de temperatura atrav�s do fan
    T0_13           = T0_2 + del_t_fan;                                     % temperatura total na sa�da do fan
    gama13          = engine_getgamma(T0_13);                                      % raz�o de calores espec�ficos
    cp13            = engine_getcp(T0_13);                                         % calor espec�fico a press�o constante
    trat(13)        = T0_13 / T0_2;                                         % raz�o de temperaturas entre entrada e sa�da do fan
    prat(13)        = (1-(1-trat(13))*eta(13))^(gama2/(gama2-1));           % raz�o de press�es entre entrada e sa�da do fan
    taurA           = T0_0;
    piclA           = prat(13);
    T0A             = T_0;
    % Compressor ----------------------------------------------------------
    del_h_c         = del_h_ht;                                             % varia��o de entalpia atrav�s do fan
    del_t_c         = -del_h_c / cp13;                                      % varia��o de temperatura atrav�s do compressor
    T0_3            = T0_13 + del_t_c;                                      % temperatura total na sa�da do compressor
    gama3           = engine_getgamma(T0_3);                                       % raz�o de calores espec�ficos
    cp3             = engine_getcp(T0_3);                                          % calor espec�fico a press�o constante
    trat(3)         = T0_3 / T0_13;                                         % raz�o de temperaturas entre entrada e sa�da do compressor
    prat(3)         = (1-(1-trat(3))*eta(3))^(gama13/(gama13-1));           % raz�o de press�es entre entrada e sa�da do compressor
    tauclA          = trat(13);
    pichA           = prat(3);
    % C�mara de combust�o -------------------------------------------------
    trat(4)         = T0_4 / T0_3;                                          % raz�o de temperaturas entre entrada e sa�da da c�mara de combust�o
    % Press�es totais -----------------------------------------------------
    P0_13           = P0_2 * prat(13);                                      % press�o total na sa�da do fan
    P0_3            = P0_13 * prat(3);                                      % press�o total na entrada do compressor
    P0_4            = P0_3 * prat(4);                                       % press�o total na sa�da do compressor / entrada da c�mara de combust�o
    P0_5            = P0_4 * prat(5);                                       % press�o total na sa�da da c�mara de combust�o / entrada da turbina de alta
    P0_15           = P0_5 * prat(15);                                      % press�o total na sa�da da turbina de baixa
    % motor completo ------------------------------------------------------
    epr             = prat(2)*prat(3)*prat(4)*prat(5)*prat(13)*prat(15);    % raz�o global de press�o no motor
    etr             = trat(2)*trat(3)*trat(4)*trat(5)*trat(13)*trat(15);    % raz�o global de temperatura no motor
end

%% PERFORMANCE DO MOTOR
% Constantes --------------------------------------------------------------
gamae               = engine_getgamma(T0_5);                                       % gamma de sa�da (T0_5 ???)
Re                  = (gamae-1)/gamae*engine_getcp(T0_5);                          % Constante R de sa�da
g                   = 32.2;
P0_8                = P0_0 * epr;                                           % press�o total na tubeira
T0_8                = T0_0 * etr;                                           % temperatura total na sa�da da tubeira
fact2               = -0.5*(gamae+1)/(gamae-1);                             % constante 2
fact1               = (1 + 0.5*(gamae-1))^fact2;                            % constante 1
mdot                = a8*sqrt(gamae)*P0_8*fact1/sqrt(T0_8*Re);              % fluxo m�ssico no n�cleo do motor [kg/s]

N1ratio             = ((T0A*taurA*piclA^((gama-1)/gama)-1)/(T0R*taurR*piclR^((gama-1)/gama)-1))^0.5;
N1A                 = N1ratio*N1ref;
N2ratio             = ((T0A*taurA*tauclA*pichA^((gama-1)/gama)-1)/(T0R*taurR*tauclR*pichR^((gama-1)/gama)-1))^0.5;
N2A                 = N2ratio*N2ref;

% Contribui��o do n�cleo --------------------------------------------------
npr                 = max(P0_8 / P_0,1);                                    % defini��o da raz�o entre a press�o de sa�da do motor e a press�o ambiente
fact1               = (gamae-1)/gamae;                                      % constante 1
u0_8                = sqrt((2*R/(gamae-1))*(gamae*T0_8*eta(7))*(1-(1/npr)^fact1));
                                                                            % velocidade de sa�da dos gases do n�cleo do motor [m/s]
if (npr<=1.893)
    pexit           = P_0;
else
    pexit           = 0.52828*P0_8;
end
fgroscore           = u0_8 + (pexit-P_0)*a8/mdot/g;                         % tra��o espec�fica bruta do n�cleo do motor [N/(kg/s)]
% Contribui��o do Fan -----------------------------------------------------
snpr                = P0_13 / P_0;
fact1               = (gama-1)/gama;
u0_13               = sqrt(2*R/fact1*T0_13*eta(7)*(1-1/snpr^fact1));
if (snpr<=1.893)
    pfexit          = P_0;
else
    pfexit          = 0.52828*P0_13;
end
fgrosfan            = bpr*u0_13 + (pfexit-P_0)*bpr*acore/mdot/g;            % tra��o espec�fica bruta do fan do motor [N/(kg/s)]
% Tra��o brutal total
fgros               = fgroscore+fgrosfan;                                   % tra��o espec�fica bruta total do motor [N/(kg/s)]
% Arrasto do motor
dram                = u0*(1+bpr);                                           % arrasto do motor [N/(kg/s)]
%% Desempenho espec�fico do motor
fnet                = fgros - dram;                                         % tra��o l�quida do motor [N/(kg/s)]
fuel_air            = (trat(4)-1)/(eta(4)*PC/(cp3*T0_3)-T0_4/T0_3);         % raz�o m�ssica entre combust�vel e ar na c�mara de combust�o

%% ESTIMATIVA DE PESO DO MOTOR
ncomp               = min(15,round(1+prc/1.5));                             % n�mero de est�gios do compressor
nturb               = 2 + floor(ncomp/4);                                   % n�mero de est�gios da turbina
dfan                = 293.02;                                               % densidade do material do fan
dcomp               = 293.02;                                               % densidade do material do compressor
dburn               = 515.2;                                                % densidade do material da c�mara de combust�o
dturb               = 515.2;                                                % densidade do material da turbina
conv1               = 10.7639104167;                                        % fator de convers�o: m� para ft�
weight              = 4.4552*0.0932*acore*conv1*sqrt(acore*conv1/6.965)*((1+bpr)*dfan*4 + dcomp*(ncomp-3) + 3*dburn + dturb*nturb);             
                                                                            % peso do motor [N]    


%% SA�DA DOS RESULTADOS
weightkgf           = weight/9.8;                                           % peso do motor [kgf]
tracaokgf           = fnet*mdot/9.8;                                        % tra��o do motor [kgf]
tracaonewt          = fnet*mdot;                                            % tracao liquida do motor [N]
FF                  = fuel_air*mdot*3600;                                   % vaz�o de combust�vel [kg/h] (corre��o de 5% baseado em dados de motores reais)
engine1             = [tracaonewt FF 0 0 0 0 0 0 weightkgf]';               % par�metros de desempenho do motor [N kg/h rpm rpm]
engine2             = [P0_0 P0_1 P0_2 P0_3 P0_4 P0_5 P0_8 P0_13 P0_15]';    % press�es totais no motor [Pa]
engine3             = [T0_0 T0_1 T0_2 T0_3 T0_4 T0_5 T0_8 T0_13 T0_15]';    % temperaturas totais no motor [K]
engine4             = [acore a8 a8*bpr 0 0 0 0 0 0]';                       % �rea de sa�da do n�cleo do motor [m�]
engine5             = [mdot mdot*bpr 0 0 0 0 0 0 0]';                       % vaz�es m�ssicas [kg/s]
engine6             = [u0_8 u0_13 0 0 0 0 0 0 0]';                          % velocidade dos gases na sa�da [m/s]
engine7             = [N1A  N2A   0 0 0 0 0 0 0]';                          % rota��o no ponto de opera��o [rpm]


%% ESTIMATIVA DE EMISS�ES DO MOTOR
% Convers�o de unidades
P0_3p               = P0_3/6894.757293;
T0_3R               = T0_3*9/5;
T0_4R               = T0_4*9/5;
% NOx
a0                  = 0.004194;
a1                  = 439;
a2                  = 0.37;
a3                  = 1471;
a4                  = 345;
EINOx               = a0*T0_4R*(P0_3p/a1)^a2*exp((T0_3R-a3)/a4);            % �ndice de emiss�o NOx [g/kg fuel]
% CO2
EICO2               = 3.155;                                                % �ndice de emiss�o CO2 [g/kg fuel]
% H2O
EIH2O               = 1.240;                                                % �ndice de emiss�o H2O [g/kg fuel]
% SO2
EISO2               = 0.800;                                                % �ndice de emiss�o SO2 [g/kg fuel]


%% IMPRESS�O
% if 0
% clc
% fprintf('Turbofan: \n');
% fprintf('  Bypass Ratio  = %3.1f \n',bpr);
% fprintf('  Diameter  = %5.3f m \n',sqrt(4*afan/pi));
% fprintf('  Estimated Weight  = %8.3f N \n',weight);
% fprintf(' \n');
% 
% fprintf('Flight Conditions: \n');
% fprintf('  Mach = %3.2f,  V0 =%4.0f km/h \n',Mach,u0*3.6);
% fprintf('  Alt =%6.0f m \n',Alt);
% fprintf('  p0 =%7.3f,  pt0 =%7.3f kPa \n',P_0/1000,P0_0/1000);
% fprintf('  T0 =%4.0f,  Tt0 =%4.0f K  \n',T_0,T0_0);
% fprintf('   \n');
% 
% fprintf('Engine Thrust and Fuel Flow:   \n');
% fprintf('  F gross = %5.0f,  D ram =%5.0f,  F net = %5.0f N \n',fgros*mdot,dram*mdot,fnet*mdot);
% fprintf('  Fuel Flow =%4.0f kg/hr \n',FF);
% fprintf('  Thrust/Weight =%5.3f \n',fnet*mdot/weight);
% fprintf('   \n');
% 
% fprintf('Engine Performance   \n');
% fprintf('  Throttle  = %4.1f %%, core airflow (m)  =%7.3f kg/s \n',manete*100,mdot);
% fprintf('  EPR =%6.3f,  ETR =%6.3f,  fuel/air = %6.3f  \n',epr,etr,fuel_air);
% fprintf('  Nozzle Pressure Ratio =%6.3f,  Vexit = %4.0f m/s \n',npr,uexit);
% fprintf('  Fg/m =%9.3f,  Dram/m =%7.2f,  Fn/m =%9.3f N/(kg/s)  \n',fgros,dram,fnet);
% fprintf('   \n');
% 
% fprintf('Component Performance:  \n');
% fprintf('   Variable     Inlet   Fan     Comp    Burn    H-Tur   L-Tur   Noz     Exhast\n');
% fprintf(' Efficiency     ');
% fprintf('%-8.3g',eta(2),eta(13),eta(3),eta(4),eta(5),eta(5),eta(7));
% fprintf('\n');
% fprintf(' Press Rat      ');
% fprintf('%-8.3g',prat(2),prat(13),prat(3),prat(4),prat(5),prat(15),prat(7));
% fprintf('\n');
% fprintf(' Press - p      ');
% fprintf('%-8.3f',P0_2/1000,P0_13/1000,P0_3/1000,P0_4/1000,P0_5/1000,P0_15/1000,P0_8/1000);
% fprintf('\n');
% fprintf(' Temp Rat       ');
% fprintf('%-8.3g',trat(2),trat(13),trat(3),trat(4),trat(5),trat(15),trat(7));
% fprintf('\n');
% fprintf(' Temp - T       ');
% fprintf('%-8.0f',T0_2,T0_13,T0_3,T0_4,T0_5,T0_15,T0_8);
% fprintf('\n');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - 