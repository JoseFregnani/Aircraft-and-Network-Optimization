function calibraempyweight()
clc
ft2m     = 0.3048;
kg2lb   = 2.2046;
%
LB=[-0.5 -0.25 0.10  0.01  -0.010 0.001];
UB=[0.50 -0.10 0.60  0.10  -0.001 0.15];
 
 %Minimizes coordinate erros to find out remaining sobieski airfoil parameters
options=gaoptimset('Generations',750,'PopulationSize',50,...
    'CrossoverFraction',0.4,'TolFun',1.e-11,'UseParallel','always',...
    'MutationFcn',@mutationadaptfeasible,'HybridFcn',@fmincon);
 %'MutationFcn',@mutationadaptfeasible,'PlotFcns',{@gaplotbestf,@gaplotbestindiv});

 
 
 X = ga({@wemptycalib},6,[],[],[],[],LB,UB,[],options)
 
C0=X(1);
C1=X(2);
C2=X(3);
C3=X(4);
C4=X(5);
C5=X(6);
 % TEste E-175

a=0.32;
b=0.66;
MMO = 0.77;
arw = 8.6;
W2  = 37500;
W2lb = W2*kg2lb;
T0=2*14200;
sw = 72.72/(ft2m*ft2m);
sweep14=23.5;
auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
% wefrac=a+b*((W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5)
OEW=W2*wefrac

% TEste F100
T0=2*13850;
MMO =0.77;
sw = 93.5/(ft2m*ft2m);
W2 = 43090;
W2lb = W2*kg2lb;
arw = 8.43;
sweep14=17.5;
auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
%wefrac=a+b*((W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5)
OEW=W2*wefrac

%Teste CRJ-200
MMO = 0.81;
arw = 9.3;
W2  = 23247;
W2lb = W2*kg2lb;
T0=2*8729;
sw = 48.25/(ft2m*ft2m);
sweep14 = 24.54;
auxsweep = (1+sweep14/35);
%wefrac=a+b*((W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
OEW=W2*wefrac 

function erro=wemptycalib(X)
ft2m     = 0.3048;
kg2lb   = 2.2046;
% Empty-to-MTOW ratio calculation
% Reference: Raymer, Aircraft Design, a Conceptual Approach
% INPUT:
% arw = wing aspect ratio
% sw  = wing area [ft2]
% MMO = Maximum operating Mach number;
% W2lb = Maximum Takeoff weight (lb)
% T0   = Maximum takeoff thrust (all engines) [lbf]
%

a=0.32;
b=0.66;
% C1=-0.13;
% C2=0.30;
% C3=0.06;
% C4=-0.05;
% C5=0.05;
C0=X(1);
C1=X(2);
C2=X(3);
C3=X(4);
C4=X(5);
C5=X(6);
%
%Fokker 100
T0=2*13850;
MMO =0.77;
sw = 93.5/(ft2m*ft2m);
W2 = 43090;
W2lb = W2*kg2lb;
arw = 8.43;
sweep14 = 17.5;
auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
OEW=W2*wefrac;
erro1=abs(OEW-24375);

% E-175
MMO = 0.82;
arw = 8.6;
W2  = 37500;
W2lb = W2*kg2lb;
T0=2*14200;
sw = 72.72/(ft2m*ft2m);
sweep14 = 23.5;
auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
OEW=W2*wefrac;
erro2=abs(OEW-21300);

% CRJ-200 ER
MMO = 0.81;
arw = 9.3;
W2  = 23247;
W2lb = W2*kg2lb;
T0=2*8729;
sw = 48.25/(ft2m*ft2m);
sweep14 = 24.54;
auxsweep = (1+sweep14/35);
wefrac=a+b*((auxsweep^C0)*(W2lb^C1)*(arw^C2)*((T0/W2lb)^C3)*((W2lb/sw)^C4)*MMO^C5);
OEW=W2*wefrac;
erro3=abs(OEW-14016);


erro=erro1+erro2+erro3;

