function cfval=cfflatpla(Re,Mach,h,ISADEV)

xt        = 0.05;
[TR, PR, DR, a] = atmos(h,ISADEV);
T = TR*288.15;

    Rex = Re * xt;
    if Rex <= 0
       Rex = .0001;
    end
    theta = .671*xt/sqrt(Rex);
    xeff = (27.78*theta*(Re^.2))^1.25;
    Rext = Re*(1-xt+xeff);
    Cfturb = 0.455/((log10(Rext))^2.58); 
    Cflam = 1.328/sqrt(Rex);
    Cfstart = 0.455/((log10(Re*xeff))^2.58);
    cfval = Cflam*xt + Cfturb*(1-xt+xeff) - Cfstart*xeff;
    Tw = 1.0 + .178*Mach*Mach;
    T1 = 1.0 + .035*Mach*Mach + .45*(Tw-1);
    mu1 = (T1^1.5) * (T+216)/(T*T1+216);
    R1 = 1/(mu1*T1);
    CfRatio = 1/(T1*(R1^.2));

cfval = cfval*CfRatio;        