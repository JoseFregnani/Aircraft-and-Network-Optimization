clc

lb     =[15  7.0 0.3 70  75 1.30 5.0 25 -5.0 0.32 ];
ub     =[35 10.0 0.5 130 85 1.50 6.5 30 -2.0 0.40 ];
initpop=[24  8.0 0.4 80  80 1.40 5.5 28 -4.0 0.35 ];

options = gaoptimset('InitialPopulation',initpop,'PopulationSize',20);

[x,fval,exitflag,output] = ga(@Network2,10,[],[],[],[],lb,ub,[],[],options)

x
fval
exitflag
output



