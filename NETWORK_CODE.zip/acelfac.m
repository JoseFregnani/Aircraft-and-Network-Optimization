function [facCAS,facMach]=acelfac(M,h,ISADEV)

TROPO=36089;
phi=((1+0.2*M^2)^3.5-1)/(0.7*M^2*((1+0.2*M^2)^2.5));
[TRISA, PRISA, DRISA, a] = atmos(h,0);
[TR, PR, DR, a] = atmos(h,ISADEV);

if (h>=TROPO)
    facCAS=0.7*(M^2)*phi;
    facMach=0;
elseif (h<TROPO)
    facCAS=0.7*(M^2)*(phi-0.190263*(TRISA/TR));
    facMach=-0.13318*(M^2)*(TRISA/TR);
end

    