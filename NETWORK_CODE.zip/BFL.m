function S=BFL(TOW,wS,MAXRATE,BPR,ISADEV,elev,CLMAX_TO)

% Torenbeek (1996).Synthesis fo Subsonic Airplane Design. Chapter 6, Design For Performance (Pg.169, Eq.5-89)

% Constants
lb2kg=0.45359237;
Gamma2=0.024; % Minimum 2nd segmment performance OEI (2 eng aircraft)
Ht0=10.7;% 35ft screen height
ne=0.8; % Thrust altitude factor
mu_static=0.02;% dry runway friction coeficient

% Calculation 
CLmax=CLMAX_TO;
h=elev;
[~, ~, sigma, ~] = atmos(h,ISADEV);
rho=1.22*sigma;
Tmax=0.95*MAXRATE*(sigma^ne)*lb2kg;
Tavg=0.75*((5+BPR)/(4+BPR))*(2*Tmax);
mu  =0.01*CLmax+mu_static;
CL2 =.694*CLmax;
DeltaGamma2=Gamma2-0.024;
DeltaSt0=200;
%
S1=0.863*(((TOW/wS)/(rho*CL2))+Ht0);
S2=(1/((Tavg/TOW)-mu)+2.7);
S3=DeltaSt0/sqrt(sigma);
S=(1/(1+2.3*DeltaGamma2))*S1*S2+S3;

