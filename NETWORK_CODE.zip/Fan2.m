%% DESCRI��O E AUTORIA %%
%Fan2     - Rotina para estimativa do ruido de fan de motores a rea��o
%autores  - Daniel ...
%           Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   HP          - altitude-press�o [ft]
%                   DISA        - varia��o da temperatura em rela��o � ISA [�C]
%                   RH          - relative humidity [%]
%                   vairp       - velocidade do avi�o [m/s]
%                   teta        - dire��o para avalia��o do ru�do [deg]
%                   fi          - eleva��o para avalia��o do ru�do [deg]
%                   R           - dist�ncia para avalia��o do ru�do [m]
%                   dfan        - di�metro do fan [m]
%                   ratT        - raz�o de temperaturas no fan
%                   mponto      - vaz�o m�ssica atrav�s do fan [kg/s]
%                   nfan        - velocidade angular do fan [rpm]
%                   MTRd        - n�mero de Mach da ponta do fan, ponto de projeto
%                   nrotor      - n�mero de palhetas do rotor
%                   nstator     - n�mero de palhetas do estator
%                   RSS         - espa�amento relativo entre rotor e estator
%                   IGV         - flag para inlet guide vanes (0 = ausente / 1 = presente)
%Dados de saida  : 
%                   f           - freq��ncias-padr�o [Hz]
%                   OASPLENG    - n�vel de ru�do em rela��o � refer�ncia [dB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA            DESCRI��O DAS MODIFICA��ES
%1.0        Daniel ...                                  Vers�o original (Bocal)
%2.0        Paulo Eduardo Cypriano      21-08-09        Remo��o da plotagem de gr�ficos
%3.0        Paulo Eduardo Cypriano      19-01-13        Uniformiza��o da rotina das propriedades atmosfericas
%4.0        Paulo Eduardo Cypriano      18-03-13        Corre��es nos c�lculos


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [ft ruidoFant] = Fan2(HP,DISA,RH,vairp,teta,fi,R,dfan,ratT,mponto,nfan,MTRd,nrotor,nstat,RSS,IGV)


%% Vari�veis globais
%global f
f                   = [50 63 80 100 125 160 200 250 315 400 500 630 800 1000 1250 1600 2000 2500 3150 4000 5000 6300 8000 10000];


%% Fatores de convers�o
m2ft= 3.28084;


%% Tabelas para interpola��o
f1                  = [44.7 56.2 70.7 89.1 112 141 178 224 282 355 447 562 708 891 1122 1413 1778 2239 2818 3548 4467 5623 7079 8913];
f2                  = [56.2 70.7 89.1 112 141 178 224 282 355 447 562 708 891 1122 1413 1778 2239 2818 3548 4467 5623 7079 8913 11220];
F2cb                = [-9.5  -8.5  -7   -5    -2    0     0     -3.5  -7.5  -9    -9.5  -10   -10.5 -11   -11.5 -12   -12.5 -13   -13.5];
tetacb              = [0     10    20   30    40    50    60    70    80    90    100   110   120   130   140   150   160   170   180];
F3blent             = [-2  -1  0   0   0   -2  -4.5 -7.5  -11  -15  -19  -25  -31  -37  -43  -49  -55  -61  -67];
tetablent           = [0   10  20  30  40  50  60   70    80   90   100  110  120  130  140  150  160  170  180];
F3dsent             = [-3.00 -1.50  0.000 0.000 0.000 -1.20 -3.50 -6.80 -10.5 -14.5 -19.0 -23.5 -28.0 -32.5 -37.0 -41.5 -46.0 -50.5 -55.0];
tetadsent           = [0     10     20    30    40    50    60    70    80    90    100   110   120   130   140   150   160   170   180];

F3bldesc            = [-15.8 -11.5 -8 -5 -2.7 -1.2 -0.3 0 -2 -6 -10 -15 -20];
tetabldesc          = [60 70 80 90 100 110 120 130 140 150 160 170 180];

tetadsdesc          = [60 70 80 90 100 110 120 130 140 150 160 170 180];
F3dsdesc            = [-15 -11 -8 -5 -3 -1 0 0 -2 -5.5 -9 -13 -18];


%% CORPO DA FUN��O %%
%% Manipula��o de dados de entrada %%
v0                  = vairp;                                                % Velocidade da aeronave [m/s]
radialdistance      = R;                                                    % dist�ncia para avalia��o do ru�do [m]

%% Dados da atmosfera %%
atm                 = atmosfera(HP*m2ft,DISA);                              % propriedades da atmosfera
T                   = atm(1);                                               % temperatura ambiente [K]
vsom                = atm(7);                                               % velocidade do som [m/s]


%% C�lculos iniciais %%
M0                  = v0/vsom;                                              % n�mero de Mach da aeronave
MTR                 = sqrt(M0^2+(nfan*pi/30*dfan/2/vsom)^2);
delta               = abs(MTR/(1-nstat/nrotor));


%% C�lculo do SPL global: %%
deltaT              = ratT*T-T;
mponto0             = 0.453;
deltaT0             = 0.555;
% deltaT0             = 288.15;
SPL                 = 20*log10(deltaT/deltaT0)+10*log10(mponto/mponto0);


%% Ruido de entrada do FAN %%
%% Ru�do banda larga %%
fb                  = nfan*nrotor/60;                                       % frequencia fundamental de passagem das p�s
if MTRd<=1.0 && MTR<=0.9
    F1bent          = 58.5;
elseif MTRd> 1.0 && MTR<=0.9
    F1bent          = 58.5+20*log10(MTRd);
elseif MTRd> 1.0 && MTR>0.9
    F1bent          = 58.5+20*log10(MTRd)-20*log10(MTR/0.9);
else
    F1bent          = 58.5-20*log10(MTR/0.9);
end
if RSS<=100
    F2bent          = -5*log10(RSS/300);
else
    F2bent          = -5*log10(100/300);
end
F3bent              = interp1(tetablent,F3blent,teta,'linear','extrap');
F4bent              = 10*log10(exp(-0.5.*(log(f/(2.5.*fb))/log(2.2)).^2));  
Lcbent              = SPL+F1bent+F2bent+F3bent+3*(IGV==1);
SPLbent             = Lcbent+F4bent-10;
%% Ru�do discreto %%
% Corre��o 01
if MTRd<=1.0 && MTR<=0.72
    F1dent          = 60.5;
elseif MTRd>1.0 && MTR<=0.72
    F1dent          = 60.5+20*log10(MTRd);
elseif MTRd>1.0 && MTR>0.72
    F1dent          = min((59.5+80*log10(MTRd/MTR)),(60.5+20*log10(MTRd)+50*log10(MTR/0.72)));
else
    F1dent          = 60.5+20*log10(MTRd)+50*log10(MTR/0.72);
end
% Corre��o 02
if RSS<=100
    F2dent          = -10*log10(RSS/300);
else
    F2dent          = -10*log10(100/300);
end
% Corre��o 03
F3dent              = interp1(tetadsent,F3dsent,teta,'linear','extrap');
Lcdent              = SPL+F1dent+F2dent+F3dent;
% Corre��o 04
k                   = achatom(fix(f/fb));
if  IGV==1
    F4dent          = (-3-3*k).*(delta>1.05 & k>1)-8*(delta<=1.05 & k==1)+(-3-3*k).*(delta<=1.05 & k>1); 
                                                                            % para k=1 e delta>1.05, n�o h� valor, e a expressao retorna 0
else
    F4dent          = (3-3*k).*(delta>1.05)-8*(delta<=1.05 & k==1)+(3-3*k).*(delta<=1.05 & k>1);
end
% Valor final
SPLdent             = (k~=0).*(Lcdent+10*log10(10.^(0.1.*F4dent))-10);

%% Ru�do combina��o, s� para MTR supers�nico %%
if  MTR>1
    F1c1_2          = (318.49*MTR-288.49)*(MTR<=1.146)+(-14.052*MTR+92.603)*(MTR>1.146);
    F1c1_4          = (147.52*MTR-117.52)*(MTR<=1.322)+(-13.274*MTR+95.049)*(MTR>1.322);
    F1c1_8          = (67.541*MTR-37.541)*(MTR<=1.61)+(-12.051*MTR+90.603)*(MTR>1.61);
    F2c             = interp1(tetacb,F2cb,teta,'linear','extrap');
    F3c1_2          = (30.*log10(2*f/fb)).*(f/fb<=0.5)+(-30.*log10(2*f/fb)).*(f/fb>0.5);
    F3c1_4          = (50*log10(4*f/fb)).*(f/fb<=0.25)+(-50*log10(4*f/fb)).*(f/fb>0.25);
    F3c1_8          = (50*log10(8*f/fb)).*(f/fb<=0.125)+(-30*log10(8*f/fb)).*(f/fb>0.125);
    Lcc1_2          = SPL+F1c1_2+F2c+F3c1_2-5*(IGV==1);
    Lcc1_4          = SPL+F1c1_4+F2c+F3c1_4-5*(IGV==1);
    Lcc1_8          = SPL+F1c1_8+F2c+F3c1_8-5*(IGV==1);
    SPLc            = 10*log10(10.^(0.1*Lcc1_2)+10.^(0.1*Lcc1_4)+10.^(0.1*Lcc1_8))-17;      % soma dos 3 espectros de frequencia
else
    SPLc(1:24)      = 0;
end

%% Ru�do da descarga do FAN %%
%% Ru�do banda larga %%
% Corre��o 01
if MTRd<=1.0 && MTR<=1.0
    F1bdesc         = 60.0;
elseif MTRd> 1.0 && MTR<=1.0
    F1bdesc         = 60.0+20*log10(MTRd);
elseif MTRd> 1.0 && MTR>1.0
    F1bdesc         = 60.0+20*log10(MTRd)-20*log10(MTR);
else
    F1bdesc         = 60.0-20*log10(MTR);
end
% Corre��o 02
F2bdesc             = F2bent;                                               %F2b � o mesmo do ru�do da entrada no FAN.
% Corre��o 03
F3bdesc             = interp1(tetabldesc,F3bldesc,teta,'linear','extrap');
% Corre��o 04
F4bdesc             = F4bent;
% VAlor final
Lcbdesc             = SPL+F1bdesc+F2bdesc+F3bdesc+3*(IGV==1);
SPLbdesc            = Lcbdesc+F4bdesc-2;
%% Ru�do discreto %%
% Corre��o 01
if MTRd<=1.0 && MTR<=1.0
    F1ddesc         = 63.0;
elseif MTRd> 1.0 && MTR<=1.0
    F1ddesc         = 63.0+20*log10(MTRd);
elseif MTRd> 1.0 && MTR>1.0
    F1ddesc         = 63.0+20*log10(MTRd)-20*log10(MTR);
else
    F1ddesc         = 63.0-20*log10(MTR);
end
% Corre��o 02
F2ddesc             = F2dent;                                               % F2d � o mesmo do ru�do da entrada do FAN
% Corre��o 03
F3ddesc             = interp1(tetadsdesc,F3dsdesc,teta,'linear','extrap');
% Corre��o 04
F4ddesc             = F4dent;
% Valor final
Lcddesc             = SPL+F1ddesc+F2ddesc+F3ddesc+6*(IGV==1);
% SPLddesc            = Lcddesc+F4ddesc-2;
for ij =1:24
    if k(ij)==0
        SPLddesc(ij) = 0;
    else
        SPLddesc(ij) = Lcddesc+10*log10(10.^(0.1*F4ddesc(ij)))-2;
    end
end

%% amortecimento atmosf�rico %%
[ft, alfaamortt, amorttott, amortatm, SPLrt] = amort(T,RH,radialdistance,f);

%% Efeito doppler %%
deltaLdoppler       = -40*log10(1-M0*cos(teta*pi/180));

%% soma dos ru�dos banda larga de entrada e descarga do FAN %%
SPLb                = 10*log10(10.^(0.1*SPLbent)+10.^(0.1*SPLbdesc));       % m�todo direto de soma
%% soma dos ru�dos discretos de entrada e descarga do FAN %%
SPLd                = 10*log10(10.^(0.1*SPLdent)+10.^(0.1*SPLddesc));       % m�todo direto de soma


%% soma dos ruidos discreto, banda larga e combina��o %%
SPLFan              = 10*log10(10.^(0.1*SPLb)+10.^(0.1*SPLc)+10.^(0.1*SPLd)); 
                                                                            % m�todo direto de soma, considerando o amortecimento atmosf�rico
                                                                            

%% DADOS DE SAIDA %%
ruidoFan            = SPLFan-amorttott';
ft                  = f';
ruidoFant           = ruidoFan';
a1                  = length(ruidoFant);
for ia1=1:a1
    if ruidoFant(ia1)<1
        ruidoFant(ia1) = 1;
    end
end


%% VERIFICA��ES EM DEBUG
% figure()
% semilogx(f,SPLbent,'o-b',f,SPLdent,'o-m',f,SPLc,'o-r',f,SPLbdesc,'o-g',f,SPLddesc,'o-c',f,SPLFan,'o-k');
% grid on;
% legend('broadband ent','discrete ent','combination','broadband disc','discrete disc','All Fan');


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - NASA TM X-71763 - Interim prediction method for fan and compressor source noise (1979)
%2 - ESDU77022 - Atmospheric properties
%3 - SCHMID, M. - Entwicklung eines Programmmoduls zur Prognose des L�rms von Strahltriebwerken im  Flugzeugvorentwurf. (2001).