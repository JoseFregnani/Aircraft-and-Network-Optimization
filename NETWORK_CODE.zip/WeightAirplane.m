%% Descri��o da fun��o
%  C�lculo do peso vazio da aeronave (OEW) via CLASS II WEIGHT ESTIMATION


%% Declara��o da fun��o
function [weighttotal, weightcomp]=WeightAirplane(Npax,Range,MTOW,fuel,Ceiling,wingtcmed,Mach,...
    T0_N,EngineLength_m,EngineDe_m,EngBPR,EngOPR,...
    PEng,PWing,...
    YEIS,xle,varSlat,wMAC,wYMAC,wingTR,wS,wAR,wSweepLE,wSweep14,varht,ht,...
    vt,fus_width, fus_height, FusSwet_m2,Fus_length,lcab,ltail,Vwf)


%% Numero de motores
NEng  = max(2,PEng);
wingb = sqrt(wAR*wS);

%% Fatores de convers�o
conversionfactors
%% Atribui��es
nlim                = 2.1 +(24000/(MTOW*kg2lb+10000));
if nlim <= 2.5
    nlim            = 2.5;
end
nult                = 1.5*nlim;                                             % ultimate load factor


%% C�lculo da VD
HPx                 = Ceiling;                                              % altitude de cruzeiro
atm                 = atmosfera(HPx,0);                                     % propriedades da atmosfera
va                  = atm(7);                                               % velocidade do som [m/s]
sigma               = atm(4);
vc                  = Mach*va;                                              % velocidade de cruzeiro meta, verdadeira [m/s]
vckeas              = vc*sigma^0.5/kt2ms;                                   % velocidade de cruzeiro meta [KEAS]
vdkeas              = 1.25*vckeas;                                          % velocidade de mergulho [KEAS]


%% ------------------------------------------------------------------------
%% Peso estrutural (STRUCTURAL WEIGHT)
%% ASA (WING)
fcor                = 1;                                                    % fator de correcao para alivio de peso do motor
if PEng==1 || PEng==3
        fcor        = 0.98;
elseif PEng==4
        fcor        = 0.95;
end
%% metodo Torenbeek
%weight.wing=fcor*1.02*0.0017*var.MZF*(((wing.b*ft)/(cos(wing.sweepC2*rad)))^0.75)*...
 %   (1+((6.3*cos(wing.sweepC2*rad))/(wing.b*ft))^0.5)*...
 %   (nult^0.55)*(((wing.b*ft*wingref.S*ft2)/(tr*var.MZF*cos(wing.sweepC2*rad)))^0.3); % [lb] eq 5.7 pag 89
%% metodo Askin - Conceptual Aircraft Design Methods pag 56
piatm               = exp(2.965-0.001525*YEIS);                            % fator "advanced technology multiplier"
pitc                = 16.5*sin(2*pi*wingtcmed);                            % fator de espessura da asa
kco                 = 1.25;                                                % kco para asa alta
if PWing == 1
	kco             = 1.17;                                                % kco para asa baixa (cantilever)
end
ksp                 = 1.02;                                                % ksp para spoilers na asa
% trem de pouso na asa ou n�o
if PWing == 1
    klg             = 1.015;                                               % se asa for baixa, trem de pouso estah alojado na asa
else
    klg             = 1.03;                                                % se asa for alta, trem de pouso fica alojado em um casulo na fuselagem
end
picw                = kco*ksp*klg;                                         % fator de configura��o da asa 
HPVMO               = Ceiling;                                             % altitude na qual ocorre VMO
atm                 = atmosfera(HPVMO,0);                                  % propriedades da atmosfera
va                  = atm(7);                                              % velocidade do som [m/s]
VMO                 = Mach*va;                                             % VMO [m/s]
taus                = 1+((1.31*(0.5*0.125*VMO*VMO/1000)^2)/nult^3);        % par�metro de rigidez estrutural
prod1               = MTOW*nult*wS*(wAR^1.5);                              % termo 1
prod2               = (1.1+ wingTR/2)*(taus^1.5);                          % termo 2
sweeprad            = degre2rad*wSweep14;
prod3               = pitc*(cos(sweeprad))^1.5;                            % termo 3
prodf               = prod1*prod2/prod3;                                   % combina��o dos termos 1, 2 e 3
weightwingaskin     = fcor*(0.0328*picw*piatm*prodf^0.656)*kg2lb;          % peso da asa, segundo a ref.(2) [lb]
weightwing_lb       = weightwingaskin;                                    % peso final da asa [lb]

%% EMPENAGEM HORIZONTAL (HORIZONTAL TAIL)
kh                  = 1.1;                                                 % empenagem horizontal movel
prod1               = 3.81*(((ht.S*m22ft2)^0.2)*vdkeas);                    % termo 1
prod2               = (1000*(cos(ht.sweepC2*degre2rad))^0.5);               % termo 2
prodf               = prod1/prod2;                                         % termo 3
weightht_lb         = 1.25*kh*(ht.S*m22ft2)*(prodf-0.287);                  % peso da EH, segundo a ref.(1) [lb]

%% EMPENAGEM VERTICAL (VERTICAL TAIL)
vtb                 = sqrt(vt.AR*vt.S);                                      % Envergadura EV [m]
if varht==1
    kv              = 1.0;                                                 % EH montada na fuselagem
else
    zh              = 0.95*vtb;
    kv              = 1+0.15*((ht.S*zh)/(vt.S*vt.b));                         % EH montada na EV
end
% prod1               = 3.81*(((vtS*m22ft2)^0.2)*vdkeas);                  % termo 1
% prod2               = (1000*(cos(vt.sweepC2*degre2rad))^0.5);            % termo 2
% prodf               = prod1/prod2;                                       % termo 3
% weightvt            = 1.00*kv*(vtS*m22ft2)*(prodf-0.287);   
% peso da EV, segundo a ref.(1) [lb]
VD                    = (Mach+0.05)*va;
vt.sweepC2rad         = vt.sweepC2*degre2rad;
aux                   = ((vt.S^0.2)*VD)/(1000*sqrt(cos(vt.sweepC2rad)));
weightvt              = kv*vt.S*(62*aux-2.5);
weightvt_lb           = weightvt*kg2lb;
%% FUSELAGEM (FUSELAGE)
% M�todo de Torenbeek

VD_kts=VD/kt2ms; %(veloc. em kts)
if PWing == 1
    kf=1.08; % 1.08 cabine pressurizada 
else
    kf=1.08*1.07;% 1.07 trem de pouso na fuselagem se asa alta + 1.08 cabine pressurizada
end
if PEng==2 || PEng==3 % motor na fuselagem
    ke = 1.04; %correcao do peso devido ao motor na fuselagem
else % motor na asa
    ke = 1.0;
end
    if varht == 1
    ht_xac=0.98*Fus_length - ht.c0 + ht.ymac*tan(degre2rad*ht.sweepLE)+...
        0.25*ht.mac;
    else
    ht_xac=0.98*Fus_length-vt.c0+vt.b*tan(degre2rad*vt.sweepLE)+...
        0.25*ht.mac+ht.ymac*tan(degre2rad*ht.sweepLE);
    end
wing_xac = xle + wYMAC*tan(degre2rad*wSweepLE) + 0.25*wMAC;
lh       = ht_xac - wing_xac;
weightfuselage_lb=0.021*kf*ke*(((VD_kts*lh)/((fus_height+fus_width)))^0.5)*(FusSwet_m2*m22ft2)^1.2; % eq 5.27 pag 94 ... 



%% NACELLE                                                 % comprimento do motor [m]
% areainl             = pi*(var.Dfan^2/4)*m22ft2;                           % area frontal do motor [ft2]
%weightnacelle_lb      = (NEng*engineT0*0.065/9.81)*kg2lb;                    % peso de todas as naceles, segundo a ref.(1) [lb]
areainl=3.1416*EngineDe_m^2/(4*0.303*0.303);  % ft^2
pre2=EngOPR; % maximum static pressure at engine compressor face (psi) a taxa de compressao do fan eh 2
weightnacelle_lb = NEng*7.435*((areainl)^0.5*(EngineLength_m/0.303)*pre2)^0.731;
%% TREM-DE-POUSO (LANDING GEAR)
switch PWing
    case 1
        Kgr         = 1.0;
    otherwise
        Kgr         = 1.08;
end
mtowkg              = MTOW;
mtowlb              = mtowkg*kg2lb;
NLG                 = [20.000 0.1000 0.0000 2.0e-6];
MLG                 = [40.000 0.1600 0.0190 1.5e-5];
prod1               = MLG(1)+MLG(2)*mtowlb^0.75;                            % termo 1
prod2               = MLG(3)*mtowlb + MLG(4)*mtowlb^1.5;                    % termo 2
weightmlg_lb        = Kgr*(prod1+prod2);                                    % peso do tdp principal, segundo a ref.(1) [lb]
prod1               = NLG(1)+NLG(2)*mtowlb^0.75;                            % termo 1
prod2               = NLG(3)*mtowlb+NLG(4)*mtowlb^1.5;                      % termo 2
weightnlg_lb        = Kgr*(prod1+prod2);                                    % peso do tdp dianteiro, segundo a ref.(1) [lb]

%% TOTAL
weightstructure_lb  = weightwing_lb+...
    weightht_lb+weightvt_lb+weightfuselage_lb+(weightmlg_lb+weightnlg_lb)+weightnacelle_lb;
%% ------------------------------------------------------------------------


%% ------------------------------------------------------------------------
%% PESO DOS GRUPOS MOTOPROPULSORES (POWER PLANT)
%% MOTOR (ENGINE)
FN                  = T0_N;                                                 % Tracao do motor, SL, ISA [N]
FNlb                = FN*N2lbf;                                             % Tracao do motor, SL, ISA [lb]
%eight.engine=(0.084*(tracionlb)^1.1*expm(-0.045*var.Bp)); % lb
weightengine        = (0.084*(FNlb)^1.1*expm(-0.045*EngBPR));               % Peso de um motor, segundo a ref.(3) [lb]
weightenginetotal   = NEng*weightengine;

%% SISTEMA DE COMBUST�VEL (FUEL SYSTEM)
% Propriedades do combustivel
fueltype            = 3;
switch fueltype
    case 1
        Kfsp        = 5.870;                                                % densidade do combustivel (AV-GAS) [lb/gal]
    case 2
        Kfsp        = 6.550;                                                % densidade do combustivel (JP-4) [lb/gal]
    otherwise
        Kfsp        = 6.710;                                                % densidade do combustivel (JET A-1) [lb/gal]
end
ntaq                = 3;                                                    % numero de tanques de combust�vel
if Range > 2000 || NEng > 2
    ntaq            = 6;
end
%fuel_capacity                                                               % calcula a capacidade dos tanques 
% prod1               = (NEng+ntaq-1)+15*(ntaq^0.5);                          % termo 1
% prod2               = (Vwf*kg2lb/Kfsp)^0.333;                               % termo 2
% weightfuelsys       = 80*prod1*prod2;    
weightfuelsys=80*(NEng+ntaq-1)+15*(ntaq^0.5)*(Vwf*lb2kg/Kfsp)^0.333; %lb% peso total do sistema de combust�vel, segundo a ref.(1) [lb]

%% PROPULSION SYSTEM
% ENGINE CONTROLS                                                           % peso dos controles do motor, segundo a ref.(1) [lb]
Kec                 = 0.686;
if PEng==2 || PEng==3                                                       % motor na fuselagem
    weightenginecontrol = Kec*(Fus_length*m2ft)^0.792;
else                                                                        % motor na asa
    weightenginecontrol = 88.46*(((Fus_length+wingb)*m2ft)/100)^0.294;
end
% STARTING SYSTEM                                                           % peso do sistema de partida, segundo a ref.(1) [lb]
weightstartsys      = 38.93*(weightengine/1000)^0.918;                     % sistemas de partida el�trica
% THRUST REVERSER
iRev                = 0;
if iRev == 0                                                                % aeronave sem reverso
    weightreverser = 0;
else                                                                        % aeronave com reverso
    weightreverser = 0.18*weightengine;                          % peso dos reversores, segundo a ref.(1) [lb]
end
% SISTEMA DE PROPULS�O COMPLETO
weightpropulsion   = NEng*(weightenginecontrol+weightstartsys+weightreverser);

%% TOTAL
weightpowerplant   = weightenginetotal+weightfuelsys+ weightpropulsion;
%%-------------------------------------------------------------------------


%%-------------------------------------------------------------------------
%% FIXED EQUIPMENT
% COMANDOS DE V�O (FLIGHT CONTROLS)
iFLTCTRPOW          = 1;
if iFLTCTRPOW == 0
    Kfc             = 0.44;                                                 % unpowered flight controls
else
    Kfc             = 0.64;                                                 % powered flight controls
end
Kle                 = 1.2;                                                  % leading edge applied flight controls
weightflightcontrol = Kle*Kfc*((MTOW*kg2lb)^(2/3));                         % peso dos comandos de voo, segundo a ref.(1) [lb]

% HYDRAULICS
Nfunc               = 7;                                                    % numero de funcoes executadas (typically 4-7)
weighthyd           = 0.2673*Nfunc*((m2ft*(lcab+ltail+wingb))^0.937);  
                                                                            % peso do sistema hidraulico, segundo a ref.(3)
% ELETRICAL SYSTEM
NGEN                = NEng;                                                 % Numero de geradores
LA                  = (lcab+ltail)*m2ft;                                    % Distancia da fiacao eletrica, do gerador `a avionica ao cockpit (motores na fuselagem) [ft]
if PEng == 1 || PEng == 4                                                   % Motores sob as asas
    LA              = (lcab+ltail-lh)*m2ft;                % Distancia da fiacao eletrica, do gerador `a avionica ao cockpit [ft]
end
RKVA                = 60;                                                   % classificacao do gerador, tipico para transportes [kVA]
weighteletricsys    = 7.291*(RKVA^0.782)*(LA^0.346)*(NGEN^0.10);            % peso do sistema eletrico, segundo a ref.(3) [lb]

% AVIONICS
wuav                = 1200 ;                                                % peso da avionica, nao instalada (tipicamente 800-1400 lb) [lb]
weightavionics      = 1.73*(wuav^0.983);                                    % peso da avionica, segundo a ref.(3) [lb]

% AIR/ICE/PRESSURE
weightpressuresys   = 6.75*(lcab*m2ft)^1.28;                                % peso do AMS, segundo a ref.(1) [lb]

% OXYGEN SYSTEM
weightoxygensys     = 30+1.2*Npax;                                          % peso do sistema de oxigenio, segundo a ref.(1) [lb]

% APU
weightapu           = 0.0085*MTOW*kg2lb;                                    % peso do APU, segundo a ref.(1) [lb]

% FURNISHINGS
weightfurnishing    = 0.211*((MTOW-fuel)*kg2lb)^0.91;                       % peso do interior, segundo a ref.(1) [lb]

% PAINT
weightpaint         = 0.0045*MTOW*kg2lb;                                    % peso da pintura, segundo a ref.(1) (coeficiente tipicamente entre 0.003 e 0.006) [lb]


% SAFETY EQUIPAMENT
valorpax            = 0.9;                                                  % aeronaves de curto alcance sobre a terra
if Range > 2000
    valorpax        = 3.4;                                                  % aeronaves de longo alcance e/ou voos sobre agua
end
weightsafety        = valorpax*Npax*kg2lb;                                  % peso do equipamento de seguranca, segundo a ref.(4) [lb]

% Handling gear
weighthandling      = 0.0003*MTOW*kg2lb;                                % peso do handling gear, segundo a ref.(3) [lb]

% SLAT
if varSlat > 0
    if PEng == 2
        slatspan    = 0.80;                                                 % motores na fuselagem
    else
        slatspan    = 0.70;                                                 % motores na asa
    end
    Sslat           = slatspan*0.15*wS*m22ft2; % �rea dos slats (considera 15% da corda) [ft2]
    weightslat      = 3.53* (Sslat^0.82); % peso dos slats, segundo a ref.(5) [lb]
else
    weightslat      = 0;
end

% TOTAL
weightfixedeq       = weightflightcontrol+weighthyd+weighteletricsys+...
                      weightavionics+weightpressuresys+weightoxygensys+...
                      weightapu+weightfurnishing+weightpaint+...
                      weightsafety+weighthandling + weightslat;
%%-------------------------------------------------------------------------


%%-------------------------------------------------------------------------
%% PESO TOTAL DA AERONAVE (TOTAL AIRPANE WEIGHT)
% peso total da aeronave vazia [lb]:
weighttotal              = weightstructure_lb+weightpowerplant+weightfixedeq;  
% Massa dos componentes [lb]:
weightempty              = weighttotal;
weightcomp.wing          = weightwing_lb + weightslat;
weightcomp.ht            = weightht_lb;
weightcomp.vt            = weightvt_lb;
weightcomp.fuselage      = weightfuselage_lb;
weightcomp.paint         = weightpaint;
weightcomp.nacelle       = weightnacelle_lb/NEng;
weightcomp.engine        = weightengine;
weightcomp.flightcontrol = weightflightcontrol;
weightcomp.hyd           = weighthyd;
weightcomp.electricsys   = weighteletricsys;
weightcomp.avionics      = weightavionics;
weightcomp.oxygensys     = weightoxygensys;
weightcomp.handling      = weighthandling;
weightcomp.safety        = weightsafety;
weightcomp.apu           = weightapu;
weightcomp.pressuresys   = weightpressuresys;
weightcomp.fuelsys       = weightfuelsys;
weightcomp.furnishing    = weightfurnishing;
weightcomp.propulsion    = weightpropulsion;
weightcomp.powerplant    = weightpowerplant;
weightcomp.nlg           = weightnlg_lb;
weightcomp.mlg           = weightmlg_lb;
%%-------------------------------------------------------------------------

fprintf('\n ---------- Empty Weight Breakdown ------------------')
fprintf('\n Empty weight: %8.0f lb \n',weightempty)
fprintf('\n Fuselage weight: %8.0f lb (%3.0f%s)',weightfuselage_lb,100*(weightfuselage_lb/weightempty),'%')
fprintf('\n     Wing weight: %8.0f lb (%3.0f%s) ',weightwing_lb,100*(weightwing_lb/weightempty),'%')
fprintf('\n       HT weight: %8.0f lb (%3.0f%s)',weightht_lb,100*(weightht_lb/weightempty),'%')
fprintf('\n       VT weight: %8.0f lb (%3.0f%s)',weightvt_lb,100*(weightvt_lb/weightempty),'%')
fprintf('\n  Nacelle weight: %8.0f lb (%3.0f%s)',weightnacelle_lb,100*(weightnacelle_lb/weightempty),'%')
fprintf('\n          Structural weight = %8.0f lb \n',weightstructure_lb)
fprintf('\n      MLG weight: %8.0f lb (%3.0f%s)',weightmlg_lb,100*(weightmlg_lb/weightempty),'%')
fprintf('\n      MLG weight: %8.0f lb (%3.0f%s)',weightnlg_lb,100*(weightnlg_lb/weightempty),'%')
fprintf('\n          LG weight = %8.0f lb \n',weightmlg_lb+weightnlg_lb)
fprintf('\n        Avionics weight: %8.0f lb (%3.0f%s)',weightavionics,100*(weightavionics/weightempty),'%')
fprintf('\n             Hyd weight: %8.0f lb (%3.0f%s)',weighthyd,100*(weighthyd/weightempty),'%')
fprintf('\n Electric system weight: %8.0f lb (%3.0f%s)',weighteletricsys,100*(weighteletricsys/weightempty),'%')
fprintf('\n             APU weight: %8.0f lb (%3.0f%s)',weightapu,100*(weightapu/weightempty),'%')
fprintf('\n              FC weight: %8.0f lb (%3.0f%s)',weightflightcontrol,100*(weightflightcontrol/weightempty),'%')
fprintf('\n             ECS weight: %8.0f lb (%3.0f%s)',weightpressuresys,100*(weightpressuresys/weightempty),'%')
fprintf('\n   Oxygen system weight: %8.0f lb (%3.1f%s)',weightoxygensys,100*(weightoxygensys/weightempty),'%')
fprintf('\n      Furnishing weight: %8.0f lb (%3.0f%s)',weightfurnishing,100*(weightfurnishing/weightempty),'%')
fprintf('\n   Safety system weight: %8.0f lb (%3.1f%s)',weightsafety,100*(weightsafety/weightempty),'%')
fprintf('\n Handling system weight: %8.0f lb (%3.1f%s)',weighthandling,100*(weighthandling/weightempty),'%')
fprintf('\n           Paint weight: %8.0f lb (%3.1f%s)',weightpaint,100*(weightpaint/weightempty),'%')
fprintf('\n                 Fixed equipment weight = %8.0f lb \n',weightfixedeq)
fprintf('\n          Engine weight: %8.0f lb (%3.1f%s)',weightenginetotal,100*(weightenginetotal/weightempty),'%')
fprintf('\n  Engine control weight: %8.0f lb (%3.1f%s)',weightenginecontrol,100*(weightenginecontrol/weightempty),'%')
fprintf('\n     Fuel system weight: %8.0f lb (%3.1f%s)',weightfuelsys,100*(weightfuelsys/weightempty),'%')
fprintf('\n    Engine start weight: %8.0f lb (%3.1f%s)',weightstartsys,100*(weightstartsys/weightempty),'%')
fprintf('\n                 Powerplant weight = %8.0f lb \n',weightpowerplant)
fprintf('\n --------- End Empty Weight Breakdown ----------------\n')
%% T�rmino da fun��o
end


%% Refer�ncias bibliogr�ficas
% 1 - ROSKAM, J. Airplane Design vol.V - Component weight estimation. DARCorp, USA, 2003.
% 2 - ISIKVEREN, A.T. Quasi-analytical modelling and optimisation techniques for transport aircraft design. KTW, Sweden, 2002.
% 3 - RAYMER, D.P. Aircraft design - a conceptual approach. AIAA, 3a ed., USA, 1999.
% 4 - JENKINSON, L.R. Civil Jet Aircraft Design. AIAA, USA, 1999.
% 5 - TORENBEEK, E. Synthesis of subsonic airplane design. Kluwer+DUP, Holanda, 1982