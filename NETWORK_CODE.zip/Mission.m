clc
clear
tic

% CONSTANTS
kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% GEOMECTRIC PARAMETERS

S=72.72;
b=25;
WAR=8.6;
afil=0.235;
tcroot = 0.145; 
tctip  = 0.11;  
tc=(3*tcroot+2*tctip)/5;
tr=0.285;
df=3.3;
phi14=23.5;
CLMAX=1.6;
PWing=1;
VTarea=16.2;
VTAR=0.89;
VTTR=0.740;
VTSweep=41;
HTarea=23.35;
HTAR=4.35;
HTTR=0.4;
PHT=1;
FusDiam=3.5;
NPax=78;
NCorr=1;
NSeat=4;
ncrew= 5;
AisleWidth=0.49;
CabHeightm=2;
Kink_semispan=0.34;
SEATwid=0.46;
widthreiratio=1.1;

%ENGINE PARAMETERS

n=2;
PEng = 1; % 1= two underwing engines; 2= two engines at rear fuselage
MAXRATE=13400;

if PEng == 1
    nedebasa=n;
else
    nedebasa=0;
end

maneted=1;
ebypass= 5;    
ediam= 1.36;  
efanpr= 1.425;
eopr= 28.5;    
eTIT= 1240; 

Engine_data(1)     = maneted;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;


% CUSTOS

ct=25; % $/min
cf=1;  % $/kg

% WET AREA CALCULATION

swet2=502;

% PROFILE PARAMETERS

HDG=0;
ORIGALT=0;
DESTALT=0;
ALTALT=0;
ISADEV=0;
ALTDIST=500;

CLBCAS=280;
CLBMACH=0.78;
CRZMACH=0.78;
CRZCAS=310;
DESCAS=280;
DESMACH=0.78;
CLBCASALT=250;
CLBMACHALT=0.74;
CRZMACHALT=0.74;
CRZCASALT=270;
DESCASALT=250;
DESMACHALT=0.72;
DISTTOT=500;

% OPERATIONS PARAMETERS

TAXITIME=15;
TAXIFF=10;
TAXIFUEL=200;
EXTRA=0;
CONTPCT=0.1;
THOLD=30;
RCMIN=300;
BUFFMARGIN=1.3;
MINCRZTIME=3;
Cf=1; % OPERATOR PROVIDED ($/kg fuel)
Ct=25; % OPERATOR PROVIDED ($/min)
PAXWT=110;
NPAX=78;
PAXWTMAX=NPAX*PAXWT;
PAYLOAD=1000; % FOR CALCULATION TYPE=0
BOW=18000;
MTOWP=37500; % PERFORMANCE LIMIT (FIELD,CLIMB,OBST,TIRESPEED,VMBE,VMCG)

% ENVELOPE PARAMETERS

MMO=0.82;
VMO=340;
MTOW=37500;
MLW=34000;
MZFW=31500;
MAXFUEL=9400;
MAXCERTALT=41000;

typecalc=1; % CALCULATION TYPE:0=GIVEN PAYLOAD, 1=MTOW LIMITED (Structural,Perofrmance,MZFW or MLW)

if typecalc ==0 % GIVEN PAYLOAD
          
    ZFW=BOW+PAYLOAD;
    TOW=ZFW+MAXFUEL;
    f=0;
         
    while f==0
     
     [T,Wf,CRZALT]=TF(TOW,DISTTOT,ORIGALT,DESTALT,ISADEV,HDG,CLBCAS,CLBMACH,CRZCAS,CRZMACH,DESCAS,DESMACH,RCMIN,BUFFMARGIN,MINCRZTIME,MMO,VMO,MTOW,MAXCERTALT);
     DOC=(T*Ct+Wf*Cf)/DISTTOT;
     LW=TOW-Wf;
     [TALT,ALTF,CRZALTALT]=TF(LW,ALTDIST,ORIGALT,ALTALT,ISADEV,HDG,CLBCASALT,CLBMACHALT,CRZCASALT,CRZMACHALT,DESCASALT,DESMACHALT,RCMIN,BUFFMARGIN,MINCRZTIME,MMO,VMO,MTOW,MAXCERTALT);
     [FFHOLD]=HOLD(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,LW-ALTF,ALTALT+1500,ISADEV);
     HOLDING=(FFHOLD/60)*THOLD;
     CONT=CONTPCT*Wf;
     RES=ALTF+HOLDING+CONT+EXTRA;
     ZFW=LW-RES;
     TOF=Wf+RES;
     TAXIFUEL=TAXITIME*TAXIFF;
     FOB=TOF+TAXIFUEL;
     if PAYLOAD>PAXWTMAX
       PAXLOAD=PAXWTMAX;
       CGOWT=PAYLOAD-PAXLOAD;
     else
       PAXLOAD=PAYLOAD;
       CGOWT=0;
     end
     PAX=round(PAXLOAD/PAXWT);
    
     delta1=0;
     delta2=0;
     delta3=0;
     flw=1;
     fzf=1;
     ffc=1;
          
     if LW>=MLW
        flw=0;
        delta1=LW-MLW;
     end
     if ZFW>=MZFW
        fzf=0;
        delta2=ZFW-MZFW;
     end
     if TOF>MAXFUEL
        ffc=0;
        delta3=TOF-MAXFUEL;       
     end;   
     
     f=flw*fzf*ffc;
     if f==0
       A=[delta1 delta2 delta3];  
       delta=max(A);         
       TOW=TOW-delta;
       if delta<50
         f=1;
       end  
     end    
   end

else
    
   if MTOWP<MTOW 
     TOW=MTOWP;
   else
     TOW=MTOW;
   end
       
   f=0;
         
   while f==0 % MTOW LIMIT
     
     [T,Wf,CRZALT]=TF(TOW,DISTTOT,ORIGALT,DESTALT,ISADEV,HDG,CLBCAS,CLBMACH,CRZCAS,CRZMACH,DESCAS,DESMACH,RCMIN,BUFFMARGIN,MINCRZTIME,MMO,VMO,MTOW,MAXCERTALT);
     DOC=(T*Ct+Wf*Cf)/DISTTOT;
     LW=TOW-Wf;
     [TALT,ALTF,CRZALTALT]=TF(LW,ALTDIST,ORIGALT,DESTALT,ISADEV,HDG,CLBCASALT,CLBMACHALT,CRZCASALT,CRZMACHALT,DESCASALT,DESMACHALT,RCMIN,BUFFMARGIN,MINCRZTIME,MMO,VMO,MTOW,MAXCERTALT);
     [FFHOLD]=HOLD(S,b,afil,tc,df,swet2,phi14,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,LW-ALTF,ALTALT+1500,ISADEV);
     HOLDING=(FFHOLD/60)*THOLD;
     CONT=CONTPCT*Wf;
     RES=ALTF+HOLDING+CONT+EXTRA;  
     ZFW=LW-RES;
     TOF=Wf+RES;
     TAXIFUEL=TAXITIME*TAXIFF;
     FOB=TOF+TAXIFUEL;
     PAYLOAD=ZFW-BOW;
          
     if PAYLOAD>PAXWTMAX
       PAXLOAD=PAXWTMAX;
       CGOWT=PAYLOAD-PAXLOAD;
     else
       PAXLOAD=PAYLOAD;
       CGOWT=0;
     end
     
     PAX=round(PAXLOAD/PAXWT);
     delta1=0;
     delta2=0;
     delta3=0;
     flw=1;
     fzf=1;
     ffc=1;
          
     if LW>MLW
         flw=0;
         delta1=LW-MLW;        
     end
     if ZFW>MZFW
        fzf=0;
        delta2=ZFW-MZFW;
     end
     if TOF>MAXFUEL
        ffc=0;
        delta3=TOF-MAXFUEL;       
     end;   
     
     f=flw*fzf*ffc;
     
     if f==0
       A=[delta1 delta2 delta3];  
       delta=max(A);         
       TOW=TOW-delta;
       if delta<50
         f=1;
       end  
     end    
   end  
   
end  

toc
if typecalc==0
  fprintf('\n ** CALCULATION TYPE: PAYLOAD GIVEN **');
else
  fprintf('\n ** CALCULATION TYPE: MTOW LIMIT **');
end 

fprintf('\n');
fprintf('\n => TOW  = %5.0f',TOW);
fprintf('\n    MTOWP= %5.0f',MTOWP);
fprintf('\n => TOF  = %5.0f',TOF);
fprintf('\n    MFUEL= %5.0f',MAXFUEL);
fprintf('\n => LW   = %5.0f',LW);
fprintf('\n    MLW  = %5.0f',MLW);
fprintf('\n => ZFW  = %5.0f',ZFW);
fprintf('\n    MZFW = %5.0f',MZFW);
fprintf('\n');
fprintf('\n => PLD  = %5.0f',PAYLOAD);
fprintf('\n => PAXWT= %5.0f',PAXLOAD);
fprintf('\n => PAX  = %5.0f',PAX);
fprintf('\n => CGOWT= %5.0f',CGOWT);
fprintf('\n');
fprintf('\n => TRIPDIST = %5.0f',DISTTOT);
fprintf('\n => TRIPTIME = %5.0f',T);
fprintf('\n => HOLDTIME = %5.0f',THOLD);
fprintf('\n => TAXITIME = %5.0f',TAXITIME);
fprintf('\n');
fprintf('\n => TRIPFUEL = %5.0f',Wf);
fprintf('\n => HOLDFUEL = %5.0f',HOLDING);
fprintf('\n => ALTFUEL  = %5.0f',ALTF);
fprintf('\n => CONT     = %5.0f',CONT);
fprintf('\n => TOF      = %5.0f',TOF);
fprintf('\n => TAXIFUEL = %5.0f',TAXIFUEL);
fprintf('\n => FOB      = %5.0f',FOB);
fprintf('\n');
fprintf('\n => CRZALT   = %5.0f',CRZALT);
fprintf('\n => CLBCAS   = %5.0f',CLBCAS);
fprintf('\n => CLBMach  = %5.3f',CLBMACH);
fprintf('\n => CRZCAS   = %5.0f',CRZCAS);
fprintf('\n => CRZMach  = %5.3f',CRZMACH);
fprintf('\n => DESCAS   = %5.0f',DESCAS);
fprintf('\n => DESMach  = %5.3f',DESMACH);
fprintf('\n');
fprintf('\n => ALTDIST  = %5.0f',ALTDIST);
fprintf('\n => CRZALTalt= %5.0f',CRZALTALT);
fprintf('\n => CLBCASalt= %5.0f',CLBCASALT);
fprintf('\n => CLBMachalt= %5.3f',CLBMACHALT);
fprintf('\n => CRZCASalt = %5.0f',CRZCASALT);
fprintf('\n => CRZMachalt= %5.3f',CRZMACHALT);
fprintf('\n => DESCASalt = %5.0f',DESCASALT);
fprintf('\n => DESMachalt= %5.3f',DESMACHALT);
fprintf('\n');
fprintf('\n => DOC      = %5.2f',DOC);
