function [Airport,D,LF,DIST,HDG]=LOADAPT(SHARE,LFREF);

rvar=0; % Select random variation of LF around LFREF (0=OFF, 1=ON)

ARPT = readtable('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\NETWORK\AIRPORTS.xlsx','ReadVariableNames',true);  
n=size(ARPT,1);

for i=1:n
    Airport(i).name=table2array(ARPT(i,'APT'));
    Airport(i).DEP_rwy=table2array(ARPT(i,'DR'));
    Airport(i).ARR_rwy=table2array(ARPT(i,'AR'));
    Airport(i).pop= table2array(ARPT(i,'POP'));
    Airport(i).CR = table2array(ARPT(i,'CR'));
    Airport(i).BPI= table2array(ARPT(i,'BPI'));
    Airport(i).GDP= table2array(ARPT(i,'GDP')); 
    Airport(i).lat= table2array(ARPT(i,'LAT'));
    Airport(i).lon=	table2array(ARPT(i,'LON'));
    Airport(i).elev=table2array(ARPT(i,'ELEV'));
    Airport(i).dmg =table2array(ARPT(i,'DMG'));
    Airport(i).Reftemp=table2array(ARPT(i,'TREF'));
    Airport(i).TORA=table2array(ARPT(i,'TORA'));
    Airport(i).TODA=table2array(ARPT(i,'TODA'));
    Airport(i).ASDA=table2array(ARPT(i,'ASDA'));
    Airport(i).LDA=table2array(ARPT(i,'LDA'));
    Airport(i).AVG_DEP_delay=table2array(ARPT(i,'AVD'));
    Airport(i).AVG_ARR_delay=table2array(ARPT(i,'AVA'));
end    

[DIST,HDG]=distGC2(Airport);

% Gravitational models
% coef=[-1.6094 0.5000  0.0000 0.0000  0.0000 0.0000];% Jaillet et all (1996)
% coef=[ 2.0559 0.5305 -0.0412 1.4448 -0.2598 0.0449];% baseline: TOP 20 Brazilian Domestic Routes 2016
% coef=[ 3.5299 0.4011 -0.0383 0.8548 -0.1401 0.1163];% baseline: TOP 20 Brazilian Domestic Routes 2015
% coef=[ 5.1453 0.3153 -0.0370 0.4901 -0.0931 0.2382];% baseline: TOP 20 Brazilian Domestic Routes 2014
% coef=[ 3.5770 0.4157 -0.0388 0.9299 -0.1643 0.1331];% baseline: TOP 20 Brazilian Domestic Routes AVG 2014-15-16
coef=[ 5.7481 -0.0864 -0.0920 0.9362 0.1416 0.0443];% baseline: TOP 30 European Routes AVG 2017

K0=coef(1);% Intercept Constant
K1=coef(2);% Population
K2=coef(3);% Catchment Radius
K3=coef(4);% Buying Power Index
K4=coef(5);% City GDP
K5=coef(6);% Distance

for i=1:n
    for j=1:n
        if i==j;
            D(i,j)=0;
        else
            %
            P1=Airport(i).pop;
            P2=Airport(j).pop;
            P=P1*P2;
            C1=pi*Airport(i).CR^2;
            C2=pi*Airport(j).CR^2;
            C=C1*C2;
            B =Airport(i).BPI+Airport(j).BPI;
            G1= Airport(i).GDP;
            G2= Airport(j).GDP;
            G=G1*G2;           
            d=DIST(i,j);
            LNY=K0+K1*log(P)+K2*log(C)+K3*log(B)+K4*log(G)+K5*log(d);
            f  = round(SHARE*exp(LNY)/365);            
            D(i,j)=f;
        end    
    end
end    

% Loadfactor

a=0.05;
b=-0.05;

for i=1:n
    for j=1:n
       if i==j
           LF(i,j)=0;
       else
           if rvar==1
               randLF=a+(b-a)*(rand(1));% Random variation of LF
           else
               randLF=0;
           end    
           LF(i,j)=LFREF+randLF;
       end
    end
end


