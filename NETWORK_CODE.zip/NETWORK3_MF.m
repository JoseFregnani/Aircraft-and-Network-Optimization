%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - NETWORK MODULE
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 3.0 / November 2017 - Network optimiztion with 3 aircraft (Mode Frontier)
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic

close all

% LOAD AIRCRAFT DATA

mode=1;% acft seletiom method: PAX:mode=1, RANGE:mode=2
rvar=0;% random distribution of delay: 1:on 0:off

[ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3,n1,n2,n3]=LOADDATABANK2(X1,X2,X3,mode);
RANGE1=ACFT1.RANGE;
RANGE2=ACFT2.RANGE;
RANGE3=ACFT3.RANGE;
NPax1 =round(ACFT1.NPax);
NPax2 =round(ACFT2.NPax);
NPax3 =round(ACFT3.NPax);
MTOW1 =round(ACFT1.MTOW);
MTOW2 =round(ACFT2.MTOW);
MTOW3 =round(ACFT3.MTOW);
wS1 =ACFT1.wS;
wS2 =ACFT2.wS;
wS3 =ACFT3.wS;
wAR1 =ACFT1.wAR;
wAR2 =ACFT2.wAR;
wAR3 =ACFT3.wAR;
ebypass1 =ACFT1.ebypass;
ebypass2 =ACFT2.ebypass;
ebypass3 =ACFT3.ebypass;
ediam1 =ACFT1.ediam;
ediam2 =ACFT2.ediam;
ediam3 =ACFT3.ediam;

% AIRLINE OPS PARAMETERS

ISADEV=10;         % ISA DEVIATION [oC]
PAXWT=110;         % PASSENGER's WEIGHT [kg]
MAXUTIL=12;        % MAXIMUM DAILY UTILIZATION [h]
TURNAROUND=45;     % TURN AROUND TIME  [min]
AVGTIT=5;          % AVG TAXI IN TIME  [min]
AVGTOT=10;         % AVG TAXI OUT TIME [min]
ID=30;             % INFLIGHT DELAY COST [$/min]  
TO_ALLOWANCE=200;  % TAKEOFF ALLOWANCE FUEL [kg]
ARR_ALLOWANCE=100; % APPROACH ALLOWANCE FUEL [kg]
avg_ticket=110;    % AVERAGE TIKET PRICE [US$/pax]=> Ref ABEAR 2016&2017
SHARE=0.20;        % MARKET SHARE    
LFREF=0.80;        % REFERENCE LOAD FACTOR  
DISTALT=200;       % ALTERNATE AIRPORT MAXIMUM DISTANCE FROM DESTINATION AIRPORT [nm]
K1=1.1;            % TOTAL REVENUE TO TICKET REVENUE FACTOR  
K2=1.3;            % TOTAL COST TO DOC FACTOR

tic

% REFERENCE DOC CALCULATION
fprintf('\n ** REFERENCE VALUES FOR NETWORK DESIGN **');
fprintf('\n'); 
%
PAYLOAD1=NPax1*PAXWT*LFREF;
PAYLOAD2=NPax2*PAXWT*LFREF;
PAYLOAD3=NPax3*PAXWT*LFREF;
[~,~,DOC1]=Mission5e(0,0,0,0,0,RANGE1,DISTALT,ISADEV,PAYLOAD1,NPax1,ACFT1,0,15);  
[~,~,DOC2]=Mission5e(0,0,0,0,0,RANGE2,DISTALT,ISADEV,PAYLOAD2,NPax2,ACFT2,0,15);
[~,~,DOC3]=Mission5e(0,0,0,0,0,RANGE3,DISTALT,ISADEV,PAYLOAD2,NPax3,ACFT3,0,15);
%
fprintf('\n RANGE1 (nm)              : %5.0f',RANGE1);
fprintf('\n RANGE2 (nm)              : %5.0f',RANGE2);
fprintf('\n RANGE3 (nm)              : %5.0f',RANGE3);
fprintf('\n DOC1   ($/nm)            : %5.2f',DOC1);
fprintf('\n DOC2   ($/nm)            : %5.2f',DOC2);
fprintf('\n DOC3   ($/nm)            : %5.2f',DOC3);
fprintf('\n PAX1                     : %5.0f',NPax1);
fprintf('\n PAX2                     : %5.0f',NPax2);
fprintf('\n PAX3                     : %5.0f',NPax3);
fprintf('\n ALTERNATE DIST (nm)      : %5.0f',DISTALT);
fprintf('\n Average fare ($)         : %5.0f',avg_ticket);
fprintf('\n Average Load Factor (pct): %5.1f',LFREF*100);
fprintf('\n Average Market Share(pct): %5.1f',SHARE*100);
fprintf('\n'); 

% NETWORK OPTIMIZATION

VPAX=[NPax1 NPax2 NPax3]';
VDOC=[DOC1 DOC2 DOC3]'; 
VRANGE=[RANGE1 RANGE2 RANGE3]';
[Airport,X,FREQ,f,LF,DIST,HDG]=NETWORKOPT_R04e(VPAX,VDOC,VRANGE,SHARE,LFREF,avg_ticket,K1,K2);
n=size(X,2);

f
X
FREQ
DIST
HDG

% SECTOR ANALYSIS 

for a=1:3
   
    fprintf('\n');   
    switch a
        case 1            
            fprintf('\n ** ACFT1 SECTORS **'); 
            fprintf('\n RANGE(nm): %5.0f',RANGE1);
            fprintf('\n PAX      : %5.0f',NPax1);
            ACFT=ACFT1;
        case 2
            fprintf('\n ** ACFT2 SECTORS **');
            fprintf('\n RANGE(nm): %5.0f',RANGE2);
            fprintf('\n PAX      : %5.0f',NPax2);
            ACFT=ACFT2;
        case 3
            fprintf('\n ** ACFT3 SECTORS **');
            fprintf('\n RANGE(nm): %5.0f',RANGE3);
            fprintf('\n PAX      : %5.0f',NPax3);
            ACFT=ACFT3;
    end
    fprintf('\n');    
    fprintf('\n SECTOR    PAX LF     ZFW   FOB  TAXI  TOF   TOW    TRIP  LW    REM   DIST   HDG   CRZALT TIME  DOC   FREQ');
    fprintf('\n               [pct]  [kg]  [kg] [kg]  [kg]  [kg]   [kg]  [kg]  [kg]  [nm]  [deg]   [FL] [min] [$/nm]     ');
    
    %
    for i=1:n
        for j=1:n
           if i~=j;
               if X(i,j,a)~=0;
                 DISTANCE=DIST(i,j);                  
                 NPAX=round(LF(i,j)*ACFT.NPax);
                 if a==3 % LOAD REMAINING PAX IN THE LAST ACFT
                    PAX1=round(NPax1*LF(i,j)*FREQ(i,j,1));
                    PAX2=round(NPax2*LF(i,j)*FREQ(i,j,2));
                    PAX3=round(NPax3*LF(i,j)*FREQ(i,j,3));
                    diff=f(i,j)-PAX2-PAX1;
                    if diff<0
                        diff=0;
                    end    
                    if diff<NPax3
                       NPAX=diff;                        
                    end    
                 end                
                 PAYLOAD=NPAX*PAXWT;
                 dep=Airport(i).name;
                 arr=Airport(j).name;
                 sector=string(strcat(dep,'/',arr));   
                 fprintf('\n');
                 fprintf('%s ',sector);
                 Origelev=Airport(i).elev;
                 Destelev=Airport(j).elev;
                 Altelev=Airport(i).elev;
                  %
                 if rvar==1
                   randTIT = -5 + 10*rand(1);  % RANDOM VARIATION FOR TAXI IN TIME (+-5 min )
                   randTOT = -3 + 6*rand(1);   % RANDOM VARIATION FOR TAXI OUT TIME(+-3 min ) 
                 else
                   randTIT=0;
                   randTOT=0;  
                 end   
                 %
                 TIT=randTIT+AVGTIT;
                 TOT=randTOT+AVGTOT;
                 TAXITIME=TIT+TOT;
                 TH=HDG(i,j);
                 THA=HDG(j,i);
                 [Wf(i,j,a),T(i,j,a),CF(i,j,a)]=Mission5e(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,ACFT.NPax,ACFT,1,TAXITIME);  
                 fprintf('%3.0f ',FREQ(i,j,a));
                 T(i,j,a)=(T(i,j,a)+TIT+TOT+TURNAROUND+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)/60; 
                 Wf(i,j,a)=Wf(i,j,a)+TO_ALLOWANCE+ARR_ALLOWANCE;
               end
           end 
        end
    end     
   
  
% NETWORK RESULTS  

    TOTCOST(a)=0;
    TOTDIST(a)=0;
    TOTALFREQ(a)=0;
    TOTALPAX(a)=0; 
    TOTTIME(a)=0;
    TOTFLIGHTS(a)=0;
    % 
        for i=1:n
            for j=1:n
                if X(i,j,a)==1;
                    TOTCOST(a)=TOTCOST(a)+DIST(i,j)*CF(i,j,a)*FREQ(i,j,a)+ID*(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
                    TOTDIST(a)=TOTDIST(a)+DIST(i,j)*FREQ(i,j,a);
                    TOTALPAX(a)=TOTALPAX(a)+round(LF(i,j)*ACFT.NPax*FREQ(i,j,a));
                    TOTTIME(a)=TOTTIME(a)+FREQ(i,j)*(T(i,j,a)+(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)+TURNAROUND)/60;
                    TOTFLIGHTS(a)=TOTFLIGHTS(a)+FREQ(i,j,a);         
                end    
            end    
        end
    %
    
    DOC(a)=TOTCOST(a)/TOTDIST(a);
    COST(a)=K2*TOTCOST(a);
    REV(a)=K1*TOTALPAX(a)*avg_ticket;
    PROFIT(a)=REV(a)-COST(a);
    CASK(a)=COST(a)/(TOTALPAX(a)*TOTDIST(a));
    RASK(a)=REV(a)/(TOTALPAX(a)*TOTDIST(a));
    NP(a)=RASK(a)-CASK(a);               
    NACFT(a)=TOTTIME(a)/MAXUTIL;     
    %
    fprintf('\n');
    fprintf('\n ** NETWORK RESULTS **');
    fprintf('\n'); 
    fprintf('\n TOTAL DIST (nm)          : %10.2f',TOTDIST(a));
    fprintf('\n TOTAL PAX                : %10.0f',TOTALPAX(a));
    fprintf('\n TOTAL COST    ($)        : %10.2f',COST(a));
    fprintf('\n TOTAL REVENUE ($)        : %10.2f',REV(a));
    fprintf('\n TOTAL PROFIT  ($)        : %10.2f',PROFIT(a));
    fprintf('\n NDOC ($/nm)              : %6.2E',DOC(a));
    fprintf('\n NRASK ($/pax.nm)         : %6.4E',RASK(a));
    fprintf('\n NCASK ($/pax.nm)         : %6.4E',CASK(a));
    fprintf('\n NP    ($/pax.nm)         : %6.4E',NP(a));
    fprintf('\n NUM OF ACFT              : %3.0f',NACFT(a));
        
end

% TOTAL RESULTS
MCOST=0;
MTOTCOST=0;
MTOTDIST=0;
MREV    =0;
MTOTALPAX=0;
MACFT=0;

for a=1:3
   MCOST    = MCOST+COST(a);
   MTOTCOST=  MTOTCOST+TOTCOST(a);
   MTOTDIST = MTOTDIST+TOTDIST(a);
   MREV     = MREV+REV(a);
   MTOTALPAX= MTOTALPAX+TOTALPAX(a);
   MACFT    = MACFT+NACFT(a);
end

MDOC=MTOTCOST/MTOTDIST;
MPROFIT=MREV-MCOST;
MCASK=MCOST/(MTOTALPAX*MTOTDIST);
MRASK=MREV/ (MTOTALPAX*MTOTDIST);
MNP=MRASK-MCASK;
%
fprintf('\n');
fprintf('\n ** ALL NETWORKS RESULTS **');
fprintf('\n'); 
fprintf('\n TOTAL DIST (nm)      : %10.2f',MTOTDIST);
fprintf('\n TOTAL PAX            : %10.0f',MTOTALPAX);
fprintf('\n TOTAL COST    ($)    : %10.2f',MCOST);
fprintf('\n TOTAL REVENUE ($)    : %10.2f',MREV);
fprintf('\n TOTAL PROFIT  ($)    : %10.2f',MPROFIT);
fprintf('\n NDOC  ($/nm)         : %6.2E',MDOC);
fprintf('\n NRASK ($/pax.nm)     : %6.4E',MRASK);
fprintf('\n NCASK ($/pax.nm)     : %6.4E',MCASK);
fprintf('\n NP    ($/pax.nm)     : %6.4E',MNP);
fprintf('\n NUM OF ACFT          : %3.0f',MACFT);
fprintf('\n');

fprintf('\n');
fprintf('\n',toc);



