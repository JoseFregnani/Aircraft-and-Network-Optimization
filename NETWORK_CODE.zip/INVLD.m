function GW=INVLD(A,LFL,ISADEV,elev)

MLW=A.MLW;
wS  =A.wS;
CLmax_LD=A.CLMAX_LD;

flag=0;

LW=MLW;
while flag==0
  FL=LD(LW,wS,ISADEV,elev,CLmax_LD);
  if FL>LFL
     LW=LW-10;
  else
     flag=1;
  end
end
GW=LW;