function GW=INVLD(A,LFL,ISADEV,elev,LD_FLAP)

MLW=A.MLW;
wS  =A.wS;
CLmax_clean=A.CLMAX;

flag=0;

LW=MLW;
while flag==0
  FL=LD(LW,wS,ISADEV,elev,CLmax_clean);
  if FL>LFL
     LW=LW-10;
  else
     flag=1;
  end
end
GW=LW;