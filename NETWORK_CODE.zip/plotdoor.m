function plotdoor(lco,FusDiam,hpiso)

eixoxe=FusDiam;
eixoye=FusDiam;

x1 = lco+0.2;


door_width  = 1.2;
door_height = 1.8;

z1=hpiso+door_height;
teta1=asin(z1/(eixoye*0.50));

z2= hpiso;
teta2=asin(z2/(eixoye*0.50));

np=20;
dteta=(teta2-teta1)/(np-1);

for j=1:(np)
    teta=teta1+(j-1)*dteta;
    xe(j)=x1;
    xd(j)=xe(j)+door_width;
    ye(j)=0.50*eixoxe*cos(teta);
    yd(j)=ye(j);
    ze(j)=0.50*eixoye*sin(teta);
    zd(j)=ze(j);
end



xpatch=[xe xd(np:-1:1) xe(1)];
ypatch=[ye yd(np:-1:1) ye(1)];
zpatch=[ze zd(np:-1:1) ze(1)];

plot3(xpatch,ypatch,zpatch,'k')
hold on
plot3(xpatch,-ypatch,zpatch,'k')

