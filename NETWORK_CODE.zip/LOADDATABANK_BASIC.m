function [A]=LOADDATABANK_BASIC()

        % E175LR
        A.OEW           =21800;
        A.MTOW          =38790;
        A.MLW           =34100;
        A.MZFW          =31700;
        A.MAXFUEL       =9428;
        A.Ceiling       =41000;
        %
        A.wS            =72.72;
        A.wSft2         =A.wS*3.28^2;
        A.wAR           =8.6;
        A.wTR           =0.44;
        A.wSweep14      =23.5;
        A.wTwist        =-3;
        A.Kink_semispan =0.32;        
        A.CLMAX         =1.65;
        A.PWing         =1;
        %
        A.inc_root      =2; 
        A.inc_kink      =0; 
        A.inc_tip       =-1; 
        A.wMAC          =3.1;
        A.wSweepLE      =23.5;
        %
        A.VTarea        =16.2;
        A.VTAR          =1.2;
        A.VTTR          =0.5;
        A.VTSweep       =41;
        A.HTarea        =23.35;
        A.HTAR          =4.4;
        A.HTTR          =0.4;
        A.PHT           =1;
        %
        A.container_type='LD2';
        A.NPax          =78;
        A.NCorr         =1;
        A.NSeat         =4;
        A.ncrew         =6;
        A.AisleWidth    =0.49;
        A.CabHeightm    =2;    
        A.SEATwid       =0.46; 
        A.widthratio    =1.1; 
        A.fus_width     =3.01;
        A.fus_height    =3.29;
        A.FusDiam       =3.6;
        %
        A.MMO           =0.82; 
        A.VMO           =340; 
        %
        A.PEng          =1; 
        A.MAXRATE       =14200;  
        A.T0            =A.MAXRATE*0.95;
        A.n             =2;  
        A.nedebasa      =2; 
        
        A.ebypass       =5.0;
        A.ediam         =1.425;
        A.efanpr        =1.6;
        A.eopr          =28.0;
        A.eTIT          =1240;
        %
        A.Airp_SWET     =485;
        A.wingSwet      =122.5;
        A.lf            =31.68;
        A.lco           =4.13;
        A.swet2         =485;
        A.RANGE         =2000;       
        A.longtras      =0.6;
        %
        A.r0            =[0.0153 0.0150 0.0150];
        A.t_c           =[0.1228 0.1055 0.0982];
        A.phi           =[-0.0799 -0.1025 -0.1553];
        A.X_tcmax       =[0.3738 0.3585 0.3590];
        A.theta         =[0.0787 -0.0295 0.1000];
        A.epsilon       =[-0.0549 -0.2101 -0.0258];
        A.Ycmax         =[-4.0000e-04 0.0185 0.0104];
        A.YCtcmax       =[-6.0000e-04 0.0028 0.0109];
        A.X_Ycmax       =[0.6188 0.7870 0.5567]
        A.wTCmed        =0.1100;               
        %
        A.Ccentro       =6.4800;
        A.Craiz         =5.6100;
        A.Cquebra       =3.8800;
        A.Cponta        =1.4600;
        A.xutip         =zeros(1,51);
        A.yutip         =zeros(1,51);
        A.xltip         =zeros(1,51);
        A.yltip         =zeros(1,51);
        A.xukink        =zeros(1,51);
        A.yukink        =zeros(1,51);
        A.xlkink        =zeros(1,51);
        A.ylkink        =zeros(1,51);
        A.xuroot        =zeros(1,51);
        A.yuroot        =zeros(1,51);
        A.xlroot        =zeros(1,51);
        A.ylroot        =zeros(1,51);
       
     
    
        
 