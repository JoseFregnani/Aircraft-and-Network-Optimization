function inter=interpola2D(N,x,y)

n=(length(N)/3)-1; 
for i=0:n-1
    if y>=N{1,i*3+2} & y<N{1,(i+1)*3+2}
        if x<=max(N{1,i*3+1})
            int1=interp1(N{1,i*3+1},N{1,i*3+3},x);
        else
            xmin=max(N{1,i*3+1});
            int1=interp1(N{1,i*3+1},N{1,i*3+3},xmin);
        end
        if x<min(N{1,i*3+1})
            xmin = min(N{1,i*3+1});
            int1=interp1(N{1,i*3+1},N{1,i*3+3},xmin);
        end
        if x<=max(N{1,3*(i+1)+1})
            int2=interp1(N{1,(i+1)*3+1},N{1,(i+1)*3+3},x);
        else
            xmin=max(N{1,3*(i+1)+1});
            int2=interp1(N{1,(i+1)*3+1},N{1,(i+1)*3+3},xmin);
        end
        if x<min(N{1,(i+1)*3+1})
            xmin = min(N{1,(i+1)*3+1});
            int2=interp1(N{1,(i+1)*3+1},N{1,(i+1)*3+3},xmin);
        end
        int2D=int1-(N{1,i*3+2}-y)*(int1-int2)/(N{1,i*3+2}-N{1,(i+1)*3+2});
    end
end
inter=int2D;