%% DESCRI��O E AUTORIA %%
%approachnoise - Rotina para c�lculo do ru�do ao longo da aproxima��o
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   saida       - trajet�ria da aeronave
%                   ACTGEO      - geometria da aeronave
%                   H1          - altura inicial da trajet�ria [m]
%                   DISA        - varia��o da temperatura padr�o [�C]
%                   SW          - �rea alar [m�]
%                   bW          - envergadura [m]
%                   RH          - umidade relativa [%]
%                   dlat        - dist�ncia lateral [m]
%                   XA          - dist�ncia longitudinal [m]
%                   gamma       - �ngulo da trajet�ria [deg]
%Dados de saida  : 
%                   f           - freq��ncias-padr�o
%                   OASPLhistory - hist�rico do ru�do [dB]
%                   tetaout     - dire��o do ru�do em rela��o ao receptor [deg]
%                   tempo       - hist�rico do tempo [s]
%                   distancia   - hist�rico da distancia [m]
%                   altura      - hist�rico da altura [m]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -
%2.0        Paulo Eduardo Cypriano      18-08-13    Racionaliza��o de vari�veis


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [f, OASPLhistory, tetaout, tempo, distancia, altura] = approachnoise(saida,DISA,gamma,RH,dlat,XA,ACTGEO,SW,bW)


%% Vari�veis globais
%global ACTGEO


%% CORPO DA FUN��O %%
%% Manipula��es iniciais %%
[a1, ~]             = size(saida);
tempo               = saida(:,1);
distancia           = saida(:,2);
altura              = saida(:,3);
%% C�lculo do ru�do %%
ACTGEO(23)       = 1;                                                    % Trem-de-pouso principal baixado
ACTGEO(24)       = 1;                                                    % Trem-de-pouso dianteiro baixado
for i1=1:a1
    H1              = saida(i1,3);
    XB              = saida(i1,2);
    L1              = abs(XB-XA);
    R               = (H1^2+L1^2+dlat^2)^0.5;
    termo1          = (((H1-L1*tan(abs(gamma*pi/180)))^2+dlat^2)/R^2)^0.5;
    if XB>XA
        teta        = 180/pi*asin(termo1);
    elseif XB==XA
        teta        = 90;
    else
        teta        = 180-180/pi*asin(termo1);
    end
    vairp           = saida(i1,7);
    fi              = atan(H1/dlat)*180/pi;
    FPhase          = 2;
    saidatemp       = ruidoaero(ACTGEO,H1,DISA,RH,vairp,teta,fi,R,SW,bW,FPhase);
    f               = saidatemp(:,1);
    tetaout(i1)     = teta;
    SPL(:,i1)       = saidatemp(:,2);
end


%% SA�DA DA FUN��O %%
OASPLhistory        = SPL;


%% FINAL DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1989)
%2 - ESDU77022 - Atmospheric properties