clc

% Test data
TOW=54000;
wS =90;
Tmax=22000;
ISADEV=0;
elev=2500;
CLmax_clean=1.6;
BPR=5.0;

FIELD_LENGHT_REQUIRED=BFL(TOW,wS,Tmax,BPR,ISADEV,elev,CLmax_clean)

