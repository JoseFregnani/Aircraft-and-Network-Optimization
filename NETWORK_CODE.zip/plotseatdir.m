function plotseatdir(orix,oriy,widthseat,seatbase,alturaencosto,...
    dzfloor,armrest_top,armrest_bottom,armrest_w)
%
% Entradas:
% orix= origem x das coordenadas do assento
% orix= origem y das coordenadas do assento
% widthseat = largura do assento
% seatbase = altura da base do assento (flutuador)
% alturaencosto = altura do esncosto do assento
% dzfllor = coordenada y do piso (o centro (0,0) � a da secao transversal
% e nao orix e oriy do assento)
%
% base do assento coord x
baseass.x(1)=orix;
baseass.x(2)=orix;
baseass.x(3)=orix+widthseat;
baseass.x(4)=orix+widthseat;
baseass.x(5)=baseass.x(1);
% base do assento coord y
baseass.y(1)=oriy;
baseass.y(2)=oriy+seatbase;
baseass.y(3)=oriy+seatbase;
baseass.y(4)=oriy;
baseass.y(5)=baseass.y(1);
% encosto coord x
encosto.x(1)=baseass.x(1);
encosto.x(2)=encosto.x(1);
encosto.x(3)=baseass.x(3);
encosto.x(4)=encosto.x(3);
% encosto coord y
encosto.y(1)=baseass.y(2);
encosto.y(2)=encosto.y(1)+alturaencosto;
encosto.y(3)=encosto.y(2);
encosto.y(4)=encosto.y(1);
patch(baseass.x,baseass.y,'k')
hold on
plot(encosto.x,encosto.y,'k')
hold on
% desenha descanso dos bracos (esquerdo)
armrest.x(1)=orix;
armrest.x(2)=orix-armrest_w;
armrest.x(3)=armrest.x(2);
armrest.x(4)=armrest.x(1);
armrest.x(5)=armrest.x(1);
armrest.y(1)=dzfloor + armrest_bottom;
armrest.y(2)=armrest.y(1);
armrest.y(3)=dzfloor + armrest_top;
armrest.y(4)=armrest.y(3);
armrest.y(5)=armrest.y(1);
plot(armrest.x,armrest.y,'k')
hold on
% desenha descanso dos bracos (direito)
armrest.x(1)=orix+widthseat;
armrest.x(2)=armrest.x(1);
armrest.x(3)=armrest.x(2) + + armrest_w;
armrest.x(4)=armrest.x(3);
armrest.x(5)=armrest.x(1);
armrest.y(1)=dzfloor + armrest_bottom;
armrest.y(2)=dzfloor + armrest_top;
armrest.y(3)=armrest.y(2);
armrest.y(4)=armrest.y(1);
armrest.y(5)=armrest.y(1);
plot(armrest.x,armrest.y,'k')
return