%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - NETWORK MODULE
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 1.0 / April 2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
close all

% LOAD AIRCRAFT

  [MTOW,MLW,MZFW,OEW,MAXFUEL,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2]=LOADDATA2();
           
% INIT VARIABLES;

MAXPAX=NPax;

% AIRLINE OPS PARAMETERS
n=5;
ISADEV=10;
PAXWT=110;
MAXUTIL=12;
TURNAROUND=30;
TIT=5;
TOT=10;
ID=30;
TO_ALLOWANCE=200;
ARR_ALLOWANCE=100;
avg_ticket=200;
K1=1.3;
K2=1.1;

% DESIGN DIAGRAM CHECK - INSERT FUNCTION HERE

design=0;

% MAIN LOOP

if design==0;
     
    % Retrieve Airport and Demand Data

    [Airport,X,D,LF,DIST,HDG]=Airportdata(n);

    % Construct Frequencies Matrix

        TOTDEMAND=0;
        for i=1:n
          for j=1:n
             if i==j
               f=0;
             else  
               f=round(D(i,j)/(MAXPAX*LF(i,j)));
             end
             FREQ(i,j)=f;  
             TOTDEMAND=TOTDEMAND+D(i,j)*X(i,j);
          end
        end

     % CONSTRUCT Wf,T and CF 

        for i=1:n
            for j=1:n
               if i~j;
                   if X(i,j)~0;
                     DISTANCE=DIST(i,j);
                     DISTALT=DIST(j,i);  
                     NPAX=LF(i,j)*MAXPAX;
                     PAYLOAD=NPAX*PAXWT;
                     dep=Airport(i).name;
                     arr=Airport(j).name;
                     Origelev=Airport(i).elev;
                     Destelev=Airport(j).elev;
                     Altelev=Airport(i).elev;
                     TH=HDG(i,j);
                     THA=HDG(j,i);
                     [Wf(i,j),T(i,j),CF(i,j)]=Mission4(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,NPax);                        
                     T(i,j)=(T(i,j)+TIT+TOT+TURNAROUND+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)/60; 
                     Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
                   end
               end 
            end
        end    

     % TOTAL DOC

        TOTCOST=0;
        TOTDIST=0;
        TOTALFREQ=0;
        TOTALPAX=0;
        TOTTIME=0;
        TOTFLIGHTS=0;
        
     % FINAL CALCULATIONS

        for i=1:n
            for j=1:n
                if X(i,j)~0
                    TOTCOST=TOTCOST+DIST(i,j)*CF(i,j)*FREQ(i,j)+ID*(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
                    TOTDIST=TOTDIST+DIST(i,j)*FREQ(i,j);
                    TOTALPAX=TOTALPAX+LF(i,j)*MAXPAX*FREQ(i,j);
                    TOTTIME=TOTTIME+FREQ(i,j)*T(i,j);
                    TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);         
                end    
            end    
        end
       
        DOC=TOTCOST/TOTDIST
        CASK=K1*DOC/TOTALPAX;
        RASK=K2*avg_ticket/TOTDIST;
        YIELD=RASK-CASK               
        NACFT=TOTTIME/MAXUTIL      
        
end
