%% DESCRI��O E AUTORIA %%
%approachfp - Rotina para c�lculo da trajet�ria de aproxima��o e pouso
%autores    - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de saida  : 
%                   timehistory - trajet�ria de decolagem
%                       (1)     - tempo [s]
%                       (2)     - dist�ncia [m]
%                       (3)     - altura em rela��o ao solo [m]
%                       (4)     - tra��o requerida [N]
%                       (5)     - coeficiente de arrasto
%                       (6)     - coeficiente de sustenta��o
%                       (7)     - velocidade verdadeira [m/s]
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
% 1.0       Paulo Eduardo Cypriano      21-10-09    -
% 2.0       Paulo Eduardo Cypriano      19-01-13    Uniformizacao do calculo das propriedades da atmosfera


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%   SW              - �rea alar [m�]
%   CLMAX           - coeficiente de sustenta��o m�ximo
%   CL3P            - coeficiente de sustenta��o no solo (3 pontos)
%   CLAIR           - coeficiente de sustenta��o no ar
%   CD3P            - coeficiente de arrasto no solo (3 pontos)
%   CDAIR           - coeficiente de arrasto no ar


%% DECLARA��O DA FUN��O %%
function [timehistory] = approachfp(LDPAR,ACTPAR,SW,NEng,VREFVS)


%% Vari�veis globais
%global VREFVS                                                               % Rela��es de velocidade
%global var
%global wing
%global LDPAR


%% CORPO DA FUN��O %%
%% C�lculos preliminares %%
%% Altitude %%
DD                  = 4000;                                                 % dist�ncia inicial da cabeceira da pista [m]
DH                  = DD*tan(-LDPAR(9)*pi/180)+50*0.3048;                % altura inicial da cabeceira da pista [m]
%% Velocidades %%
atm                 = atmosfera(LDPAR(1)+DH,LDPAR(2));                    % propriedades da atmosfera
sigma               = atm(4);                                               % razao das densidades
ro                  = atm(6);                                               % densidade do ar [kg/m�]
VSE                 = (sigma)^0.5*((LDPAR(3))/(0.5*ro*LDPAR(6)*SW))^0.5;            
                                                                            % velocidade de estol - equivalente [m/s]
VREFE               = VREFVS*VSE;                                           % velocidade de refer�ncia no pouso - equivalente [m/s]


%% C�lculo da trajet�ria %%
i1 = 1;
dt = 0.5;                                                                   % intervalo de tempo para integra��o [s]
t(i1) = 0.0;                                                                % tempo inicial [s]
d(i1) = DD;                                                                 % dist�ncia inicial [m]
h(i1) = DH;                                                                 % altura inicial [m]
while h(i1)>50*0.3048
    atm             = atmosfera(LDPAR(1)+h(i1),LDPAR(2));                   % propriedades da atmosfera
    sigma           = atm(4);                                               % razao das densidades
    ro(i1)          = atm(6);                                               % densidade do ar [kg/m�]
    VT(i1)          = VREFE/(sigma^0.5);                                    % velocidade verdadeira [m/s]
    CL(i1)          = LDPAR(3)/(0.5*(VT(i1))^2*SW*ro(i1));               % coeficiente de sustenta��o  
    CD(i1)          = ACTPAR(6);                                            % coeficiente de arrasto
    L(i1)           = 0.5*ro(i1)*SW*CL(i1)*VT(i1)^2;                     % for�a de sustenta��o [N]
    D(i1)           = 0.5*ro(i1)*SW*CD(i1)*VT(i1)^2;                     % for�a de arrasto [N]
    FN(i1)          = (1/NEng)*LDPAR(3)*(sin(LDPAR(9)*pi/180)+CD(i1)/CL(i1));                                                                         % tra��o requerida [N/mot]
    RoC(i1)         = VT(i1)*sin(LDPAR(9)*pi/180);                          % raz�o de descida [m/s]
    i1              = i1+1;                                                 % aumento do �ndice
    t(i1)           = t(i1-1)+dt;                                           % instante de tempo seguinte [s]
    h(i1)           = h(i1-1)+RoC(i1-1)*dt;                                 % altura seguinte [m]
    d(i1)           = d(i1-1)-VT(i1-1)*dt*cos(LDPAR(9)*pi/180);             % dist�ncia seguinte [m]
end

%% SA�DA DOS DADOS %% 
timehistory         = [t(1:(i1-1))' d(1:(i1-1))' h(1:(i1-1))' FN' CD' CL' VT'];


%% FINAL DA ROTINA %%
end
