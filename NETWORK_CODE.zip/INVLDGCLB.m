function GW=INVLDGCLB(A,NNind,NNwav,NNcd0,NNCL,ISADEV,elev,APP_FLAP)

lb2kg=0.4535;
ne=0.8;
cfe= 0.0030;

% CALCULATIONS
h    =elev;
T0_kg=A.MAXRATE*lb2kg*0.98;% GA Thrust assumed as 98% T/O
[~, ~, sigma, ~] = atmos(h,ISADEV);
T=T0_kg*sigma^ne;
MLW=A.MLW;
n=A.n;
%
flag=0;
while flag==0
    TW_APPCLB=check_APPCLBLIM(A,NNind,NNwav,NNcd0,NNCL,cfe,APP_FLAP,ISADEV,elev);
    ToW        = n*T/MLW;
    if ToW<TW_APPCLB
        MLW=MLW-10;
    else    
        flag=1;
    end    
end
 
GW=MLW;