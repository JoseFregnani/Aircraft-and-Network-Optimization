function y=IRRCALC(CASHFLOW)

n=size(CASHFLOW,1);
r=0;
f=0;
while f==0 
  SUM=0;
  for i=1:n    
    C=CASHFLOW(i,1)/((1+r)^(i-1));    
    SUM=SUM+C;
  end
  if SUM<=0
     f=1;
  else
     r=r+0.001;
  end   
end
y=r;
