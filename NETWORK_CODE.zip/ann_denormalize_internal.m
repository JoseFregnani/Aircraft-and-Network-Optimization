function X = ann_denormalize_internal(X_norm, Mean, Range)

%Number of training sets
m = size(X_norm,2);

%Denormalization
X = X_norm.*(Range*ones(1,m))/2 + Mean*ones(1,m);

end