clc

lb     =[250 0.65 0.65 250 250 0.65 250 0.65 0.65 250 250 0.65 500];
ub     =[320 0.80 0.80 320 320 0.80 320 0.80 0.80 320 320 0.80 4000];
initpop=[280 0.78 0.78 280 280 0.78 250 0.74 0.74 250 250 0.74 2000];

options = saoptimset('MaxIter',100,'PlotFcns',{@saplotbestx,@saplotbestf,@saplotx,@saplotf});

[x,fval,exitflag,output] = simulannealbnd(@Mission2_OPT,initpop,lb,ub,options)

Mission2_OPT(x)



