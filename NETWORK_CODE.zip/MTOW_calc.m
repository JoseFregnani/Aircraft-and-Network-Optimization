 function [MTOWcalc, OEW, W_climb_final, SWETsai,...
     TOTFUEL, TOTFUEL_ALT, TOTTIME, htsai,vtsai,xlesai,xcg_fwd,xcg_aft]...
    = MTOW_calc(MTOW,AirplaneCLmaxClean,wTCmed,wSweepLE,wSweep14,...
    wS,wTR,wAR,wMAC,wYMAC,...
    inc_root,inc_kink,inc_tip,Kink_semispan,longtras,posxmunhao,...
    xcgtanques,NSeat,fuelcapacitykg,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,Ccentro,Craiz,Cponta,margin_static,...
    Range,Engine_data, CruiseMach,Ceiling,SWET,wingSwet,Payload,ncrew,...
    TLOIT,DIST_ALT,NNind,NNwav,NNcd0,NNCL,PHT,ht,...
    EnginLength_m,EngineDe_m,pylon,...
    CLALFA_rad,wingfuelcapacity,PWing,vt,vtac_rel,htac_rel,...
    YEIS,xle,slat,fus_width, fus_height, FusSwet_m2,lf,lcab,ltail,...
    VHT,VVT,SeatPitch,Aislewidth,SeatWidth)

% CONSTANTS
lb2kg   = 1/2.2046;

% GEOMECTRIC PARAMETERS
S       = wS; % WING REFERENCE AREA [m2]
lco     = lf -(lcab+ltail); % forward fuselage length [m]
PEng    = Engine_data(1); % 1= two underwing engines; 2= two engines at rear fuselage
ebypass = Engine_data(2); % Engine by-pass ratio
ediam   = Engine_data(3); % Fan diameter [m]
efanpr  = Engine_data(4); % Fan pressure ratio
eopr    = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT    = Engine_data(6); % Turbine Inlet Temperature [K]
CLMAX   = AirplaneCLmaxClean;
%ENGINE PARAMETERS

%MAXRATE=13400;

n=max(2,PEng); % number of engines

% OPERATIONS PARAMETERS
DISTTOT     = Range; % [nm]
ALTDIST     = 200; 
HDG         = 0;
TOW         = MTOW;
ORIGALT     = 0;
DESTALT     = 0;
CLBCAS      = 280;
CLBCAS_ALT  = 250;
CLBMACH     = 0.78;
CLBMACH_ALT = 0.74;
CRZMACH     = 0.78;
CRZMACH_ALT = 0.74;
CRZCAS      = 270;
CRZCAS_ALT  = 270;
DESCAS      = 280;
DESCAS_ALT  = 280;
DESMACH     = 0.78;
DESMACH_ALT = 0.72;
ISADEV      = 0;
RCMIN       = 300; % Rate of climb [ft/min]
BUFFMARGIN  = 1.3;
MINCRZTIME  = 3;
HOLDTIME    = 30;
%**************************************************************************
%****** Takeoff %%
%**************************************************************************
ftakeoff = 0.005*TOW;
ttakeoff = 1;
fprintf('\n TAKEOFF:');
fprintf('\n => time = %5.1f min',ttakeoff);
fprintf('\n => fuel = %5.1f kg \n',ftakeoff);
% MAX & OPT ALTITUDE CALCULATION
initalt = ORIGALT;
hf      = Ceiling;
step    = 100;
W_climb = TOW - ftakeoff;
%[HMAX,RCRES]=MAXALT(S,b,afil,tc,df,swet2,phi14,nedebasa,n,0.95,ebypass,
%ediam,efanpr,eopr,eTIT,W_climb,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN);
[HMAX,RCRES]=MAXALT(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,W_climb,initalt,step,hf,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
    [HOPT,SRMAX]=optalt(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,W_climb,initalt,hf,step,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);
% [HOPT,SRMAX]=optalt(S,b,afil,tc,df,swet2,phi14,nedebasa,...
%     n,0.95,ebypass,ediam,efanpr,eopr,eTIT,W_climb,initalt,hf,step,CLBCAS,CLBMACH,ISADEV,RCMIN);

% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK

g_sub=4/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=10*CRZMACH*MINCRZTIME;
K2=DISTTOT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>Ceiling
  HMAX2=Ceiling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt=HOPT;
else
    finalalt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 

finalalt= 1000*(fix (finalalt/1000));
FL=finalalt/100;

ODDFL=[90 110 130 150 170 190 210 230 250 270 290 310 330 350 370 390 410 430 450 470 490 510];
EVENFL=[80 100 120 140 160 180 200 220 240 260 280 300 320 340 360 380 400 420 440 460 480 500 520];
if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        %fprintf('\n ODD',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        %fprintf('\n EVEN',FL);
        finalalt=finalalt+1000;
        if finalalt>=HMAX
            finalalt=finalalt-3000;
        end 
    end
end    

% CLIMB CALCULATION
maneted=0.95;
initalt=ORIGALT+1500;
[dclb,tclb,fclb,~]=CALC_CLB_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    W_climb,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);
%
fprintf('\n CLIMB TO DESTINATION:');
fprintf('\n => GWi  = %5.0f',W_climb);
fprintf('\n => GWf  = %5.0f',W_climb-fclb);
fprintf('\n => ALTi = %5.0f',initalt);
fprintf('\n => ALTf = %5.0f',finalalt);
fprintf('\n => OPTALT = %5.0f',HOPT);
fprintf('\n => MAXALT = %5.0f',HMAX);
fprintf('\n => CAS = %5.0f',CLBCAS);
fprintf('\n => Mach= %5.3f',CLBMACH);
fprintf('\n => AVG RC= %5.0f',(finalalt-initalt+1500)/tclb);
fprintf('\n => RES RC= %5.0f',RCRES);
fprintf('\n => OPT SR= %6.4f',SRMAX);
fprintf('\n');
fprintf('\n => time = %5.1f min',tclb);
fprintf('\n => dist = %5.1f nm',dclb);
fprintf('\n => fuel = %5.1f kg',fclb);
fprintf('\n => AVGFF = %5.1f',fclb/tclb*60);   

% CRUISE & DESCENT ALGORITHM 
% Massa no final da subida
W_climb_final = W_climb-fclb;
WTOC          = W_climb_final;
INITCRZALT    = finalalt;
CRZMACH       = CLBMACH;
h             = INITCRZALT;

K = 0;
dcrz=DISTTOT-dclb-K;
flag=1;

while flag==1
    
    % CRUISE
    
  [TA]=transitionalt(CRZMACH,CRZCAS,ISADEV);
    [~, PR, ~, ~] = atmos(h,ISADEV);

    if h<=10000
        M=CAS2MACH(250,PR);
    end
    if and(h>10000,h<=TA)
        M=CAS2MACH(CRZCAS,PR);
    end
    if h>TA
        M=CRZMACH;
    end
    
    [tcrz,fcrz,mancrz]=CALC_CRZ(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
        n,ebypass,ediam,efanpr,eopr,eTIT,WTOC,h,M,dcrz,ISADEV,NNind,NNwav,NNcd0,NNCL);
    
    WTOD=WTOC-fcrz;
    
    % DESCENT

    FINALCRZALT=INITCRZALT;
    initalt=FINALCRZALT;
    finalalt=DESTALT+1500;
    maneted=0.55;

    [ddes,tdes,fdes]=CALC_DES_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
         inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
        WTOD,initalt,finalalt,CLBCAS,CLBMACH,ISADEV,NNind,NNwav,NNcd0,NNCL);

    dTOT=dclb+dcrz+ddes;
    e=abs(DISTTOT-dTOT);
    if e<=0.5;
       flag=0;
       fprintf('\n => DTOT= %5.0f',dTOT);
    else   
       dcrz=dcrz-e; 
    end 
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% CLIMB to Alternate %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% MAX & OPT ALTITUDE CALCULATION

initalt_climb_alt=DESTALT;
hf=Ceiling;
step=50;

TOW_ALT=TOW-fclb-fdes-fcrz-ftakeoff;

%
[HMAX,RCRES]=MAXALT(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,step,hf,...
    CLBCAS,CLBMACH_ALT,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL);
%
    [HOPT,SRMAX]=optalt(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,hf,step,...
    CLBCAS,CLBMACH_ALT,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);
%
%[HMAX,RCRES]=MAXALT(S,b,afil,tc,df,swet2,phi14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,hf,step,CLBCAS,CLBMACH_ALT,ISADEV,RCMIN,CLMAX,BUFFMARGIN);
%[HOPT,SRMAX]=optalt(S,b,afil,tc,df,swet2,phi14,nedebasa,n,0.95,ebypass,ediam,efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,hf,step,CLBCAS,CLBMACH_ALT,ISADEV,RCMIN);

% MAX ALTITUDE WITH MINIMUM CRUISE TIME CHECK

g_sub=2/1000;
g_des=3/1000;
K1=g_sub+g_des;
Dmin=CRZMACH*10*MINCRZTIME;
K2=DIST_ALT-Dmin+g_sub*(ORIGALT+1500)+g_des*(DESTALT+1500);
HMAX2=K2/K1;
if HMAX2>Ceiling
  HMAX2=Ceiling;
end
if HMAX>HMAX2
   HMAX=HMAX2;
end
if HOPT<HMAX
    finalalt_climb_alt=HOPT;
else
    finalalt_climb_alt=HMAX;
end   

% NEXT UPPER FEASIBLE RVSM FL CHECK ACCORDING TO PRESENT HEADING 

finalalt_climb_alt= 1000*(fix (finalalt_climb_alt/1000));
FL=finalalt_climb_alt/100;

if and(HDG>0,HDG<=180)
    C=ismember([FL],[ODDFL]);
    if C==0
        %fprintf('\n ODD',FL);
        finalalt_climb_alt=finalalt_climb_alt+1000;
        if finalalt_climb_alt>=HMAX
            finalalt_climb_alt=finalalt_climb_alt-3000;
        end    
    end
elseif and(HDG>180,HDG<=360)
    C=ismember([FL],[EVENFL]);
    if C==0
        %fprintf('\n EVEN',FL);
        finalalt_climb_alt=finalalt_climb_alt+1000;
        if finalalt_climb_alt>=HMAX
            finalalt_climb_alt=finalalt_climb_alt-3000;
        end 
    end
end    

% CLIMB to ALTERNATE CALCULATION

maneted=0.95;
initalt_climb_alt=ORIGALT+1500;
%
[dclb_alt,tclb_alt,fclb_alt,hf]=CALC_CLB_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    W_climb,initalt_climb_alt,finalalt_climb_alt,CLBCAS_ALT,...
    CLBMACH_ALT,ISADEV,RCMIN,NNind,NNwav,NNcd0,NNCL);
%

% [dclb_alt,tclb_alt,fclb_alt,hf]=CALC_CLB_REV07(S,b,afil,tc,...
%     df,swet2,phi14,n,nedebasa,maneted,ebypass,ediam,...
%     efanpr,eopr,eTIT,TOW_ALT,initalt_climb_alt,finalalt_climb_alt,...
%     CLBCAS_ALT,CLBMACH_ALT,ISADEV,RCMIN);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%% CRUISE e DESCENT to ALTERNATE %%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% CRUISE & DESCENT ALGORITHM 

WTOC_ALT=TOW_ALT-fclb_alt;
INITCRZALT=finalalt_climb_alt;
h=finalalt_climb_alt;
dcrz_alt=DIST_ALT-dclb_alt-5;
flag=1;

while flag==1
    
    % CRUISE
    
    [TR, PR, DR, a] = atmos(h,ISADEV);
    [MCRZ]=CAS2MACH(CRZCAS,PR);
    if MCRZ>CRZMACH_ALT
      MCRZ=CRZMACH_ALT;
    end  
    
    [tcrz_alt,fcrz_alt,mancrz]=CALC_CRZ(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,ebypass,ediam,efanpr,eopr,eTIT,WTOC_ALT,h,MCRZ,dcrz_alt,...
        ISADEV,NNind,NNwav,NNcd0,NNCL);
    %
    %[tcrz_alt,fcrz_alt,mancrz]=CALC_CRZ(S,b,afil,...
    %tc,df,swet2,phi14,n,nedebasa,ebypass,ediam,efanpr,eopr,...
    %eTIT,WTOC_ALT,h,MCRZ,dcrz_alt,ISADEV);
    
    WTOD_ALT=WTOC_ALT-fcrz_alt;
    
    % DESCENT

    FINALCRZALT=INITCRZALT;
    initalt_crz_alt=FINALCRZALT;
    finalalt_crz_alt=DESTALT+1500;
    maneted=0.50;
        
        [ddes_alt,tdes_alt,fdes_alt]=CALC_DES_REV07(S,wAR,wTR,SWET,wingSwet,wSweepLE,...
         inc_root,inc_kink,inc_tip,Kink_semispan,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
        n,maneted,ebypass,ediam,efanpr,eopr,eTIT,...
        WTOD_ALT,initalt_crz_alt,finalalt_crz_alt,DESCAS_ALT,DESMACH_ALT,...
        ISADEV,NNind,NNwav,NNcd0,NNCL);
    
    %[ddes_alt,tdes_alt,fdes_alt]=CALC_DES_REV07...
    %(S,b,afil,tc,df,swet2,phi14,nedebasa,maneted,...
    %ebypass,ediam,efanpr,eopr,eTIT,WTOD_ALT,initalt_crz_alt,...
    %finalalt_crz_alt,CLBCAS_ALT,CLBMACH_ALT,ISADEV,RCMIN);

    dTOT=dclb_alt+dcrz_alt+ddes_alt;
    e=abs(dTOT-DIST_ALT);
    if e < 0.5
       flag=0;
       fprintf('\n => DTOT= %5.0f',dTOT);
    else   
       dcrz_alt=dcrz_alt-e;   
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%% LOITER %%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
WLoit       = WTOD;
hLoit       = DESTALT + 26250;
MLoit       = 0.55;
Tspan       =[0.01 45]; % [min]
IC          = WLoit;
[~, X]= ode45(@(t,x) loiter(t,x,hLoit,MLoit,S,ISADEV,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
     Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,SWET,wingSwet,...
     n,efanpr,eopr,ebypass,ediam,eTIT),Tspan,IC);
nf           = size(X,1);
WLoitf       = X(nf);
floit        = WLoit-WLoitf;
% WLoit       = WTOD;
% hLoit       = DESTALT + 26250;
% MLoit       = 0.55;
% [~, ~, DR, a] = atmos(hLoit,ISADEV);
% dens0       = 1.225;
% dens        = dens0*DR;
% TAS         = MLoit*a;
% V           = TAS*kt2ms;
% bank_angle  = 25;
% V           = V/sqrt(cos(rad*bank_angle));
% q           = (1/2)*dens*(V^2);
% CL          = (WLoit*g)/(q*S);
%
% [CDwing]=CDCLneural(MLoit, hLoit/m2feet,0,S,wAR,wTR,wSweepLE,...
%    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
%     Ycmax,YCtcmax,X_Ycmax);
% cfe          = 0.0030;
% [CD0]        = cfe*SWET/S;
% % CD0          = CDwing + CD0_ubrige;
% %
% %[CD0]      = cd0torenbeek(MLoit,V,S,b,afil,tc,df,hLoit,swet2,ISADEV);
% LD           = CL/(2*CD0);
% TLOITs       = TLOIT*60; 
% AUX          = (TLOITs/(LD*3600))*0.60;
% WRATIO       = exp(AUX);
% WLoitf       = WLoit/WRATIO;
% floit        = WLoit-WLoitf;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%% TAXI %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ttaxi = (0.51 * 1e-6 * TOW + 0.125) * 60; %[min] Roskam vol VIII pag 98
ftaxi = 0.005*TOW;
%
%%%%%%%%%%%%% FINAL COMPUTATION %%%%%%%%%%%%%%%%%%%%
%
TOTFUEL     = fclb+fdes+fcrz+ftakeoff;
TOTFUEL_ALT = TOTFUEL + fclb_alt + fcrz_alt + fdes_alt + ftaxi+floit;
TOTTIME     = tclb+tdes+tcrz+ttakeoff;
TOTDIST     = dclb+ddes+dcrz;
%
fprintf('\n');
fprintf('\n CRUISE:');
fprintf('\n => GWi  = %5.0f',WTOC);
fprintf('\n => GWf  = %5.0f',WTOD);
fprintf('\n => ALTi = %5.0f',INITCRZALT);
fprintf('\n => ALTf = %5.0f',FINALCRZALT);
fprintf('\n => CAS = %5.0f',CRZCAS);
fprintf('\n => Mach= %5.3f',MCRZ);
fprintf('\n => time = %5.1f min',tcrz);
fprintf('\n => dist = %5.1f',dcrz);
fprintf('\n => fuel = %5.1f',fcrz);   
fprintf('\n => AVGFF = %5.1f',fcrz/tcrz*60);   
fprintf('\n => maneted = %5.2f',mancrz);   
fprintf('\n');
fprintf('\n DESCENT:');
fprintf('\n => GWi  = %5.0f',WTOD);
fprintf('\n => GWf  = %5.0f',WTOD-fdes);
fprintf('\n => ALTi = %5.0f',initalt);
fprintf('\n => ALTf = %5.0f',finalalt);
fprintf('\n => CAS = %5.0f',DESCAS);
fprintf('\n => Mach= %5.3f',DESMACH);
fprintf('\n => AVG RD= %5.0f',(finalalt-initalt+1500)/tdes);
fprintf('\n');
fprintf('\n => time = %5.1f',tdes);
fprintf('\n => dist = %5.0f',ddes);
fprintf('\n => fuel = %5.1f',fdes);
fprintf('\n => AVGFF = %5.1f',fdes/tdes*60);   
fprintf('\n');

fprintf('\n CLIMB TO ALTERNATE:');
fprintf('\n => GWi  = %5.0f',TOW_ALT);
fprintf('\n => GWf  = %5.0f',TOW_ALT-fclb_alt);
fprintf('\n => ALTi = %5.0f',initalt_climb_alt);
fprintf('\n => ALTf = %5.0f',finalalt_climb_alt);
fprintf('\n => OPTALT = %5.0f',HOPT);
fprintf('\n => MAXALT = %5.0f',HMAX);
fprintf('\n => CAS = %5.0f',CLBCAS_ALT);
fprintf('\n => Mach= %5.3f',CLBMACH_ALT);
fprintf('\n => AVG RC= %5.0f',(finalalt-initalt+1500)/tclb_alt);
fprintf('\n => RES RC= %5.0f',RCRES);
fprintf('\n => OPT SR= %6.4f',SRMAX);
fprintf('\n');
fprintf('\n => time = %5.1f min',tclb_alt);
fprintf('\n => dist = %5.1f nm',dclb_alt);
fprintf('\n => fuel = %5.1f kg',fclb_alt);
fprintf('\n => AVGFF = %5.1f \n',fclb_alt/tclb_alt*60);  

fprintf('\n CRUISE TO ALTERNATE:');
fprintf('\n => GWi  = %5.0f',WTOC_ALT);
fprintf('\n => GWf  = %5.0f',WTOD_ALT);
fprintf('\n');
fprintf('\n => time = %5.1f min',tcrz_alt);
fprintf('\n => dist = %5.1f nm',dcrz_alt);
fprintf('\n => fuel = %5.1f kg',fcrz_alt);
fprintf('\n => AVGFF = %5.1f /n',fcrz_alt/tcrz_alt*60);  

fprintf('\n');
fprintf('\n DESCENT to ALTERNATE:');
fprintf('\n => GWi  = %5.0f',WTOD_ALT);
fprintf('\n => GWf  = %5.0f',WTOD_ALT-fdes_alt);
fprintf('\n => ALTi = %5.0f',initalt_crz_alt);
fprintf('\n => ALTf = %5.0f',finalalt_crz_alt);
fprintf('\n => CAS = %5.0f',DESCAS);
fprintf('\n => Mach= %5.3f',DESMACH);
fprintf('\n => AVG RD= %5.0f',(finalalt-initalt+1500)/tdes_alt);
fprintf('\n');
fprintf('\n => time = %5.1f',tdes_alt);
fprintf('\n => dist = %5.0f',ddes_alt);
fprintf('\n => fuel = %5.1f',fdes_alt);
fprintf('\n => AVGFF = %5.1f',fdes_alt/tdes_alt*60);   
fprintf('\n');

fprintf('\n');
fprintf('\n TAXI:');
fprintf('\n => time = %5.1f min',ttaxi);
fprintf('\n => fuel = %5.1f kg',ftaxi);
fprintf('\n');

fprintf('\n');
fprintf('\n LOITER:');
fprintf('\n => time = %5.1f min',TLOIT);
fprintf('\n => fuel = %5.1f kg',floit);
fprintf('\n');

fprintf('\n TOTAL:');
fprintf('\n => time = %5.1f h',TOTTIME/60);
fprintf('\n => dist = %5.1f',TOTDIST);
fprintf('\n => fuel for destination = %5.1f kg',TOTFUEL);
fprintf('\n => fuel for alternate   = %5.1f kg',TOTFUEL_ALT);

% New MTOW Estimation

MMO        = CruiseMach;
[Fn,~]     = engine_main(0,0,efanpr,eopr,ebypass,1,ediam,eTIT);
%T0         = n*Fn*N2lbf;
%fprintf('\n Takeoff thrust single engine = %6.0f lb \n',T0/n)
%wSft2      = wS*m2feet*m2feet;
MTOW_error = 1E06;
MTOWcalc   = MTOW;
while MTOW_error > 50
%W2lb       = MTOWcalc*kg2lb;
%wefrac     = wempty(wAR,wSft2,MMO,W2lb,T0,wSweep14);
%OEW        = MTOW*wefrac;
NPax          = round(Payload/100);
[OEW_lb, weightcomp] = WeightAirplane(NPax,Range,MTOW,TOTFUEL,...
    Ceiling,wTCmed,MMO,...
    Fn,EnginLength_m,EngineDe_m,ebypass,eopr,...
    Engine_data(1),PWing,...
    YEIS,xle,slat,wMAC,wYMAC,wTR,wS,wAR,wSweepLE,wSweep14,PHT,ht,vt,...
    fus_width,fus_height,FusSwet_m2,lf,lcab,ltail,wingfuelcapacity);
OEW           = OEW_lb*lb2kg;
MTOWnew       = Payload + OEW + ncrew*100 + TOTFUEL_ALT*1.0025;
MTOW_error    = abs(MTOWcalc-MTOWnew);
MTOWcalc      = 0.20*MTOWcalc+ 0.80*MTOWnew;
HTSWET_old    = ht.Swet;
VTSWET_old    = vt.Swet;
SWET_old      = SWET;
[xleout,htout, vtout,~,xcg_fwd,xcg_aft,~]=...
    tailsizing(xle,VHT,VVT,...
    slat,PWing,wS,wAR,wTR,wSweep14,wMAC,wYMAC,...
    wSweepLE,Ccentro,Craiz,Cponta,margin_static,fus_width,fus_height,lf,...
    lcab,lco,longtras,posxmunhao,xcgtanques,NPax,NSeat,fuelcapacitykg,...
    PEng,EnginLength_m,EngineDe_m,PHT,ht,vt,Kink_semispan,vtac_rel,htac_rel,...
    Ceiling,CruiseMach,CLALFA_rad,pylon,weightcomp,...
    SeatPitch,Aislewidth,SeatWidth);
xle = xleout;
ht  = htout;
vt  = vtout;
SWET = SWET_old + ht.Swet + vt.Swet - (HTSWET_old + VTSWET_old);
end
vtsai  = vt;
htsai  = ht;
xlesai = xle;
SWETsai = SWET;
end
%