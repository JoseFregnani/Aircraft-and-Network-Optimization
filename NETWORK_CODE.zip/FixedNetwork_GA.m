clc

lb     =[15  7.0 0.3  70 75 1.3 5.0 25.0 -5.0 0.32];
ub     =[35 10.0 0.5 130 85 1.5 6.5 30.0 -2.0 0.40];

options = gaoptimset('PopulationSize',20,'PlotFcns',{@gaplotbestf,@gaplotpareto});

[x,fval,exitflag,output] = gamultiobj(@Network_GA,10,[],[],[],[],lb,ub,options)

x
fval
exitflag
output



