% Network Fixed Analysis

clc
clear all

% INIT VARIABLES;

% BASELINE

wSweep14=2;
wAR=8.6;
wTR=0.34;
MAXPAX=78;
wS=72.72
ediam=1.425
ebypass=5.0;
eopr=28.5;
wTwist=-3;
Kink_semispan=0.34;

% % % % MAX YIELD - MOGA-II
% wS=79.71
% wAR=8.9;
% wTR=0.37;
% wSweep14=33.362;
% ediam=1.5;
% ebypass=5.844;
% eopr=28.6;
% wTwist=-5;
% Kink_semispan=0.354;
% MAXPAX=130;

% % % % % MAX YIELD - NSGA-II
% wS=83.57;
% wAR=9.67;
% wTR=0.313;
% wSweep14=34.18;
% ediam=1.4963;
% ebypass=5.59;
% eopr=29.42;
% wTwist=-3.87;
% Kink_semispan=0.367;
% MAXPAX=129;

% MIN DOC - MOGA-II
% wS=82.81
% wAR=8.4;
% wTR=0.36;
% wSweep14=34.5;
% ediam=1.431;
% ebypass=5.6;
% eopr=28.8;
% wTwist=-3.6;
% Kink_semispan=0.3;
% MAXPAX=70;

% % MIN DOC - NSGA-II
% wS=82.97
% wAR=9.615;
% wTR=0.323;
% wSweep14=33.340;
% ediam=1.495;
% ebypass=5.59;
% eopr=28.44;
% wTwist=-3.907;
% Kink_semispan=0.35;
% MAXPAX=71;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ISADEV=10;
n=5;
PAXWT=110;
MAXUTIL=12;
TURNAROUND=30;
TIT=5;
TOT=10;
ID=30;
TO_ALLOWANCE=200;
ARR_ALLOWANCE=100;
NSeat=4;
NCorr=1;
avg_ticket=250;

% PRE CALCULATION

PRECALC(wS,wAR,wTR,wSweep14,NSeat,NCorr,MAXPAX,ediam,ebypass,eopr,wTwist,Kink_semispan);

% Retrieve Networkdata

[Airport,X,D,LF,DIST,HDG]=Airportdata(n);

% Frequencies Matrix

TOTDEMAND=0;
for i=1:n
  for j=1:n
     if i==j
       f=0;
     else  
       f=round(D(i,j)/(MAXPAX*LF(i,j)));
     end
     FREQ(i,j)=f;  
     TOTDEMAND=TOTDEMAND+D(i,j)*X(i,j);
  end
end

% Wf,T and CF matrixes

for i=1:n
    for j=1:n
       if i~j;
           if X(i,j)~0;
             DISTANCE=DIST(i,j);
             DISTALT=DIST(j,i);  
             NPAX=LF(i,j)*MAXPAX;
             PAYLOAD=NPAX*PAXWT;
             dep=Airport(i).name;
             arr=Airport(j).name;
             Origelev=Airport(i).elev;
             Destelev=Airport(j).elev;
             Altelev=Airport(i).elev;
             TH=HDG(i,j);
             THA=HDG(j,i);
             [Wf(i,j),T(i,j),CF(i,j)]=Mission3_MF(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,MAXPAX);                        
             T(i,j)=(T(i,j)+TIT+TOT+TURNAROUND+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)/60; 
             Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
            end
       end 
    end
end    

% TOTAL DOC

TOTCOST=0;
TOTDIST=0;
TOTALFREQ=0;
TOTALPAX=0;
TOTTIME=0;
TOTFLIGHTS=0;

for i=1:n
    for j=1:n
        if X(i,j)~0
            TOTCOST=TOTCOST+DIST(i,j)*CF(i,j)*FREQ(i,j)+ID*(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
            TOTDIST=TOTDIST+DIST(i,j)*FREQ(i,j);
            TOTALPAX=TOTALPAX+LF(i,j)*MAXPAX*FREQ(i,j);
            TOTTIME=TOTTIME+FREQ(i,j)*T(i,j);
            TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);         
        end    
    end    
end

K1=1.3;
K2=1.1;
DOC=TOTCOST/TOTDIST
CASK=K1*DOC/TOTALPAX;
RASK=K2*avg_ticket/TOTDIST;
YIELD=RASK-CASK
NETEFF=TOTALPAX/TOTDEMAND
if NETEFF>1 
   NETEFF=1
end  
NACFT=TOTTIME/MAXUTIL
