%% DESCRI��O E AUTORIA %%
%approachEPNdB - Rotina para c�lculo do ru�do EPNdB na aproxima��o
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   saida       - trajet�ria da aeronave
%                   ACTGEO      - geometria da aeronave
%                       (1)     - SH - �rea de refer�ncia da empenagem horizontal [m�]
%                       (2)     - bH - envergadura da empenagem horizontal [m]
%                       (3)     - SV - �rea de refer�ncia da empenagem vertical [m�]
%                       (4)     - bV - envergadura da empenagem vertical [m]
%                       (5)     - SF - �rea total dos flapes [m�]
%                       (6)     - bF - envergadura total dos flapes [m]
%                       (7)     - deltaf - deflex�o dos flapes [deg]
%                       (8)     - dmtyre - di�metro do pneu - trem de pouso principal [m]
%                       (9)     - dntyre - di�metro do pneu - trem de pouso dianteiro [m]
%                       (10)    - nmgear - n�mero de unidades no trem de pouso principal
%                       (11)    - nmgear - n�mero de unidades no trem de pouso dianteiro
%                       (12)    - lmgear - comprimento da perna do trem de pouso principal [m]
%                       (13)    - lngear - comprimento da perna do trem de pouso dianteiro [m]
%                       (14)    - nmwheel - n�mero de pneus por trem principal 
%                       (15)    - nnwheel - n�mero de pneus por trem dianteiro
%                       (16)    - fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
%                       (17)    - fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
%                       (18)    - fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
%                       (19)    - fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
%                       (20)    - fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
%                       (21)    - nslots - n�mero de slots no flape
%                       (22)    - fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
%                       (23)    - fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
%                       (24)    - hprec - altitude no ponto de medi��o
%                       (25)    - disarec - temperatura no ponto de medi��o [�C]
%                   H1          - altura inicial da trajet�ria [m]
%                   DISA        - varia��o da temperatura padr�o [�C]
%                   SW          - �rea alar [m�]
%                   bW          - envergadura [m]
%                   RH          - umidade relativa [%]
%                   dlat        - dist�ncia lateral [m]
%                   XA          - dist�ncia longitudinal [m]
%Dados de saida  : 
%                   APPEPNdB    - ru�do da aeronave na aproxima��o [EPNdB]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [APPEPNdB] = approachEPNdB(saida,DISA,gamma,RH,dlat,XA,ACTGEO,SW,bW)


%% CORPO DA FUN��O %%
%% C�lculo do hist�rico do ru�do de pouso %%
[f, SPL, tetaout, tempo, distancia, altura] = approachnoise(saida,DISA,gamma,RH,dlat,XA,ACTGEO,SW,bW);
%% Transforma��o de SPL para NOY %%
[f,NOY]             = calcNOY(f,SPL);
%% C�lculo de Perceived Noise Level (PNL) %%
[PNL]               = calcPNL(f,NOY);
%% C�lculo da corre��o de tom para PNL %%
[~, a2]             = size(SPL);
for i1=1:a2
    C(i1)           = calcPNLT(f,SPL(:,i1));
end
%% C�lculo de Perceived Noise Level - tone corrected (PNLT) %%
PNLT                = PNL+C;
%% C�lculo de Effective Perceived Noise Level (EPNdB) %%
APPEPNdB            = calcEPNdB(tempo,PNLT);


%% ENCERRAMENTO DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1989)
%2 - ESDU77022 - Atmospheric properties