function dxhn=ESDU77012(xle,wingCLa,wS,wAR,wMAC,wYMAC,wSweepLE,...
    EnginLength_m,EngineDe_m,dist_quebra,wingac_rel,fuselageac_rel)
%%%%%%%%%%%%%%%%%%%%%%%%%%AC FUSELAGE-WING-NACELLE%%%%%%%%%%%%%%%%%%%%%%%%%
%ESDU77012
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
rad         = pi/180;
%
wingb       = sqrt(wS*wAR);
wingxac_m   = xle + wYMAC*tan(rad*wSweepLE) + wingac_rel*wMAC;
%s = wingb/2; % semi spam
wMGC        = wS/wingb;
%
w_l = EngineDe_m/(EnginLength_m); % rela�ao entre diametro e comprimento da nacelle
%w_l = 0.50;
%sn = dist_quebra;
nacellex = xle+dist_quebra*tan(rad*wSweepLE)-0.6*dist_quebra; % posicao da entrada de ar
fuselagexac_m = xle + wYMAC*tan(rad*wSweepLE) + fuselageac_rel*wMAC; % posicao da xac da asa-fuselagem em metros
%wingxac_m = xle + wingref.ymac*tan(rad*wSweepLE) + wingxac_rel*wMAC; % posicao da xac da asa em metros
r = nacellex - fuselagexac_m;
rlinha = nacellex - wingxac_m;
%rlinha_s = rlinha/s;
%TanC4 = tan(wSweep14*rad);
Zn = 0.85*EngineDe_m; % z/d = 0.85 figure 4.41 pag 111
R  = sqrt((r^2)+(Zn^2));

% interpolando Cla da nacelle
clan_xv = [0.00914634	0.0457317	0.0914634	0.128049	0.192073	0.228659	0.283537	0.347561	0.484756	0.594512	0.722561	0.832317	0.969512	1.07927	1.18902	1.37195	1.50915	1.62805	1.7378	1.82927	1.92988	1.9939];
clan_yv = [0.00923618	0.110638	0.230483	0.368717	0.543868	0.682101	0.848016	1.04158	1.41954	1.75136	2.09246	2.38745	2.7562	3.02357	3.27253	3.66904	3.97332	4.18548	4.37918	4.536	4.69285	4.77592];
nacelleCLa = interp1(clan_xv,clan_yv,w_l); % [rad-1]

% dxhn
dxhn = ((2*nacelleCLa*r*EngineDe_m*EnginLength_m)/(wS*wMAC))*((1/wingCLa)+(rlinha*wMGC/(4*pi*R)));