function [t, fuel] = Breguet(CDoCL,TSFC, W0, M, ISADEV, h,d)

[TR, PR, DR, a] = atmos(h,ISADEV);

V=M*a;
a1=TSFC*(CDoCL);
a2=d*a1/V;
f=exp(a2);
Wf=W0/f;
fuel=W0-Wf;
t=(1/a1)*log(W0/Wf)*60;