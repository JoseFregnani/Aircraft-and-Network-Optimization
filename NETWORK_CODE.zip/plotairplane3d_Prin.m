function plotairplane3d_Prin(lf,lco,ltail,df,Ccentro,Cquebra,Craiz,wtaper,xle,sweepLE,semispan,wingdi,engloc,engdi,engleng,yposeng, ...
    ctipvt,crootvt,arv,sweepLEvt,ht,htloc,wingloc,X_TP1,nt_m,D0m_max,wm_max,ds_m,Lpist_n,ds_n,wn_max,D0n_max,...
    iroot,ikink,itip,SweepLE_winglet,AR_winglet,...
         TR_winglet,CantAngle_wlet,wlet_present,longtras,bflap,yc_munhao, munhao_comp,Lpist_m,tcroot)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Autor: Bento Mattos (bxistos@gmail.com)
% Local e data: ITA 2014
% Finalidade: desenho tridimensional de aviao de linha 
% Pupose: 3D drawing of an airliner
%--------------------------------------------------------------------------
% Variaveis de entrada:
% lf        = Comprimento da fuselagem (m)
% lco       = Comprimento da fuselagem dianteira (m)
% ltail     = Comprimento do cone de cauda (m)
% Ccentro   = Corda da asa na linha de centro da fuselagem (m)
% Cquebra   = Corda da sa na se�ao da quebra (m)
% wtaper    = Afilamento da asa
% xle       = distancia do nariz ao bordo de ataque da asa na linha centro da
%             fuselagem (m)
% sweepLE   = Enflechamento de bordo de ataque da asa 
% semispan  = semi-envergadura da asa (m)
% wingdi    = Angulo diedro em graus da asa
% wintwist  = Tor��o da asa (graus, valor negativo significa incidencia da
%             ponta menor do que a da raiz
% engloc    = Localiza�ao do motor (1=asa; 2= fuselagem traseira)
% engdi     = Diamentro do motor (em metros, externo)
% engleng   = Comprimento do motor (m)
% yposeng   = Percentual da semi-envergadura onde estah a quebra da asa
% ctipvt    = Corda da ponta da EV (m)
% crootvt   = Corda da raiz da EV (m)
% arv       = Alongamento da EV
% sweepLEvt = Angulo de enflechamento de bordo de ataque da EV
% ctipht    = Corda da ponta da EH (m)
% crootht   = Corda da raiz da EH (em metros, valor desconsiderado se for
%             cauda em "T")
% arh       = Alongamento da EH
% sweepLEht = Angulo de enflechamento da EH (bordo de ataque,em graus)
% htloc     = configura�ao da EH (1= convencional;
%                                 2 = configuracao da cauda em "T")
% wingloc   = Localiza�ao da asa (1=baixa; 2 = alta)
% X_TP1     = Coordenada longitudinal do TDP do nariz
% nt_m      = Numero de pneus no TDP principal
% D0m_max   = Diametro do pneu (m) do TDP principal
% wm_max    = Largura do pneu (m) do TDP principal
% Ss_m      = Comprimento do munhao (m)
% List_m    = Comprimento do cilindro do amortcedor (TDP principal)
% ds_m      = Diametro do munhao (m) do TDP principal
% List_m    = Comprimento do cilindro do amortcedor (TDP do nariz)
% ds_n      = Diametro do munhao (m) do TDP do nariz
% wn_max    = Largura do pneu (m) do TDP do nariz
% D0n_max   = Diametro do pneu (m) do TDP do nariz
% pneum_p   = Pressao maxima do pneu do TDP principal (psi)
% pneun_p   = Pressao maxima do pneu do TDP dianteiro (psi)
%--------------------------------------------------------------------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Constantes
rad=pi/180;
%%

%% Parametros
wing.b = 2*semispan;
fuselage.lco=lco;
fuselage.df=df;
%%
Cponta=Craiz*wtaper;
lcab=lf-(lco+ltail);
raio=df/2;
bv=0.50*(crootvt+ctipvt)*arv;
bh=ht.b;
tanaux=tan(rad*sweepLE);


%%------------------ WING
% Read root airfoil geometry
arq_input = ('proot.dat');
fid = fopen(arq_input);
fgetl(fid);
%fprintf(' \n %s \n',linhai);
icount=0;
while (~feof(fid))
    linha = fgetl(fid);
    READ=strread(linha);
    icount=icount+1;
    xp=READ(1);
    %
    yp=READ(2);
    xperraiz(icount)=xp;
    yperraiz(icount)=yp;
end
npraiz=icount;
fclose(fid);
% reinterpola perfil da raiz
npontos = 50;
xspline = (cos(pi:-pi/npontos:0)+1)/2.;
ds(1) = 0;
for i=1:1:(npraiz-1)
ds(i+1) = ds(i)+sqrt((xperraiz(i+1)-xperraiz(i))^2 + (yperraiz(i+1)-yperraiz(i))^2);
end


[~, indp]=min(xperraiz);
xaux   = xperraiz(1:1:indp);
dsaux  = ds(1:1:indp);
dsplin = spline(xaux,dsaux,xspline);
nuraiz  = npontos+1;
xuraiz  = xspline;
yuraiz = spline(ds,yperraiz,dsplin);
%
nlraiz   = npontos+1;
xaux1   = xperraiz(indp:1:npraiz);
dsaux1  = ds(indp:1:npraiz);
dsplin1 = spline(xaux1,dsaux1,xspline);
xlraiz   = xspline;
ylraiz   = spline(ds,yperraiz,dsplin1);

xperroot=[xuraiz(npontos+1:-1:2), xlraiz];
yperroot=[yuraiz(npontos+1:-1:2), ylraiz];
esspraiz=max(yuraiz)-min(ylraiz);

%%%%%%%%%%%%%%%%%%%%%%%%%%% Read kink station airfoil
arq_input = ('pkink.dat');

fid = fopen(arq_input);
fgetl(fid);
%fprintf(' \n %s \n',linhai);
icount=0;
while (~feof(fid))
    linha = fgetl(fid);
    READ=strread(linha);
    icount=icount+1;
    xp=READ(1);
    %
    yp=READ(2);
    xperbreak(icount)=xp;
    yperbreak(icount)=yp;
end
npbreak=icount;
fclose(fid);
% reinterpola perfil da ponta
npontos = 50;
xspline = (cos(pi:-pi/npontos:0)+1)/2.;
ds=[];
ds(1) = 0;
for i=1:1:(npbreak-1)
ds(i+1) = ds(i)+sqrt((xperbreak(i+1)-xperbreak(i))^2 + (yperbreak(i+1)-yperbreak(i))^2);
end


[xmin, indp]=min(xperbreak);
xaux      = xperbreak(1:1:indp);
dsaux     = ds(1:1:indp);
dsplin    = spline(xaux,dsaux,xspline);
%nutip  = npontos+1;
xubreak   = xspline;
yubreak   = spline(ds,yperbreak,dsplin);
%
%nltip   = npontos+1;
xaux1     = xperbreak(indp:1:npbreak);
dsaux1    = ds(indp:1:npbreak);
dsplin1   = spline(xaux1,dsaux1,xspline);
xlbreak   = xspline;
ylbreak   = spline(ds,yperbreak,dsplin1);

xperbreak = [xubreak(npontos+1:-1:2), xlbreak];
yperbreak = [yubreak(npontos+1:-1:2), ylbreak];
%%%%%%%%%%%%%%%%%%%%%%%%%%% read tip airfoil
arq_input = ('ptip.dat');

fid = fopen(arq_input);
fgetl(fid);
%fprintf(' \n %s \n',linhai);
icount=0;
while (~feof(fid))
    linha = fgetl(fid);
    READ=strread(linha);
    icount=icount+1;
    xp=READ(1);
    %
    yp=READ(2);
    xpertip(icount)=xp;
    ypertip(icount)=yp;
end
nptip=icount;
fclose(fid);
% reinterpola perfil da ponta
npontos = 50;
xspline = (cos(pi:-pi/npontos:0)+1)/2.;
ds=[];
ds(1) = 0;
for i=1:1:(nptip-1)
ds(i+1) = ds(i)+sqrt((xpertip(i+1)-xpertip(i))^2 + (ypertip(i+1)-ypertip(i))^2);
end
%
[~, indp]=min(xpertip);
xaux   = xpertip(1:1:indp);
dsaux  = ds(1:1:indp);
dsplin = spline(xaux,dsaux,xspline);
%nutip  = npontos+1;
xutip  = xspline;
yutip  = spline(ds,ypertip,dsplin);
%
%nltip   = npontos+1;
xaux1   = xpertip(indp:1:nptip);
dsaux1  = ds(indp:1:nptip);
dsplin1 = spline(xaux1,dsaux1,xspline);
xltip   = xspline;
yltip   = spline(ds,ypertip,dsplin1);

xpertip=[xutip(npontos+1:-1:2), xltip];
ypertip=[yutip(npontos+1:-1:2), yltip];
% *************************************************************************
% **************************** Wing ***************************************
% *************************************************************************
if wingloc ==1
    wingpos=-0.48*raio;
    engzpos=-0.485*raio;
else
    wingpos=raio-Ccentro*1.15*0.12/2;
    engzpos=wingpos-0.10*engdi/2;
end
% Rotate root section according to given incidence
teta  = -iroot; % - points sky; + points ground
tetar = teta*rad;
xperroot_rota=xperroot*cos(tetar)-yperroot*sin(tetar);
yperroot_rota=xperroot*sin(tetar)+yperroot*cos(tetar);

% Rotate kink station airfoil
teta  = -ikink;
tetar = teta*rad;
xperbreak_rota=xperbreak*cos(tetar)-yperbreak*sin(tetar);
yperbreak_rota=xperbreak*sin(tetar)+yperbreak*cos(tetar);

% Rotate tip airfoil
teta  =-itip;
tetar =teta*rad;
xperponta=xpertip*cos(tetar)-ypertip*sin(tetar);
yperponta=xpertip*sin(tetar)+ypertip*cos(tetar);
deltax=semispan*tanaux;

maxcota=-0.48*(df/2)+1.15*Ccentro*esspraiz;
yraiz=sqrt((df/2)^2-maxcota^2);
xleraiz=xle+yraiz*tanaux;
xlequebra=xle+semispan*yposeng*tanaux;

xistosxper=[xle+Ccentro*xperroot_rota; xleraiz+Craiz*xperroot_rota; xlequebra+Cquebra*xperbreak_rota; xle+deltax+Cponta*xperponta];
%
xistoszper=[(wingpos+Ccentro*yperroot_rota);wingpos+Craiz*yperroot_rota;(wingpos+(yposeng*semispan*tan(rad*wingdi))+ Cquebra*yperbreak_rota);(semispan*tan(rad*wingdi)+wingpos+Ccentro*wtaper*yperponta)];

sizex=size(xperroot);
yper1(1:sizex(2))=0;
yper2(1:sizex(2))=yraiz;
yper3(1:sizex(2))=semispan*yposeng;
yper4(1:sizex(2))=semispan;
xistosyper=[yper1;yper2; yper3; yper4];
% 
surface(xistosxper,xistosyper,xistoszper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
hold on
surface(xistosxper,-xistosyper,xistoszper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
hold on
%
% Flape interno
%
xistossizex=size(xperbreak,2);
%extradorso
for j=1:round(xistossizex/2)
    if xperbreak(j+1) < longtras && longtras < xperbreak(j)
        dx = xperbreak(j+1)-xperbreak(j);
        dy = yperbreak(j+1)-yperbreak(j);
        ykinkflapi= yperbreak(j) + (dy/dx)*(longtras-xperbreak(j));
        meme=j;
    end
end
Cordaflapkink=(1-longtras)*Cquebra;
teta  = -ikink;
tetar = teta*rad;
xkinkflapi_rota=longtras*cos(tetar)-ykinkflapi*sin(tetar);
ykinkflapi_rota=longtras*sin(tetar)+ykinkflapi*cos(tetar);

for j=1:round(xistossizex/2)
    if (1-xperroot(j))*Craiz*cos(rad*iroot) <= Cordaflapkink
        memroot=j;
    end
end
yrootflapi= yperroot(memroot);
xrootflapi= xperroot(memroot);
teta  = -iroot; % - points sky; + points ground
tetar = teta*rad;
xrootflapi_rota=xrootflapi*cos(tetar)-yrootflapi*sin(tetar);
yrootflapi_rota=xrootflapi*sin(tetar)+yrootflapi*cos(tetar);

xflapi(1)=xleraiz+xrootflapi_rota*Craiz;
zflapi(1)=wingpos+yrootflapi_rota*Craiz;
yflapi(1)=yraiz;
xflapi(2)=xleraiz+xperroot_rota(1)*Craiz;
zflapi(2)=wingpos+yperroot_rota(1)*Craiz;
yflapi(2)=yraiz;
xflapi(3)=xlequebra+xperbreak(1)*Cquebra;
zflapi(3)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+yperbreak(1)*Cquebra;
yflapi(3)=semispan*yposeng;
xflapi(4)=xlequebra+xkinkflapi_rota*Cquebra;
zflapi(4)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+ykinkflapi_rota*Cquebra;
yflapi(4)=semispan*yposeng;
xflapi(5)=xflapi(1);
yflapi(5)=yflapi(1);
zflapi(5)=zflapi(1);
plot3(xflapi,yflapi,zflapi,'k')
hold on
plot3(xflapi,-yflapi,zflapi,'k')
% intradorso
for j=round(xistossizex/2):round(xistossizex)
    if xperbreak(j) < longtras && longtras < xperbreak(j+1)
        dx = xperbreak(j+1)-xperbreak(j);
%         yrootflapi_low= yperroot(j) + (dy/dx)*(longtras-xperroot(j));
        dy = yperbreak(j+1)-yperbreak(j);
        ykinkflapi_low= yperbreak(j) + (dy/dx)*(longtras-xperbreak(j));
        memi=j;
    end
end
%
teta  = -ikink;
tetar = teta*rad;
xkinkflapi_low_rota=longtras*cos(tetar)-ykinkflapi_low*sin(tetar);
ykinkflapi_low_rota=longtras*sin(tetar)+ykinkflapi_low*cos(tetar);

for j=round(xistossizex/2):round(xistossizex)
    if (1-xperroot(j))*Craiz*cos(rad*iroot) >= Cordaflapkink
        memroot=j;
    end
end
yrootflapi_low= yperroot(memroot);
xrootflapi_low= xperroot(memroot);
teta  = -iroot; % - points sky; + points ground
tetar = teta*rad;
xrootflapi_low_rota=xrootflapi_low*cos(tetar)-yrootflapi_low*sin(tetar);
yrootflapi_low_rota=xrootflapi_low*sin(tetar)+yrootflapi_low*cos(tetar);


xflapi(1)=xleraiz+xrootflapi_low_rota*Craiz;
zflapi(1)=wingpos+yrootflapi_low_rota*Craiz;
yflapi(1)=yraiz;
xflapi(2)=xleraiz+xperroot_rota(1)*Craiz;
zflapi(2)=wingpos+yperroot_rota(1)*Craiz;
yflapi(2)=yraiz;
xflapi(3)=xlequebra+xperbreak(1)*Cquebra;
zflapi(3)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+yperbreak(1)*Cquebra;
yflapi(3)=semispan*yposeng;
xflapi(4)=xlequebra+xkinkflapi_low_rota*Cquebra;
zflapi(4)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+ykinkflapi_low_rota*Cquebra;
yflapi(4)=semispan*yposeng;
xflapi(5)=xflapi(1);
yflapi(5)=yflapi(1);
zflapi(5)=zflapi(1);
plot3(xflapi,yflapi,zflapi,'k')
hold on
plot3(xflapi,-yflapi,zflapi,'k')

% Flape externo
wstation=bflap;
%extradorso FE
        dx = xperponta(meme+1)-xperponta(meme);
        dy = yperponta(meme+1)-yperponta(meme);
        ytipflapi= yperponta(meme) + (dy/dx)*(longtras-xperponta(meme));

        dy  = ytipflapi-ykinkflapi_rota;
        ds  = semispan-yposeng*semispan;
        ystateflapi=ykinkflapi_rota+(dy/ds)*(wstation-yposeng)*semispan;
        dy  = yperponta(1)-yperbreak(1);
        ystateflapi_bf=yperbreak(1)+(dy/ds)*(wstation-yposeng)*semispan;
        dy=Cponta-Cquebra;
        Cstation=Cquebra+(dy/ds)*(wstation-yposeng)*semispan;
        
xflape(1)=xlequebra+xperbreak(1)*Cquebra;
zflape(1)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+yperbreak(1)*Cquebra;
yflape(1)=semispan*yposeng;
xflape(2)=xlequebra+xkinkflapi_rota*Cquebra;
zflape(2)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+ykinkflapi_rota*Cquebra;
yflape(2)=semispan*yposeng;
xflape(3)=xle+wstation*semispan*tan(rad*sweepLE) + longtras*Cstation;
zflape(3)= ystateflapi*Cstation+(wingpos+(wstation*semispan*tan(rad*wingdi)));
yflape(3)=wstation*semispan;
xflape(4)= xle+wstation*semispan*tan(rad*sweepLE) + Cstation;
zflape(4)=ystateflapi_bf*Cstation+(wingpos+(wstation*semispan*tan(rad*wingdi)));
yflape(4)=yflape(3);

xflape(5)=xflape(1);
yflape(5)=yflape(1);
zflape(5)=zflape(1);

plot3(xflape,yflape,zflape,'k')
hold on
plot3(xflape,-yflape,zflape,'k')
hold on
% Intradorso FE

        dx = xperponta(memi+1)-xperponta(memi);
        dy = yperponta(memi+1)-yperponta(memi);
        ytipflapi_low= yperponta(memi) + (dy/dx)*(longtras-xperponta(memi));

        dy  = ytipflapi_low-ykinkflapi_low_rota;
        ds  = semispan-yposeng*semispan;
        ystateflapi_low=ykinkflapi_low_rota+(dy/ds)*(wstation-yposeng)*semispan;
        dy  = yperponta(1)-yperbreak(1);
        ystateflapi_low_bf=yperbreak(1)+(dy/ds)*(wstation-yposeng)*semispan;
        dy=Cponta-Cquebra;
        Cstation=Cquebra+(dy/ds)*(wstation-yposeng)*semispan;
        
xflape(1)= xlequebra+xperbreak(1)*Cquebra;
zflape(1)= (wingpos+(yposeng*semispan*tan(rad*wingdi)))+yperbreak(1)*Cquebra;
yflape(1)= semispan*yposeng;
xflape(2)= xlequebra+xkinkflapi_low_rota*Cquebra;
zflape(2)=(wingpos+(yposeng*semispan*tan(rad*wingdi)))+ykinkflapi_low_rota*Cquebra;
yflape(2)= semispan*yposeng;
xflape(3)= xle+wstation*semispan*tan(rad*sweepLE) + longtras*Cstation;
zflape(3)= ystateflapi_low*Cstation+(wingpos+(wstation*semispan*tan(rad*wingdi)));
yflape(3)= wstation*semispan;
xflape(4)= xle+wstation*semispan*tan(rad*sweepLE) + Cstation;
zflape(4)= ystateflapi_low_bf*Cstation+(wingpos+(wstation*semispan*tan(rad*wingdi)));
yflape(4)= yflape(3);

xflape(5)=xflape(1);
yflape(5)=yflape(1);
zflape(5)=zflape(1);

plot3(xflape,yflape,zflape,'k')
hold on
plot3(xflape,-yflape,zflape,'k')
%%=== End wing
%%=== Begin Winglet
if wlet_present == 1
Z_wing_ponta = semispan*tan(rad*wingdi)+wingpos;
xLE_wing_ponta = xle+ semispan*tan(rad*sweepLE);
plotwinglet(semispan,SweepLE_winglet,AR_winglet,TR_winglet,...
    xLE_wing_ponta,Cponta,CantAngle_wlet,Z_wing_ponta)
end
%%== End Winglet

%====  Wing-fuselage fairing
%
maxcota=-0.48*raio+1.15*Ccentro*esspraiz;

xfar10(1)=xle;
yfar10(1)=sqrt(raio^2-maxcota^2);
zfar10(1)=maxcota;
xfar10(2)=xle;
yfar10(2)=sqrt(raio^2-maxcota^2);
zfar10(2)=-raio;
xfar10(3)=xle;
yfar10(3)=0.80*sqrt(raio^2-maxcota^2);
zfar10(3)=-1.1*raio;
xfar10(4)=xle;
yfar10(4)=-0.80*sqrt(raio^2-maxcota^2);
zfar10(4)=-1.1*raio;
xfar10(5)=xle;
yfar10(5)=-sqrt(raio^2-maxcota^2);
zfar10(5)=-raio;
xfar10(6)=xle;
yfar10(6)=-sqrt(raio^2-maxcota^2);
zfar10(6)=maxcota;
%
for j=1:6
    xfar0(j)=xle-0.80*Ccentro;
    yfar0(j)=0.30*yfar10(j);
    zfar0(j)=0.45*zfar10(j);
end
for j=1:6
    xfar5(j)=xle-0.30*Ccentro;
    yfar5(j)=0.60*yfar10(j);
    zfar5(j)=0.90*zfar10(j);
end
%
for j=1:6
    xfar20(j)=xle+Ccentro;
    yfar20(j)=yfar10(j);
    zfar20(j)=zfar10(j);
end
%
for j=1:6
    xfar30(j)=xle+1.90*Ccentro;
    yfar30(j)=0.40*yfar10(j);
    zfar30(j)=0.40*zfar10(j);
end
%
xistosxfar=[xfar0;xfar5; xfar10; xfar20;xfar30];
xistosyfar=[yfar0;yfar5; yfar10; yfar20;yfar30];
xistoszfar=[zfar0;zfar5; zfar10; zfar20;zfar30];
surface(xistosxfar,xistosyfar,xistoszfar,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.35 0.45 0.35]);
% ==> End fairing
% *************************************************************************
% *****************************  VT ***************************************
% *************************************************************************
% arq_output = ('airfoils/naca0012.per');
% fid = fopen(arq_output);
% linhai=fgetl(fid);
% icount=0;
% while (~feof(fid))
%     linha = fgetl(fid);
%     READ=strread(linha);
%     icount=icount+1;
%     xp=READ(1);
%     %
%     yp=READ(2);
%     xpervt(icount)=xp;
%     ypervt(icount)=yp;
% end
% %
% fclose(fid);
%
iaf.designation='0011';
iaf.n=50;
iaf.HalfCosineSpacing=1;
iaf.wantFile=0;
iaf.datFilePath='./'; % Current folder
iaf.is_finiteTE=0;
af = naca4gen(iaf);
%
xpo=af.xU';
nxp=size(xpo,2);
xpinv=xpo(nxp-1:-1:1);
zvtprov=af.zU';
xpervt=[xpo xpinv];
ypervt=[zvtprov -zvtprov(nxp-1:-1:1)];
%
sweepLEvtrad=sweepLEvt*rad;
deltaxvt=0.95*lf-crootvt;
xistosxpervt=[deltaxvt+crootvt*xpervt; deltaxvt+crootvt*xpervt; deltaxvt+bv*tan(sweepLEvtrad)+ctipvt*xpervt];
xistosypervt=[crootvt*ypervt;crootvt*ypervt;ctipvt*ypervt];
sizex=size(xpervt);
zper1(1:sizex(2))=0.90*raio;
zper2(1:sizex(2))=0.98*raio;
zper3(1:sizex(2))=0.98*raio+bv;
xistoszper=[zper1; zper2; zper3];
%surface(xistosxpervt,xistosypervt,xistoszper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xistosxpervt,xistosypervt,xistoszper,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.245 0.249 0.253]);
%surface(xistosxpervt,-xistosypervt,xistoszper,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
%surf(xistoszper)
% Dorsal fin
finend   = deltaxvt;
finbegin = finend - 1.5;
xfin(1)= finbegin;
yfin(1) = 0;
zfin(1) = 0.98*raio;
xfin(2) = finend;
yfin(2) = 0;
zfin(2) = 0.98*raio;
deltahfin = 0.5; %[m]
xfin(3) = finend+deltahfin*tan(sweepLEvt*rad);
yfin(3) = 0;
zfin(3) = deltahfin+0.98*raio;
xfin3d=[xfin(1) xfin(1) xfin(1) xfin(1); xfin(2) xfin(2) xfin(3) xfin(3)];
yfin3d=[yfin(1) yfin(1) yfin(1) yfin(1); yfin(2) yfin(2) yfin(3) yfin(3)];
zfin3d=[zfin(1) zfin(1) zfin(1) zfin(1); zfin(2) zfin(2) zfin(3) zfin(3)];
surface(xfin3d,yfin3d,zfin3d,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.245 0.249 0.253])
hold on
% Rudder
fchord_rudder = 0.25;
xdes          = 1-fchord_rudder;
for iru=1:(nxp-1)
    if xpo(iru) > xdes && xpo(iru+1) < xdes
        ind = iru;
        dx = xpo(iru) - xpo(iru+1);
        dy = zvtprov(iru) - zvtprov(iru+1);
        ydes = zvtprov(iru) + (dy/dx)*(xdes-xpo(iru));
    end
end
%
[xrudd,yrudd,zrudd]=rudder(ctipvt,crootvt,arv,sweepLEvt,ydes);
xrudd = xrudd + deltaxvt;
zrudd = zrudd + 0.98*raio;
plot3(xrudd,yrudd,zrudd,'y')
hold on
plot3(xrudd,-yrudd,zrudd,'y')
hold on
%=== End VT
% *************************************************************************
% *****************************  HT ***************************************
% *************************************************************************
if engloc ==2 || htloc==2
htdi =ht.di;
bh2=bh/2;
thiratio=10/12;
sweepLEhtrad=ht.sweepLE*rad;
deltaxht=deltaxvt+bv*tan(sweepLEvtrad);
deltazht=0.98*raio+bv;
xistosxperht=[deltaxht+ht.c0*xpervt; deltaxht+bh2*tan(sweepLEhtrad)+ht.ct*xpervt];
xistoszperht=[deltazht+thiratio*ht.c0*ypervt;deltazht+thiratio*ht.ct*ypervt+bh2*tan(rad*htdi)];
%xistoszperht=[deltazht+crootht*ypervt;deltazht+ctipht*ypervt];
sizex=size(xpervt);
%yperht1(1:sizex(2))=0;
yperht2(1:sizex(2))=0;
yperht3(1:sizex(2))=0.48*raio+bh2;
xistosyperht=[yperht2; yperht3];
surface(xistosxperht,xistosyperht,xistoszperht,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.333293, 0.419599, 0.184301]);
surface(xistosxperht,-xistosyperht,xistoszperht,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.333293, 0.419599, 0.184301]);
else
htdi = ht.di;
bh2=ht.b/2-0.48*raio;
thiratio=10/12;
sweepLEhtrad=ht.sweepLE*rad;
deltaxht=0.92*lf-ht.c0;
deltazht=0.48*raio;
xistosxperht=[deltaxht+ht.c0*xpervt; deltaxht+bh2*tan(sweepLEhtrad)+ht.ct*xpervt];
xistoszperht=[deltazht+thiratio*ht.c0*ypervt;deltazht+thiratio*ht.ct*ypervt+bh2*tan(rad*htdi)];
sizex=size(xpervt);
%yperht1(1:sizex(2))=0;
yperht2(1:sizex(2))=0;
yperht3(1:sizex(2))=0.48*raio+bh2;
xistosyperht=[yperht2; yperht3];
surface(xistosxperht,xistosyperht,xistoszperht,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xistosxperht,-xistosyperht,xistoszperht,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);      
end
%
%====> Fuselagem central
hpiso=-0.60;
plotwindow(lf,lco,ltail,df,hpiso)
plotdoor(lco,df,hpiso)

yfus1=[raio*cos(0:0.1:2*pi) raio];
zfus1=[(raio*sin(0:0.1:2*pi)) 0];
sizey=size(yfus1,2);
xfus1(1:sizey)=lco;
xfus2(1:sizey)=lf-ltail;
xfus=[xfus1;xfus2];
yfus=[yfus1;yfus1];
zfus=[zfus1;zfus1];
%
surface(xfus,yfus,zfus,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.35 0.45 0.35]);

% Fuselagem dianteira


%%%%%%%%%%%%%%%%%%%%%%%%%    NOSE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                    TOP VIEW  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%COCKPIT%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cockpit.r=fuselage.df/2; % height [m]
cockpit.parameter1=2; % parametro elipse
cockpit.parameter2=1.8; % parametro elipse

npx=round(fuselage.lco/0.01);
icomp=fuselage.lco/(npx-1);
%for aux1=0:0.01:fuselage.lco
for i=1:(npx-1)
    aux1=(i-1)*icomp;
    aux2=i;
    cockpit.x(aux2)=aux1;
    cockpit.y(aux2)=real((cockpit.r^cockpit.parameter2-(((aux1-fuselage.lco)^cockpit.parameter1)*(cockpit.r^cockpit.parameter2)/(fuselage.lco^cockpit.parameter1)))^(1/cockpit.parameter2));
    cockpit.w(aux2)=2*cockpit.y(aux2);


end

% plot(cockpit.x,cockpit.y,'+-')
% hold on
% plot(cockpit.x,-cockpit.y)
% axis equal
% hold on

%                  LATERAL VIEW
%OVER
cockpit.a1         = (3/5)*fuselage.lco;
cockpit.b1         = (3/8)*fuselage.df;
cockpit.parameter3 = 1.5;
cockpit.parameter4 = 1;

npx=round(cockpit.a1/0.01);
icomp=cockpit.a1/(npx-1);
%for aux5=0:0.01:cockpit.a1
for i=1:npx
    aux5=(i-1)*icomp;
    aux6=i;
    cockpit.xover(aux6)=aux5;
    cockpit.zover(aux6)=((cockpit.b1^cockpit.parameter4)*(1-((cockpit.xover(aux6)/cockpit.a1)^cockpit.parameter3)))^(1/cockpit.parameter4);
    auxline.cockpitover(aux6)=cockpit.zover(aux6)+fuselage.df/8;
end

%NOSE
cockpit.a2=(2/4)*fuselage.lco;
cockpit.b2=(2.5/8)*fuselage.df;
%cockpit.parameter5=1.2;
%cockpit.parameter6=1.4;
cockpit.parameter5=1.;
cockpit.parameter6=1.5;
aux8=0;
for aux7=0:0.01:cockpit.a2
    aux8=aux8+1;
    cockpit.xnose(aux8)=aux7;
    cockpit.znose(aux8)=((cockpit.b2^cockpit.parameter6)*(1-((cockpit.xnose(aux8)/cockpit.a2)^cockpit.parameter5)))^(1/cockpit.parameter6);
    auxline.cockpitnose(aux8)=cockpit.znose(aux8)-1.5*fuselage.df/8;
end

%UNDER
cockpit.a3=fuselage.lco;
cockpit.b3=(2.5/8)*fuselage.df;
%cockpit.parameter7=1.5;
%cockpit.parameter8=2;
cockpit.parameter7=1.5;
cockpit.parameter8=2;
npx=round(cockpit.a3/0.01);
icomp=cockpit.a3/(npx-1);
% for aux9=0:0.01:cockpit.a3
for i=1:npx
    aux9=(i-1)*icomp;
    aux10=i;
    cockpit.xunder(aux10)=aux9;
    cockpit.zunder(aux10)=((cockpit.b3^cockpit.parameter8)*(1-((cockpit.xunder(aux10)/cockpit.a3)^cockpit.parameter7)))^(1/cockpit.parameter8);
    auxline.cockpitunder(aux10)=-cockpit.zunder(aux10)-1.5*fuselage.df/8;
end

%plot(-cockpit.xover+cockpit.a1+cockpit.a2,cockpit.zover+fuselage.df/8)
%axis equal
%hold on
% plot(-cockpit.xnose+cockpit.a2,cockpit.znose-1.5*fuselage.df/8,'x-')
% hold on    
% plot(-cockpit.xunder+cockpit.a3,-cockpit.zunder-1.5*fuselage.df/8,'r+')  
% hold on
% %

[~,ncock]=size(cockpit.x);

lateralx_low=-cockpit.xunder+cockpit.a3;
lateralz_low_aux=-cockpit.zunder-1.5*fuselage.df/8;
lateralx_upp=[-cockpit.xnose+cockpit.a2 , -cockpit.xover+cockpit.a1+cockpit.a2]; 
lateralz_upp_aux=[cockpit.znose-1.5*fuselage.df/8,cockpit.zover+fuselage.df/8];

[lateralx_low,IX]=sort(lateralx_low);
[~,latlowm]=size(lateralx_low);

for j = 1:latlowm
    lateralz_low(j) = lateralz_low_aux(IX(j)); 
end 
    

[~,latuppm]=size(lateralz_upp_aux);
[lateralx_upp,IZ]=sort(lateralx_upp);

for j=1:latuppm
   lateralz_upp(j) = lateralz_upp_aux(IZ(j));  
end

%figure(2)
%     plot(lateralx_low,lateralz_low,'g')
%     hold on
%     plot(lateralx_upp,lateralz_upp,'r')
% axis equal

jx=0;
x0=0.005;
npx=round((fuselage.lco-x0)/0.025);
icomp=(fuselage.lco-x0)/(npx-1);

% 
for i=1:(npx-1)
   xlat=x0+ (i-1)*icomp;
    jmem_low=0;
   for j=1:(latlowm-1)
       if xlat <= lateralx_low(j+1) && xlat > lateralx_low(j)
           jmem_low=j;
       end
   end
    
       jmem_upp=0;
   for j=1:(latuppm-1)
       if xlat <= lateralx_upp(j+1) && xlat > lateralx_upp(j)
           jmem_upp=j;
       end
   end
   jx=jx+1;
   xnariz(jx)=xlat;
   eixoz(jx)=lateralz_upp(jmem_upp)-lateralz_low(jmem_low);
   posz(jx)=0.50*(lateralz_upp(jmem_upp)-lateralz_low(jmem_low));
   
   jmem_top=0;
   for j=1:(ncock-1)
       if xlat <= cockpit.x(j+1) && xlat > cockpit.x(j)

           jmem_top=j;
       end
   end
   eixoy(jx)=2*cockpit.y(jmem_top);
end


% acerto da dist vertical

%[mpos, npos]=size(posz);
z2min=-eixoz(jx)*0.5 +posz(jx);
delta=-raio-z2min;

for j=1:jx
    posz(j)=posz(j)+delta;
end
%
for j=1:(jx-1)
    y1 = eixoy(j)*0.5*cos(-pi/2:0.02:pi/2);
    z1 = eixoz(j)*(0.5*sin(-pi/2:0.02:pi/2))+posz(j);
    y2 = eixoy(j+1)*0.5*cos(-pi/2:0.02:pi/2);
    z2 = eixoz(j+1)*(0.5*sin(-pi/2:0.02:pi/2))+posz(j+1);
    [~, ny2] = size(y2);
    x1(1:ny2)  = xnariz(j);
    x2(1:ny2)  = xnariz(j+1);
    xsurface   = [x1;x2];
    ysurface   = [y1;y2];
    zsurface   = [z1;z2];
    %surface(xsurface,ysurface,zsurface,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.1 0.2 0.80])
    surface(xsurface,ysurface,zsurface,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.35 0.45 0.35])
    %surface(xsurface,-ysurface,zsurface,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.1 0.2 0.80])
    surface(xsurface,-ysurface,zsurface,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.35 0.45 0.35])
    hold on
end


%
%------------- Tail cone
ycone1=[0.25*cos(0:0.1:2*pi) 0.25];
zcone1=[(0.45*raio+0.4*sin(0:0.1:2*pi)) 0.45*raio];
xcone1(1:sizey)=lf;
ycone12=[0.5*cos(0:0.1:2*pi) 0.5];
zcone12=[(0.32*raio+0.9*sin(0:0.1:2*pi)) 0.32*raio];
xcone12(1:sizey)=lf-0.40*ltail;
ycone2=[raio*cos(0:0.1:2*pi) raio];
zcone2=[(raio*sin(0:0.1:2*pi)) 0];
xcone2(1:sizey)=lf-ltail;
ycone3=[raio*cos(0:0.1:2*pi) raio];
zcone3=[(raio*sin(0:0.1:2*pi)) 0];
xcone3(1:sizey)=lf-ltail;
xcone=[xcone1;xcone12;xcone2; xcone3];
ycone=[ycone1;ycone12;ycone2; ycone3];
zcone=[zcone1;zcone12;zcone2; zcone3];
surface(xcone,ycone,zcone,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.35 0.45 0.35]);
hold on
%--- Fechamento do cone de cauda
sizecon=size(cos(0:0.1:pi),2)+1;
xcone1f(1:sizecon)=lf;
ycone1f=[0.25*cos(0:0.1:pi) 0.25];
zcone1f=[(0.45*raio+0.4*sin(0:0.1:pi)) 0.45*raio];
xcone2f(1:sizecon)=lf;
ycone2f=[0.25*cos(pi:0.1:2*pi) 0.25];
zcone2f=[(0.45*raio+0.4*sin(pi:0.1:2*pi)) 0.45*raio];
xconef=[xcone1f;xcone2f];
yconef=[ycone1f;ycone2f];
zconef=[zcone1f;zcone2f];
surface(xconef,yconef,zconef,'FaceLighting','gouraud','EdgeColor','black','FaceColor',[0.1 0.2 0.80]);
hold on

%%--------------- Engine (Motor) ------------------------------------------
reng=1.05*engdi/2;
switch engloc
case 1 % underwing config
dxeng=yposeng*tan(rad*sweepLE)*wing.b*0.50;   
dzeng=engzpos+ yposeng*tan(rad*wingdi)-reng;    
%
    if Cquebra < 0.70*engleng
    dxaux= engleng-Cquebra;
    xeng1(1:sizey)=xle+dxeng-dxaux; 
    else
    dxaux=0.30*engleng;
    xeng1(1:sizey)=xle+dxeng-dxaux;
    end
%
    zeng1=[dzeng+reng*sin(0:0.1:2*pi) dzeng];
    yeng1=[yposeng*semispan+reng*cos(0:0.1:2*pi) (yposeng*semispan+reng)];
    xeng2(1:sizey)=xle+1.2*dxeng;
    zeng2=[dzeng+reng*sin(0:0.1:2*pi) dzeng];
    yeng2=[yposeng*semispan+reng*cos(0:0.1:2*pi) (yposeng*semispan+reng)];
    xeng3(1:sizey)=xle+1.2*dxeng;
    zeng3=[dzeng+0.8*reng*sin(0:0.1:2*pi) dzeng];
    yeng3=[yposeng*semispan+0.80*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.80*reng)];
 
    xeng4(1:sizey)=xle+dxeng+engleng-dxaux;
    zeng4=[dzeng+0.7*reng*sin(0:0.1:2*pi) dzeng];
    yeng4=[yposeng*semispan+0.70*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.70*reng)];
    
xeng=[xeng1;xeng2];
yeng=[yeng1;yeng2];
zeng=[zeng1;zeng2];
%
surface(xeng,yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.98 0.949 0.953]);
surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.98 0.949 0.953]);
hold on

xeng=[xeng3;xeng4];
yeng=[yeng3;yeng4];
zeng=[zeng3;zeng4];
%
surface(xeng,yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
hold on

%%%%%% rear panel and Exhaust plug

% --- Rear panel

    xeng7(1:sizey)=xle+dxeng+engleng-dxaux;
    zeng7=[dzeng+0.2*reng*sin(0:0.1:2*pi) dzeng];
    yeng7=[yposeng*semispan+0.20*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.20*reng)];
    
xeng=[xeng4;xeng7];
yeng=[yeng4;yeng7];
zeng=[zeng4;zeng7];
%
surface(xeng,yeng,zeng,'FaceLighting','gouraud','EdgeColor','k','FaceColor',[0.8 0.949 0.953]);
surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','k','FaceColor',[0.8 0.949 0.953]);
hold on   
% Exhaust plug
    xeng8(1:sizey)=xle+dxeng+engleng-dxaux+ 0.15*engleng;
    zeng8=[dzeng+0.0125*reng*sin(0:0.1:2*pi) dzeng];
    yeng8=[yposeng*semispan+0.01*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.01*reng)];

xeng=[xeng7;xeng8];
yeng=[yeng7;yeng8];
zeng=[zeng7;zeng8];
%
surface(xeng,yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.8 0.953]);
surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.8 0.953]);
hold on

%============> Engine inlet
% parte frontal
dyeng=yposeng*semispan;
dzeng=engzpos+ yposeng*tan(rad*wingdi)-reng;
xin0(1:sizey)=xle+dxeng-0.30*engleng;
yin0(1:sizey)=[cos(0:0.1:2*pi) 1];
yin0=engdi/2*yin0+dyeng;
zin0(1:sizey)=[sin(0:0.1:2*pi) 0];
zin0=engdi/2*zin0+dzeng;
xin2(1:sizey)=xle+dxeng-0.30*engleng;
yin2(1:sizey)=[cos(0:0.1:2*pi) 1];
yin2=reng*yin2+dyeng;
zin2(1:sizey)=[sin(0:0.1:2*pi) 0];
zin2=reng*zin2+dzeng;
xin=[xin0;xin2];
yin=[yin0;yin2];
zin=[zin0;zin2];
surface(xin, yin, zin,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xin, -yin, zin,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
hold on
% metade inferior
sizey2=size(cos(0:0.1:pi),2)+1;
xin0i(1:sizey2)=xle+dxeng-0.30*engleng;
yin0i(1:sizey2)=[cos(0:0.1:pi) -1];
yin0i=engdi/2*yin0i+dyeng;
zin0i(1:sizey2)=[sin(0:0.1:pi) 0];
zin0i=engdi/2*zin0i+dzeng;
xin2i(1:sizey2)=xle+dxeng;
yin2i(1:sizey2)=[cos(0:0.1:pi) -1];
yin2i=engdi/2*yin2i+dyeng;
zin2i(1:sizey2)=[sin(0:0.1:pi) 0];
zin2i=engdi/2*zin2i+dzeng;
xinsi=[xin0i;xin2i];
yinsi=[yin0i;yin2i];
zinsi=[zin0i;zin2i];
surface(xinsi, yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xinsi, -yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
hold on
% metade superior
sizey2=size(cos(0:0.1:pi),2)+1;
xin0i(1:sizey2)=xle+dxeng-0.30*engleng;
yin0i(1:sizey2)=[cos(pi:-0.1:0) 1];
yin0i=engdi/2*yin0i+dyeng;
zin0i(1:sizey2)=[-sin(pi:-0.1:0) 0];
zin0i=engdi/2*zin0i+dzeng;
xin2i(1:sizey2)=xle+dxeng;
yin2i(1:sizey2)=[cos(pi:-0.1:0) 1];
yin2i=engdi/2*yin2i+dyeng;
zin2i(1:sizey2)=[-sin(pi:-0.1:0) 0];
zin2i=engdi/2*zin2i+dzeng;
xinsi=[xin0i;xin2i];
yinsi=[yin0i;yin2i];
zinsi=[zin0i;zin2i];
surface(xinsi, yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
surface(xinsi, -yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.945 0.949 0.953]);
%--- Fan
xin0f(1:sizey)=xle+dxeng;
yin0f(1:sizey)=[cos(0:0.1:2*pi) 1];
yin0f=0.01*yin0f+dyeng;
zin0f(1:sizey)=[sin(0:0.1:2*pi) 0];
zin0f=0.01*zin0f+dzeng;
xin2f(1:sizey)=xle+dxeng;
yin2f(1:sizey)=[cos(0:0.1:2*pi) 1];
yin2f=engdi/2*yin2f+dyeng;
zin2f(1:sizey)=[sin(0:0.1:2*pi) 0];
zin2f=engdi/2*zin2f+dzeng;
xinsf=[xin0f;xin2f];
yinsf=[yin0f;yin2f];
zinsf=[zin0f;zin2f];
surface(xinsf, yinsf, zinsf,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
surface(xinsf, -yinsf, zinsf,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
% spinner
    xeng7(1:sizey)=xle+dxeng;
    zeng7=[dzeng+0.2*reng*sin(0:0.1:2*pi) dzeng];
    yeng7=[yposeng*semispan+0.20*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.20*reng)];
    
xeng=[xeng4;xeng7];
yeng=[yeng4;yeng7];
zeng=[zeng4;zeng7];
%
hold on   
    
    xeng8(1:sizey)=xle+dxeng-0.10;
    zeng8=[dzeng+0.01*reng*sin(0:0.1:2*pi) dzeng];
    yeng8=[yposeng*semispan+0.01*reng*cos(0:0.1:2*pi) (yposeng*semispan+0.01*reng)];

xeng=[xeng7;xeng8];
yeng=[yeng7;yeng8];
zeng=[zeng7;zeng8];
%
surface(xeng, yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
hold on
    case 2 % rear mounted
% engposx=lco+lcab+0.10*ltail+engleng;
% xeng1(1:sizey)=engposx-engleng;
% dzeng=0.48*raio;
% enginelateral=raio;
% 
% yposeng2=enginelateral+reng;
% zeng1=[dzeng+reng*sin(0:0.1:2*pi) dzeng];
% yeng1=[yposeng2+reng*cos(0:0.1:2*pi) (yposeng2+reng)];
% xeng2(1:sizey)=engposx-0.70*engleng;
% zeng2=[dzeng+reng*sin(0:0.1:2*pi) dzeng];
% yeng2=[yposeng2+reng*cos(0:0.1:2*pi) (yposeng2+reng)];
% xeng3(1:sizey)=engposx;
% zeng3=[dzeng+0.8*reng*sin(0:0.1:2*pi) dzeng];
% yeng3=[yposeng2+0.80*reng*cos(0:0.1:2*pi) (yposeng2+0.80*reng)];
% xeng=[xeng1;xeng2;xeng3];
% yeng=[yeng1;yeng2;yeng3];
% zeng=[zeng1;zeng2;zeng3];    
% %
% surface(xeng,yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
% surface(xeng,-yeng,zeng,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
% %============> Engine inlet
% % parte frontal
% dyeng=enginelateral+reng;
% dzeng=0.48*raio;
% dxeng=engposx-engleng;
% xin0(1:sizey)=dxeng;
% yin0(1:sizey)=[cos(0:0.1:2*pi) 1];
% yin0=engdi/2*yin0+dyeng;
% zin0(1:sizey)=[sin(0:0.1:2*pi) 0];
% zin0=engdi/2*zin0+dzeng;
% xin2(1:sizey)=dxeng;
% yin2(1:sizey)=[cos(0:0.1:2*pi) 1];
% yin2=reng*yin2+dyeng;
% zin2(1:sizey)=[sin(0:0.1:2*pi) 0];
% zin2=reng*zin2+dzeng;
% xin=[xin0;xin2];
% yin=[yin0;yin2];
% zin=[zin0;zin2];
% surface(xin, yin, zin,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% surface(xin, -yin, zin,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% % metade inferior
% sizey2=size(cos(0:0.1:pi),2)+1;
% xin0i(1:sizey2)=dxeng;
% yin0i(1:sizey2)=[cos(0:0.1:pi) -1];
% yin0i=engdi/2*yin0i+dyeng;
% zin0i(1:sizey2)=[sin(0:0.1:pi) 0];
% zin0i=engdi/2*zin0i+dzeng;
% xin2i(1:sizey2)=dxeng+0.30*engleng;
% yin2i(1:sizey2)=[cos(0:0.1:pi) -1];
% yin2i=engdi/2*yin2i+dyeng;
% zin2i(1:sizey2)=[sin(0:0.1:pi) 0];
% zin2i=engdi/2*zin2i+dzeng;
% xinsi=[xin0i;xin2i];
% yinsi=[yin0i;yin2i];
% zinsi=[zin0i;zin2i];
% surface(xinsi, yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% surface(xinsi, -yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% % metade superior
% sizey2=size(cos(0:0.1:pi),2)+1;
% xin0i(1:sizey2)=dxeng;
% yin0i(1:sizey2)=[cos(pi:-0.1:0) 1];
% yin0i=engdi/2*yin0i+dyeng;
% zin0i(1:sizey2)=[-sin(pi:-0.1:0) 0];
% zin0i=engdi/2*zin0i+dzeng;
% xin2i(1:sizey2)=dxeng+0.30*engleng;
% yin2i(1:sizey2)=[cos(pi:-0.1:0) 1];
% yin2i=engdi/2*yin2i+dyeng;
% zin2i(1:sizey2)=[-sin(pi:-0.1:0) 0];
% zin2i=engdi/2*zin2i+dzeng;
% xinsi=[xin0i;xin2i];
% yinsi=[yin0i;yin2i];
% zinsi=[zin0i;zin2i];
% surface(xinsi, yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% surface(xinsi, -yinsi, zinsi,'FaceLighting','gouraud','EdgeColor','black','FaceColor','blue');
% 
% % Tampa traseira motor
% reng=1.1*engdi/2;
% zecac=cos(0:0.1:pi);
% zecas=sin(0:0.1:pi);
% zecoc=cos(pi:0.1:2*pi);
% zecos=sin(pi:0.1:2*pi);
% sizecov=size(zecac,2)+1;
% coverposx=engposx;
% coverposy=dyeng;
% coverposz=dzeng;
% xcover(1:sizecov)=coverposx;
% ycover=[coverposy+0.80*reng*zecas coverposy];
% zcover=[coverposz+0.80*reng*zecac coverposz-0.80*reng];
% xcover1(1:sizecov)=coverposx;
% ycover1=[coverposy+0.80*reng*zecos coverposy];
% zcover1=[coverposz+0.80*reng*zecoc coverposz+0.80*reng];
% xcovf=[xcover;xcover1];
% ycovf=[ycover;ycover1];
% zcovf=[zcover;zcover1];
% surface(xcovf, ycovf, zcovf,'FaceLighting','gouraud','EdgeColor','black','FaceColor',[0.945 0.949 0.953]);
% surface(xcovf,-ycovf, zcovf,'FaceLighting','gouraud','EdgeColor','black','FaceColor',[0.945 0.949 0.953]);
% %--- Fan
% xin0f(1:sizey)=dxeng+0.30*engleng;
% yin0f(1:sizey)=[cos(0:0.1:2*pi) 1];
% yin0f=0.01*yin0f+dyeng;
% zin0f(1:sizey)=[sin(0:0.1:2*pi) 0];
% zin0f=0.01*zin0f+dzeng;
% xin2f(1:sizey)=dxeng+0.30*engleng;
% yin2f(1:sizey)=[cos(0:0.1:2*pi) 1];
% yin2f=engdi/2*yin2f+dyeng;
% zin2f(1:sizey)=[sin(0:0.1:2*pi) 0];
% zin2f=engdi/2*zin2f+dzeng;
% xinsf=[xin0f;xin2f];
% yinsf=[yin0f;yin2f];
% zinsf=[zin0f;zin2f];
% surface(xinsf, yinsf, zinsf,'FaceLighting','gouraud','EdgeColor','black','FaceColor','y');
% surface(xinsf, -yinsf, zinsf,'FaceLighting','gouraud','EdgeColor','black','FaceColor','y');
%
    engposx       = lco+lcab+0.10*ltail+engleng;
    xeng          = engposx-engleng;
    dzeng         = 0.48*raio;
    enginelateral = raio;
    reng          = 1.05*engdi/2;
    yposaux       = enginelateral+reng;
%
    drawengine(xeng,yposaux,dzeng,engdi,engleng) ;
    drawengine(xeng,-yposaux,dzeng,engdi,engleng) ;
    dyeng         = enginelateral+reng;
%% -----  End Engine ------------------------------------------------------

%%----- Engine pylon
dxpylon=engposx-engleng+0.15*engleng;
thiratio=10/12;
sweepTE=32;
cepylon=0.50*engleng;
dyeng_pylon = dyeng - 0.72*reng;
cipylon=cepylon+dyeng_pylon*tan(rad*sweepTE);
dzpylon=dzeng;
xpylon=[dxpylon+cepylon*xpervt; dxpylon+cipylon*xpervt];
zpylon=[dzpylon+thiratio*cepylon*ypervt;dzpylon+thiratio*cipylon*ypervt];
sizex=size(xpervt);
%yperht1(1:sizex(2))=0;
ypylon2(1:sizex(2))=dyeng_pylon;
ypylon3(1:sizex(2))=0;
ypylon=[ypylon2; ypylon3];
surface(xpylon,ypylon,zpylon,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
surface(xpylon,-ypylon,zpylon,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
hold on
%% -------------- End Pylon -----------------------------------------------
end
% Trem de pouso Principal
% X_TP2= coordenada longitudinal do TDP principal
% nt_m = numero de pneus no TDP principal
% D0m_max = diametro do pneu (m)
% wm_max = largura do pneu (m)
% Ss_m = comprimento do amortecedor (m)
% ds_m = diametro do amortecedor (m)

switch wingloc
    
case 1
    
% desenha munhao
npmunhao=20;
 
% recalculo da posicao longitudinal do trem de pouso principal
%
[X_TP2,~, ~]=MLGpos(xle,sweepLE,longtras,Craiz,Cquebra,Cponta,...
         yraiz,yposeng,semispan,engloc,engdi,D0m_max,Lpist_m,tcroot);
%
%
dxang=2*pi/(npmunhao-1);
ang=(0:dxang:2*pi);

x1munhao(1:npmunhao)=X_TP2+ds_m*0.50*cos(ang);
x2munhao=x1munhao;

y1munhao=yc_munhao + ds_m*0.50*sin(ang);
y2munhao=y1munhao;

z1munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi);
z2munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi)-munhao_comp;

xmunhao=[x1munhao; x2munhao];
ymunhao=[y1munhao; y2munhao];
zmunhao=[z1munhao; z2munhao];

surface(xmunhao,ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
surface(xmunhao,-ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
hold on
% Barra lateral (side strut)
x1munhao(1:npmunhao)=X_TP2-ds_m*0.35*cos(ang)-0.10;
x2munhao=x1munhao+0.10;

y1munhao=yc_munhao -1 + ds_m*0.35*sin(ang);
y2munhao=yc_munhao + ds_m*0.35*sin(ang);

z1munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi)-esspraiz*0.50*Craiz;
z2munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi)-0.40*munhao_comp;

xmunhao=[x1munhao; x2munhao];
ymunhao=[y1munhao; y2munhao];
zmunhao=[z1munhao; z2munhao];

surface(xmunhao,ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.1 0.1 0.80]);
surface(xmunhao,-ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor',[0.1 0.1 0.80]);
hold on

% eixo das rodas

x1munhao(1:npmunhao)=X_TP2+ds_m*0.50*cos(ang);
x2munhao=x1munhao;

y1munhao(1:npmunhao)=yc_munhao + ds_m*0.50+wm_max*0.50;
y2munhao(1:npmunhao)=yc_munhao - ds_m*0.50-wm_max*0.50;

z1munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi)-munhao_comp+ds_m*0.50*sin(ang);
z2munhao(1:npmunhao)=wingpos+(yc_munhao-yraiz)*tan(rad*wingdi)-munhao_comp+ds_m*0.50*sin(ang);

xmunhao=[x1munhao; x2munhao];
ymunhao=[y1munhao; y2munhao];
zmunhao=[z1munhao; z2munhao];

surface(xmunhao,ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
surface(xmunhao,-ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
hold on

% Rodas
nproda=20;
dxang=2*pi/(nproda-1);
angroda=(0:dxang:2*pi);

    switch nt_m
    case 2
       
        % Roda no 1
        x0=X_TP2;
        y0=yc_munhao+ds_m+wm_max;
        z0=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp;
        plotwheel_right(x0,y0,z0,D0m_max,wm_max)
        y0=-yc_munhao+ds_m+wm_max;
        plotwheel_right(x0,y0,z0,D0m_max,wm_max)
        % Roda no 2
        y0=yc_munhao-ds_m-wm_max;
        plotwheel_left(x0,y0,z0,D0m_max,wm_max)
        y0=-yc_munhao-ds_m-wm_max;
        plotwheel_left(x0,y0,z0,D0m_max,wm_max)
 
    case 4
       % base das rodas
       comprimb=2*(0.75*D0m_max);
       alturab=0.12*D0m_max;
       largurab=1.5*ds_m;
       
       y1=[];
       y1=[-1 -1 1 1];
       z1=[];
       z1=[-1 1 1 -1];
       x1b=X_TP2-comprimb*0.50;
       x2b=X_TP2+comprimb*0.50;
        
       y10b=yc_munhao;
       y1b=y10b+largurab*y1;
        
       z10b=wingpos-(yc_munhao-yraiz)*tan(rad*wingdi)-munhao_comp;
       z1b=z10b+alturab*z1;
        
       xbase=[];
       ybase=[];
       zbase=[];
        
       xbase=[x1b, x1b, x1b, x1b; x2b, x2b, x2b, x2b];
       ybase=[y1b; y1b];
       zbase=[z1b; z1b];
        
       surface(xbase,ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       surface(xbase,-ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       hold on
       
       xbase=[];
       ybase=[];
       zbase=[];
       xbase=[x1b, x1b, x1b; x1b, x1b, x1b];
       ybase=[y10b+largurab, y10b+largurab, y10b+largurab;y10b-largurab,y10b-largurab,y10b-largurab];
       zbase=[z10b+alturab,z10b, z10b-alturab;z10b+alturab,z10b, z10b-alturab];
       surface(xbase,ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       surface(xbase,-ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       hold on
       
       xbase=[x2b, x2b, x2b; x2b, x2b, x2b];
       surface(xbase,ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       surface(xbase,-ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       hold on
        
       xbase=[x1b, x1b, x1b; x2b,x2b,x2b];
       ybase=[y10b+largurab, y10b, y10b-largurab;y10b+largurab, y10b, y10b-largurab];
       zbase=[z10b-alturab,z10b-alturab,z10b-alturab;z10b-alturab,z10b-alturab,z10b-alturab];
       surface(xbase,ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       surface(xbase,-ybase,zbase,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
       hold on
        
       %roda 1
        y1roda1(1:nproda)=yc_munhao+largurab;
        y2roda1(1:nproda)=yc_munhao+largurab+wm_max;
        x1roda1=X_TP2+0.55*D0m_max+D0m_max*0.50*cos(angroda);
        x2roda1=x1roda1;
        z1roda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp+D0m_max*0.50*sin(angroda);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        surface(xroda1,-yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        % Face externa da roda 1
        dxangf=pi/(nproda-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=X_TP2+0.55*D0m_max+D0m_max*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:nproda)=yc_munhao+wm_max+0.50*largurab;
        y2froda1=y1froda1;
        z1froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp +D0m_max*0.50*sin(angrodaf);
        z2froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp -D0m_max*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
        surface(xfroda1,-yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
        hold on
         %roda 2
        y1roda1(1:nproda)=yc_munhao+largurab;
        y2roda1(1:nproda)=yc_munhao+largurab+wm_max;
        x1roda1=X_TP2-0.55*D0m_max+D0m_max*0.50*cos(angroda);
        x2roda1=x1roda1;
        z1roda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp+D0m_max*0.50*sin(angroda);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        surface(xroda1,-yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        % Face externa da roda 2
        dxangf=pi/(nproda-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=X_TP2-0.55*D0m_max+D0m_max*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:nproda)=yc_munhao+wm_max+0.50*largurab;
        y2froda1=y1froda1;
        z1froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp +D0m_max*0.50*sin(angrodaf);
        z2froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp -D0m_max*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
        surface(xfroda1,-yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y');
        hold on
        % Roda no. 3
        y1roda1(1:nproda)=yc_munhao-0.50*largurab;
        y2roda1(1:nproda)=yc_munhao-0.50*largurab-wm_max;
        x1roda1=X_TP2-0.55*D0m_max+D0m_max*0.50*cos(angroda);
        x2roda1=x1roda1;
        z1roda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp+D0m_max*0.50*sin(angroda);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        surface(xroda1,-yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        hold on
        % Face externa da roda no. 3
        dxangf=pi/(nproda-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=X_TP2-0.55*D0m_max+D0m_max*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:nproda)=yc_munhao-wm_max-0.50*largurab;
        y2froda1=y1froda1;
        z1froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp +D0m_max*0.50*sin(angrodaf);
        z2froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp -D0m_max*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        surface(xfroda1,-yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        hold on
        % Roda no. 4
        y1roda1(1:nproda)=yc_munhao-0.50*largurab;
        y2roda1(1:nproda)=yc_munhao-0.50*largurab-wm_max;
        x1roda1=X_TP2+0.55*D0m_max+D0m_max*0.50*cos(angroda);
        x2roda1=x1roda1;
        z1roda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp+D0m_max*0.50*sin(angroda);
        z2roda1=z1roda1;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1=[z1roda1;z2roda1];
        surface(xroda1,yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        surface(xroda1,-yroda1,zroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        hold on
        % Face externa da roda no. 4
        dxangf=pi/(nproda-1);
        angrodaf=(0:dxangf:pi);
        x1froda1=X_TP2+0.55*D0m_max+D0m_max*0.50*cos(angrodaf);
        x2froda1=x1froda1;
        y1froda1(1:nproda)=yc_munhao-wm_max-0.50*largurab;
        y2froda1=y1froda1;
        z1froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp +D0m_max*0.50*sin(angrodaf);
        z2froda1=wingpos+(yc_munhao-yraiz)*sin(rad*wingdi)-munhao_comp -D0m_max*0.50*sin(angrodaf);
        xfroda1=[x1froda1;x2froda1];
        yfroda1=[y1froda1;y2froda1];
        zfroda1=[z1froda1;z2froda1];
        surface(xfroda1,yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        surface(xfroda1,-yfroda1,zfroda1,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
        hold on
    end
% Trem do nariz


dxang=2*pi/(npmunhao-1);
ang=(0:dxang:2*pi);

x1munhao(1:npmunhao)=X_TP1+ds_n*0.50*cos(ang);
x2munhao=x1munhao;

y1munhao= ds_n*0.50*sin(ang);
y2munhao=y1munhao;

z1munhao(1:npmunhao)=-df/2;
z2munhao(1:npmunhao)=-df/2-Lpist_n;

xmunhao=[x1munhao; x2munhao];
ymunhao=[y1munhao; y2munhao];
zmunhao=[z1munhao; z2munhao];

surface(xmunhao,ymunhao,zmunhao,'FaceLighting','gouraud','EdgeColor','none','FaceColor','blue');
disp('nose landing gear')


% Roda area de contacto com solo
        y1roda1(1:nproda)= ds_n*0.50;
        y2roda1(1:nproda)= ds_n*0.50+wn_max;
        x1roda1=X_TP1+D0n_max*0.50*cos(angroda);
        x2roda1=x1roda1;
        z1roda1_n = [];
        xistosin  = sin(angroda);
        z1roda1_n = [z1roda1_n, -df/2-Lpist_n+D0n_max*0.50*sin(angroda)];
        z2roda1_n=z1roda1_n;
        xroda1=[x1roda1;x2roda1];
        yroda1=[y1roda1;y2roda1];
        zroda1_n=[z1roda1_n;z2roda1_n];
        surface(xroda1,yroda1,zroda1_n,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        surface(xroda1,-yroda1,zroda1_n,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        hold on
        % face externa da roda
   
        dxangf=pi/(nproda-1);
        angrodaf=(0:dxangf:pi);
        x1frodan=X_TP1+D0n_max*0.50*cos(angrodaf);
        x2frodan=x1frodan;
        y1frodan(1:nproda)=ds_n*0.50 + wn_max;
        y2frodan=y1frodan;
        z1frodan=-df/2-Lpist_n +D0n_max*0.50*sin(angrodaf);
        z2frodan=-df/2-Lpist_n -D0n_max*0.50*sin(angrodaf);
        xfrodan=[x1frodan;x2frodan];
        yfrodan=[y1frodan;y2frodan];
        zfrodan=[z1frodan;z2frodan];
        surface(xfrodan,yfrodan,zfrodan,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        surface(xfrodan,-yfrodan,zfrodan,'FaceLighting','gouraud','EdgeColor','none','FaceColor','k');
        hold on
case 2 % wingloc
        % do nothing
end % wingloc
axis 'equal'
colormap 'Jet'

%shading 'interp'
%shading 'faceted'

saveas(gcf,'airplane3d.fig')