function y=PRECALC(wS,wAR,wTR,wSweep14,NSeat,NCorr,NPax,ediam,ebypass,eopr,wTwist,Kink_semispan);

close all

% CONSTANTS

kg2lb=2.2046;
m2feet=3.28083;
g=9.80665;

% DESIGN VARIABLES - BASELINE ACFT
%
% wS           = 72.72;
% wAR          = 8.6;
% wTR          = 0.285;
% wSweep14     = 23.5;
% wTwist       = -3.5;
% Kink_semispan= 0.34;
% ebypass      = 5;    
% ediam        = 1.36;  
% eopr         = 28.5;
% NPax         = 78;

% AIRFRAME PARAMETERS

wSft2          = wS*m2feet*m2feet;
b              = sqrt(wAR*wS);
CLMAX          = 1.6;
PWing          = 1;
VTarea         = 16.2;
VTAR           = 0.89;
VTTR           = 0.740;
VTSweep        = 41;
HTarea         = 23.35;
HTAR           = 4.35;
HTTR           = 0.4;
PHT            = 1;
container_type = 'None';
NCorr          = 1;
NSeat          = 4;
ncrew          = 5;
AisleWidth     = 0.49;
CabHeightm     = 2;
SEATwid        = 0.46;
widthreiratio  = 1.15;
inc_root       = 2;
inc_kink       = 0;
inc_tip        = inc_root + wTwist;
MMO            =0.82;
VMO            =340;

%ENGINE PARAMETERS

PEng = 1; % 1= two underwing engines; 2= two engines at rear fuselage
MAXRATE=13400;
%
switch PEng
    case 1
        n= 2;
        nedebasa=2;
    case 2
        n=2;
        nedebasa=0;
    case 3
        n=3;
        nedebasa=2;
    case 4
        n=4;
        nedebasa=4;
end

efanpr= 1.425;
eTIT= 1240; 
Engine_data(1)     = PEng;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;

% Sobiescki parameters for three wing airfoils

[r0, t_c, phi, X_tcmax, theta, epsilon,Ycmax, YCtcmax, X_Ycmax]=airfoilcoeff();
wTCmed = (t_c(1)+t_c(2)+t_c(3))/3;

%Fuselage cross-section sizing

[fus_width, fus_height]=fuscrosssect02(container_type,NCorr,NSeat,CabHeightm,SEATwid,AisleWidth,widthreiratio);
FusDiam = sqrt(fus_width*fus_height);

% WET AREA CALCULATION

[Airp_SWET, wingSwet,lf ,lco, ~ , ~ ,wMAC, wSweepLE, ~ ,...
    ~ , ~,~,~,~, ~,~,~,Ccentro,Craiz,Cquebra, Cponta, ...
    xutip, yutip, xltip, yltip,...
    xukink,yukink,xlkink,ylkink, xuroot,yuroot,xlroot,ylroot,T0]...
    = wettedarea(...
    MMO,FusDiam,...
    NPax,NCorr,NSeat,SEATwid,AisleWidth,...
    Kink_semispan,wS,wAR,wTR,wSweep14,wTwist,...
    PWing,Engine_data,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT);

swet2=Airp_SWET; % [m2]

% SAVE PARAMETERS ON DISK 

fid=fopen('parameters.dat','w+');
     
        % wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT
        fprintf(fid,'%6.2f\n',wS);
        fprintf(fid,'%6.2f\n',wSft2);
        fprintf(fid,'%6.2f\n',wAR);  
        fprintf(fid,'%6.2f\n',wTR);
        fprintf(fid,'%6.2f\n',wSweep14);
        fprintf(fid,'%6.2f\n',wTwist); 
        fprintf(fid,'%6.2f\n',CLMAX);
        fprintf(fid,'%6.2f\n',PWing);
        fprintf(fid,'%6.2f\n',VTarea);
        fprintf(fid,'%6.2f\n',VTAR); 
        fprintf(fid,'%6.2f\n',VTTR);
        fprintf(fid,'%6.2f\n',VTSweep);
        fprintf(fid,'%6.2f\n',HTarea);
        fprintf(fid,'%6.2f\n',HTAR);
        fprintf(fid,'%6.2f\n',HTTR);
        fprintf(fid,'%6.2f\n',PHT);
        
        % NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio
        fprintf(fid,'%6.2f\n',NPax);
        fprintf(fid,'%6.2f\n',NCorr);
        fprintf(fid,'%6.2f\n',NSeat);
        fprintf(fid,'%3.0f\n',ncrew);
        fprintf(fid,'%6.2f\n',AisleWidth);  
        fprintf(fid,'%6.2f\n',CabHeightm); 
        fprintf(fid,'%6.2f\n',Kink_semispan);
        fprintf(fid,'%6.2f\n',SEATwid);
        fprintf(fid,'%6.2f\n',widthreiratio);
     
        % inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
        fprintf(fid,'%6.2f\n',inc_root);
        fprintf(fid,'%6.2f\n',inc_kink);
        fprintf(fid,'%6.2f\n',inc_tip);
        fprintf(fid,'%6.2f\n',MMO);
        fprintf(fid,'%6.2f\n',VMO);
        fprintf(fid,'%6.2f\n',PEng);
        fprintf(fid,'%6.2f\n',MAXRATE);
        fprintf(fid,'%6.2f\n',n);
        fprintf(fid,'%6.2f\n',nedebasa);
        fprintf(fid,'%6.2f\n',ebypass);
        fprintf(fid,'%6.2f\n',ediam);
        fprintf(fid,'%6.2f\n',efanpr);
        fprintf(fid,'%6.2f\n',eopr);
        fprintf(fid,'%6.2f\n',eTIT);   
        
        % wTCmed,fus_width,fus_height,FusDiam,...
        fprintf(fid,'%6.2f\n',wTCmed);
        fprintf(fid,'%6.2f\n',fus_width);
        fprintf(fid,'%6.2f\n',fus_height);
        fprintf(fid,'%6.2f\n',FusDiam);
        
        % Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,
        fprintf(fid,'%6.2f\n',Airp_SWET);
        fprintf(fid,'%6.2f\n',wingSwet);
        fprintf(fid,'%6.2f\n',lf);
        fprintf(fid,'%6.2f\n',lco);
        fprintf(fid,'%6.2f\n',wMAC);
        fprintf(fid,'%6.2f\n',wSweepLE);
        fprintf(fid,'%6.2f\n',Ccentro);
        fprintf(fid,'%6.2f\n',Craiz);
        fprintf(fid,'%6.2f\n',Cquebra);
        fprintf(fid,'%6.2f\n',Cponta);
        
        % T0,swet2,container_type
        fprintf(fid,'%6.2f\n',T0);
        fprintf(fid,'%6.2f\n',swet2);        
        fprintf(fid,container_type);  
        fprintf(fid,'\n');      
        
        % r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,
        for i=1:3
          fprintf(fid,num2str(r0(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(t_c(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(phi(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(X_tcmax(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(theta(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(epsilon(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(X_Ycmax(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(Ycmax(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(YCtcmax(1,i),'%6.4f\n'));
          fprintf(fid,num2str('\n')); 
        end       
 
        % xutip,yutip,xltip,yltip,xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot
        for i=1:51
          % 
          fprintf(fid,num2str(xutip(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(yutip(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(xltip(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(yltip(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(xukink(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(yukink(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(xlkink(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(ylkink(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(xuroot(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(yuroot(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(xlroot(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
          fprintf(fid,num2str(ylroot(1,i),'%6.4f\n'));    
          fprintf(fid,num2str('\n')); 
        end
         
fclose(fid);

