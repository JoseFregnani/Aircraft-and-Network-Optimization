function [D0m_max, D0n_max, wm_max, wn_max,ds_m, ds_n, Lpist_m,Lpist_n]=...
plotairplane3d_V2(xcg_dianteiro,xcg_traseiro,zcg_dianteiro,MTOW,...
   MLW,CLmax_to,CLmax_land,lf,lco,ltail,df,Ccentro,Craiz,Cquebra,Cponta,warea,wtaper,...
   xle,sweepLE,semispan,wingdi,engloc,engdi,engleng,yposeng, ...
   ctipvt,crootvt,arv,sweepLEvt,ht,htloc,...
   wingloc,pneum_p,pneun_p,tcroot,iroot,ikink,itip,SweepLE_winglet,AR_winglet,...
         TR_winglet,CantAngle_wlet,wlet_present,poslongtras,...
         bflap,X_TP1)
%
% ------- Calculos auxiliares
yraiz = 0.85*(df/2);
if engloc == 2 && htloc == 1 
    htloc = 2;
    fprintf('\n WARNING: HT configuration was changed due to desired engine configuration \n')
end

D0m_max       = 0.95; % estimativa inicial (m)
D0n_max       = 100;
D0m_max_new   = 100;
Lpist_m       = 1;
diam_n        = 0.80;
pist_n        = 0.80*Lpist_m;
% recalculo da posicao longitudinal do trem de pouso principal
%cd Landing_gear

while abs(D0m_max - D0m_max_new) > 0.01 || abs(diam_n - D0n_max) > 0.01
[X_TP2, yc_munhao, munhao_comp] = MLGpos(xle,sweepLE,poslongtras,Craiz,Cquebra,Cponta,...
         yraiz,yposeng,semispan,engloc,engdi,D0m_max,Lpist_m,tcroot);

% chamada da rotina de dimensionamento do munhao e pneus do LG

[~, nt_m,D0m_max_new, wm_max, Lpist_m_new, ds_m, Lpist_n, ds_n, wn_max, D0n_max]=...
    LGDesign2(df,xcg_dianteiro,xcg_traseiro,zcg_dianteiro,MTOW,MLW,...
    X_TP1,X_TP2,CLmax_to,CLmax_land,warea,lf,pneum_p,pneun_p,diam_n,pist_n);
%
Lpist_m  = 0.40*Lpist_m + 0.60*Lpist_m_new;
D0m_max  = (0.40*D0m_max + 0.60*D0m_max_new);
pist_n   = (Lpist_n + pist_n)/2;
diam_n   = (D0n_max + diam_n)/2;
end
%
fprintf('\n MLG tyre diameter = %5.2f m \n',D0m_max)
fprintf('\n NLG tyre diameter = %5.2f m \n',D0n_max)
%
%cd ..
% Desenha aviao
plotairplane3d_Prin(lf,lco,ltail,df,Ccentro,Cquebra,Craiz,wtaper,xle,sweepLE,semispan,wingdi,engloc,engdi,engleng,yposeng, ...
    ctipvt,crootvt,arv,sweepLEvt,ht,htloc,wingloc,X_TP1,nt_m,D0m_max,wm_max,ds_m,Lpist_n,ds_n,wn_max,D0n_max,...
    iroot,ikink,itip,SweepLE_winglet,AR_winglet,...
         TR_winglet,CantAngle_wlet,wlet_present,poslongtras,bflap,yc_munhao, munhao_comp,tcroot,Lpist_m)
%**************************************************************************




   
 

 