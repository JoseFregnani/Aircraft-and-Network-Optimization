clear; clc
npax=73;
paxmin=55;
paxmax=130;
nt =3;
t(1)=75;
t(2)=95;
% t(3)=105;
% t(4)=115;
%
classifica = 0;
for i=1:(nt-1)
rastreia=npax -t(i);
    if rastreia < 0
    classifica = i;
    break
    end
end
if(classifica == 0) 
    classifica = nt;
end
xistosclassifica=classifica




