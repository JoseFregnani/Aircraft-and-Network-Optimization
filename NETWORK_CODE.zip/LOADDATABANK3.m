function [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3]=LOADDATABANK3(n1,n2,n3,mode)

i=1;
db=4;

for k=1:db
    
    switch k
        case 1
            acftdata='parameters_1000_1500.dat'; 
        case 2   
            acftdata='parameters_1500_2000.dat';
        case 3    
            acftdata='parameters_2000_2500.dat';
        case 4    
            acftdata='parameters_1600.dat';  
    end           
            
    fid = fopen(acftdata);

    while ~feof(fid)

       [MTOW,MLW,MZFW,OEW,MAXFUEL,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
        container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthratio,...
        inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
        r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
        Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
        xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2,RANGE]=LOADDATA3(fid);    
        %
        A(i).OEW=OEW;
        A(i).MTOW=MTOW;
        A(i).MLW=MLW;
        A(i).MZFW=MZFW;
        A(i).MAXFUEL=MAXFUEL;
        %
        A(i).wS =wS;
        A(i).wSft2 =wSft2;
        A(i).wAR=wAR;
        A(i).wTR=wTR;
        A(i).wSweep14=wSweep14;
        A(i).wTwist=wTwist;
        A(i).CLmax=CLmax;
        A(i).PWing=PWing;
        A(i).Kink_semispan=Kink_semispan;
        A(i).inc_root=inc_root; 
        A(i).inc_kink=inc_kink; 
        A(i).inc_tip=inc_tip; 
        A(i).wMAC=wMAC;
        A(i).wSweepLE=wSweepLE;
        %
        A(i).VTarea=VTarea;
        A(i).VTAR=VTAR;
        A(i).VTTR=VTTR;
        A(i).VTSweep=VTSweep;
        A(i).HTarea=HTarea;
        A(i).HTAR=HTAR;
        A(i).HTTR=HTTR;
        A(i).PHT=PHT;
        %
        A(i).container_type=container_type;
        A(i).NPax=round(NPax);
        A(i).NCorr=round(NCorr);
        A(i).NSeat=round(NSeat);
        A(i).ncrew=ncrew;
        A(i).AisleWidth=AisleWidth;
        A(i).CabHeightm=CabHeightm;    
        A(i).SEATwid=SEATwid; 
        A(i).widthratio=widthratio; 
        A(i).fus_width=fus_width;
        A(i).fus_height=fus_height;
        A(i).FusDiam=FusDiam;
        %
        A(i).MMO=MMO; 
        A(i).VMO=VMO; 
        %
        A(i).PEng=PEng; 
        A(i).MAXRATE=MAXRATE;   
        A(i).n=n;  
        A(i).nedebasa=nedebasa; 
        A(i).ebypass=ebypass;
        A(i).ediam=ediam;
        A(i).efanpr=efanpr;
        A(i).eopr=eopr;
        A(i).eTIT=eTIT;
        %
        A(i).r0=r0;
        A(i).t_c=t_c;
        A(i).phi=phi;
        A(i).X_tcmax=X_tcmax;
        A(i).theta=theta;
        A(i).epsilon=epsilon;
        A(i).Ycmax=Ycmax;
        A(i).YCtcmax=YCtcmax;
        A(i).X_Ycmax=X_Ycmax;
        A(i).wTCmed=wTCmed;
        %
        A(i).Airp_SWET=Airp_SWET;
        A(i).wingSwet=wingSwet;
        A(i).lf=lf;
        A(i).lco=lco;
        %
        A(i).Ccentro=Ccentro;
        A(i).Craiz=Craiz;
        A(i).Cquebra=Cquebra;
        A(i).Cponta=Cponta;
        A(i).xutip=xutip;
        A(i).yutip=yutip;
        A(i).xltip=xltip;
        A(i).yltip=yltip;
        A(i).xukink=xukink;
        A(i).yukink=yukink;
        A(i).xlkink=xlkink;
        A(i).ylkink=ylkink;
        A(i).xuroot=xuroot;
        A(i).yuroot=yuroot;
        A(i).xlroot=xlroot;
        A(i).ylroot=ylroot;
        A(i).T0=T0;
        A(i).swet2=swet2;
        A(i).RANGE=RANGE;
        %
        i=i+1;

    end    
    fclose(fid);
    
end    
n=i-1;

switch mode

    case 1 % SELECTION USING PAX CAPACITY   
        
        MAXPAX=0;
        MINPAX=999;
        for i=1:n
           PAX=A(i).NPax;
           if PAX<=MINPAX
              MINPAX=round(PAX);
           end
           if PAX>=MAXPAX
              MAXPAX=round(PAX);
           end
        end   

%         LIM1=round(MINPAX+(MAXPAX-MINPAX)/3);
%         LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3);
%         LIM3=MAXPAX;
        LIM1=80;
        LIM2=90;
        LIM3=110;

        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            PAX=A(i).NPax;
            if PAX<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(PAX>LIM1,PAX<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(PAX>LIM2,PAX<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end    
        
    case 2% SELECTION USING RANGE  
        
        MAXRANGE=0;
        MINRANGE=999;
        for i=1:n
           RANGE=A(i).RANGE;
           if RANGE<=MINRANGE
              MINRANGE=round(RANGE);
           end
           if RANGE>=MAXRANGE
              MAXRANGE=round(RANGE);
           end
        end   

%       LIM1=round(MINRANGE+(MAXRANGE-MINRANGE)/3);
%       LIM2=round(MINRANGE+(MAXRANGE-MINRANGE)*2/3);
%       LIM3=MAXRANGE;
        LIM1=80;
        LIM2=90;
        LIM3=110;

        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            RANGE=A(i).RANGE;
            if RANGE<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(RANGE>LIM1,RANGE<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(RANGE>LIM2,RANGE<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end    
                
end        

% Choose aircrafts from the list
l1=size(A1,2);
l2=size(A2,2);
l3=size(A3,2);
% n1=ceil(X1*l1);
% n2=ceil(X2*l2);
% n3=ceil(X3*l3);
ACFT1=A1(n1)
ACFT2=A2(n2)
ACFT3=A3(n3)

% % Save on spreadsheet
% %ACFT1
% filename = 'C:\Users\Jose\Desktop\MATLAB FILES\Perfo\NETWORK5d_3ACFT\DB1.xlsx';
% delete filename;
% 
% for i=1:l1;
%     LIN1=[i A1(i).OEW A1(i).MTOW A1(i).MLW A1(i).MZFW A1(i).MAXFUEL A1(i).wS A1(i).wSft2 A1(i).wAR];
%     LIN2=[A1(i).wTR A1(i).wSweep14 A1(i).wTwist A1(i).CLMAX A1(i).PWing A1(i).Kink_semispan A1(i).inc_root A1(i).inc_kink A1(i).inc_tip A1(i).wMAC];
%     LIN3=[A1(i).wSweepLE A1(i).VTarea A1(i).VTAR A1(i).VTTR A1(i).VTSweep A1(i).HTarea A1(i).HTAR A1(i).HTTR 0 A1(i).NPax];
%     LIN4=[A1(i).NCorr A1(i).NSeat A1(i).ncrew A1(i).AisleWidth A1(i).CabHeightm A1(i).SEATwid A1(i).widthratio A1(i).fus_width A1(i).fus_height];
%     LIN5=[A1(i).FusDiam A1(i).MMO A1(i).VMO A1(i).PEng A1(i).MAXRATE A1(i).n A1(i).nedebasa A1(i).ebypass A1(i).ediam A1(i).efanpr A1(i).eopr A1(i).eTIT];     
%     LIN6=[A1(i).r0 A1(i).t_c A1(i).phi A1(i).X_tcmax A1(i).theta A1(i).epsilon A1(i).Ycmax A1(i).YCtcmax A1(i).X_Ycmax A1(i).wTCmed A1(i).Airp_SWET];
%     LIN7=[A1(i).wingSwet A1(i).lf A1(i).lco A1(i).Ccentro A1(i).Craiz A1(i).Cquebra A1(i).Cponta A1(i).xutip A1(i).yutip A1(i).xltip A1(i).yltip A1(i).xukink];
%     LIN8=[A1(i).yukink A1(i).xlkink A1(i).ylkink A1(i).xuroot A1(i).yuroot A1(i).xlroot A1(i).ylroot A1(i).T0 A1(i).swet2 A1(i).RANGE];
%     LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8];       
%     M1(i,:)=LIN;
% end
% xlswrite(filename,M1);
% 
% %ACFT2
% filename = 'C:\Users\Jose\Desktop\MATLAB FILES\Perfo\NETWORK5d_3ACFT\DB2.xlsx';
% delete filename;
% 
% for i=1:l2;
%     LIN1=[i A2(i).OEW A2(i).MTOW A2(i).MLW A2(i).MZFW A2(i).MAXFUEL A2(i).wS A2(i).wSft2 A2(i).wAR];
%     LIN2=[A2(i).wTR A2(i).wSweep14 A2(i).wTwist A2(i).CLMAX A2(i).PWing A2(i).Kink_semispan A2(i).inc_root A2(i).inc_kink A2(i).inc_tip A2(i).wMAC];
%     LIN3=[A2(i).wSweepLE A2(i).VTarea A2(i).VTAR A2(i).VTTR A2(i).VTSweep A2(i).HTarea A2(i).HTAR A2(i).HTTR 0 A2(i).NPax];
%     LIN4=[A2(i).NCorr A2(i).NSeat A2(i).ncrew A2(i).AisleWidth A2(i).CabHeightm A2(i).SEATwid A2(i).widthratio A2(i).fus_width A2(i).fus_height];
%     LIN5=[A2(i).FusDiam A2(i).MMO A2(i).VMO A2(i).PEng A2(i).MAXRATE A2(i).n A2(i).nedebasa A2(i).ebypass A2(i).ediam A2(i).efanpr A2(i).eopr A2(i).eTIT];     
%     LIN6=[A2(i).r0 A2(i).t_c A2(i).phi A2(i).X_tcmax A2(i).theta A2(i).epsilon A2(i).Ycmax A2(i).YCtcmax A2(i).X_Ycmax A2(i).wTCmed A2(i).Airp_SWET];
%     LIN7=[A2(i).wingSwet A2(i).lf A2(i).lco A2(i).Ccentro A2(i).Craiz A2(i).Cquebra A2(i).Cponta A2(i).xutip A2(i).yutip A2(i).xltip A2(i).yltip A2(i).xukink];
%     LIN8=[A2(i).yukink A2(i).xlkink A2(i).ylkink A2(i).xuroot A2(i).yuroot A2(i).xlroot A2(i).ylroot A2(i).T0 A2(i).swet2 A2(i).RANGE];
%     LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8];       
%     M2(i,:)=LIN;
% end
% xlswrite(filename,M2);
% 
% %ACFT3
% filename = 'C:\Users\Jose\Desktop\MATLAB FILES\Perfo\NETWORK5d_3ACFT\DB3.xlsx';
% delete filename;
% 
% for i=1:l3;
%     LIN1=[i A3(i).OEW A3(i).MTOW A3(i).MLW A3(i).MZFW A3(i).MAXFUEL A3(i).wS A3(i).wSft2 A3(i).wAR];
%     LIN2=[A3(i).wTR A3(i).wSweep14 A3(i).wTwist A3(i).CLMAX A3(i).PWing A3(i).Kink_semispan A3(i).inc_root A3(i).inc_kink A3(i).inc_tip A3(i).wMAC];
%     LIN3=[A3(i).wSweepLE A3(i).VTarea A3(i).VTAR A3(i).VTTR A3(i).VTSweep A3(i).HTarea A3(i).HTAR A3(i).HTTR 0 A3(i).NPax];
%     LIN4=[A3(i).NCorr A3(i).NSeat A3(i).ncrew A3(i).AisleWidth A3(i).CabHeightm A3(i).SEATwid A3(i).widthratio A3(i).fus_width A3(i).fus_height];
%     LIN5=[A3(i).FusDiam A3(i).MMO A3(i).VMO A3(i).PEng A3(i).MAXRATE A3(i).n A3(i).nedebasa A3(i).ebypass A3(i).ediam A3(i).efanpr A3(i).eopr A3(i).eTIT];     
%     LIN6=[A3(i).r0 A3(i).t_c A3(i).phi A3(i).X_tcmax A3(i).theta A3(i).epsilon A3(i).Ycmax A3(i).YCtcmax A3(i).X_Ycmax A3(i).wTCmed A3(i).Airp_SWET];
%     LIN7=[A3(i).wingSwet A3(i).lf A3(i).lco A3(i).Ccentro A3(i).Craiz A3(i).Cquebra A3(i).Cponta A3(i).xutip A3(i).yutip A3(i).xltip A3(i).yltip A3(i).xukink];
%     LIN8=[A3(i).yukink A3(i).xlkink A3(i).ylkink A3(i).xuroot A3(i).yuroot A3(i).xlroot A3(i).ylroot A3(i).T0 A3(i).swet2 A3(i).RANGE];
%     LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8];       
%     M3(i,:)=LIN;
% end
% xlswrite(filename,M3);
% 
% 
% 
