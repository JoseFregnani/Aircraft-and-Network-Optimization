%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - NETWORK MODULE
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 2.0 / October 2017 - Network optimiztion 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
close all

% LOAD AIRCRAFT
  [MTOW,MLW,MZFW,OEW,MAXFUEL,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT,...
    container_type,NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio,...
    inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
    r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,wTCmed,fus_width,fus_height,FusDiam,...
    Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,xutip,yutip,xltip,yltip,...
    xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot,T0,swet2]=LOADDATA2();
           
% AIRLINE OPS PARAMETERS
MAXPAX=NPax;
ISADEV=10;
PAXWT=110;
MAXUTIL=12;
TURNAROUND=30;
TIT=5;
TOT=10;
ID=30;
TO_ALLOWANCE=200;
ARR_ALLOWANCE=100;
avg_ticket=200;
SHARE=0.10;
LFREF=0.80;

% REFERENCE DOC CALCULATION
REF_RANGE=1000;
DISTALT=200; 
PAYLOAD=MAXPAX*PAXWT*LFREF;
[~,~,DOCREF]=Mission5b(0,0,0,0,0,REF_RANGE,DISTALT,ISADEV,PAYLOAD,MAXPAX);   

clc
fprintf('\n ** REFFERENCE VALUES FOR NETWORK DESIGN **');
fprintf('\n'); 
fprintf('\n RANGE (nm)               : %5.0f',REF_RANGE);
fprintf('\n ALTERNATE DIST (nm)      : %5.0f',DISTALT);
fprintf('\n DOC   ($/nm)             : %5.2f',DOCREF);
fprintf('\n Average fare ($)         : %5.0f',avg_ticket);
fprintf('\n Average Load Factor (pct): %5.1f',LFREF*100);
fprintf('\n Average Market Share(pct): %5.1f',SHARE*100);
fprintf('\n'); 

% Network Optimiztion
VPAX=[MAXPAX 0 0]';
VDOC=[DOCREF 0 0]'; 
VRANGE=[REF_RANGE 0 0]';
[Airport,X,FREQ,f,LF,DIST,HDG]=NETWORKOPT_R04d(VPAX,VDOC,VRANGE,SHARE,LFREF,avg_ticket);
n=size(X,2);

% SECTOR ANALYSIS 
fprintf('\n');
fprintf('\n ** SECTORS EVALUATION **');
fprintf('\n'); 
fprintf('\n SECTOR   PAX   ZFW   FOB  TXI   TOF   TOW   TRIP   LW   REM   DIST   HDG   CRZALT TIME  DOC   FREQ');
fprintf('\n               [kg]  [kg]  [kg]  [kg]  [kg]  [kg]  [kg]  [kg]  [nm]  [deg]   [FL] [min] [$/nm]     ');
            
    for i=1:n
        for j=1:n
           if i~=j;
               if X(i,j)~=0;
                 DISTANCE=DIST(i,j);                  
                 NPAX=LF(i,j)*MAXPAX;
                 PAYLOAD=NPAX*PAXWT;
                 dep=Airport(i).name;
                 arr=Airport(j).name;
                 sector=string(strcat(dep,'/',arr));   
                 fprintf('\n');
                 fprintf('%s ',sector);
                 Origelev=Airport(i).elev;
                 Destelev=Airport(j).elev;
                 Altelev=Airport(i).elev;
                 TH=HDG(i,j);
                 THA=HDG(j,i);
                 [Wf(i,j),T(i,j),CF(i,j)]=Mission5b(Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ISADEV,PAYLOAD,MAXPAX);  
                 fprintf('%3.0f ',FREQ(i,j));
                 T(i,j)=(T(i,j)+TIT+TOT+TURNAROUND+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)/60; 
                 Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
               end
           end 
        end
    end

% NETWORK RESULTS   
    
TOTCOST=0;
TOTDIST=0;
TOTALFREQ=0;
TOTALPAX=0;
TOTTIME=0;
TOTFLIGHTS=0;
%
for i=1:n
    for j=1:n
        if X(i,j)==1;
            TOTCOST=TOTCOST+DIST(i,j)*CF(i,j)*FREQ(i,j)+ID*(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
            TOTDIST=TOTDIST+DIST(i,j)*FREQ(i,j);
            TOTALPAX=TOTALPAX+LF(i,j)*MAXPAX*FREQ(i,j);
            TOTTIME=TOTTIME+FREQ(i,j)*(T(i,j)+(Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay)+TURNAROUND)/60;
            TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);         
        end    
    end    
end
% 
DOCoTOTCOST=0.65;
costfac=1/DOCoTOTCOST;
DOC=TOTCOST/TOTDIST;
COST=TOTCOST*costfac;
REV=TOTALPAX*avg_ticket;
PROFIT=REV-COST;
CASK=COST/(TOTALPAX*TOTDIST);
RASK=avg_ticket/TOTDIST;
YIELD=RASK-CASK;               
NACFT=TOTTIME/MAXUTIL;     
%
fprintf('\n');
fprintf('\n ** NETWORK RESULTS **');
fprintf('\n'); 
fprintf('\n TOTAL DIST (nm)/ day     : %10.2f',TOTDIST);
fprintf('\n TOTAL PAX                : %10.0f',TOTALPAX);
fprintf('\n TOTAL COST    ($)/day    : %10.2f',COST);
fprintf('\n TOTAL REVENUE ($)/day    : %10.2f',REV);
fprintf('\n TOTAL PROFIT  ($)/day    : %10.2f',PROFIT);
fprintf('\n NDOC ($/nm)              : %6.2f',DOC);
fprintf('\n NRASK ($/pax.nm)x1E-3    : %6.2f',RASK*1E3);
fprintf('\n NCASK ($/pax.nm)x1E-3    : %6.2f',CASK*1E3);
fprintf('\n NYIELD($/pax.nm)x1E-3    : %6.2f',YIELD*1E3);
fprintf('\n NUM OF ACFT              : %6.0f',NACFT);
    
    
    


