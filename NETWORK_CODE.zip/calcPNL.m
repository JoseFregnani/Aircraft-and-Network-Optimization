%% DESCRI��O E AUTORIA %%
%calcPNL  - Rotina para c�lculo de Perceived Noise Levels
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   f           - freq��ncias-padr�o
%                   NOY         - ru�do [NOY]
%Dados de saida  : 
%                   PNL         - perceived noise level [PNdB]
%
%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-08-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%
%


%% DECLARA��O DA FUN��O %%
function [PNL] = calcPNL(f,NOY)


%% CORPO DA FUN��O %%
%% Defini��es dos loops %%
a1                  = max(size(f));
[a2 a3]             = size(NOY);

%% Convers�o de NOY em PNdB%%
for i2 = 1:a3;
    for i1 = 1:a1
        nmax(i2)    = max(NOY(:,i2));
        N(i2)       = nmax(i2)+0.15*(sum(NOY(:,i2))-nmax(i2));
        PNL(i2)     = 40+10/log10(2)*log10(N(i2));
    end
end


%% ENCERRAMENTO DA FUN��O
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T. Aircraft Noise (1989)
%2 - ICAO - Annex 16 - Environmental Protection ()