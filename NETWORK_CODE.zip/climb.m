function [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL)

%a0=661.4786;
kt2fpm=101.269;
%
[~, PR, ~, a] = atmos(h,ISADEV);
%
if (M>0)
    [facCAS,~]=acelfac(M,h,ISADEV);
    TAS=M*a;
    %[CDoCL]=CDCL (S,b,afil,tc,df,swet2,phi14,nedebasa,W,h,TAS,ISADEV);
    [CDoCL]= CDCL_mod(S,wAR,wTR,swet2,wingSwet,wSweepLE, ...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
    sin_gamma=(ToW-CDoCL)/(1+facCAS);
    
else
   
    [M]=CAS2MACH(CAS,PR);
	 [~,facMach]=acelfac(M,h,ISADEV);
    TAS=M*a;
    [CDoCL]= CDCL_mod(S,wAR,wTR,swet2,wingSwet,wSweepLE, ...
    W,h,TAS,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0);
    sin_gamma=(ToW-CDoCL)/(1+facMach);
end

RC=(TAS*sin_gamma)*kt2fpm;



