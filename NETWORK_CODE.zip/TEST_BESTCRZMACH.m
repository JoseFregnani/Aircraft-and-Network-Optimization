
%LOAD ACFT
X1=rand(1);
X2=rand(1);
X3=rand(1);          
[ACFT,~,~,~,~,~,~,~,~]=LOADDATABANK2b(X1,X2,X3,1);
% LOAD NEURAL NETWORK
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');
        
% TEST DATA
ALT=35000;
ISADEV=10;
W=ACFT.MTOW-1000;

clc
CRZMACH=BESTCRZSPEED(ACFT,W,ALT,ISADEV,NNind,NNwav,NNcd0,NNCL)
