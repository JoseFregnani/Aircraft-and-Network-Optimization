function GW=INVCLB(A,NNind,NNwav,NNcd0,NNCL,ISADEV,elev)

lb2kg=0.4535;
ne=0.8;
cfe= 0.0030;

% CALCULATIONS
h    =elev;
T0_kg=A.MAXRATE*lb2kg;
[~, ~, sigma, ~] = atmos(h,ISADEV);
T=T0_kg*sigma^ne;
MTOW=A.MTOW;
n=A.n;
%
flag=0;
while flag==0
    TW_2seg_req=check_CLBLIM(A,NNind,NNwav,NNcd0,NNCL,cfe,ISADEV,elev);
    ToW        =n*T/MTOW;
    if ToW<TW_2seg_req
        MTOW=MTOW-10;
    else    
        flag=1;
    end    
end
 
GW=MTOW;