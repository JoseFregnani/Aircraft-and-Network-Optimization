function [finalalt,RCRES]=MAXALT(S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
    n,maneted,ebypass,ediam,efanpr,eopr,eTIT,W,initalt,step,finalalt,...
    CLBCAS,CLBMACH,ISADEV,RCMIN,CLMAX,BUFFMARGIN,NNind,NNwav,NNcd0,NNCL)

% CONSTANTS
kg2lb  = 2.2046;
m2feet = 3.28083;
g      = 9.8067;

[TA]=transitionalt(CLBMACH,CLBCAS,ISADEV);
t=0;
d=0;
fuel=0;
RC=9999;


% CLIMB TO 10000ft with 250KCAS

hi=initalt+1500;
h=hi;
hf=10000;
%deltafuel=0;

while and(RC>RCMIN, h<hf)
    CAS = 250;  
    %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/m2feet;
    [~, PR, ~, ~] = atmos(h,ISADEV);
    [M]=CAS2MACH(CAS,PR);    
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    ToW=n*Fn/W;
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
   % [RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,250,M,h,ISADEV);
    
    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
%     plot(h,TAS,'r')
%     hold on
%     plot(h,CAS,'b')
%     hold on

end
%
deltaalt=0;
hi = 10000+deltaalt;
h  = hi;
hf = TA;
% CLIMB TO TA at CONSTANT CAS

while and(RC>RCMIN, h<=hf)

     %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/m2feet;
    [~, PR, ~, a] = atmos(h,ISADEV);
    [M]=CAS2MACH(CLBCAS,PR);   
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    ToW=n*Fn/W;
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CLBCAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
    %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,CLBCAS,0,h,ISADEV);
    
    % INTEGRATION STEP
    deltat    = step/RC;
    t         = t+deltat;
    d         = d+(TAS/60)*deltat;
    deltafuel =(FF/60)*deltat;
    fuel      = fuel+deltafuel;
    W         = W-deltafuel;
    h         = h+step;
%    plot(h,TAS,'r')
%    hold on
%    plot(h,CAS,'b')
%    hold on
end
%
% CLIMB TO TA at CONSTANT MACH
hf=finalalt;
BUFFALT=999999;
M=CLBMACH;
%
while and(RC>RCMIN, h<=hf)

    %[Fn,FF]=thrust(maneted,T0,h,ISADEV,M);
    altm=h/3.28083;
    [~, PR, ~, ~] = atmos(h,ISADEV);
    [CAS]=MACH2CAS(M,PR);
    [Fn,FF] = engine_main(altm,M,efanpr,eopr,ebypass,maneted,ediam,eTIT);
    Fn=Fn/g;
    ToW=n*Fn/W;
    %[facCAS,facMach]=acelfac(M,h,ISADEV);
    %[RC,TAS]=climb(ToW,S,b,afil,tc,df,swet2,phi14,nedebasa,W,0,M,h,ISADEV);
    [RC,TAS]=climb(ToW,S,wAR,wTR,swet2,wingSwet,wSweepLE,...
    W,CAS,M,h,ISADEV,inc_root,inc_kink,inc_tip,Kink_semispan,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
    [BUFFALT]= BUFFET(h,W,S,TAS,M,ISADEV,CLMAX,BUFFMARGIN);
    
    % INTEGRATION STEP
    deltat=step/RC;
    t=t+deltat;
    d=d+(TAS/60)*deltat;
    deltafuel=(FF/60)*deltat;
    fuel=fuel+deltafuel;
    W=W-deltafuel;
    h=h+step;
%    plot(h,TAS,'r')
%    hold on
%    plot(h,CLBCAS,'b')
%    hold on
end

finalalt=h-100;

if BUFFALT<finalalt
    finalalt=BUFFALT;
end    
RCRES=RC;




