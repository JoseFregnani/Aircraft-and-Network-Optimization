%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - NETWORK MODULE SHORT
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 3.1 / January 2018 - Network optimiztion with 3 aircraft
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
close all

% LOAD AIRCRAFT

calctype=2;% 1:RANDOM SAMPLE  2:KNOWN SAMPLE

switch calctype
    case 1
        X1=rand(1);
        X2=rand(1);
        X3=rand(1);
    case 2 % GIVEN POSITION ON TABLES
        n1=63
        n2=14
        n3=10
end

mode=1;% acft seletiom method: PAX:mode=1, RANGE:mode=2
if calctype==1
    [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3,n1,n2,n3]=LOADDATABANK2(X1,X2,X3,mode);
else
    [ACFT1,ACFT2,ACFT3,LIM1,LIM2,LIM3]=LOADDATABANK3(n1,n2,n3,mode);
end    

RANGE1=ACFT1.RANGE;
RANGE2=ACFT2.RANGE;
RANGE3=ACFT3.RANGE;
NPax1 =round(ACFT1.NPax);
NPax2 =round(ACFT2.NPax);
NPax3 =round(ACFT3.NPax);
MTOW1 =round(ACFT1.MTOW);
MTOW2 =round(ACFT2.MTOW);
MTOW3 =round(ACFT3.MTOW);
wS1 =ACFT1.wS;
wS2 =ACFT2.wS;
wS3 =ACFT3.wS;
wAR1 =ACFT1.wAR;
wAR2 =ACFT2.wAR;
wAR3 =ACFT3.wAR;
ebypass1 =ACFT1.ebypass;
ebypass2 =ACFT2.ebypass;
ebypass3 =ACFT3.ebypass;
ediam1 =ACFT1.ediam;
ediam2 =ACFT2.ediam;
ediam3 =ACFT3.ediam;

% AIRLINE OPS PARAMETERS
ISADEV=10;
PAXWT=110;
MAXUTIL=12;
TURNAROUND=45;
AVGTIT=5;
AVGTOT=10;
ID=30;
TO_ALLOWANCE=200;
ARR_ALLOWANCE=100;
avg_ticket=200;
SHARE=0.20;
LFREF=0.80;
DISTALT=200; 

tic
% REFERENCE DOC CALCULATION
fprintf('\n ** REFERENCE VALUES FOR NETWORK DESIGN **');
fprintf('\n'); 
%
PAYLOAD1=NPax1*PAXWT*LFREF;
PAYLOAD2=NPax2*PAXWT*LFREF;
PAYLOAD3=NPax3*PAXWT*LFREF;
[~,~,DOC1]=Mission5e(0,0,0,0,0,RANGE1,DISTALT,ISADEV,PAYLOAD1,NPax1,ACFT1,0,15);  
[~,~,DOC2]=Mission5e(0,0,0,0,0,RANGE2,DISTALT,ISADEV,PAYLOAD2,NPax2,ACFT2,0,15);
[~,~,DOC3]=Mission5e(0,0,0,0,0,RANGE3,DISTALT,ISADEV,PAYLOAD2,NPax3,ACFT3,0,15);
%
fprintf('\n RANGE1 (nm)              : %5.0f',RANGE1);
fprintf('\n RANGE2 (nm)              : %5.0f',RANGE2);
fprintf('\n RANGE3 (nm)              : %5.0f',RANGE3);
fprintf('\n DOC1   ($/nm)            : %5.2f',DOC1);
fprintf('\n DOC2   ($/nm)            : %5.2f',DOC2);
fprintf('\n DOC3   ($/nm)            : %5.2f',DOC3);
fprintf('\n PAX1                     : %5.0f',NPax1);
fprintf('\n PAX2                     : %5.0f',NPax2);
fprintf('\n PAX3                     : %5.0f',NPax3);
fprintf('\n ALTERNATE DIST (nm)      : %5.0f',DISTALT);
fprintf('\n Average fare ($)         : %5.0f',avg_ticket);
fprintf('\n Average Load Factor (pct): %5.1f',LFREF*100);
fprintf('\n Average Market Share(pct): %5.1f',SHARE*100);
fprintf('\n'); 

% Network Optimiztion
VPAX=[NPax1 NPax2 NPax3]';
VDOC=[DOC1 DOC2 DOC3]'; 
VRANGE=[RANGE1 RANGE2 RANGE3]';
[Airport,X,FREQ,f,LF,DIST,HDG]=NETWORKOPT_R04e(VPAX,VDOC,VRANGE,SHARE,LFREF,avg_ticket);
n=size(X,2);
%
f
X
FREQ
DIST
HDG

