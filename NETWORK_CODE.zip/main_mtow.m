clc
clear all
%**************************************************************************
%                         Neural Networks 
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');
%
%**************************************************************************
% Atente para estas informacoes necessarias!!!!!!
posxmunhao=3.89;
xcgtanques=4.0789;
CLALFA_rad=4.5;
CD0_Wing = 0.060;
K_IND = 0.0043545;
%
wingfuelcapacity   = 5000;
fus_width          = 3.01;
fus_height         = 3.35;
AirplaneCLmaxClean = 1.6;
% *******  Exemplo de dados de entrada *************
%
N2lbf   = 1/4.448221615;
kg2lb   = 2.2046;
ft2m    = 0.3048;
rad     = pi/180;
cfe     = 0.0030; % 
%matlabpool local 2
datasimulacao=date;
fprintf('\n')
fprintf('****** \n Aviao Aeronautico AER2016R3 ****** \n')
fprintf('\n ++++ %s ++++ \n',datasimulacao)
fprintf('\n')
%
Takeofffl          = 1612; % [m]
Landfl             = 1259; % [m]
wSweep14           = 23;
wS                 = 75;
wTR                = 0.3;
wAR                = 8.6;
wTwist             = -4;
Kink_semispan      = 0.37;
diedro             = 3;
dflecflaptakeoff   = 35; % Deflexao do flape de decolagem [graus]
dflecflapland      = 45;  % Deflexao de flape no pouso [graus]
bflap              = 0.75;
PWing              = 1;
%
VTArea             = 16.2; % [m2]
VTAR               = 1;
VTTR               = 0.540;
VTSweep            = 41;
%
HTArea             = 23.35; % [m2]
HTAR               = 4.35;
HTTR               = 0.40;
PHT                = 1;
% Winglet data
wlet_present       = 1; % =1 if present in the configuration
SweepLE_winglet    = 35;
AR_winglet         = 2.75;
TR_winglet         = 0.25;
CantAngle_wlet     = 75;
%
VHT                = 0.95;
VVT                = 0.12;
%
margin_static      = 0.15;
htac_rel           = 0.25;
vtac_rel           = 0.25;
%
ncrew              = 4;
%
Engine_data(1)     = 1;  % Configuration
PEng               = Engine_data(1);
Engine_data(2)     = 5.0; % by-pass ratio
Engine_data(3)     = 1.23; % Engine fan diameter
Engine_data(4)     = 1.4; % Fan pressure ratio
Engine_data(5)     = 28; % Overall pressure ratio
Engine_data(6)     = 1450; % Turbine inlet Temperature [K]
%
TLOIT              = 45; % Loiter [min]
DIST_ALT           = 100; % Range fo alternate airport [nm]
Range              = 1450; % Range with maximum payload (nm)
CruiseMach         = 0.82;
Ceiling            = 41000;
container_type     ='None';
NCorr              = 1;
NSeat              = 4;
NPax               = 88;
CabHeightm         = 2;
SEATwid            = 0.46;
AisleWidth         = 0.50;
widthreiratio      = fus_height/fus_width;
%
MTOWi              = 37500;
Payload            = NPax*100;
%
inc_root           = 2;
inc_kink           = 0.3;
inc_tip            = inc_root + wTwist;
%
slat               = 1;
longtras           = 0.72; % Fracao da corda onde encontra-se a longarina traseira
if PWing ==2 || PEng == 2
    PHT =2;
end
% find Sobiescki coefficientes for basic airfoils
[r0, t_c, phi, X_tcmax, theta, epsilon, ...
    Ycmax, YCtcmax, X_Ycmax]=airfoilcoeff();
%
wTCmed = (t_c(1)+t_c(2)+t_c(3))/3; % Wing average relative maximum thickness
%
FusDiam             = sqrt(fus_width*fus_height);
%
[Airp_SWET, wingSwet,FusSwet_m2,lf ,lco, ltail , EnginLength_m,wYMAC ,wMAC, wSweepLE, ~ ,...
    ht,vt,...
    Ccentro,Craiz,Cquebra, Cponta, ...
    xutip, yutip, xltip, yltip,...
    xukink,yukink,xlkink,ylkink, xuroot,yuroot,xlroot,ylroot,pylon]...
    = wettedarea(Ceiling,...
    CruiseMach,FusDiam,...
    NPax,NCorr,NSeat,SEATwid,AisleWidth,...
    Kink_semispan,wS,wAR,wTR,wSweep14,wTwist,...
    PWing,Engine_data,VTArea,VTAR,VTTR,VTSweep,HTArea,HTAR,HTTR,PHT,htac_rel);
%
FusDiam             = sqrt(fus_width*fus_height);
nukink              = size(xukink,2);
wingb               = sqrt(wAR*wS);
htb                 = sqrt(HTAR*HTArea);
planffusdf          = fus_width;
wingcrank           = Kink_semispan; 
wingsweepLE         = wSweepLE;
%
MMO  = CruiseMach;
YEIS = 2016;
xle  = 0.45*lf;
lcab = lf-(ltail+lco);
fuel = 0.25*MTOWi;
EngineDe_m = Engine_data(3)*1.1;
BPR        = Engine_data(2);
ediam      = Engine_data(3); % Fan diameter [m]
efanpr     = Engine_data(4); % Fan pressure ratio
eopr       = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT       = Engine_data(6); % Turbine Inlet Temperature [K]
[T0_N,~]    = engine_main(0,0,efanpr,eopr,BPR,1,ediam,eTIT);
% Divergence Mach Number
% Divergence Mach Number
Mach  = 0.69;
k     = 0;
CL1   = 0.45;
MMAX  = 0.85;
while Mach <= MMAX
k = k + 1;
Mach = Mach + 0.01;
MBUFFER(k)=Mach;
%
[CDwing]  = CDCLneural(Mach,Ceiling*ft2m,CL1,wS,wAR,wTR,wSweepLE,...
   inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL);
[CD0_ubrige] = cfe*(Airp_SWET-wingSwet)/wS;
CDT(k)       = CDwing + CD0_ubrige;
end
%
plot(MBUFFER,CDT,'-b')
MDESIRED=min(MMO,MMAX);
[BMAC, Indice]=sort(abs(MBUFFER-MDESIRED),'ascend');
CDmin=CDT(1);
%machesco=MBUFFER(Indice(1))
CDmax=CDT(Indice(1));
DeltaCD=CDmax-CDmin;
%
[weighttotal, weightcomp]=WeightAirplane(NPax,Range,MTOWi,fuel,Ceiling,...
    wTCmed,MMO,T0_N,EnginLength_m,EngineDe_m,BPR,...
    Engine_data(1),PWing,...
    YEIS,xle,slat,wMAC,wYMAC,wTR,wS,wAR,wSweepLE,wSweep14,PHT,ht,vt,...
    fus_width, fus_height,FusSwet_m2,lf,lcab,ltail,wingfuelcapacity);
%
switch slat
 case 1
 AirplaneCLmaxTakeo = AirplaneCLmaxClean + 0.60;
 AirplaneCLmaxLandi = AirplaneCLmaxClean + 1.20;
 otherwise
 AirplaneCLmaxTakeo = AirplaneCLmaxClean + 0.40;
 AirplaneCLmaxLandi = AirplaneCLmaxClean + 1.00;
end
%
pneum_p          = 200; % (psi) MLG tyre pressure upper boundary
pneun_p          = 190; % (psi) NLG tyre pressure upper boundary
tcroot           = t_c(1);
X_TP1            = lco - 0.40;
%
MTOW              = MTOWi;
mtowdif           = 1e06;
iplot             = 1;
mtowplot          = MTOW;
iter              = 1;
%
mtowcount         = 0;
%
while mtowdif > 10 && mtowcount < 25
%
[MTOWcalc, OEW, W_climb_final, Airp_SWET,...
    TOTFUEL, TOTFUEL_ALT, TOTTIME,htout,vtout,xleout,xcg_fwd,xcg_aft]=...
    MTOW_calc(MTOW,...
    AirplaneCLmaxClean,wTCmed,wSweepLE,wSweep14,wS,wTR,wAR,wMAC,wYMAC,...
    inc_root,inc_kink,inc_tip,Kink_semispan,longtras,posxmunhao,...
    xcgtanques,NSeat,wingfuelcapacity,...
    r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,Ccentro,Craiz,Cponta,margin_static,...
    Range,Engine_data,CruiseMach,Ceiling,Airp_SWET,wingSwet,Payload,ncrew,...
    TLOIT,DIST_ALT,NNind,NNwav,NNcd0,NNCL,PHT,ht,...
    EnginLength_m,EngineDe_m,pylon,...
    CLALFA_rad,wingfuelcapacity,PWing,vt,vtac_rel,htac_rel,...
    YEIS,xle,slat,fus_width,fus_height,FusSwet_m2,lf,lcab,ltail,VHT,VVT);
%
xle = xleout;
ht  = htout;
vt  = vtout;
mtowdif        = abs(MTOWcalc-MTOW);
MTOW           = 0.20*MTOW+0.80*MTOWcalc;
% iter           = iter + 1;
% iplot          = [iplot iter];
% mtowplot       = [mtowplot MTOW];
fprintf('\n');
fprintf('\n **** MTOW = %6.0f kg **** ',MTOW)
fprintf('\n **** OEW  = %6.0f kg **** \n',OEW)
mtowcount        = mtowcount +1;
fprintf('\n');
%
end
%
if mtowcount >= 25
    fprintf('\n MTOW calculation not converged \n')
flag_req  = 1;
DOCcalc   = 100;
deltafuel = -10000;
TOnoise   = 400;
else
hfigura=figure(14);
hcg =-0.80;
[D0m_max, D0n_max,wm_max, wn_max,ds_m,ds_n, Lpist_m,Lpist_n]= ...
plotairplane3d(xcg_fwd,xcg_aft,hcg,MTOW,...
   0.90*MTOW,AirplaneCLmaxTakeo, AirplaneCLmaxLandi,lf,lco,ltail,...
   fus_width,Ccentro,Craiz,Cquebra,Cponta,wS,wTR,...
   xle,wSweepLE,wingb/2,diedro,PEng,EngineDe_m,EnginLength_m,Kink_semispan, ...
   vt.ct,vt.c0,VTAR,vt.sweepLE,ht.ct,ht.c0,HTAR,ht.sweepLE,PHT,...
   PWing,pneum_p,pneun_p,tcroot,inc_root,inc_kink,inc_tip,SweepLE_winglet,AR_winglet,...
         TR_winglet,CantAngle_wlet,wlet_present,longtras,...
         bflap,X_TP1);
view(45,45);
%savefig(hfigura,'airplane3D.fig')
%print -djpeg -f14 -r300 'airplane3D.jpg'
close(figure(14))
%
% ******************** Calculo do ruido externo **********************************
dcdflapland      = CD_flap(dflecflapland,longtras);
CD0_ubrige       = cfe*(Airp_SWET-wingSwet)/wS;
[CD_main, CD_nose]=CD_LGear(D0m_max,D0n_max,wm_max,wn_max,...
Lpist_m,Lpist_n,ds_m,ds_n,2,2,2,wS);
dcdlandinggear   = CD_main + CD_nose;
CD0_Land         = CD0_Wing + CD0_ubrige  + dcdflapland + dcdlandinggear;
NEng             = max(2,PEng);
[TOnoise, SLnoise, LDnoise]=Noise_Calculation(0,0,MTOW,0.90*MTOW,...
    NEng,wS,wingb,ht.S,vt.b,vt.S,vt.b,AirplaneCLmaxLandi,AirplaneCLmaxTakeo,...
	K_IND,CD0_Land,BPR,ediam,efanpr,eopr,D0m_max, D0n_max);
% ***************** Fim Calculo de Ruido Externo ***************************
%
deltafuel = wingfuelcapacity - 1.05*TOTFUEL_ALT;
%
if deltafuel < 0
fprintf('\n fuel accommodation deficit: %f kg \n',abs(deltafuel))
else
fprintf('\n fuel accommodation surplus: %f kg \n',deltafuel)
end
%
n=max(2,Engine_data(1));
%
BPR        = Engine_data(2);
ediam      = Engine_data(3); % Fan diameter [m]
efanpr     = Engine_data(4); % Fan pressure ratio
eopr       = Engine_data(5); % Overall pressure ratio = compressor x fan   
eTIT       = Engine_data(6); % Turbine Inlet Temperature [K]
[Fn,FF]    = engine_main(0,0,efanpr,eopr,BPR,1,ediam,eTIT);
T0         = Fn*N2lbf; % [lbf]
%
weight_engine_kg=(0.084*(T0)^1.1*expm(-0.045*BPR))/kg2lb; % [kg]
DOCcalc = DOC (TOTTIME, TOTFUEL,OEW,Range,...
    T0,n,weight_engine_kg,MTOW);
% ***** Check design requirements *****
%  2nd segment climb
ToW     =  (n*T0)/(MTOW*kg2lb);
% 2nd segment
TW_2seg_req=check_2ndseg(wS,wAR,wTR,wSweepLE,...
inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,...
n,Airp_SWET,wingSwet,longtras,AirplaneCLmaxTakeo,MTOW,vt.S,vt.sweep,ediam,BPR,...
NNind,NNwav,NNcd0,NNCL,cfe,dflecflaptakeoff)
%
flag2seg = 0;
  if TW_2seg_req > ToW
  flag2seg = 1;
  end
%
% ROC at service ceiling
TW_ROC_req=check_ROC(wS,wAR,wTR,W_climb_final,CruiseMach,Engine_data,wTCmed,...
    wSweep14,Airp_SWET,Ceiling,T0,MTOW,FusDiam)
%
flagROC = 0;
  if TW_ROC_req > ToW
  flagROC = 1;
  end


% Takeoff
TW_takeoff_req=check_takeoff(AirplaneCLmaxTakeo,Takeofffl,MTOW,wS)
%
flagTakeoff = 0;
  if TW_takeoff_req > ToW
  flagTakeoff = 1;
  end
%
TWreq_crz=check_CRZ(Ceiling,CruiseMach,MTOW,W_climb_final,wS,wAR,wTR,...
    wSweepLE,Airp_SWET,wingSwet,Engine_data,T0,inc_root,inc_kink,inc_tip,...
    Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
    Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,cfe)
%
flagCRZ = 0;
  if TWreq_crz > ToW
  flagCRZ = 1;
  end
% Wing loading for landing requirements
MLW       = MTOW - TOTFUEL;
massratio = MLW/MTOW
wland     = (Landfl*.119*AirplaneCLmaxLandi)/massratio
%
WS        = MTOW/wS
flagLand  = 0;
  if wland < WS
  flagLand = 1
  end
%
%flag_req=[flag2seg, flagROC, flagTakeoff, flagCRZ, flagLand];
flag_req=[flag2seg, flagTakeoff, flagCRZ];
flag_req=max(flag_req)
end
%


clear NNind NNCL NNwav NNcd0
clear SWET wingSwet W_climb_fina vt ht pylon
clear wS wAR wTR wSweepLE FusDiam BPR AirplaneCLmaxTakeo AirplaneCLmaxLandi