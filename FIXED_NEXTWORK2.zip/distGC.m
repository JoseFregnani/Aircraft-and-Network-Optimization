function [DIST,HDG]=distGC(Airport);

n=length(Airport);
E=referenceEllipsoid(7030);
for i=1:n
  for j=1:n
   if i==j
     arclen=0;
     az=0;
     dmgavg=0;
   else  
     lat1=Airport(i).lat;
     lat2=Airport(j).lat;
     lon1=Airport(i).lon;
     lon2=Airport(j).lon;
     dmg1=Airport(i).dmg;
     dmg2=Airport(j).dmg;
     dmgavg=(dmg1+dmg2)/2;
     [arclen,az]=distance(lat1,lat2,lon1,lon2,E);
     arclen=arclen/1852;
   end
   DIST(i,j)=arclen;
   HDG(i,j)=az+dmgavg;
  end
end
