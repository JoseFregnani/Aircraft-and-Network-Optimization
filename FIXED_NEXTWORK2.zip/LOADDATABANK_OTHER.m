function [A]=LOADDATABANK_OTHER()

% aircraft data
        OEW     =22020
        MTOW    =37850
        MLW     =33470
        MZFW    =32801
        MAXFUEL =7464
        RANGE   =1600
        MMO     =0.82
        VMO     =340
        Ceiling =41000
        PAX     =92
        Crew    =5
        NCorr   =1
        NSeat   =4
        NSeat   =0.46
        Pitch   =32
        NAisle  =1
        CabHt   =2
        lf      =32.94
        lco     =3.7
        fuswr   =1.0959
        fusw    =3.44
        fusd    =3.6
        fush    =3.77
        fusdz   =0
        fuswetS =0
        CLMAX   =1.57
        CLMAXTO =2.37
        CLMAXLD =2.17
        wS      =83.05
        wAR     =8.22
        wTR     =0.42
        b       =26.128
        wSweep14=23.4
        wSweepLE=25.73
        wTwist  =-4.33
        wingSwet=144.11
        kinkpos =0.37
        incroot=2
        inckink=0
        inctip =-2.33
        tcroot =0
        tckink =0
        tctip  =0
        chordc =5.86
        chordr =4.99
        chordk =3.5
        chordt =1.89
        CMA    =3.52
        xle    =0
        slat   =0
        bflap  =0
        sflap  =0
        flapTO =0
        flapLD =0
        ailpos =0
        rsparps =0.75
        VT_S    =16.2
        VT_AR   =1.2
        VT_TR   =0.5
        VT_sweep=41
        HT_S    =23.35
        HT_AR   =4.35
        HT_TR   =0.4
        HT_sweep=42
        WL_AR   =0

        WL_sweep=0
        WL_cantl=0

        MAXRATE =14489
        BPR     =6
        DFAN    =1.29
        FPR     =1.6
        OPR     =29.04
        ITT     =1406
        englen =0

        pylondz=0
        engswet=0
        TOTSWET=546.16
        POSENG =1
        POSHT  =1
        POSWING=1

        A.OEW           =OEW;
        A.MTOW          =MTOW;
        A.MLW           =MLW;
        A.MZFW          =MZFW;
        A.MAXFUEL       =MAXFUEL;
        A.ceiling       =Ceiling;        %
        A.wS            =wS;
        A.wSft2         =A.wS*3.28^2;
        A.wAR           =wAR;
        A.wTR           =wTR;
        A.wSweep14      =wSweep14;
        A.wTwist        =wTwist;
        A.Kink_semispan =kinkpos;        
        A.CLMAX         =CLMAX;
        A.CLMAX_TO      =CLMAXTO;
        A.CLMAX_LD      =CLMAXLD;
        A.Flap_def_take =15;
        A.Flap_def_land =35;
        A.PWing         =1;
        %
        A.inc_root      =incroot; 
        A.inc_kink      =inckink; 
        A.inc_tip       =inctip; 
        A.wMAC          =CMA;
        A.wSweepLE      =wSweepLE;
        %
        A.VTarea        =VT_S;
        A.VTAR          =VT_AR;
        A.VTTR          =VT_TR;
        A.VTSweep       =VT_sweep;
        A.HTarea        =HT_S;
        A.HTAR          =HT_AR;
        A.HTTR          =HT_TR;
        A.PHT           =1;
        %
        A.container_type='LD2';
        A.NPax          =PAX;
        A.NCorr         =NCorr;
        A.NSeat         =NSeat;
        A.ncrew         =Crew;
        A.AisleWidth    =0.5;
        A.CabHeightm    =CabHt;    
        A.SEATwid       =NSeat; 
        A.widthratio    =fuswr; 
        A.fus_width     =fusw;
        A.fus_height    =fush;
        A.FusDiam       =fusd;
        %
        A.MMO           =MMO; 
        A.VMO           =VMO; 
        %
        A.PEng          =1; 
        A.MAXRATE       =MAXRATE;  
        A.T0            =A.MAXRATE*0.95;
        A.n             =2;  
        A.nedebasa      =2; 
        
        A.ebypass       =BPR;
        A.ediam         =DFAN;
        A.efanpr        =FPR;
        A.eopr          =OPR;
        A.eTIT          =ITT;
        %
        A.Airp_SWET     =0;
        A.wingSwet      =0;
        A.lf            =lf;
        A.lco           =lco;
        A.swet2         =0;
        A.RANGE         =RANGE;       
        A.longtras      =0.75;
        %
        A.r0            =[0.0153 0.0150 0.0150];
        A.t_c           =[0.1228 0.1055 0.0982];
        A.phi           =[-0.0799 -0.1025 -0.1553];
        A.X_tcmax       =[0.3738 0.3585 0.3590];
        A.theta         =[0.0787 -0.0295 0.1000];
        A.epsilon       =[-0.0549 -0.2101 -0.0258];
        A.Ycmax         =[-4.0000e-04 0.0185 0.0104];
        A.YCtcmax       =[-6.0000e-04 0.0028 0.0109];
        A.X_Ycmax       =[0.6188 0.7870 0.5567]
        A.wTCmed        =0.1100;               
        %
        A.Ccentro       =6.4800;
        A.Craiz         =5.6100;
        A.Cquebra       =3.8800;
        A.Cponta        =1.4600;
        A.xutip         =zeros(1,51);
        A.yutip         =zeros(1,51);
        A.xltip         =zeros(1,51);
        A.yltip         =zeros(1,51);
        A.xukink        =zeros(1,51);
        A.yukink        =zeros(1,51);
        A.xlkink        =zeros(1,51);
        A.ylkink        =zeros(1,51);
        A.xuroot        =zeros(1,51);
        A.yuroot        =zeros(1,51);
        A.xlroot        =zeros(1,51);
        A.ylroot        =zeros(1,51);
       
     
    
        
 