%% Descri��o da fun��o
%  Projeto do trem de pouso


%% Declara��o da fun��o
function [A_min, nt_m,D0m_max, wm_max, Lpist_m, ds_m, Lpist_n, ds_n, wn_max, D0n_max]=LGDesign2(...
    df,xcg_dianteiro,xcg_traseiro,zcg_dianteiro,MTOW,MLW,X_TP1,X_TP2,CLmax_to,CLmax_land,...
    warea,lf,pneum_p,pneun_p,diam_n,pist_n)


%% Variaveis globais
% df                                                  % diametro da fuselagem
% global X_TP1                                                                % Coordenada x do trem de pouso dianteiro [m]
% global X_TP2                                                                % Coordenada x do trem de pouso principal [m]
% global g                                                                    % Acelera��o da gravidade [m/s2]
% global wing                                                                 % Par�metros da asa
% global var                                                                  % Vari�veis de entrada
% global fuselage                                                             % Par�metros da fuselagem
% global landinggear                                                          % Par�metros do trem-de-pouso
% global wingref
% Constantes
g =9.81; % aceleracao da gravidade
%
%fprintf('\n => Starting LG design ... \n')
% Renomeacao de variaveis
var.MTOW = MTOW;
var.MLW=MLW;
wing.CLmax_to=CLmax_to;
wing.CLmax_land=CLmax_land;
var.S=warea;
fuselage.length=lf;
%% Fatores de convers�o
%
in2m                = 0.0254;                                               % [in] para [m]
rad2deg             = 180/pi;                                               % [rad] para [deg]
kgf2lbf             = 2.204622622;                                          % [kgf] para [lbf]
ms2mph              = 2.236936292;                                          % [m/s] para [mph] 
ft2m                = 0.3048;                                               % [ft] para [m]
%% C�LCULOS
ns                  = 2;                                                    % N�mero de struts do trem de pouso principal
nt_m                = 2;                                                    % N�mero de pneus por strut do trem principal
nt_n                = 2;                                                    % N�mero de pneus por strut do trem secundario
psi_m               = pneum_p;                                              % Pressao maxima do pneu do TDP principal
psi_n               = pneun_p;                                              % Pressao maxima do pneu do TDP do nariz
% DIMENS�ES PRIM�RIAS
ln                  = xcg_dianteiro-X_TP1;                                  % Dist�ncia do tdp dianteiro ao CG [m]
lm                  = X_TP2-xcg_dianteiro;                                  % Dist�ncia do tdp principal ao CG [m]
hcg                 = zcg_dianteiro;                                        % Altura do CG [m]
M                   = X_TP2-xcg_traseiro;
F                   = X_TP2-X_TP1;
L                   = xcg_dianteiro - X_TP1;
%
Fator               = 1.07;                                                % Fator de ajuste 14CFR25
% wt                  = 3.658;                                             % Raz�o de descida [m/s]
%% CARGAS
% Cargas est�ticas
OEW                 = 0.50*var.MTOW;

%Pn_max              = OEW*(X_TP2-xcg_dianteiro)/F;                         % Carga m�xima no tdp dianteiro [kgf]
fatrespdyn          = 2;
mi                  = 0.80; % coef de fric��o
J                   = hcg + df/2 + pist_n + diam_n/2;
fatdyn              = fatrespdyn*mi*L*J/(F+mi*J);
Pn_max              = OEW*((F-L)  + fatdyn)/F; 
%Pm_max              = OEW*(xcg_traseiro-X_TP1)/F;                          % Carga maxima no trem principal [kgf]
Pm_max              = OEW*(F-M)/F; 
LoadMax             = Fator*(Pm_max*kgf2lbf)/(ns*nt_m);                    % Carga maxima por pneu no trem principal [lbf]
if LoadMax > 59500                                                         % Verifica carga m�xima por pneu e acerta n�mero de pneus
    nt_m_req        = ceil(LoadMax/59500);                                 % Define n�mero de pneus requerido
    nwtest          = mod(nt_m_req,ns);                                    % Verifica se n�mero requerido de pneus � multiplo de 4
    if nwtest ~= 0.
       disp('passei por aqui como?')
        nt_m        = (nwtest+1)*2;                                        % Define n�mero de pneus como um n�mero par
    end
end
%fprintf('\n MLG: Tyre number per strut %2i \n',nt_m)

% Cargas din�micas
axg                 = 0.45;
Pn_dyn              = var.MTOW*((lm+axg*hcg)/(lm+ln+axg*hcg));             % Carga no tdp dianteiro [kgf]
% Carga por pneu
TL_m_static         = LoadMax/kgf2lbf;                                     % Carga est�tica por pneu no tdp principal [kgf]
TL_n_static         = Pn_max/nt_n*Fator;                                   % Carga est�tica por pneu no tdp dianteiro [kgf]
TL_n_dyn            = 0;                                                   % Carga din�mica por pneu no tdp dianteiro [kgf]
% 
v_tfo               = 1.1*sqrt(2*var.MTOW*g/(1.225*wing.CLmax_to*var.S));  % Velocidade m�xima de lift-off [m/s]
v_land              = 1.2*sqrt(2*MLW*g/(1.225*wing.CLmax_land*var.S));     % Velocidade m�xima de toque no pouso [m/s]
v_qualified         = max(v_tfo,v_land);                                   % Velocidade usada para dimensionamento dos pneus [m/s]
%% PNEUS
vqualmph            = v_qualified*ms2mph;
% Pneu tdp principal
loadM               = TL_m_static*kgf2lbf;
%fprintf('\n Tyre sizing for main landing gear ... ')
[TDia, TWid, ~]     = tyreselection(loadM,vqualmph,psi_m,'weight');
fprintf('\n Done! \n ')
D0m_max             = TDia;                                                 % Di�metro m�ximo pneu tdp principal [m]
%fprintf('\n MLF tyre diameter: %5.2f m \n', D0m_max)
D0m_min             = 0.96*TDia;                                            % Di�metro m�nimo pneu tdp principal [m]
wm_max              = TWid;                                                 % Largura m�xima pneu tdp principal [m]
mstatic_load        = 0.4*TDia;                                             % Raio do pneu, carregado [m]
st_m                = (0.25*(D0m_max+D0m_min)-(mstatic_load));              % Deflex�o permitida do pneu [m]
% Pneu tdp dianteiro (Tipo VII)
loadN               = max([TL_n_static TL_n_dyn])*kgf2lbf;
%fprintf('\n Tyre sizing for nose landing gear ... ')
[TDia, TWid, ~]     = tyreselection(loadN,vqualmph,psi_n,'size');
%fprintf('\n Done! \n ')
D0n_max             = TDia;                                                 % Di�metro m�ximo pneu tdp dianteiro [m]
D0n_min             = 0.96*TDia;                                            % Di�metro m�nimo pneu tdp dianteiro [m]
wn_max              = TWid;                                                 % Largura m�xima pneu tdp dianteiro [m]
nstatic_load        = 0.4*TDia;                                             % Raio do pneu, carregado [m]
st_n                = ((D0n_max+D0n_min)/2/2-(nstatic_load))*in2m;          % Deflex�o permitida do pneu [m]
%% SHOCK ABSORBERS (STRUTS)  - Mason
ni_t                = 0.47;                                                 % Efici�ncia para absor��o de energia, pneu
ni_s                = 0.8;                                                  % Efici�ncia para absor��o de energia, shock absorber (considerado como oleo-pneum�tico)
Ng                  = 1.5;                                                  % Fator de carga 14CFR25 [g]

% TDP dianteiro
vsink                = 10*ft2m;
Ss_n                = (0.5*Pn_max/g*vsink^2/(1*(Pn_dyn)*Ng)-ni_t*st_n)/ni_s; % Comprimento, shock absorber, tdp dianteiro [m]
Ss_n                = Ss_n+1/12*in2m;                                       % Comprimento de projeto, shock absorber, tdp dianteiro [m]
ds_n                = (0.041+0.0025*(Pn_dyn/0.4535)^0.5)/3.28;              % Di�metro, shock absorber, tdp dianteiro [m]
Lpist_n              = Ss_n + 2.75*ds_n;                                     % MIL-L-8552 - Minimum piston length
%fprintf('\n Nose landing gear Minimum piston length: %5.2f m \n',Lpist_n)
% - TDP Principal

% Energy calculation
%  At takeoff
vsink                = 6*ft2m;                                              % Velocidade de descida (FAR)
Sst_ma               = (0.50*vsink^2)/(ni_s*Ng*g) - (ni_t*st_m)/ni_s;       % Comprimento, shock absorber, tdp principal [m]
Sst_ma               = Sst_ma+1/12*in2m;                                    % Comprimento de projeto, shock absorber
%  At landing
vsink                = 10*ft2m;
Ssl_ma               = (0.50*vsink^2/(ni_s*Ng*g) - ni_t*st_m)/ni_s;         % Comprimento, shock absorber, tdp principal [m]
Ssl_ma               = Ssl_ma+1/12*in2m;                                    % Comprimento de projeto, shock absorber [m]

Ss_m                 = max(Sst_ma,Ssl_ma);
Pm                   = Pm_max/ns;
ds_m                 = (0.041+0.0025*(Pm/0.4535)^0.5)/3.28;                 % Di�metro, shock absorber, tdp principal [m]
Lpist_m              = Ss_m + 2.75*ds_m;                                    % MIL-L-8552 - Minimum piston length [m]
%fprintf('\n Main landing gear Minimum piston length: %5.2f m \n',Lpist_m)
%% �NGULOS
% A (entre a vertical do tdp principal e o cg)
A_min               = (atan(M/hcg))*rad2deg;                                  % valor para A m�nimo [deg]
A_max               = (atan(lm/hcg))*rad2deg;                                 % valor para A m�ximo [deg]
% Beta (clearance da cauda com o solo)
B                   = atan((hcg-zcg_dianteiro)/(fuselage.length-X_TP2))*rad2deg;         
                                                                            % valor de beta
%% ARRASTO
% �rea frontal
% Smgear              = ns*(nt_m*D0m_max*in2m*wm_max*in2m+Ss_m*ds_m);
% Sngear              = nt_n*D0n_max*in2m*wn_max*in2m+Ss_n*ds_n;         
% % CD b�sico
% CDLGBasic1          = 1.5*(Smgear+Sngear)/var.S;
% CDLGBasic2          = 7e-4*var.MTOW^0.785/var.S;
% CDLGBasic           = max(CDLGBasic1,CDLGBasic2);
% % CL
% CLLAND                = wing.CLmax_land/1.23^2;
% CLTO                  = wing.CLmax_to/1.20^2;
% % Fator de ajuste
% FLGLAND             = (1-0.04*(CLLAND+0.0010*(1.5*var.S/wing.Sail-1)/(Ss_m/wingref.mgc)))^2;
% FLGTO               = (1-0.04*(CLTO+0.0010*(1.5*var.S/wing.Sail-1)/(Ss_m/wingref.mgc)))^2;
% % Coeficiente de arrasto
% dcdland             = FLGLAND*CDLGBasic;
% dcdto               = FLGTO*CDLGBasic;

 %fprintf('\n => LG design finished \n')                                                                          

%% T�rmino da fun��o
end


%% Refer�ncias bibliogr�ficas
% 1 - ROSKAM, J. Airplane Design vol. IV - Layout of landing gear and systems. DARCorp, 2010.
% 2 - TORENBEEK, E. Synthesis of subsonic airplane design. DUP / Kluwer, 1982.