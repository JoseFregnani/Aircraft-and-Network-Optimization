%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Aircraft and Network Optimization - FIXED NETWORK MODULE (1 ACFT)
%
% AUTHOR: Jos� Alexandre Fregnani
%
% VERSION: 1.0 / April 2017
%          1.1 / August 2019
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc
close all
tic

fprintf('** Aircraft and Network Optimization - FIXED NETWORK MODULE **');

% LOAD AIRCRAFT DATA
sel=0;% 0=basic aircraft, 1= aircraft from parameters.dat  
switch sel
    case 0
      [ACFT]=LOADDATABANK_BASIC();
    case 1
      [ACFT]=LOADDATA2();      
end  
%
s0=date;
name1=num2str(ACFT.wS);
name2=num2str(ACFT.wAR);
name3=num2str(ACFT.wTR);
NAME=strcat('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\FIXED_NETWORK\FIXED_NETWORK_',s0,'_',name1,'_',name2,'_',name3,'.txt');
%
LIN=strings(3000,1);
lin=1;
LIN(lin)  =' '; 
LIN(lin+1)='** Aircraft and Network Optimization - FIXED NETWORK MODULE **';
LIN(lin+2)  =' '; 
[LIN]=ACFTLIN(ACFT,LIN,lin+3);
lin=90;
%
OEW=ACFT.OEW;
MTOW=ACFT.MTOW;
MLW=ACFT.MLW;
MZFW=ACFT.MZFW;
MAXFUEL=ACFT.MAXFUEL;
MMO=ACFT.MMO; 
VMO=ACFT.VMO; 
RANGE=ACFT.RANGE;
%
wS=ACFT.wS;
wSft2=ACFT.wSft2;
wAR=ACFT.wAR;
wTR=ACFT.wTR;
wSweep14=ACFT.wSweep14;
wTwist=ACFT.wTwist;
CLMAX=ACFT.CLMAX;
PWing=ACFT.PWing;
Kink_semispan=ACFT.Kink_semispan;
inc_root=ACFT.inc_root; 
inc_kink=ACFT.inc_kink; 
inc_tip=ACFT.inc_tip; 
wMAC=ACFT.wMAC;
wSweepLE=ACFT.wSweepLE;
%
VTarea=ACFT.VTarea;
VTAR=ACFT.VTAR;
VTTR=ACFT.VTTR;
VTSweep=ACFT.VTSweep;
%
HTarea=ACFT.HTarea;
HTAR=ACFT.HTAR;
HTTR=ACFT.HTTR;
PHT=ACFT.PHT;
%
container_type=ACFT.container_type;
NPax=ACFT.NPax;
NCorr=ACFT.NCorr;
NSeat=ACFT.NSeat;
ncrew=ACFT.ncrew;
AisleWidth=ACFT.AisleWidth;
CabHeightm=ACFT.CabHeightm;    
SEATwid=ACFT.SEATwid;  
fus_width=ACFT.fus_width;
fus_height=ACFT.fus_height;
FusDiam=ACFT.FusDiam;
%
PEng=ACFT.PEng; 
MAXRATE=ACFT.MAXRATE;
T0=ACFT.T0;
n=ACFT.n;  
nedebasa=ACFT.nedebasa; 
ebypass=ACFT.ebypass;
ediam=ACFT.ediam;
efanpr=ACFT.efanpr;
eopr=ACFT.eopr;
eTIT=ACFT.eTIT;
%
r0=ACFT.r0;
t_c=ACFT.t_c;
phi=ACFT.phi;
X_tcmax=ACFT.X_tcmax;
theta=ACFT.theta;
epsilon=ACFT.epsilon;
Ycmax=ACFT.Ycmax;
YCtcmax=ACFT.YCtcmax;
X_Ycmax=ACFT.X_Ycmax;
wTCmed=ACFT.wTCmed;
%
Airp_SWET=ACFT.Airp_SWET;
wingSwet=ACFT.wingSwet;
lf=ACFT.lf;
lco=ACFT.lco;
%
Ccentro=ACFT.Ccentro;
Craiz=ACFT.Craiz;
Cquebra=ACFT.Cquebra;
Cponta=ACFT.Cponta;
xutip=ACFT.xutip;
yutip=ACFT.yutip;
xltip=ACFT.xltip;
yltip=ACFT.yltip;
xukink=ACFT.xukink;
yukink=ACFT.yukink;
xlkink=ACFT.xlkink;
ylkink=ACFT.ylkink;
xuroot=ACFT.xuroot;
yuroot=ACFT.yuroot;
xlroot=ACFT.xlroot;
ylroot=ACFT.ylroot;
swet2=ACFT.Airp_SWET;

% Constants
N2lbf   = 0.2248;
kg2lb   = 2.2046;
ft2m    = 0.3048;
rad     = pi/180;
cfe     = 0.0030;  
kg2lb   = 2.2046;
m2feet  = 3.28083;
g       = 9.80665;
Gal2l   = 3.7852;

% SETUP PARAMETERS
ISADEV=0;          % ISA DEVIATION [oC]
PAXWT=110;         % PASSENGER's WEIGHT [kg]
MAXUTIL=13;        % MAXIMUM DAILY UTILIZATION [h]
TURNAROUND=45;     % TURN AROUND TIME  [min]
TIT=5;             % AVG TAXI IN TIME  [min]
TOT=10;            % AVG TAXI OUT TIME [min]
avg_ticket=120;    % AVERAGE TIKET PRICE [$/pax]
SHARE=0.10;        % 10% of the market  
LFREF=0.85;        % REFERENCE LOAD FACTOR  
K1=1.1;            % TOTAL REVENUE TO TICKET REVENUE FACTOR  
K2=1.2;            % TOTAL COST TO DOC FACTOR
ACFT_Mkt_Share=0.6;% ACFT Market Share
IR=0.05;           % Interest rate  
p=15;              % life cycle (years) 
KVA=75;            % Electrical system AC Power
TO_ALLOWANCE=200*MTOW/22000;  % TAKEOFF ALLOWANCE FUEL [kg]
ARR_ALLOWANCE=100*MTOW/22000; % APPROACH ALLOWANCE FUEL [kg]    

% NPV CALCULATION
[TOT_NPV,CASHFLOW,PV,IRR,BE,Price]=NPV(ACFT_Mkt_Share,IR,p,MTOW,wS,n,MAXRATE,ediam,NPax,KVA);

% REFERENCE DOC CALCULATION
PAYLOAD=round(NPax*PAXWT*LFREF);
[~,~,DOC,CRZMACH,~,~]=Mission4_FIXED(ACFT,0,0,0,0,0,RANGE,200,2500,2000,2000,15,15,15,0,PAYLOAD,TIT,TOT,0,TO_ALLOWANCE,ARR_ALLOWANCE); 

%
fprintf('\n'); 
fprintf('\n ** ACFT REFERENCE VALUES **');
fprintf('\n'); 
fprintf('\n CRZMACH                  : %5.3f',CRZMACH);
fprintf('\n RANGE (nm)               : %5.0f',RANGE);
fprintf('\n MTOW                     : %5.0f',MTOW);
fprintf('\n MLW                      : %5.0f',MLW);
fprintf('\n DOC   ($/nm)             : %5.2f',DOC);
fprintf('\n PAX                      : %5.0f',NPax);
fprintf('\n NPV   (x1E9 $)           : %5.1f',TOT_NPV/1E9);
fprintf('\n Price (x1E6 $)           : %5.1f',Price/1E6);
fprintf('\n Average fare ($)         : %5.0f',avg_ticket);
fprintf('\n Average Load Factor (pct): %5.1f',LFREF*100);
fprintf('\n Average Market Share(pct): %5.1f',SHARE*100);
fprintf('\n'); 

LIN(lin)  =' '; 
LIN(lin+1)='** REFERENCE VALUES FOR NETWORK DESIGN **';
LIN(lin+2)=' '; 
LIN(lin+3)=strcat('CRZMACH1                 : ',num2str(CRZMACH,1));
LIN(lin+4)=strcat('RANGE1 (nm)              : ',int2str(RANGE));
LIN(lin+5)=strcat('DOC1   ($/nm)            : ',num2str(DOC,2));
LIN(lin+6)=strcat('PAX1                     : ',int2str(NPax));
LIN(lin+7)=strcat('NPV1   (x1E9 $)          : ',num2str(TOT_NPV/1E9));
LIN(lin+8)=strcat('Price1 (x1E6 $)          : ',num2str(Price/1E6));
LIN(lin+9)=strcat('Average fare ($)         : ',num2str(avg_ticket));
LIN(lin+10)=strcat('Average Load Factor (pct): ',num2str(LFREF*100));
LIN(lin+11)=strcat('Average Marketshare (pct): ',num2str(SHARE*100));
LIN(lin+12)=' '; 
lin=lin+13;

% Retrieve Airport and Demand Datafor fixed network
[Airport,D,LF,DIST,HDG]=LOADAPT(SHARE,LFREF);
 X = [0 1 1 1 1 ;
      1 0 1 1 1 ;
      1 1 0 1 1 ;
      1 1 1 0 1 ;
      1 1 1 1 0] ;      
n=size(D,1); 

% TOTAL DEMAND AND FREQUENCIES
TOTDEMAND=0;
for i=1:n
  for j=1:n      
     if or(i==j,X(i,j)==0);
       f=0;
       NPAX(i,j)=0;
       FREQ(i,j)=0;
     else
       NPAX(i,j)=round(LF(i,j)*NPax); 
       f=round(D(i,j)/NPAX(i,j));       
       FREQ(i,j)=f;      
     end
     TOTDEMAND=TOTDEMAND+D(i,j)*X(i,j);     
  end
end
%
% plot network
figure (1)
for i=1:n
  LAT(i)=Airport(i).lat;
  LON(i)=Airport(i).lon;    
end    
plot(LON,LAT,'bo')
%
LIN(lin,1)='** NETWORK PRE-COMPUTATION **'; 
LIN(lin+1)=' '; 
APT='';
n=size(Airport,2);
for i=1:n
    if i<n
      APT=strcat(APT,Airport(i).name,',');
    else
      APT=strcat(APT,Airport(i).name); 
    end  
end
LIN(lin+2)=strcat('AIRPORT ARRAY: ',APT);
LIN(lin+3)=' ';
lin=lin+4;
%
LIN(lin)='* DAILY DEMAND *';  
lin=lin+1;
L=NETWORKARRAYS(D);
n=size(L,1);
for i=1:n
   LIN(lin,1)=L(i);
   lin=lin+1;
end
LIN(lin+1,1)='';
lin=lin+2;
%
LIN(lin,1)='* DISTANCES *';  
lin=lin+1;
L=NETWORKARRAYS(DIST);
n=size(L,1);
for i=1:n
   LIN(lin,1)=L(i,1);
   lin=lin+1;
end
LIN(lin+1,1)=' ';
lin=lin+2;
%
LIN(lin,1)='* HEADINGS *';  
lin=lin+1;
[L]=NETWORKARRAYS(HDG');
n=size(L,1);
for i=1:n
   LIN(lin)=L(i,1);
   lin=lin+1;
end
LIN(lin+1)=' ';
lin=lin+2;
%
LIN(lin,1)='* FREQUENCIES *';  
lin=lin+1;
[L]=NETWORKARRAYS(FREQ');
n=size(L,1);
for i=1:n
   LIN(lin)=L(i,1);
   lin=lin+1;
end
LIN(lin+1)=' ';
lin=lin+2;

%
% NETWORK PARAMETERS CALCULATION
[n,N,AVG_DON,L,ND,AVG_C]=NETWORKPAR(X,DIST,500);   

fprintf('\n'); 
fprintf('\n *** NETWORK DATA ***');    
fprintf('\n'); 
fprintf('*DISTANCE MATRIX*');
DIST
fprintf('\n'); 
fprintf('*HEADING MATRIX*');
HDG
fprintf('\n'); 
fprintf('*DEMAND MATRIX*');
D
fprintf('TOTAL: %6.0f',TOTDEMAND);
fprintf('\n');
fprintf('*LOAD FACTOR*');
LF
fprintf('\n');
fprintf('*FREQUENCIES*');
FREQ

fprintf('\n');
fprintf('\n Number of Nodes (n)              : %6.0f',n);
fprintf('\n Number of Arcs (N)               : %6.0f',N);
fprintf('\n Average Degree of Nodes (AVG DON): %6.1f',AVG_DON);
fprintf('\n Average Path Length (L)- nm      : %6.1f',L);
fprintf('\n Network Density (ND)             : %6.2f',ND);
fprintf('\n Average Clustering (AVG C)       : %6.2f',AVG_C);
fprintf('\n');   
fprintf('\n *** MISSION ANALYSIS ***'); 
fprintf('\n');    
fprintf('\n SECTOR  ZFW   FOB  TAXI  TOF   TOW    TRIP  LW    REM   DIST    HDG    ALT  TIME  DOC   RTOW  RLW  CRZM  FREQ PAX LF');
fprintf('\n         [kg]  [kg] [kg]  [kg]  [kg]   [kg]  [kg]  [kg]  [nm]   [deg]   [FL] [min] [$/nm][kg]  [kg]                [pct]');
%
LIN(lin,1)=' ';
LIN(lin+2)='*NETWORK DATA*';
LIN(lin+3)=strcat('Number of Nodes (n)              :',int2str(n));
LIN(lin+4)=strcat('Number of Arcs (N)               :',int2str(N));
LIN(lin+5)=strcat('Average Degree of Nodes (AVG DON):',num2str(AVG_DON));
LIN(lin+6)=strcat('Average Path Length (L)- nm      :',num2str(L));
LIN(lin+7)=strcat('Network Density (ND)             :',num2str(ND));
LIN(lin+8)=strcat('Average Clustering (AVG C)       :',num2str(AVG_C));
LIN(lin+9)=' ';
LIN(lin+10)='*** MISSION ANALYSIS *** ';
LIN(lin+11)=' ';
LIN(lin+12)='SECTOR  ZFW   FOB  TAXI  TOF   TOW    TRIP  LW    REM   DIST    HDG    ALT  TIME  DOC   RTOW  RLW  CRZM  FREQ PAX LF';
LIN(lin+13)='        [kg]  [kg] [kg]  [kg]  [kg]   [kg]  [kg]  [kg]  [nm]   [deg]   [FL] [min] [$/nm][kg]  [kg]                [pct]';
lin=lin+14;

TO_ALLOWANCE=200*MTOW/22000;  % TAKEOFF ALLOWANCE FUEL [kg]
ARR_ALLOWANCE=100*MTOW/22000; % APPROACH ALLOWANCE FUEL [kg]
RMK=' ';

% SECTOR CALCULATION
for i=1:n
    for j=1:n
       if i~=j;
           if X(i,j)>0;                     
             DISTANCE=DIST(i,j);
             [DISTALT]=MINALTDIST(DIST,i);              
             PAYLOAD=NPAX(i,j)*PAXWT;
             dep=Airport(i).name;
             arr=Airport(j).name;
             sector=string(strcat(dep,'/',arr));   
             fprintf('\n');                     
             fprintf('%s ',sector);
             Origelev=Airport(i).elev;
             Destelev=Airport(j).elev;
             Altelev=Airport(i).elev;
             ASDA=Airport(i).ASDA;
             LDA=Airport(j).LDA;
             ALT_LDA=Airport(i).LDA;
             DEP_TREF=Airport(i).Reftemp;
             ARR_TREF=Airport(j).Reftemp;
             ALT_TREF=Airport(i).Reftemp;                      
             TH=HDG(i,j);
             THA=HDG(j,i);           
             %
             PAX_calc=0;
             [Wf(i,j),T(i,j),CF(i,j),CRZMACH(i,j),PAX_calc,RMK,S] = Mission4_FIXED(ACFT,Origelev,Destelev,Altelev,TH,THA,DISTANCE,DISTALT,ASDA,LDA,ALT_LDA,DEP_TREF,ARR_TREF,ALT_TREF,ISADEV,PAYLOAD,TIT,TOT,1,TO_ALLOWANCE,ARR_ALLOWANCE);  
             if PAX_calc<NPAX(i,j);
                 NPAX(i,j)=PAX_calc;
                 FREQ(i,j)=round(D(i,j)/NPAX(i,j));
             end
             %
             T(i,j)=T(i,j)+TIT+TOT;
             Wf(i,j)=Wf(i,j)+TO_ALLOWANCE+ARR_ALLOWANCE;
             fprintf('%3.0f ',FREQ(i,j));            
             fprintf('%5.1f ',NPAX(i,j));   
             fprintf('%5.1f ',(NPAX(i,j)/NPax)*100);
             s1=int2str(FREQ(i,j));
             s2=int2str(PAX_calc);
             s3=num2str((NPAX(i,j)/NPax)*100);
             LIN(lin)=strcat(sector,',',S,',',s1,',',s2,',',s3);
             lin=lin+1; 
           end
       end 
    end
end    

% TOTAL 
TOTCOST=0;
TOTDIST=0;
TOTALFREQ=0;
TOTALPAX=0;
TOTTIME=0;
TOTFUEL=0;
TOTFLIGHTS=0;
AVGMACH=0;
AVGDOC=0;
NF=0;
AVA=24.253+0.0009*MTOW; % ARRIVAL DELAY COST [$/min]
AVD=9.8308+0.0007*MTOW; % DEPARTURE DELAY COST [$/min]

% CONSOLIDATED DATA
for i=1:n
    for j=1:n
        if X(i,j)>0
            TOTCOST=TOTCOST+FREQ(i,j)*(DIST(i,j)*CF(i,j)+AVD*Airport(i).AVG_DEP_delay+AVA*Airport(j).AVG_ARR_delay);
            TOTDIST=TOTDIST+FREQ(i,j)*DIST(i,j);
            TOTALPAX=TOTALPAX+FREQ(i,j)*round(LFREF*NPAX(i,j));
            TOTTIME=TOTTIME+FREQ(i,j)*(T(i,j)+Airport(i).AVG_DEP_delay+Airport(j).AVG_ARR_delay);
            TOTFLIGHTS=TOTFLIGHTS+FREQ(i,j);
            TOTFUEL=TOTFUEL+FREQ(i,j)*Wf(i,j);
            NF= NF+FREQ(i,j);
            AVGMACH=AVGMACH+FREQ(i,j)*CRZMACH(i,j);
            AVGDOC=AVGDOC+FREQ(i,j)*CF(i,j);
        end    
    end    
end

AVGMACH=AVGMACH/NF;
AVGDOC=AVGDOC/NF;
COST=K2*TOTCOST;
REV=K1*TOTALPAX*avg_ticket;
PROFIT=REV-COST;
CASK=COST/(TOTALPAX*TOTDIST);
RASK=REV/(TOTALPAX*TOTDIST);
NP=RASK-CASK;               
NACFT=round(TOTTIME/(MAXUTIL*60));   
CO2EFF=3.15*TOTFUEL/(TOTALPAX*TOTDIST*1.852);
%
fprintf('\n');
fprintf('\n ** NETWORK RESULTS **');
fprintf('\n'); 
fprintf('\n Average Cruise Mach      : %10.3f',AVGMACH);
fprintf('\n TOTAL FUEL (kg)          : %10.2f',TOTFUEL);
fprintf('\n TOTAL CO2  (kg)          : %10.2f',TOTFUEL*3.15);
fprintf('\n CO2 EFF(kg/PAX.km)       : %6.4E',CO2EFF);
fprintf('\n TOTAL DIST (nm)          : %10.2f',TOTDIST);
fprintf('\n TOTAL PAX                : %10.0f',TOTALPAX);
fprintf('\n TOTAL COST    ($)        : %10.2f',COST);
fprintf('\n TOTAL REVENUE ($)        : %10.2f',REV);
fprintf('\n TOTAL PROFIT  ($)        : %10.2f',PROFIT);
fprintf('\n MARGIN        (pct)      : %10.2f',100*PROFIT/COST); 
fprintf('\n AVG DOC ($/nm)           : %6.2E',AVGDOC);
fprintf('\n NRASK ($/pax.nm)         : %6.4E',RASK);
fprintf('\n NCASK ($/pax.nm)         : %6.4E',CASK);
fprintf('\n NP    ($/pax.nm)         : %6.4E',NP);
fprintf('\n NUM OF FREQUENCIES       : %4.0f',NF);
fprintf('\n NUM OF ACFT              : %3.0f',NACFT);
fprintf('\n SECTORS PER ACFT         : %3.0f',NF/NACFT);
fprintf('\n');

LIN(lin+1)=" ";
LIN(lin+2)='** NETWORK RESULTS **';
LIN(lin+3)=" ";
LIN(lin+4)=strcat('Average Cruise Mach      : ',num2str(AVGMACH,3));
LIN(lin+5)=strcat('TOTAL FUEL (kg)          : ',int2str(TOTFUEL));
LIN(lin+6)=strcat('TOTAL CO2  (kg)          : ',num2str(TOTFUEL*3.15));
LIN(lin+7)=strcat('CO2 EFF(kg/PAX)          : ',num2str(CO2EFF));
LIN(lin+8)=strcat('TOTAL DIST (nm)          : ',int2str(TOTDIST));
LIN(lin+9)=strcat('TOTAL PAX                : ',int2str(TOTALPAX));
LIN(lin+10)=strcat('TOTAL COST    ($)        : ',num2str(COST));
LIN(lin+11)=strcat('TOTAL REVENUE ($)        : ',num2str(REV));
LIN(lin+12)=strcat('TOTAL PROFIT  ($)        : ',num2str(PROFIT));
LIN(lin+13)=strcat('MARGIN        (pct)      : ',num2str(100*PROFIT/COST));
LIN(lin+14)=strcat('AVGDOC ($/nm)            : ',num2str(AVGDOC));
LIN(lin+15)=strcat('NRASK ($/pax.nm)x1E-4    : ',num2str(RASK*1E4));
LIN(lin+16)=strcat('NCASK ($/pax.nm)x1E-4    : ',num2str(CASK*1E4));
LIN(lin+17)=strcat('NP    ($/pax.nm)x1E-4    : ',num2str(NP*1E4));
LIN(lin+18)=strcat('NUM OF FREQUENCIES       : ',int2str(NF));
LIN(lin+19)=strcat('NUM OF ACFT              : ',int2str(NACFT));
LIN(lin+20)=strcat('SECTORS PER ACFT         : ',num2str(NF/NACFT));
lin=lin+21;
toc

% SAVE RESULTS IN TEXT FILE
N=lin;
fid=fopen(NAME,'w+');
for i=1:N 
     fprintf(fid,'%s\n',LIN(i));
end
fclose(fid);

% SAVE ROUTES IN KML
NAME=strcat('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\FIXED_NETWORK\FIXED_NETWORK_',s0,'_',name1,'_',name2,'_',name3,'.kml');  
k=1;
for i=1:n   
  for j=1:n
      if i~=j
        if FREQ(i,j)>0  
          LA1(k)=Airport(i).lat;
          LO1(k)=Airport(i).lon;           
          LA2(k)=Airport(j).lat;
          LO2(k)=Airport(j).lon;
          k=k+1;
        end
      end  
  end   
end
try
    LAT1=LA1';
    LAT2=LA2';
    LON1=LO1';
    LON2=LO2';        
    RTEKML (LAT1,LON1,LAT2,LON2,NAME);
catch
  fprintf('NO KML GENERATED ',NAME); 
end  



