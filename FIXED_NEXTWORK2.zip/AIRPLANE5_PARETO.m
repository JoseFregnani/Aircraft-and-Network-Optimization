%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% Aircraft and Network Optimization - AIRPLANE MODULE
% 
% AUTHOR: Jos� Alexandre Fregnani/Bento Mattos
%
% VERSION: 5.0 / April 2017
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
function [TOTNOISE]=AIRPLANE5_PARETO(X,ID);

clc;
close all;

% Constants
N2lbf   = 0.2248;
ft2m    = 0.3048;
m2ft    = 1./ft2m;
rad     = pi/180;
cfe     = 0.0030; % 
kg2lb   = 2.2046;
lb2kg   = 1./kg2lb;
m2feet  = 3.28083;
g       = 9.80665;

% FROM OPTIMIZATION
NPax                = X(1);  
NSeat               = X(2);
wS                  = X(3);
wAR                 = X(4);
wTR                 = X(5);
wSweep14            = X(6);
wTwist              = X(7);
Kink_semispan       = X(8);
ebypass             = X(9);    
ediam               = X(10);  
eopr                = X(11);
eTIT                = X(12);
efanpr              = X(13);
Range               = X(14);
eHp                 = X(15);
eM                  = X(16);    
PEng                = X(17);  
wlet_present        = X(18);
SlatPres            = X(19);

% CABIN
NCorr              = 1;
ncrew              = 5;
CabHeightm         = 2;
SEATwid            = 0.46;
AisleWidth         = 0.50;
SeatPitch          = 0.8128;
widthreiratio      = 1.1;

% AERODYNAMICS 
diedro             = 3;
Clmax2D            = 1.9;
dflecflaptakeoff   = 35; 
dflecflapland      = 45;  
bflap              = 0.75;
inc_root           = 2;
inc_kink           = 0;
inc_tip            = inc_root + wTwist;
slat               = 1;
%% Winglet 
SweepLE_winglet    = 35;
AR_winglet         = 2.75;
TR_winglet         = 0.25;
CantAngle_wlet     = 75;

% OPERATIONS
YEIS               = 2017;
Takeofffl          = 2000; 
Landfl             = 1500; 
% wingfuelcapacity   = 10000;
% MAXFUEL            = wingfuelcapacity; 
MMO                = 0.82;
CruiseMach         = MMO - 0.02;
VMO                = 340;
TLOIT              = 30;   % Holding time [min]
DIST_ALT           = 200;  % Range fo alternate airport [nm]
Ceiling            = 41000;
PAXWT              = 100;
Payload            = NPax*PAXWT;

% AIRFRAME PARAMETERS
longtras           = 0.75; 
wSft2              = wS*m2feet*m2feet;
b                  = sqrt(wAR*wS);
CLMAX              = 0.90*Clmax2D *cos(wAR*pi/180);
AirplaneCLmaxClean = CLMAX;
PWing              = 1;
VTArea             = 16.2;
VTAR               = 1.2;
VTTR               = 0.5;
VTSweep            = 41;
HTArea             = 23.35;
HTAR               = 4.35;
HTTR               = 0.4;
PHT                = 1;
VHT                = 0.90;
VVT                = 0.09;
margin_static      = 0.15;
htac_rel           = 0.25;
vtac_rel           = 0.25;
pneum_p            = 200; % (psi) MLG tyre pressure upper boundary
pneun_p            = 190; % (psi) NLG tyre pressure upper boundary

% USELAGE PARAMETERS
% Escolha do tipo de container de acordo com o n�mero de passageiros
nt  = 3; % Number of transitions in pax number
t(1)=75; % First transition point
t(2)=95; % Second transition point
%
classifica = 0;
for i=1:(nt-1)
rastreia=NPax -t(i);
    if rastreia < 0
    classifica = i;
    break
    end
end
if(classifica == 0) 
    classifica = nt;
end
switch classifica
    case 1
        container_type     = 'None';
    case 2
        container_type     = 'LD3-45W';
    case 3
        container_type     = 'LD3-45';
end

%
[fus_width, fus_height, FUSELAGE_Dz_floor, a_mini]=...
fuscrosssect02(container_type,NCorr,NSeat,CabHeightm,...
    SEATwid,AisleWidth,widthreiratio);

%ENGINE PARAMETERS
MAXRATE            = 20000;
% efanpr             = 1.425;
% eTIT               = 1450; 
Engine_data(1)     = PEng;
Engine_data(2)     = ebypass;
Engine_data(3)     = ediam;
Engine_data(4)     = efanpr;
Engine_data(5)     = eopr;
Engine_data(6)     = eTIT;

switch PEng
    case 0
        n=2;
        nedebasa=0;
    case 1
        n=2;
        nedebasa=2;  
end
if PWing ==2 || PEng == 2
  PHT =2;
end

% Load Neural Networks 
NNind = importdata('NN_CDind.mat');
NNwav = importdata('NN_CDwave.mat');
NNcd0 = importdata('NN_CDfp.mat');
NNCL  = importdata('NN_CL.mat');

% find Sobiescki coefficientes for basic airfoils
[r0, t_c, phi, X_tcmax, theta, epsilon, ...
    Ycmax, YCtcmax, X_Ycmax]=airfoilcoeff();

% WET AREA CALCULATION
wTCmed = (t_c(1)+t_c(2)+t_c(3))/3; % Wing average relative maximum thickness
%FusDiam             = sqrt(fus_width*fus_height);
[Airp_SWET, wingSwet,FusSwet_m2,lf ,lco, ltail , EnginLength_m,wYMAC ,wMAC, wSweepLE, ~ ,...
    ht,vt,...
    Ccentro,Craiz,Cquebra, Cponta, ...
    xutip, yutip, xltip, yltip,...
    xukink,yukink,xlkink,ylkink, xuroot,yuroot,xlroot,ylroot,pylon]...
    = wettedarea(Ceiling,...
    CruiseMach,fus_width,fus_height,...
    NPax,NCorr,NSeat,SEATwid,AisleWidth,...
    Kink_semispan,wS,wAR,wTR,wSweep14,wTwist,...
    PWing,Engine_data,VTArea,VTAR,VTTR,VTSweep,HTArea,HTAR,HTTR,PHT,htac_rel);
%
swet2=Airp_SWET; % [m2]
% Wing structural layout: output cxgtanks and trunnion position
wingb = sqrt(wS*wAR);
[posxmunhao, xcgtanques, wingfuelcapacity]=winglaywei2017c(fus_width,Kink_semispan,wSweepLE,wingb, longtras, slat, ...
    Ccentro,Cquebra, Cponta, PEng, xutip,yutip,yltip,...
    xukink,xlkink, yukink,ylkink, xuroot,xlroot, yuroot, ylroot);
%
%Estimation of MTOW [kg] by Class I methodology
areamolhadam2       = Airp_SWET;
areamolhadaft2      = areamolhadam2*m2ft*m2ft;
wt0i                = (log10(areamolhadaft2) - 0.0199)/0.7531;
wt0i                = 10^wt0i;
MTOWi               = wt0i*lb2kg;
% input parameters preparation 
FusDiam             = sqrt(fus_width*fus_height);
nukink              = size(xukink,2);
wingb               = sqrt(wAR*wS);
htb                 = sqrt(HTAR*HTArea);
planffusdf          = fus_width;
wingcrank           = Kink_semispan; 
wingsweepLE         = wSweepLE;
xle                 = 0.45*lf;
lcab                = lf-(ltail+lco);
fuel                = 0.25*MTOWi;
EngineDe_m          = Engine_data(3)*1.1;
BPR                 = Engine_data(2);
ediam               = Engine_data(3); 
efanpr              = Engine_data(4);
eopr                = Engine_data(5);   
eTIT                = Engine_data(6); 
[T0_N,~]            = engine_main(0,0,efanpr,eopr,BPR,1,ediam,eTIT);
%
% Calculo deo CD0 da asa e do fator k do arrasto induzido
CL1=0.40;
Alfa_ou_CL = 0; % =0 means CL fixed; = 1 alfa fixed
alfadummy  = 0;
     [CDwing_CL1, ~]  = CDCLneural2(0.15,100.,CL1,alfadummy,wS,wAR,wTR,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
         Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL);
%
CL2=0.50;
      [CDwing_CL2, ~]  = CDCLneural2(0.15,100.,CL2,alfadummy,wS,wAR,wTR,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
         Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL);
 %
K_IND       = (CDwing_CL1 - CDwing_CL2)/(CL1^2-CL2^2);
CD0_Wing    = CDwing_CL1 - K_IND*(CL1^2);

% Estimativa do CL alfa
Alfa_ou_CL = 1; % =0 means CL fixed; = 1 alfa fixed
alfag1     = 1;
     [CDwing_CL1, CLout1]  = CDCLneural2(0.15,0.,0.45,alfag1,wS,wAR,wTR,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
         Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL);
alfag2     = 2;
      [CDwing_CL2, CLout2]  = CDCLneural2(0.15,0.,0.45,alfag2,wS,wAR,wTR,wSweepLE,...
        inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
         Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,Alfa_ou_CL);    
%
CLALFA_deg = (CLout2-CLout1)/(alfag2-alfag1);
CLALFA_rad = CLALFA_deg/(pi/180);

% % MACH DIV CHECK
Mach      = 0.70;
k         = 0;
CL1       = 0.40;
alfadummy = 1;
MMAX      = MMO;
CDmax     = -10000;
CDmin     = +10000;

while Mach <= MMAX
    Mach = Mach + 0.01;    
    [CDwing, ~]  = CDCLneural2(Mach,Ceiling*ft2m,CL1,alfadummy,wS,wAR,wTR,wSweepLE,...
       inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
       Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,0); 
    [CD0_ubrige] = cfe*(Airp_SWET-wingSwet)/wS;
    CDT          = CDwing + CD0_ubrige;
    CDmax        = max(CDmax,CDT);
    CDmin        = min(CDmin,CDT);
end
DeltaCD=CDmax-CDmin;

switch slat
 case 1
     AirplaneCLmaxTakeo = AirplaneCLmaxClean + 0.60;
     AirplaneCLmaxLandi = AirplaneCLmaxClean + 1.20;
 otherwise
     AirplaneCLmaxTakeo = AirplaneCLmaxClean + 0.40;
     AirplaneCLmaxLandi = AirplaneCLmaxClean + 1.00;
end

% MTOW & OEW CALCULATION
tcroot           = t_c(1);
X_TP1            = lco - 0.40;
MTOW             = MTOWi;
mtowdif          = 1e06;
iplot            = 1;
mtowplot         = MTOW;
iter             = 1;
mtowcount        = 0;
maxmtow_count    = 25;
PASS=0;

while mtowdif > 100 && mtowcount < maxmtow_count

    [MTOWcalc, OEW, W_climb_final, Airp_SWET,...
        TOTFUEL, TOTFUEL_ALT, TOTTIME,htout,vtout,xleout,xcg_fwd,xcg_aft]=...
        MTOW_calc(MTOW,...
        AirplaneCLmaxClean,wTCmed,wSweepLE,wSweep14,wS,wTR,wAR,wMAC,wYMAC,...
        inc_root,inc_kink,inc_tip,Kink_semispan,longtras,posxmunhao,...
        xcgtanques,NSeat,wingfuelcapacity,...
        r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,Ccentro,Craiz,Cponta,margin_static,...
        Range,Engine_data,CruiseMach,Ceiling,Airp_SWET,wingSwet,Payload,ncrew,...
        TLOIT,DIST_ALT,NNind,NNwav,NNcd0,NNCL,PHT,ht,...
        EnginLength_m,EngineDe_m,pylon,...
        CLALFA_rad,wingfuelcapacity,PWing,vt,vtac_rel,htac_rel,...
        YEIS,xle,slat,fus_width,fus_height,FusSwet_m2,lf,lcab,ltail,...
        VHT,VVT,SeatPitch,AisleWidth,SEATwid);
    
        xle = xleout;
        ht  = htout;
        vt  = vtout;
        mtowdif        = abs(MTOWcalc-MTOW);
        MTOW           = 0.20*MTOW+0.80*MTOWcalc;
        fprintf('\n');
        fprintf('\n **** MTOW = %6.0f kg **** ',MTOW)
        fprintf('\n **** OEW  = %6.0f kg **** \n',OEW)
        mtowcount        = mtowcount +1;
        fprintf('\n');
end

if mtowcount > maxmtow_count
    fprintf('\n MTOW calculation not converged \n')
    flag_req  = 1;
    DOCcalc   = 100;
    deltafuel = -10000;
    TOnoise   = 400;
    PASS=1;
else
    hfigura=figure(14);
    hcg =-0.80;
    [D0m_max, D0n_max,wm_max, wn_max,ds_m,ds_n, Lpist_m,Lpist_n]= ...
    plotairplane3d_V2(xcg_fwd,xcg_aft,hcg,MTOW,...
       0.90*MTOW,AirplaneCLmaxTakeo, AirplaneCLmaxLandi,lf,lco,ltail,...
       fus_width,Ccentro,Craiz,Cquebra,Cponta,wS,wTR,...
       xle,wSweepLE,wingb/2,diedro,PEng,EngineDe_m,EnginLength_m,Kink_semispan, ...
       vt.ct,vt.c0,VTAR,vt.sweepLE,ht,PHT,...
       PWing,pneum_p,pneun_p,tcroot,inc_root,inc_kink,inc_tip,SweepLE_winglet,AR_winglet,...
             TR_winglet,CantAngle_wlet,wlet_present,longtras,...
             bflap,X_TP1);
    view(45,45);
    %
    name=strcat('ID',ID,'.fig');
    savefig(name);
    
    %close(figure(14))

    % NOISE CHECK
    dcdflapland      = CD_flap(dflecflapland,longtras);
    CD0_ubrige       = cfe*(Airp_SWET-wingSwet)/wS;
    [CD_main, CD_nose]=CD_LGear(D0m_max,D0n_max,wm_max,wn_max,...
    Lpist_m,Lpist_n,ds_m,ds_n,2,2,2,wS);
    dcdlandinggear   = CD_main + CD_nose;
    CD0_Land         = CD0_Wing + CD0_ubrige  + dcdflapland + dcdlandinggear;
    NEng             = max(2,PEng);
    [TOnoise, SLnoise, LDnoise]=Noise_Calculation(0,0,MTOW,0.90*MTOW,...
        NEng,wS,wingb,ht.S,vt.b,vt.S,vt.b,AirplaneCLmaxLandi,AirplaneCLmaxTakeo,...
        K_IND,CD0_Land,BPR,ediam,efanpr,eopr,D0m_max, D0n_max);
    TOTNOISE=TOnoise+SLnoise+LDnoise
    %
    flagnoise=0;
    if TOTNOISE>270 %ICAO Annex 16 - Chapter 4 Requirement
        flagnoise=1;
    end    
        
    %FUEL DEFICIT
    deltafuel = wingfuelcapacity - 1.005*TOTFUEL_ALT;
    if deltafuel < 0
      fprintf('\n fuel accommodation deficit: %f kg \n',abs(deltafuel))
      flagfuel=1;
    else
      fprintf('\n fuel accommodation surplus: %f kg \n',deltafuel)
      flagfuel=0;
    end
%
    % ENGINE WEIGHT ESTIMATION
    n          = max(2,Engine_data(1));
    BPR        = Engine_data(2);
    ediam      = Engine_data(3); % Fan diameter [m]
    efanpr     = Engine_data(4); % Fan pressure ratio
    eopr       = Engine_data(5); % Overall pressure ratio = compressor x fan   
    eTIT       = Engine_data(6); % Turbine Inlet Temperature [K]
    [Fn,FF]    = engine_main(0,0,efanpr,eopr,BPR,1,ediam,eTIT);
    T0         = Fn*N2lbf; % [lbf]
    weight_engine_kg=(0.084*(T0)^1.1*expm(-0.045*BPR))/kg2lb; % [kg] Torembeek
%     weight_engine_kg2=ENGWT(BPR,eopr,T0,ediam,1000*MTOW/22000,3);
    
    MAXRATE= 0.3264*MTOW + 2134.8;
    T0= MAXRATE*0.95;
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %
    % DESIGN ENVELOPE CHECK
    %
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %  2nd segment climb
    ToW     =  (n*T0)/(MTOW*kg2lb);
    TW_2seg_req=check_2ndseg(wS,wAR,wTR,wSweepLE,...
    inc_root,inc_kink,inc_tip,Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,...
    n,Airp_SWET,wingSwet,longtras,AirplaneCLmaxTakeo,MTOW,vt.S,vt.sweep,ediam,BPR,...
    NNind,NNwav,NNcd0,NNCL,cfe,dflecflaptakeoff);
    %
    flag2seg = 0;
    if TW_2seg_req > ToW
      flag2seg = 1; 
    end
    %
    % ROC at service ceiling
    TW_ROC_req=check_ROC(wS,wAR,wTR,W_climb_final,CruiseMach,Engine_data,wTCmed,...
        wSweep14,Airp_SWET,Ceiling,T0,MTOW,FusDiam);
    %
    flagROC = 0;
    if TW_ROC_req > ToW
      flagROC = 1 ;
    end

    % TAKEOFF
    TW_takeoff_req=check_takeoff(AirplaneCLmaxTakeo,Takeofffl,MTOW,wS);
    %
    flagTakeoff = 0;
    if TW_takeoff_req > ToW
      flagTakeoff = 1  ;
    end

    % CRUISE
    TWreq_crz=check_CRZ(Ceiling,CruiseMach,MTOW,W_climb_final,wS,wAR,wTR,...
        wSweepLE,Airp_SWET,wingSwet,Engine_data,T0,inc_root,inc_kink,inc_tip,...
        Kink_semispan,r0,t_c,phi,X_tcmax,theta,epsilon,...
        Ycmax,YCtcmax,X_Ycmax,NNind,NNwav,NNcd0,NNCL,cfe);
    %
    flagCRZ = 0;
    if TWreq_crz > ToW
      flagCRZ = 1 ;
    end

    % LANDING
    MLW       = MTOW - TOTFUEL;
    MZFW      = MLW*0.98;
    massratio = MLW/MTOW;
    wland     = (Landfl*.119*AirplaneCLmaxLandi)/massratio;
    WS        = MTOW/wS;
    flagLand  = 0;
    if wland < WS
      flagLand = 1 ;
    end
  
end

% FAIL:PASS=1 ; OK:PASS=0
flag_req=[flag2seg, flagROC, flagTakeoff, flagCRZ, flagLand,flagnoise,flagfuel]
flag_req=max(flag_req);
PASS=flag_req;


    fid=fopen('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\FIXED_NETWORK\parameters.dat','w+');

            % MTOW,MLW,MZFW,OEW,MAXFUEL,wS,wSft2,wAR,wTR,wSweep14,wTwist,CLMAX,PWing,VTarea,VTAR,VTTR,VTSweep,HTarea,HTAR,HTTR,PHT
            fprintf(fid,'%6.2f\n',MTOW);
            fprintf(fid,'%6.2f\n',MLW);
            fprintf(fid,'%6.2f\n',MZFW);
            fprintf(fid,'%6.2f\n',OEW);
            fprintf(fid,'%6.2f\n',wingfuelcapacity);
            fprintf(fid,'%6.2f\n',wS);
            fprintf(fid,'%6.2f\n',wSft2);
            fprintf(fid,'%6.2f\n',wAR);  
            fprintf(fid,'%6.2f\n',wTR);
            fprintf(fid,'%6.2f\n',wSweep14);
            fprintf(fid,'%6.2f\n',wTwist); 
            fprintf(fid,'%6.2f\n',CLMAX);
            fprintf(fid,'%6.2f\n',PWing);
            fprintf(fid,'%6.2f\n',VTArea);
            fprintf(fid,'%6.2f\n',VTAR); 
            fprintf(fid,'%6.2f\n',VTTR);
            fprintf(fid,'%6.2f\n',VTSweep);
            fprintf(fid,'%6.2f\n',HTArea);
            fprintf(fid,'%6.2f\n',HTAR);
            fprintf(fid,'%6.2f\n',HTTR);
            fprintf(fid,'%6.2f\n',PHT);

            % NPax,NCorr,NSeat,ncrew,AisleWidth,CabHeightm,Kink_semispan,SEATwid,widthreiratio
            fprintf(fid,'%6.2f\n',NPax);
            fprintf(fid,'%6.2f\n',NCorr);
            fprintf(fid,'%6.2f\n',NSeat);
            fprintf(fid,'%3.0f\n',ncrew);
            fprintf(fid,'%6.2f\n',AisleWidth);  
            fprintf(fid,'%6.2f\n',CabHeightm); 
            fprintf(fid,'%6.2f\n',Kink_semispan);
            fprintf(fid,'%6.2f\n',SEATwid);
            fprintf(fid,'%6.2f\n',widthreiratio);

            % inc_root,inc_kink,inc_tip,MMO,VMO,PEng,MAXRATE,n,nedebasa,ebypass,ediam,efanpr,eopr,eTIT,...
            fprintf(fid,'%6.2f\n',inc_root);
            fprintf(fid,'%6.2f\n',inc_kink);
            fprintf(fid,'%6.2f\n',inc_tip);
            fprintf(fid,'%6.2f\n',MMO);
            fprintf(fid,'%6.2f\n',VMO);
            fprintf(fid,'%6.2f\n',PEng);
            fprintf(fid,'%6.2f\n',MAXRATE);
            fprintf(fid,'%6.2f\n',n);
            fprintf(fid,'%6.2f\n',nedebasa);
            fprintf(fid,'%6.2f\n',ebypass);
            fprintf(fid,'%6.2f\n',ediam);
            fprintf(fid,'%6.2f\n',efanpr);
            fprintf(fid,'%6.2f\n',eopr);
            fprintf(fid,'%6.2f\n',eTIT);   

            % wTCmed,fus_width,fus_height,FusDiam,...
            fprintf(fid,'%6.2f\n',wTCmed);
            fprintf(fid,'%6.2f\n',fus_width);
            fprintf(fid,'%6.2f\n',fus_height);
            fprintf(fid,'%6.2f\n',FusDiam);

            % Airp_SWET,wingSwet,lf,lco,wMAC,wSweepLE,Ccentro,Craiz,Cquebra,Cponta,
            fprintf(fid,'%6.2f\n',Airp_SWET);
            fprintf(fid,'%6.2f\n',wingSwet);
            fprintf(fid,'%6.2f\n',lf);
            fprintf(fid,'%6.2f\n',lco);
            fprintf(fid,'%6.2f\n',wMAC);
            fprintf(fid,'%6.2f\n',wSweepLE);
            fprintf(fid,'%6.2f\n',Ccentro);
            fprintf(fid,'%6.2f\n',Craiz);
            fprintf(fid,'%6.2f\n',Cquebra);
            fprintf(fid,'%6.2f\n',Cponta);

            % T0,swet2,container_type
            fprintf(fid,'%6.2f\n',T0);
            fprintf(fid,'%6.2f\n',swet2);        
            fprintf(fid,container_type);  
            fprintf(fid,'\n');      

            % r0, t_c, phi,X_tcmax,theta,epsilon,Ycmax,YCtcmax,X_Ycmax,
            for i=1:3
              fprintf(fid,num2str(r0(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(t_c(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(phi(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(X_tcmax(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(theta(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(epsilon(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(X_Ycmax(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(Ycmax(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(YCtcmax(1,i),'%6.4f\n'));
              fprintf(fid,num2str('\n')); 
            end       

            % xutip,yutip,xltip,yltip,xukink,yukink,xlkink,ylkink,xuroot,yuroot,xlroot,ylroot
            for i=1:51
              % 
              fprintf(fid,num2str(xutip(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(yutip(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(xltip(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(yltip(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(xukink(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(yukink(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(xlkink(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(ylkink(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(xuroot(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(yuroot(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(xlroot(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
              fprintf(fid,num2str(ylroot(1,i),'%6.4f\n'));    
              fprintf(fid,num2str('\n')); 
            end
        
    fclose(fid);

toc

clear wS wAR wTR wSweep14 wTwist Kink_semispan ebypass ediam eopr eTIT NPax NAisle NSeat
clear weighttotal weightcomp Engine_data diedro
%





