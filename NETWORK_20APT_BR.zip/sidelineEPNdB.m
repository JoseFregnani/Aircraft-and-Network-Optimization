%% DESCRI��O E AUTORIA %%
%sidelinePNdB - Rotina para c�lculo do ru�do lateral EPNdB na decolagem
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   timehistory - trajet�ria da aeronave
%                   ACTGEO      - geometria da aeronave
%                       (1)     - SH - �rea de refer�ncia da empenagem horizontal [m�]
%                       (2)     - bH - envergadura da empenagem horizontal [m]
%                       (3)     - SV - �rea de refer�ncia da empenagem vertical [m�]
%                       (4)     - bV - envergadura da empenagem vertical [m]
%                       (5)     - SF - �rea total dos flapes [m�]
%                       (6)     - bF - envergadura total dos flapes [m]
%                       (7)     - deltaf - deflex�o dos flapes [deg]
%                       (8)     - dmtyre - di�metro do pneu - trem de pouso principal [m]
%                       (9)     - dntyre - di�metro do pneu - trem de pouso dianteiro [m]
%                       (10)    - nmgear - n�mero de unidades no trem de pouso principal
%                       (11)    - nmgear - n�mero de unidades no trem de pouso dianteiro
%                       (12)    - lmgear - comprimento da perna do trem de pouso principal [m]
%                       (13)    - lngear - comprimento da perna do trem de pouso dianteiro [m]
%                       (14)    - nmwheel - n�mero de pneus por trem principal 
%                       (15)    - nnwheel - n�mero de pneus por trem dianteiro
%                       (16)    - fwtype1 - tipo de asa: (1)=convencional / (2)=delta 
%                       (17)    - fwtype2 - tipo de aeronave: (1)=transporte / (2)=planador
%                       (18)    - fslats - posi��o dos slats: (1)=estendidos / (2)=recolhidos
%                       (19)    - fhtype - tipo de empenagem horizontal: (1)=aeronave de transporte / (2)=planador
%                       (20)    - fvtype - tipo de empenagem vertical: (1)=aeronave de transporte / (2)=planador
%                       (21)    - nslots - n�mero de slots no flape
%                       (22)    - fmgear - posi��o dos trens de pouso principais: (1)=estendidos / (2)=recolhidos
%                       (23)    - fngear - posi��o do trem de pouso dianteiro: (1)=estendido / (2)=recolhido
%                       (24)    - hprec - altitude no ponto de medi��o
%                       (25)    - disarec - temperatura no ponto de medi��o [�C]
%                   ENGPAR      - par�metros do motor
%                       (1)     - fanpr = raz�o de press�o no fan
%                       (2)     - opr = raz�o de press�o total do motor
%                       (3)     - bpr = raz�o de deriva��o do motor
%                       (4)     - maneted = percentual da tra��o m�xima (0 a 1)
%                       (5)     - diamfan = di�metro do fan do motor [m]
%                   maneted     - posi��o da manete de tra��o (1.0 = 100%)
%                   DISA        - varia��o da temperatura padr�o [�C]
%                   DMAX        - m�xima dist�ncia no c�lculo da trajet�ria [m]
%                   SW          - �rea alar [m�]
%                   bW          - envergadura [m]
%                   RH          - umidade relativa [%]
%                   dlat        - dist�ncia lateral [m]
%                   XA          - dist�ncia longitudinal [m]
%Dados de saida  : 
%                   SLEPNdB     - ru�do lateral da aeronave na decolagem [EPNdB]
%                   XApeak      - ponto ao longo da trajet�ria no qual o ru�do lateral tem m�xima intensidade [m]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-01-10    -
%2.0        Paulo Eduardo Cypriano      18-08-13    Otimiza��o de entradas


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [SLEPNdB XApeak] = sidelineEPNdB(timehistory,maneted,DISA,DMAX,RH,dlat,ACTGEO,SW,bW,ENGPAR,NEng)


%% CORPO DA FUN��O %%
%% C�lculo do ru�do lateral por aproxima��es sucessivas do ponto onde ele � mais intenso
% 1� aproxima��o (milhares de metros)
Dmax1               = DMAX;
Dmin1               = 0;
DD                  = 1000;
ncount              = (Dmax1-Dmin1)/DD+1;
XA                  = zeros(1,ncount);
SLnoise             = zeros(1,ncount);
for i=1:ncount
    XA(i)           = DD*(i-1)+Dmin1;
    SLnoise(i)      = takeoffEPNdB(timehistory,maneted,DISA,RH,dlat,XA(i),ACTGEO,SW,bW,ENGPAR,NEng);
end
[S1max,I1max]       = max(SLnoise);
% 2� aproxima��o (centenas de metros)
Dmax2               = DD*(I1max)+Dmin1;
Dmin2               = DD*(I1max-2)+Dmin1;
DD                  = 100;
ncount              = (Dmax2-Dmin2)/DD+1;
XA                  = zeros(1,ncount);
SLnoise             = zeros(1,ncount);
for i=1:ncount
    XA(i)           = DD*(i-1)+Dmin2;
    SLnoise(i)      = takeoffEPNdB(timehistory,maneted,DISA,RH,dlat,XA(i),ACTGEO,SW,bW,ENGPAR,NEng);
end
[S1max,I1max]       = max(SLnoise);
% 3� aproxima��o (dezenas de metros)
Dmax3               = DD*(I1max)+Dmin2;
Dmin3               = DD*(I1max-2)+Dmin2;
DD                  = 10;
ncount              = (Dmax3-Dmin3)/DD+1;
XA                  = zeros(1,ncount);
SLnoise             = zeros(1,ncount);
for i=1:ncount
    XA(i)           = DD*(i-1)+Dmin3;
    SLnoise(i)      = takeoffEPNdB(timehistory,maneted,DISA,RH,dlat,XA(i),ACTGEO,SW,bW,ENGPAR,NEng);
end
[S1max,I1max]       = max(SLnoise);
% 4� aproxima��o (metros)
Dmax4               = DD*(I1max)+Dmin3;
Dmin4               = DD*(I1max-2)+Dmin3;
DD                  = 1;
ncount              = (Dmax4-Dmin4)/DD+1;
XA                  = zeros(1,ncount);
SLnoise             = zeros(1,ncount);
for i=1:ncount
    XA(i)           = DD*(i-1)+Dmin4;
    SLnoise(i)      = takeoffEPNdB(timehistory,maneted,DISA,RH,dlat,XA(i),ACTGEO,SW,bW,ENGPAR,NEng);
end
[S1max,I1max]       = max(SLnoise);


%% SA�DA DOS DADOS %% 
SLEPNdB             = SLnoise(I1max);
XApeak              = XA(I1max);


%% FINAL DA FUN��O %%
end


%% REFERENCIAS BIBLIOGRAFICAS %%
%1 - SMITH, M.J.T - Aircraft Noise (1989)
%2 - ESDU77022 - Atmospheric properties