function [DISTALT]=MINALTDIST(D,lin);

DISTALT=9999;
n=size(D,2);
for j=1:n
     DIST=D(lin,j);
     if DIST~=0 && DIST<DISTALT 
        DISTALT=DIST;
     end
end    