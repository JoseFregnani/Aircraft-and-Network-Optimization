%% Defini��o da fun��o
% Estabelece fatores de conversao de unidades

%% Fatores de convers�o - Fatores s�o sempre multiplicativos
%% Dimensoes lineares
m2ft                = 1/0.3048;                                             % [m] para [ft]
ft2m                = 0.3048;                                               % [ft] para [m]
nm2m                = 1852;                                                 % [nm] para [m]
m2nm                = 1/1852;                                               % [m] para [nm]
nm2km               = 1.852;                                                % [nm] para [km]
km2nm               = 1/1.852;                                              % [km] para [nm]
in2m                = 0.0254;                                               % [in] para [m]
m2in                = 1/0.0254;                                             % [m] para [in]
%% Superficies
m22ft2              = m2ft^2;                                               % [m2] para [ft2]
ft22m2              = ft2m^2;                                               % [ft2] para [m2]
m22in2              = m2in^2;                                               % [m2] para [in2]
in22m2              = in2m^2;                                               % [in2] para [m2]
%% Volumes
m32ft3              = m2ft^3;                                               % [m3] para [ft3]
ft32m3              = ft2m^3;                                               % [ft3] para [m3]
%% Angulos
rad2deg             = 180/pi;                                               % [rad] para [deg]
degre2rad           = pi/180;                                               % [deg] para [rad]
%% Massa
lb2kg               = 1/2.2046;                                             % [lb] para [kg]
kg2lb               = 2.2046;                                               % [kg] para [lb]
kg2slug             = 0.068521766;                                          % [kg] para [slug]
slug2kg             = 1/0.068521766;                                        % [slug] para [kg]
%% Velocidade
ms2kt               = 1.943844;                                             % [m/s] para [kt]
kt2ms               = 1/1.943844;                                           % [kt] para [m/s]
ms2fts              = 1/0.3048;                                             % [m/s] para [ft/s]
fts2ms              = 0.3048;                                               % [ft/s] para [m/s]
ms2ftmin            = 196.850393701;                                        % [m/s] para [ft/min]
ftmin2ms            = 1/196.850393701;                                      % [ft/min] para [m/s]
kt2ftmin            = 101.268591426;                                        % [kt] para [ft/min]
ftmin2kt            = 1/101.268591426;                                      % [ft/min] para [kt]
ms2mph              = 2.236936292;                                          % [m/s] para [mph]                 
mph2ms              = 1/2.236936292;                                        % [mph] para [m/s]
%% Aceleracao
ms22fts2            = 1/0.3048;                                             % [m/s2] para [ft/s2]
fts22ms2            = 0.3048;                                               % [ft/s2] para [m/s2]
%% Forca
kgf2N               = 9.80665;                                              % [kgf] para [N]
N2kgf               = 1/9.80665;                                            % [N] para [kgf]
lbf2N               = 4.448221615;                                          % [lbf] para [N]
N2lbf               = 1/4.448221615;                                        % [N] para [lbf]
kgf2lbf             = 2.204622622;                                          % [kgf] para [lbf]
lbf2kgf             = 1/2.204622622;                                        % [lbf] para [kgf]
%% Densidade
kgm32slugft3        = 0.00194032;                                           % [kg/m3] para [slug/ft3]

%% Refer�ncias bibliogr�ficas
% 1 - ESDU