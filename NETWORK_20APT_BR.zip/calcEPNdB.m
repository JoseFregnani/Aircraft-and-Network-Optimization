%% DESCRI��O E AUTORIA %%
%calcEPNdB - Rotina para c�lculo do ru�do EPNdB
%autores  - Paulo Eduardo Cypriano da Silva Magalh�es
%
%Dados de entrada: 
%                   tempo       - linha do tempo [s]
%                   PNLT        - hist�rico de PNLT
%Dados de saida  : 
%                   EPNdB       - ru�do efetivamente percebido [EPNdB]

%Esta fun��o opera de acordo com os procedimentos de c�lculo indicados pelas refer�ncias bibliogr�ficas.
%Fundamentos te�ricos para o c�lculo podem ser encontrados nas refer�ncias bibliogr�ficas.


%% CONTROLE DE VERS�ES %%
%VERS�O     AUTOR                       DATA        DESCRI��O DAS MODIFICA��ES
%1.0        Paulo Eduardo Cypriano      21-10-09    -


%% NOMENCLATURA ADOTADA NO C�LCULO %%


%% DECLARA��O DA FUN��O %%
function [EPNdB] = calcEPNdB(tempo,PNLT)


%% CORPO DA FUN��O %%
PNLTM               = max(PNLT);                                            % Determina��o do PNLT m�ximo
PNLTL               = PNLTM-10;                                             % Determina��o do n�vel m�nimo a ser considerado
a1                  = max(size(PNLT));                                      % Determina��o das vari�veis de controle do c�lculo
dt                  = tempo(2)-tempo(1);                                    % Determina��o das vari�veis de controle do c�lculo
for i1=1:a1-1                                                               % Separa��o dos valores de PNLT que ser�o usados
    if PNLT(i1+1)>PNLTL && PNLT(i1)<PNLTL
        ind1        = i1+1;
    else
        ind1        = 1;
    end
    if PNLT(i1+1)<PNLTL && PNLT(i1)>PNLTL
        ind2        = i1+1;
    else
        ind2        = a1;
    end
end
% Somat�rio do ru�do
termo1              = 0;
for i1=ind1:ind2
    termo1          = termo1+dt*10^(PNLT(i1)/10);
end
D                   = 10*log10(0.1*termo1)-PNLTM-13;                        % Determina��o do fator de corre��o
EPNdB               = PNLTM+D;                                              % Determina��o de EPNdB


%% FINAL DA FUN��O %%
end