clc
clear all

mode=1;

DB_name={'airplane_3_77170039512_737288.dat','airplane_13_92220051407_737289.dat',...
         'airplane_14_92220047152_737289.dat','airplane_21_116190055196_737290.dat','airplane_25_90180045891_737290.dat'...
         'airplane_32_112220059399_737291.dat','airplane_36_101150045925_737291.dat','airplane_40_74183038461_737293.dat',...
         'airplane_41_80180039754_737294.dat','airplane_42_80180040300_737294.dat','airplane_43_80180039355_737294.dat',...
         'airplane_44_144180062766_737295.dat','airplane_45_144180064218_737295.dat','airplane_48_124190057146_737295.dat',...
         'airplane_49_84180041649_737295.dat','airplane_57_100160047689_737296.dat','airplane_60_105160049229_737296.dat',...
         'airplane_80_90190042454_737296.dat','airplane_81_174155068530_737298.dat','airplane_82_174160068601_737298.dat',...
         'airplane_86_104190049500_737298.dat','airplane_88_88160040677_737299.dat','airplane_92_110190050213_737299.dat',...
         'airplane_93_72180037256_737299.dat','airplane_94_50140024105_737303.dat','airplane_95_50140024224_737303.dat',...
         'airplane_96_50140025716_737303.dat','airplane_97_70150034555_737303.dat','airplane_98_70180035936_737303.dat',...
         'airplane_99_44140024044_737303.dat','airplane_101_110180047671_737303.dat','airplane_106_95160042056_737304.dat',...
         'airplane_107_100100045029_737304.dat','airplane_108_100100041380_737304.dat','airplane_111_120190056656_737305.dat',...
         'airplane_121_116220054624_737305.dat','airplane_200_60160031390_737306.dat','airplane_201_60160032344_737306.dat',...
         'airplane_205_60160031847_737307.dat','airplane_206_70160035002_737307.dat','airplane_501_75160042506_737292.dat',...
         'airplane_508_120180055735_737293.dat','airplane_514_126160060140_737294.dat','airplane_516_73180040188_737294.dat',...
         'airplane_527_133195058348_737295.dat','airplane_528_120190058750_737295.dat','airplane_552_130190058556_737299.dat',...
         'airplane_556_100180048101_737299.dat','airplane_558_115200052989_737299.dat'};

% PAX CAPACITY GROUP LIMIT     
%% paper
% LIM1=80;
% LIM2=90;
% LIM3=110;    
%% cluster analysis
LIM1=70;
LIM2=110;
LIM3=180;   
auto=0; % auto=1 choses limits ccording to the sample distribution

% 2D Airfoils parameters
r0      =[0.0153 0.0150 0.0150];
t_c     =[0.1228 0.1055 0.0982];
phi     =[-0.0799 -0.1025 -0.1553];
X_tcmax =[0.3738 0.3585 0.3590];
theta   =[0.0787 -0.0295 0.1000];
epsilon =[-0.0549 -0.2101 -0.0258];
Ycmax   =[-4.0000e-04 0.0185 0.0104];
YCtcmax =[-6.0000e-04 0.0028 0.0109];
X_Ycmax =[0.6188 0.7870 0.5567];
wTCmed  =0.1100;  
% initialize vector with airfoils coordinates
xutip   =zeros(1,51);
yutip   =zeros(1,51);
xltip   =zeros(1,51);
yltip   =zeros(1,51);
xukink  =zeros(1,51);
yukink  =zeros(1,51);
xlkink  =zeros(1,51);
ylkink  =zeros(1,51);
xuroot  =zeros(1,51);
yuroot  =zeros(1,51);
xlroot  =zeros(1,51);
ylroot  =zeros(1,51);        
     
n=size(DB_name,2); 

for i=1:n
       %
       filename=char(DB_name(i));       
       [Range,DOC,MMO,Ceiling, MTOW_kg, OEW_kg,MLW,...
         MZFW,PEng, PHT,PWing,slat,lco,ltail,lf,...
		 fus_w,fus_h,FUSELAGE_Dz_floor, FusSwet_m2,container_type,...
		 NSeat, NPax,NCorr,CabHeightm,AisleWidth,...
		 SEATwid,SeatPitch,fuselagefuelcapacity_kg,...
		 wS,wAR,wTR, Ccentro, Craiz, Cquebra,Cponta,...
		 iroot, ikink, itip, tcroot,tckink,tctip,...
		 wingb, yposeng, wingdi, xle, wSweepLE,...
		 wSweep14,wingSwet,bflap, posaileron, longtras,...
		 flap_area_m2, Flap_def_take, Flap_def_land,...
		 wingfuelcapacity_kg,arh, sweepLEht, crootht,...
		 ctipht, arv, sweepLEvt,crootvt, ctipvt,...
		 EnginLength_m, BPR, OPR, FANPR, DFAN, eTIT,...
		 DX_Eng, ESwet, DZ_Pylon,mlg,nlg,wlet_present,...
         SweepLE_winglet, AR_winglet, TR_winglet,...
		 CantAngle_wlet,Twist_wlet]= read_parameters(filename);
      %
        A(i).PEng=PEng;
        A(i).PHT=PHT;
        A(i).PWing=PWing;
        A(i).wlet_present=wlet_present;
        %
        A(i).RANGE=Range;
        A(i).DOCref=DOC;
        A(i).MMO=MMO; 
        A(i).VMO=340; 
        A(i).Ceiling=Ceiling;
        %
        Clmax=1.6;
        CLMAX=0.9*Clmax*cos(wSweep14/180*pi());
        A(i).CLMAX=CLMAX;
        A(i).CLMAX_TO=CLMAX+0.6;
        A(i).CLMAX_LD=CLMAX+1.2;
        %
        A(i).OEW=OEW_kg;
        A(i).MTOW=MTOW_kg;
        A(i).MLW=MLW;
        A(i).MZFW=MLW*0.98;
        WFC=wingfuelcapacity_kg(1,1);
        FFC=fuselagefuelcapacity_kg;
        MAXFUEL=WFC+FFC;
        A(i).MAXFUEL=MAXFUEL;
        %
        A(i).wS =wS;
        A(i).wSft2 =10.76*wS;
        A(i).wAR=wAR;
        A(i).wTR=wTR;
        A(i).wingb=wingb;
        A(i).wSweep14=wSweep14;
        A(i).wSweepLE=wSweepLE;
        A(i).wingSwet=wingSwet;
        A(i).wingdi=wingdi;
        A(i).wTwist=itip-iroot;
        A(i).Kink_semispan=yposeng;
        A(i).inc_root=iroot; 
        A(i).inc_kink=ikink; 
        A(i).inc_tip=itip; 
        A(i).tc_root=tcroot; 
        A(i).tc_kink=tckink; 
        A(i).tc_tip=tctip;        
        A(i).Ccentro=Ccentro;
        A(i).Craiz=Craiz;
        A(i).Cquebra=Cquebra;
        A(i).Cponta=Cponta;
        A(i).wMAC=(2/3)*Ccentro*(1+wTR+wTR^2)/(1+wTR);
        A(i).xle=xle;
        A(i).slat=slat;
        A(i).bflap=bflap;
        A(i).flap_area_m2=flap_area_m2;
        A(i).Flap_def_take=Flap_def_take;
        A(i).Flap_def_land=Flap_def_land;
        A(i).posaileron=posaileron;
        A(i).longtras=longtras;
        %
        A(i).VTarea=(arv*(ctipvt+crootvt)^2)/4;
        A(i).VTAR=arv;
        A(i).VTTR=ctipvt/crootvt;
        A(i).VTSweep=sweepLEvt;
        %
        A(i).HTarea=(arh*(ctipht+crootht)^2)/4;
        A(i).HTAR=arh;
        A(i).HTTR=ctipht/crootht;
        A(i).HTSweep=sweepLEht;
        %
        A(i).container_type=container_type;
        A(i).NPax=round(NPax);
        A(i).NCorr=round(NCorr);
        A(i).NSeat=round(NSeat);
        A(i).SeatPitch=SeatPitch;
        A(i).ncrew=5;
        A(i).AisleWidth=AisleWidth;
        A(i).CabHeightm=CabHeightm;    
        A(i).SEATwid=SEATwid; 
        %     
        A(i).lf=lf;
        A(i).lco=lco;
        A(i).ltail=ltail;
        A(i).widthratio=fus_w/fus_h; 
        A(i).fus_width=fus_w;
        A(i).FusDiam=(fus_w+fus_h)/2;
        A(i).fus_height=fus_h;
        A(i).FUSELAGE_Dz_floor=FUSELAGE_Dz_floor;
        A(i).FusSwet_m2=FusSwet_m2;
        %
        A(i).mlg=mlg;
        A(i).nlg=nlg;
        %
        %A(i).MAXRATE=(MTOW_kg/22000)*8895; 
        A(i).MAXRATE= 0.3264*MTOW_kg + 2134.8 %regression 
        A(i).T0=A(i).MAXRATE*0.95;        
        A(i).n=2; 
        A(i).nedebasa=1;
        A(i).ebypass=BPR;
        A(i).ediam=DFAN;
        A(i).efanpr=FANPR;
        A(i).eopr=OPR;
        A(i).eTIT=eTIT;
        A(i).EnginLength_m=EnginLength_m;        
        A(i).DX_Eng=DX_Eng;
        A(i).ESwet=ESwet;
        A(i).DZ_Pylon=DZ_Pylon;
        %
        A(i).SweepLE_winglet=SweepLE_winglet;
        A(i).AR_winglet=AR_winglet;
        A(i).TR_winglet=TR_winglet;
        A(i).CantAngle_wlet=CantAngle_wlet;
        A(i).Twist_wlet=Twist_wlet;
        %  
        A(i).Airp_SWET=wingSwet+FusSwet_m2;
                %
        A(i).r0=r0;
        A(i).t_c=t_c;
        A(i).phi=phi;
        A(i).X_tcmax=X_tcmax;
        A(i).theta=theta;
        A(i).epsilon=epsilon;
        A(i).Ycmax=Ycmax;
        A(i).YCtcmax=YCtcmax;
        A(i).X_Ycmax=X_Ycmax;
        A(i).wTCmed=wTCmed;
        %
        A(i).xutip=xutip;
        A(i).yutip=yutip;
        A(i).xltip=xltip;
        A(i).yltip=yltip;
        A(i).xukink=xukink;
        A(i).yukink=yukink;
        A(i).xlkink=xlkink;
        A(i).ylkink=ylkink;
        A(i).xuroot=xuroot;
        A(i).yuroot=yuroot;
        A(i).xlroot=xlroot;
        A(i).ylroot=ylroot;
        
end    

if mode==1
       % SELECTION USING PAX CAPACITY  
        MAXPAX=0;
        MINPAX=999;
        for i=1:n
           PAX=A(i).NPax;
           if PAX<=MINPAX
              MINPAX=round(PAX);
           end
           if PAX>=MAXPAX
              MAXPAX=round(PAX);
           end
        end 
        
        if auto==1
            LIM1=round(MINPAX+(MAXPAX-MINPAX)/3);
            LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3);
            LIM3=MAXPAX;
        else
            LIM1;
            LIM2;
            LIM3;
        end 
        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            PAX=A(i).NPax;
            if PAX<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(PAX>LIM1,PAX<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(PAX>LIM2,PAX<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end    
    
else  
        % SELECTION USING RANGE 
        MAXRANGE=0;
        MINRANGE=999;
        for i=1:n
           RANGE=A(i).RANGE;
           if RANGE<=MINRANGE
              MINRANGE=round(RANGE);
           end
           if RANGE>=MAXRANGE
              MAXRANGE=round(RANGE);
           end
        end   
        if auto==1
            LIM1=round(MINPAX+(MAXPAX-MINPAX)/3);
            LIM2=round(MINPAX+(MAXPAX-MINPAX)*2/3);
            LIM3=MAXPAX;
        else
            LIM1;
            LIM2;
            LIM3;
        end      
        k1=1;
        k2=1;
        k3=1;
        for i=1:n
            RANGE=A(i).RANGE;
            if RANGE<LIM1        
               A1(k1)=A(i);
               k1=k1+1;
            end
            if and(RANGE>LIM1,RANGE<=LIM2)
               A2(k2)=A(i);
               k2=k2+1;
            end   
            if and(RANGE>LIM2,RANGE<=LIM3)
               A3(k3)=A(i);        
               k3=k3+1;
            end               
        end  
end 

l1=size(A1,2);
l2=size(A2,2);
l3=size(A3,2);

filename = 'C:\Users\engfr\Desktop\MATLAB FILES\Perfo\NETWORK\HEADER.xlsx';
delete filename;
HEADER={'NPAX','OEW','MTOW','MLW','MZFW','MAXFUEL','RANGE','wS','wAR','wTR','wSweep14','wSwepLE','wSwet','wingdi',...
        'wTwist','Kink_semispan','inc_root','inc_kink','inc_tip','tc_root','tc_kink','tc_tip','Ccentro','Craiz','Cquebra',...
        'Cponta','wMAC','xle','slat','bflap','flap_area_m2','Flap_def_take','Flap_def_land','posaileron','longtras','CLMAX',...
        'CLMAX_TO','CLMAX_LD','VTarea','VTAR','VTTR','VTSweep','HTarea','HTAR','HTTR','HTSweep',' ','NCorr','NSeat','SeatPitch',...
        'ncrew','AisleWidth','CabHeightm','SEATwid','lf','lco','ltail','widthratio','fus_width','FusDiam','fus_height','FUSELAGE_Dz_floor',...
        'FusSwet_m2','MAXRATE','T0','n',' ',' ','nedebasa','ebypass','ediam','efanpr','eopr','eTIT','EnginLength_m','DX_Eng',...
        'ESwet','DZ_Pylon','SweepLE_winglet','AR_winglet','TR_winglet','CantAngle_wlet','Twist_wlet','Airp_SWET','MMO','VMO',...
        'Ceiling','PEng','PHT','PWing','wlet_present',' '};
xlswrite(filename,HEADER);

% SAVE ACFT DB#1
%
filename = 'C:\Users\engfr\Desktop\MATLAB FILES\Perfo\NETWORK\DB1.xlsx';
delete filename;
%
for i=1:l1;    
    LIN1 =[A1(i).NPax          A1(i).OEW A1(i).MTOW    A1(i).MLW             A1(i).MZFW      A1(i).MAXFUEL         A1(i).RANGE ];    
    LIN2 =[A1(i).wS            A1(i).wAR A1(i).wTR     A1(i).wSweep14        A1(i).wSweepLE  A1(i).wingSwet        A1(i).wingdi];
    LIN3 =[A1(i).wTwist        A1(i).Kink_semispan     A1(i).inc_root        A1(i).inc_kink  A1(i).inc_tip         A1(i).tc_root];
    LIN4 =[A1(i).tc_kink       A1(i).tc_tip            A1(i).Ccentro         A1(i).Craiz     A1(i).Cquebra         A1(i).Cponta];
    LIN5 =[A1(i).wMAC          A1(i).xle               A1(i).slat            A1(i).bflap     A1(i).flap_area_m2    A1(i).Flap_def_take];
    LIN6 =[A1(i).Flap_def_land A1(i).posaileron        A1(i).longtras        A1(i).CLMAX     A1(i).CLMAX_TO        A1(i).CLMAX_LD];      
    LIN7 =[A1(i).VTarea        A1(i).VTAR              A1(i).VTTR            A1(i).VTSweep   A1(i).HTarea          A1(i).HTAR];
    LIN8 =[A1(i).HTTR          A1(i).HTSweep           0                     A1(i).NCorr     A1(i).NSeat           A1(i).SeatPitch];
    LIN9 =[A1(i).ncrew         A1(i).AisleWidth        A1(i).CabHeightm      A1(i).SEATwid   A1(i).lf              A1(i).lco];
    LIN10=[A1(i).ltail         A1(i).widthratio        A1(i).fus_width       A1(i).FusDiam   A1(i).fus_height      A1(i).FUSELAGE_Dz_floor];
    LIN11=[A1(i).FusSwet_m2    A1(i).MAXRATE           A1(i).T0              A1(i).n         0                  0];
    LIN12=[A1(i).nedebasa      A1(i).ebypass           A1(i).ediam           A1(i).efanpr    A1(i).eopr            A1(i).eTIT];
    LIN13=[A1(i).EnginLength_m A1(i).DX_Eng            A1(i).ESwet           A1(i).DZ_Pylon  A1(i).SweepLE_winglet A1(i).AR_winglet];
    LIN14=[A1(i).TR_winglet    A1(i).CantAngle_wlet    A1(i).Twist_wlet      A1(i).Airp_SWET A1(i).MMO             A1(i).VMO]; 
    LIN15=[A1(i).Ceiling       A1(i).PEng              A1(i).PHT             A1(i).PWing     A1(i).wlet_present    0];
    LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8 LIN9 LIN10 LIN11 LIN12 LIN13 LIN14 LIN15];
    M1(i,:)=LIN;
end
% 
 xlswrite(filename,M1);
 
 
% SAVE ACFT DB#2
%
filename = 'C:\Users\engfr\Desktop\MATLAB FILES\Perfo\NETWORK\DB2.xlsx';
delete filename;
%
for i=1:l2;    
    LIN1 =[A2(i).NPax          A2(i).OEW A2(i).MTOW    A2(i).MLW             A2(i).MZFW      A2(i).MAXFUEL         A2(i).RANGE ];    
    LIN2 =[A2(i).wS            A2(i).wAR A2(i).wTR     A2(i).wSweep14        A2(i).wSweepLE  A2(i).wingSwet        A2(i).wingdi];
    LIN3 =[A2(i).wTwist        A2(i).Kink_semispan     A2(i).inc_root        A2(i).inc_kink  A2(i).inc_tip         A2(i).tc_root];
    LIN4 =[A2(i).tc_kink       A2(i).tc_tip            A2(i).Ccentro         A2(i).Craiz     A2(i).Cquebra         A2(i).Cponta];
    LIN5 =[A2(i).wMAC          A2(i).xle               A2(i).slat            A2(i).bflap     A2(i).flap_area_m2    A2(i).Flap_def_take];
    LIN6 =[A2(i).Flap_def_land A2(i).posaileron        A2(i).longtras        A2(i).CLMAX     A2(i).CLMAX_TO        A2(i).CLMAX_LD];      
    LIN7 =[A2(i).VTarea        A2(i).VTAR              A2(i).VTTR            A2(i).VTSweep   A2(i).HTarea          A2(i).HTAR];
    LIN8 =[A2(i).HTTR          A2(i).HTSweep           0                     A2(i).NCorr     A2(i).NSeat           A2(i).SeatPitch];
    LIN9 =[A2(i).ncrew         A2(i).AisleWidth        A2(i).CabHeightm      A2(i).SEATwid   A2(i).lf              A2(i).lco];
    LIN10=[A2(i).ltail         A2(i).widthratio        A2(i).fus_width       A2(i).FusDiam   A2(i).fus_height      A2(i).FUSELAGE_Dz_floor];
    LIN11=[A2(i).FusSwet_m2    A2(i).MAXRATE           A2(i).T0              A2(i).n         0                  0];
    LIN12=[A2(i).nedebasa      A2(i).ebypass           A2(i).ediam           A2(i).efanpr    A2(i).eopr            A2(i).eTIT];
    LIN13=[A2(i).EnginLength_m A2(i).DX_Eng            A2(i).ESwet           A2(i).DZ_Pylon  A2(i).SweepLE_winglet A2(i).AR_winglet];
    LIN14=[A2(i).TR_winglet    A2(i).CantAngle_wlet    A2(i).Twist_wlet      A2(i).Airp_SWET A2(i).MMO             A2(i).VMO]; 
    LIN15=[A2(i).Ceiling       A2(i).PEng              A2(i).PHT             A2(i).PWing     A2(i).wlet_present    0];
    LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8 LIN9 LIN10 LIN11 LIN12 LIN13 LIN14 LIN15];
    M2(i,:)=LIN;
end
% 
 xlswrite(filename,M2);
 
 % SAVE ACFT DB#3
%
filename = 'C:\Users\engfr\Desktop\MATLAB FILES\Perfo\NETWORK\DB3.xlsx';
delete filename;
%
for i=1:l3;    
    LIN1 =[A3(i).NPax          A3(i).OEW A3(i).MTOW    A3(i).MLW             A3(i).MZFW      A3(i).MAXFUEL         A3(i).RANGE ];    
    LIN2 =[A3(i).wS            A3(i).wAR A3(i).wTR     A3(i).wSweep14        A3(i).wSweepLE  A3(i).wingSwet        A3(i).wingdi];
    LIN3 =[A3(i).wTwist        A3(i).Kink_semispan     A3(i).inc_root        A3(i).inc_kink  A3(i).inc_tip         A3(i).tc_root];
    LIN4 =[A3(i).tc_kink       A3(i).tc_tip            A3(i).Ccentro         A3(i).Craiz     A3(i).Cquebra         A3(i).Cponta];
    LIN5 =[A3(i).wMAC          A3(i).xle               A3(i).slat            A3(i).bflap     A3(i).flap_area_m2    A3(i).Flap_def_take];
    LIN6 =[A3(i).Flap_def_land A3(i).posaileron        A3(i).longtras        A3(i).CLMAX     A3(i).CLMAX_TO        A3(i).CLMAX_LD];      
    LIN7 =[A3(i).VTarea        A3(i).VTAR              A3(i).VTTR            A3(i).VTSweep   A3(i).HTarea          A3(i).HTAR];
    LIN8 =[A3(i).HTTR          A3(i).HTSweep           0                     A3(i).NCorr     A3(i).NSeat           A3(i).SeatPitch];
    LIN9 =[A3(i).ncrew         A3(i).AisleWidth        A3(i).CabHeightm      A3(i).SEATwid   A3(i).lf              A3(i).lco];
    LIN10=[A3(i).ltail         A3(i).widthratio        A3(i).fus_width       A3(i).FusDiam   A3(i).fus_height      A3(i).FUSELAGE_Dz_floor];
    LIN11=[A3(i).FusSwet_m2    A3(i).MAXRATE           A3(i).T0              A3(i).n         0                  0];
    LIN12=[A3(i).nedebasa      A3(i).ebypass           A3(i).ediam           A3(i).efanpr    A3(i).eopr            A3(i).eTIT];
    LIN13=[A3(i).EnginLength_m A3(i).DX_Eng            A3(i).ESwet           A3(i).DZ_Pylon  A3(i).SweepLE_winglet A3(i).AR_winglet];
    LIN14=[A3(i).TR_winglet    A3(i).CantAngle_wlet    A3(i).Twist_wlet      A3(i).Airp_SWET A3(i).MMO             A3(i).VMO]; 
    LIN15=[A3(i).Ceiling       A3(i).PEng              A3(i).PHT             A3(i).PWing     A3(i).wlet_present    0];
    LIN=[LIN1 LIN2 LIN3 LIN4 LIN5 LIN6 LIN7 LIN8 LIN9 LIN10 LIN11 LIN12 LIN13 LIN14 LIN15];
    M3(i,:)=LIN;
end
% 
 xlswrite(filename,M3);

