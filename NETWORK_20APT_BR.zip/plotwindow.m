function plotwindow(lf,lco,ltail,FusDiam,hpiso)

eixoxe=FusDiam;
eixoye=FusDiam;

x1 = lco+2;
while x1 < (lf-ltail)
z1=hpiso + 1.2;
window_width  = 0.15;
window_height = 0.20;
teta=asin(z1/(eixoye*0.50));
y1=0.50*eixoxe*cos(teta);
plotwindowsingle(x1,y1,z1,eixoxe,eixoye,window_width,window_height)
x1=x1+0.80;
end




function plotwindowsingle(x1,y1,z1,eixoxe,eixoye,window_width,window_height)
% (x1,y1,z1) � a coordenada do canto superior esquerdo

x(1)=x1;
y(1)=y1;
z(1)=z1;

x(2)=x1;
z(2)=(z(1)-window_height/2);
teta=asin(z(2)/(eixoye*0.50));
y(2)=eixoxe*0.50*cos(teta);

x(3)=x(2);
z(3)=z(1)-window_height;
teta=asin(z(3)/(eixoye*0.50));
y(3)=eixoxe*0.50*cos(teta);

x(4) = x1+window_width;
y(4) = y(3);
z(4) = z(3);

x(5)  = x(4);
z(5)  = z(4) + window_height/2;
teta  = asin(z(5)/(eixoye*0.50));
y(5)  = eixoxe*0.50*cos(teta);

x(6) = x(4);
y(6) = y(1);
z(6) = z(1);

y(1:6)=y(1:6);
xpatch=[x(1),x(2), x(3); x(6), x(5), x(4)];
ypatch=[-y(1),-y(2), -y(3); -y(6), -y(5), -y(4)];
zpatch=[z(1),z(2), z(3); z(6), z(5), z(4)];

surface(xpatch,ypatch,zpatch,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y')
hold on
surface(xpatch,-ypatch,zpatch,'FaceLighting','gouraud','EdgeColor','none','FaceColor','y')
hold on
