function [X]=LOADPARETO()

ds=xlsread('C:\Users\engfr\Desktop\MATLAB FILES\Perfo\OPT_NETWORK\Pareto.xlsx');
n=size(ds,1)

for i=1:n
    X(i,1)=ds(i,7);
    X(i,2)=ds(i,8);
    X(i,3)=ds(i,9);
    X(i,4)=ds(i,10); 
    X(i,5)=ds(i,11);
    X(i,6)=ds(i,12);
    X(i,7)=ds(i,13);
    X(i,8)=ds(i,14);
    X(i,9)=ds(i,15);
    X(i,10)=ds(i,16);
    X(i,11)=ds(i,17);
    X(i,12)=ds(i,18);    
    X(i,13)=ds(i,19);
    X(i,14)=ds(i,20); 
    X(i,15)=ds(i,21);
    X(i,16)=ds(i,22);
    X(i,17)=ds(i,23);
    X(i,18)=ds(i,24);
    X(i,19)=ds(i,25);
    X(i,20)=ds(i,1);      
end
